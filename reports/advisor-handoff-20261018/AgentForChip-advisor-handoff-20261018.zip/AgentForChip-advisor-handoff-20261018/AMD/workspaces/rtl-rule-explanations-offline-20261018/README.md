# Offline Constraint Explanations

Independent successor of `D:/AMD/workspaces/rtl-diagnostic-guards-20261018`. This copy adds explanations to the diagnostic skill, a local knowledge graph, and offline validation. No model, network, EDA or cloud campaign was run. It does not edit DUT answers or update the sealed handoff.

Source of truth: `skills/rtl-diagnostic-reasoning/references/rules.json`. Each rule records condition, meaning, reason, counterexample, checks, scope and evidence limits. `build-rule-knowledge.mjs` compiles the graph and a short English skill, then updates only `rtl.00_diagnostic_reasoning` in this copy's registry. The other six entries and runtime sources are unchanged. Version `2.0.0` is locally reviewed guidance, not proof of model understanding or measured gain.

The graph is `knowledge/constraint-graph.json`. No graph server or retrieval tool was introduced. The Agent receives compiled summaries through its existing C skill selector, context builder and optional `retrieve_skill`; it does not automatically read the full graph or catalog. B remains skill-free. Guidance competes for the original 768-token soft budget and may displace another skill or be omitted if a request is too large.

Offline tests use synthetic observations, an explicitly estimated counter, mocked model/EDA routes in the Harness suite, and unchanged deterministic guards. They prove wiring and invariants, not model behavior. The old multiline plan-format restriction is documented, not fixed here.

Run from this directory with the existing local Node installation:

```powershell
node --import tsx/esm --test ./test-rule-knowledge.mjs
node --import tsx/esm --test ./test-repair-guards.mjs
node ./node_modules/vitest/vitest.mjs run --config ./vitest.config.ts
```

Output: `D:/AMD/output/rtl-rule-explanations-offline-20261018`. The builder is a one-time artifact generator and refuses to replace an existing graph/build receipt. Tests retain snapshots and fixtures for audit.

Legacy campaign/analysis scripts were copied with the preceding source for traceability and still refer to historical experiments. Do not run their prepare, preflight, models, selection, finalize or old delivery commands in this offline copy. They are not part of this change. A future real-model comparison requires a separately authorized and frozen experiment.

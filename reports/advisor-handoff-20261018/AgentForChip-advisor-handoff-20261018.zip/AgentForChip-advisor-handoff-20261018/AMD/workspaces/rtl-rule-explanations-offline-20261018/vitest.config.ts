import { defineConfig } from 'vitest/config'
import ts from 'typescript'
import { resolve } from 'node:path'
import { standardDecoratorPlugin, vitestExecArgv } from '../http-paired-20261016/harness/vitest.shared.ts'

const repo = 'D:/AMD/workspaces/http-paired-20261016/harness'
const paths = ts.readConfigFile(repo + '/tsconfig.base.json', ts.sys.readFile).config.compilerOptions.paths as Record<string, string[]>
export default defineConfig({
  root: 'D:/AMD/workspaces/rtl-rule-explanations-offline-20261018',
  plugins: [standardDecoratorPlugin()],
  resolve: { alias: Object.entries(paths).map(([key, values]) => ({ find: new RegExp('^' + key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '$'), replacement: resolve(repo, values[0]!) })) },
  test: { include: ['rtl-tools/tests/p10-model.spec.ts'], execArgv: vitestExecArgv, testTimeout: 30000 },
})

import assert from 'node:assert/strict'
import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { skillHash } from './rtl-tools/src/phase1/p09-context.ts'
import { hash } from './selection.mjs'

export const here = dirname(fileURLToPath(import.meta.url))
export const out = 'D:/AMD/output/rtl-rule-explanations-offline-20261018'
export const catalogPath = here + '/skills/rtl-diagnostic-reasoning/references/rules.json'
export const priorRegistry = 'D:/AMD/workspaces/rtl-diagnostic-guards-20261018/skill-registry/skills.validated.json'

export function compileGraph(catalog) {
  const skill = 'skill:rtl-diagnostic-reasoning'
  const nodes = [{ id: skill, type: 'skill', name: 'rtl-diagnostic-reasoning', entry: 'skills/rtl-diagnostic-reasoning/SKILL.md' }]
  const edges = []
  for (const rule of catalog.rules) {
    nodes.push({ id: rule.id, type: 'rule', rule, evidence_limit: 'Local source/log explanations and offline checks, not proven model understanding.' },
      { id: 'symptom:' + rule.id, type: 'symptom', aliases: rule.symptoms },
      { id: 'cause:' + rule.id, type: 'cause', explanation_zh: rule.why_zh },
      { id: 'check:' + rule.id, type: 'check', steps_zh: rule.checks_zh },
      { id: 'counterexample:' + rule.id, type: 'counterexample', explanation_zh: rule.counterexample_zh })
    edges.push({ from: 'symptom:' + rule.id, to: rule.id, type: 'routes_to' },
      { from: rule.id, to: skill, type: 'loaded_from' },
      { from: rule.id, to: 'cause:' + rule.id, type: 'explained_by' },
      { from: rule.id, to: 'check:' + rule.id, type: 'checked_by' },
      { from: rule.id, to: 'counterexample:' + rule.id, type: 'contrasted_with' })
    for (const id of rule.evidence_ids) edges.push({ from: rule.id, to: 'evidence:' + id, type: 'grounded_in' })
  }
  for (const evidence of catalog.evidence) nodes.push({ ...evidence, id: 'evidence:' + evidence.id, type: 'evidence' })
  return { schema: 'rtl-runtime-knowledge-v1', scope: 'LOCAL_EXPLANATIONS_NOT_PROVEN_MODEL_GAIN', source_catalog_sha256: hash(JSON.stringify(catalog)), nodes, edges }
}

export function compileSkill(catalog) {
  return '---\nname: rtl-diagnostic-reasoning\ndescription: Explain RTL rule violations and Host repair refusals before a constrained edit. Use for enum, fixed-interface, driver, anchor, replay or verification-state errors.\n---\n\n# Explain the Constraint\n\n' +
    'Use the first bound independent error and actual declarations. State the violated relation, a concrete change and how to check it, not private reasoning or a copied error. Failure alone does not prove non-understanding; distinguish language, contract, protocol, format and environment.\n\n' +
    catalog.rules.map(rule => '- ' + rule.compact).join('\n') +
    '\n\nDetailed meanings, counterexamples and limits: [references/rules.json](references/rules.json). The offline builder compiles these summaries into normal Agent guidance; it does not make the Agent read the full graph or learn new weights.\n'
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const catalog = JSON.parse(await readFile(catalogPath, 'utf8'))
  const graph = compileGraph(catalog), markdown = compileSkill(catalog)
  assert.equal(catalog.rules.length, 9)
  assert.doesNotMatch(markdown, /Prob\d+|q_in|out_always|1101/)
  await mkdir(here + '/knowledge', { recursive: true })
  await writeFile(here + '/knowledge/constraint-graph.json', JSON.stringify(graph, null, 2), { flag: 'wx' })
  await writeFile(here + '/skills/rtl-diagnostic-reasoning/SKILL.md', markdown)
  const root = here + '/skill-registry', evidenceRoot = root + '/evidence/offline-rule-explanations'
  await mkdir(evidenceRoot, { recursive: true })
  const records = []
  for (const [name, path] of [['rules.json', catalogPath], ['constraint-graph.json', here + '/knowledge/constraint-graph.json'],
    ['SKILL.md', here + '/skills/rtl-diagnostic-reasoning/SKILL.md'],
    ['prior-guard-tests.log', 'D:/AMD/output/rtl-diagnostic-guards-20261018/unit-guards-complete.log']]) {
    await copyFile(path, evidenceRoot + '/' + name)
    records.push({ path: 'evidence/offline-rule-explanations/' + name, sha256: hash(await readFile(path)) })
  }
  const entries = JSON.parse(await readFile(priorRegistry, 'utf8'))
  const previous = entries.find(entry => entry.id === 'rtl.00_diagnostic_reasoning')
  assert.ok(previous)
  const entry = { ...previous, version: '2.0.0', scope: 'Offline explanations of RTL and current Harness constraints',
    rule: markdown.split(/^---\s*$/m).slice(2).join('---').trim(),
    limitations: 'Offline source/log review only; not model understanding, measured gain or EDA proof. Full graph stays local; compiled summaries load normally.',
    source_cases: ['local-guarded-pair-20261018'], validation_records: records, content_hash: '' }
  entry.content_hash = skillHash(entry)
  const updated = entries.map(item => item.id === entry.id ? entry : item)
  await writeFile(root + '/skills.validated.json', JSON.stringify(updated, null, 2))
  const settings = { skillsFile: root + '/skills.validated.json', skillsSha256: hash(await readFile(root + '/skills.validated.json')) }
  const bundle = { status: 'OFFLINE_EXPLANATIONS_ONLY_NO_MODEL_GAIN_CLAIM', settings, updated_id: entry.id, previous_skill_registry: priorRegistry,
    integration: 'unchanged normal C selector/buildContext/retrieve_skill; no network, dynamic graph server or answer edits',
    source_catalog: catalogPath, graph: here + '/knowledge/constraint-graph.json', source_catalog_sha256: hash(await readFile(catalogPath)),
    old_other_six_entries_unchanged: true }
  await writeFile(root + '/bundle.json', JSON.stringify(bundle, null, 2))
  await writeFile(out + '/build.json', JSON.stringify({ ...bundle, rule_count: catalog.rules.length, nodes: graph.nodes.length, edges: graph.edges.length,
    model_calls: 0, network_calls: 0, runtime_source_changes: 0, rule_characters: entry.rule.length }, null, 2), { flag: 'wx' })
  console.log(JSON.stringify({ status: 'BUILT', rules: catalog.rules.length, nodes: graph.nodes.length, edges: graph.edges.length, rule_characters: entry.rule.length }))
}

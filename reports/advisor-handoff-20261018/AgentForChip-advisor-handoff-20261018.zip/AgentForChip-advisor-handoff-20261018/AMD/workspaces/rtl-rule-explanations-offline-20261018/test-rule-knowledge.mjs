import assert from 'node:assert/strict'
import test from 'node:test'
import { readFile, writeFile, mkdir, mkdtemp, cp } from 'node:fs/promises'
import { createRequire } from 'node:module'
import net from 'node:net'
import { buildContext, selectSkills } from './rtl-tools/src/phase1/p09-context.ts'
import { loadP09Skills, retrieveP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
import { enumConstraints, guardRepair, guardPlan } from './rtl-tools/src/phase1/p10-repair-guards.ts'
import { compactPlan } from './rtl-tools/src/phase1/p10-plan-format.ts'
import { here, out, compileGraph, compileSkill, priorRegistry } from './build-rule-knowledge.mjs'
import { hash } from './selection.mjs'

let networkAttempts = 0
globalThis.fetch = async () => { networkAttempts++; throw new Error('OFFLINE_ONLY') }
net.Socket.prototype.connect = function () { networkAttempts++; throw new Error('OFFLINE_ONLY') }
const json = async path => JSON.parse(await readFile(path, 'utf8'))
const catalog = await json(here + '/skills/rtl-diagnostic-reasoning/references/rules.json')
const graph = await json(here + '/knowledge/constraint-graph.json')
const bundle = await json(here + '/skill-registry/bundle.json')
const settings = { variant: 'C', ...bundle.settings }
const entries = await loadP09Skills(settings), prior = await json(priorRegistry)
const id = bundle.updated_id, rule = entries.find(e => e.id === id)
const limits = { window: 8192, output: 2048, margin: 1024, feedback: 2048, ledger: 512, skills: 768, sourceWarning: 3072 }
const counter = { quality: 'estimated', identity: { implementation: 'offline-byte-div-4-NOT-a-production-tokenizer' },
  count: async view => Math.ceil(Buffer.byteLength(view.system + view.prompt) / 4) }
const iface = { top: 'TopModule', ports: [{ name: 'a', direction: 'input', width: 1, signed: false }, { name: 'q', direction: 'output', width: 1, signed: false }] }
const source = 'module TopModule(input a, output q); assign q=a; endmodule'
const input = (variant_id = 'C', kind = 'type_or_port') => ({
  task: { id: 'offline-generic-cell', spec: 'Copy input a to output q.', interface: iface, constraints: 'Fixed one-bit interface.' },
  sample_id: 'offline-only', variant_id, purpose: 'repair', edit_protocol: 'exact-replacements', tool_mode: true, pending_verification: false,
  current: { source, source_sha256: hash(source), revision_id: 'revision-offline' },
  binding: { source_sha256: hash(source), revision_id: 'revision-offline', verification_key: 'a'.repeat(64) }, ledger: [],
  feedback: { schema_version: '1.4', evidence_kind: 'live_verification', original_run: 'SYNTHETIC_NOT_AN_EDA_RUN',
    stages: [{ stage: 'compile', status: 'FAIL', complete: true, process_clean: true, verdict: { checks: null, mismatches: null },
      diagnostics: [{ severity: 'ERROR', kind, origin: 'dut', message_id: 'OFFLINE_FIXTURE', line: 1, message: 'Synthetic diagnostic for context routing.' }] }] }
})
const build = (data, budget = limits, loader = () => loadP09Skills(settings)) => buildContext(data, budget, counter, new AbortController().signal, loader)
const snapshot = async (name, data) => {
  try { await writeFile(out + '/' + name, JSON.stringify(data, null, 2), { flag: 'wx' }) }
  catch (error) { if (error.code !== 'EEXIST') throw error; assert.deepEqual(await json(out + '/' + name), data) }
}

test('graph and skill are deterministic products of the same local explanations', async () => {
  assert.deepEqual(graph, compileGraph(catalog))
  assert.equal(await readFile(here + '/skills/rtl-diagnostic-reasoning/SKILL.md', 'utf8'), compileSkill(catalog))
  const nodes = new Set(graph.nodes.map(n => n.id))
  assert.equal(nodes.size, graph.nodes.length)
  for (const edge of graph.edges) assert.ok(nodes.has(edge.from) && nodes.has(edge.to))
  for (const item of catalog.rules) {
    for (const relation of ['routes_to', 'explained_by', 'checked_by', 'contrasted_with', 'grounded_in']) {
      assert.ok(graph.edges.some(e => e.type === relation && (e.from === item.id || e.to === item.id)))
    }
  }
})

test('local source/log evidence exists and full graph stays outside model guidance', async () => {
  for (const item of catalog.evidence) await readFile(item.path)
  assert.equal(catalog.rules.length, 9)
  assert.doesNotMatch(rule.rule, /Prob\d+|q_in|out_always|1101|API_KEY|PRIVATE KEY/)
  assert.ok(rule.rule.length < 2300)
  assert.equal(rule.rule, compileSkill(catalog).split(/^---\s*$/m).slice(2).join('---').trim())
})

test('frontmatter and references validate with the already installed YAML parser', async () => {
  const markdown = await readFile(here + '/skills/rtl-diagnostic-reasoning/SKILL.md', 'utf8')
  const yaml = createRequire(import.meta.url)('js-yaml')
  const front = yaml.load(/^---\n([\s\S]*?)\n---/.exec(markdown)[1])
  assert.equal(front.name, 'rtl-diagnostic-reasoning')
  assert.deepEqual(Object.keys(front).sort(), ['description', 'name'])
  assert.equal(typeof front.description, 'string')
  assert.ok(front.description.length <= 1024)
  for (const link of markdown.matchAll(/\]\(([^)]+)\)/g)) await readFile(here + '/skills/rtl-diagnostic-reasoning/' + link[1])
})

test('the six other skills remain identical and all original diagnostic routes reach the update', () => {
  assert.equal(entries.length, 7)
  assert.deepEqual(entries.filter(e => e.id !== id), prior.filter(e => e.id !== id))
  for (const tag of rule.trigger_tags) assert.ok(selectSkills(entries, [tag]).some(e => e.id === id))
  assert.equal(rule.version, '2.0.0')
})

test('C loads the compiled explanations through normal context and retrieve_skill', async () => {
  const data = input(), view = await build(data), prompt = JSON.parse(view.prompt)
  assert.ok(prompt.guidance.some(e => e.id === id && e.rule === rule.rule))
  assert.equal(prompt.current.source, source)
  assert.equal(view.audit.count_quality, 'estimated')
  assert.ok(view.audit.tokens <= view.audit.budget)
  const retrieval = await retrieveP09Skills(settings, data.feedback)
  assert.deepEqual(retrieval.skills.map(e => e.id), selectSkills(entries, ['type_or_port']).map(e => e.id))
  assert.equal(retrieval.skills.find(e => e.id === id).rule, rule.rule)
  await snapshot('request-on.json', { provenance: 'OFFLINE_CONTEXT_ONLY_NO_MODEL_OR_EDA_CALL', view })
})

test('A/B never load rule storage and skill ON/OFF leave trusted core identical', async () => {
  const on = await build(input())
  for (const variant of ['A', 'B']) {
    const off = await build(input(variant), limits, async () => { throw new Error('OFF_MUST_NOT_READ') })
    assert.equal(JSON.parse(off.prompt).guidance.length, 0)
    assert.equal(off.audit.core_sha256, on.audit.core_sha256)
    assert.equal((await loadP09Skills({ variant, skillsFile: 'missing', skillsSha256: 'wrong' })).length, 0)
    await snapshot('request-' + variant.toLowerCase() + '.json', { provenance: 'OFFLINE_CONTEXT_ONLY_NO_MODEL_OR_EDA_CALL', view: off })
  }
})

test('compressed context preserves concrete rejection facts and the new explanations', async () => {
  const rows = []
  for (const observation of [
    { error: 'ENUM_CONSTRAINT_REJECTED', details: [{ code: 'ENUM_CAPACITY', width: 1, members: 3 }] },
    { error: 'PATCH_ANCHOR_NOT_UNIQUE', details: { replacement_index: 2, kind: 'ambiguous', occurrences: 2, lines: [3, 6] } },
    { error: 'VERIFICATION_REQUEST_REJECTED', expected: { revision_id: 'revision-offline', pending_verification: false } }
  ]) {
    const data = { ...input(), core_only: true, previous_tool_result: { tool: 'edit_dut', accepted: false, observation } }
    const view = await build(data), prompt = JSON.parse(view.prompt)
    assert.deepEqual(prompt.previous_tool_result, data.previous_tool_result)
    assert.ok(prompt.guidance.some(e => e.id === id && e.rule === rule.rule))
    rows.push({ view })
  }
  await snapshot('compressed-rejections.json', { provenance: 'SYNTHETIC_OBSERVATIONS_NOT_REAL_MODEL_RECOVERY', rows })
})

test('skill budgets remain enforced instead of forcing guidance into an overfull request', async () => {
  const view = await build(input(), { ...limits, skills: 32 })
  assert.equal(JSON.parse(view.prompt).guidance.length, 0)
  assert.ok(view.audit.omissions.some(item => item.startsWith('skill:')))
})

test('pending candidate receives no stale diagnostic skill selection', async () => {
  const data = { ...input(), binding: null, feedback: null, pending_verification: true }
  assert.equal(JSON.parse((await build(data)).prompt).guidance.length, 0)
  assert.equal((await retrieveP09Skills(settings, null)).skills.length, 0)
})

test('enum counterexample and positive example agree with the bounded offline checker', () => {
  for (const values of ["A=1'b0,B=1'b1,C=1'b0", "A=1'b0,B=1'b1,C=1'b1"]) {
    const issues = enumConstraints('typedef enum logic [0:0] {' + values + '} mode_t;').issues
    assert.ok(issues.some(i => i.code === 'ENUM_CAPACITY'))
    assert.ok(issues.some(i => i.code === 'ENUM_DUPLICATE'))
  }
  assert.equal(enumConstraints("typedef enum logic [1:0] {A=2'd0,B=2'd1,C=2'd2} mode_t;").issues.length, 0)
})

test('port-changing workaround is rejected while a legal declaration change is accepted', () => {
  assert.throws(() => guardRepair(source.replace('input a', 'input [2:0] a'), source, iface), error => error.details[0].code === 'FIXED_PORT')
  assert.equal(guardRepair(source.replace('output q', 'output logic q'), source, iface).interface_checked, true)
})

test('a before-equals-after or comment-only plan is not a substantive repair', () => {
  const plan = after => JSON.stringify({ cause: 'Generic fixture.', changes: [{ before: 'q=a;', after }], checks: ['Check the output.'] })
  assert.throws(() => guardPlan(plan('q=a;'), source, iface), /REPEATED_CANDIDATE/)
  assert.throws(() => guardPlan(plan('q=a; /* explanation only */'), source, iface), /REPEATED_CANDIDATE/)
})

test('documented format restriction is not silently fixed or confused with HDL verification', () => {
  const plan = before => JSON.stringify({ cause: 'A short diagnosis.', changes: [{ before, after: 'output logic q' }], checks: ['Run EDA after edit.'] })
  assert.doesNotThrow(() => compactPlan(plan('output q'), true))
  assert.throws(() => compactPlan(plan('output\nq'), true), /PLANNER_PLAN_INVALID/)
  assert.throws(() => compactPlan(plan('a'.repeat(201)), true), /PLANNER_PLAN_INVALID/)
})

test('tampered graph evidence prevents loading rather than silently injecting changed guidance', async () => {
  await mkdir(out + '/tamper-tests', { recursive: true })
  const root = await mkdtemp(out + '/tamper-tests/registry-')
  await cp(here + '/skill-registry', root, { recursive: true })
  const path = root + '/evidence/offline-rule-explanations/constraint-graph.json'
  await writeFile(path, (await readFile(path, 'utf8')) + ' ')
  await assert.rejects(loadP09Skills({ ...settings, skillsFile: root + '/skills.validated.json' }), /SKILL_EVIDENCE_INVALID/)
})

test('all tests remain offline; no claim of model understanding is derived', async () => {
  assert.equal(networkAttempts, 0)
  await snapshot('offline-validation.json', { status: 'PASS', model_calls: 0, network_attempts: networkAttempts, eda_calls: 0,
    counter_quality: 'estimated_NOT_a_model_tokenizer', runtime_sources_changed: false, other_six_skills_unchanged: true,
    graph_rules: 9, graph_nodes: graph.nodes.length, graph_edges: graph.edges.length, compiled_rule_characters: rule.rule.length,
    normal_C_route: true, AB_skill_leakage: 0, compressed_rejection_facts_preserved: true,
    real_model_understanding_tested: false, real_model_gain_tested: false, weights_or_training_changed: false })
})

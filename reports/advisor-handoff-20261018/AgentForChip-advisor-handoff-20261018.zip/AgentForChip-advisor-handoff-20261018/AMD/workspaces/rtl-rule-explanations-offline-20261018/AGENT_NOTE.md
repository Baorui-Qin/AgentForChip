# Offline Scope and Evidence

Explain constraints offline rather than equating every refusal with lack of understanding. Separate language legality, fixed task contract, Host action protocol, current Host format and environment. Describe a violated relation and a falsifiable check; do not request hidden chain-of-thought or treat copied diagnostics as a coherent repair.

This copy changes the diagnostic skill/catalog/registry and adds a knowledge graph. Runtime source, model weights, original budgets and refusal policies are unchanged. The full graph remains an offline source for compiled guidance, not a newly connected graph database. The other six skill entries remain identical.

Validate C/AB isolation, compressed rejection facts, evidence hashes, bounded known-form examples and preserved source. Estimated token counts are test doubles, not production tokenizer receipts. Mocked model/EDA outputs must never be counted as genuine repairs or improvements.

Preserve original uncommitted changes, previous source/results and sealed handoff. No network, cloud/API calls or new model score claims. Do not run inherited campaign scripts that still target prior experiments.

import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { inventory, hash } from './selection.mjs'
import { here, out, priorRegistry, compileGraph, compileSkill } from './build-rule-knowledge.mjs'
import { loadP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'

const json = async path => JSON.parse(await readFile(path, 'utf8'))
const before = await inventory('D:/AMD/workspaces/rtl-diagnostic-guards-20261018/rtl-tools/src')
const after = await inventory(here + '/rtl-tools/src')
const prefix = path => path.slice(path.indexOf('/rtl-tools/src/'))
assert.deepEqual(Object.fromEntries(Object.entries(after).map(([p, h]) => [prefix(p), h])), Object.fromEntries(Object.entries(before).map(([p, h]) => [prefix(p), h])))
const bundle = await json(here + '/skill-registry/bundle.json')
const entries = await loadP09Skills({ variant: 'C', ...bundle.settings }), prior = await json(priorRegistry)
assert.deepEqual(entries.filter(e => e.id !== bundle.updated_id), prior.filter(e => e.id !== bundle.updated_id))
const catalog = await json(here + '/skills/rtl-diagnostic-reasoning/references/rules.json')
assert.deepEqual(await json(here + '/knowledge/constraint-graph.json'), compileGraph(catalog))
assert.equal(await readFile(here + '/skills/rtl-diagnostic-reasoning/SKILL.md', 'utf8'), compileSkill(catalog))
assert.match(await readFile(out + '/offline-tests.log', 'utf8'), /pass 15\b/)
assert.match(await readFile(out + '/guard-regressions.log', 'utf8'), /pass 19\b/)
assert.match(await readFile(out + '/harness-tests-host.log', 'utf8'), /Tests\s+90 passed/)
assert.equal((await json(out + '/preservation.json')).status, 'PASS')
assert.equal((await json(out + '/history-preservation.json')).status, 'PASS')
const validation = await json(out + '/offline-validation.json')
assert.equal(validation.model_calls, 0); assert.equal(validation.network_attempts, 0)
let links = 0
for (const match of (await readFile(out + '/REPORT.zh.md', 'utf8')).matchAll(/\]\(([^)]+)\)/g)) {
  if (match[1] !== out + '/delivery-verification.json') await readFile(match[1])
  links++
}
const paths = [here + '/skills/rtl-diagnostic-reasoning/references/rules.json', here + '/skills/rtl-diagnostic-reasoning/SKILL.md',
  here + '/knowledge/constraint-graph.json', here + '/skill-registry/skills.validated.json', here + '/skill-registry/bundle.json',
  here + '/build-rule-knowledge.mjs', here + '/test-rule-knowledge.mjs', out + '/REPORT.zh.md']
const receipt = { status: 'OFFLINE_EVIDENCE_AUDIT_PASS', model_calls: 0, cloud_calls: 0, real_eda_calls: 0,
  runtime_source_files_unchanged: Object.keys(after).length, focused_tests_passed: 124, new_tests_passed: 15,
  rules: 9, graph_nodes: 51, graph_edges: 58, skill_version: '2.0.0', other_six_skills_unchanged: true,
  original_and_previous_results_preserved: true, handoff_updated: false, graph_runtime_server_added: false,
  integration: 'compiled explanations via unchanged normal C skill routes; AB no skills',
  production_tokenizer_verified: false, real_model_understanding_or_gain_verified: false,
  known_host_format_restriction_fixed: false, document_links_checked: links,
  files: Object.fromEntries(await Promise.all(paths.map(async path => [path, hash(await readFile(path))]))) }
await writeFile(out + '/delivery-verification.json', JSON.stringify(receipt, null, 2), { flag: 'wx' })
console.log(JSON.stringify(receipt))

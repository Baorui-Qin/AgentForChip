"""Expose all complete and rejected planner outputs separately from transport success."""
from collections import Counter
import csv
import json
from pathlib import Path

OUT = Path('D:/AMD/output/rtl-diagnostic-guards-20261018')


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


rows = []
for model in load(OUT / 'model-output-index.json'):
    if model['phase'] != 'plan':
        continue
    directory = Path(model['directory'])
    validation = load(directory / 'plan-validation.json')
    record = load(directory / 'model.json')
    rows.append({'task': model['task'], 'arm': model['arm'], 'request_sha256': model['request_sha256'],
        'valid_compact_json': validation['valid'], 'truncated': validation['truncated'], 'recovery': validation['recovery'],
        'raw_chars': len(record['content']), 'completion_tokens': record['usage']['completion_tokens'],
        'raw_output_sha256': validation['raw_output_sha256'], 'canonical_plan_sha256': validation['canonical_plan_sha256'],
        'record': str(directory / 'model.json'), 'validation_file': str(directory / 'plan-validation.json'),
        'completed_binding': (directory.parent / 'plan.json').exists()})
for extension in ('json', 'csv'):
    with (OUT / ('planner-validation-index.' + extension)).open('x', encoding='utf-8-sig' if extension == 'csv' else 'utf-8', newline='') as stream:
        if extension == 'json':
            json.dump(rows, stream, ensure_ascii=False, indent=2)
        elif rows:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
print(json.dumps({'planner_attempts': len(rows), 'valid': sum(row['valid_compact_json'] for row in rows),
    'truncated': sum(row['truncated'] for row in rows), 'recovery_attempts': sum(row['recovery'] for row in rows),
    'by_arm': dict(Counter(row['arm'] for row in rows))}))

/** Off-target public-spec fixtures; no seven-task candidates or reference solutions. */
const prefix = 'module TopModule(input wire clk, input wire select, input wire bit_a, input wire bit_b, output logic value);\n'
const tb = 'module tb; reg clk=0, select, bit_a, bit_b; wire value; integer i, mismatches=0; TopModule dut(clk,select,bit_a,bit_b,value); initial begin for(i=0;i<8;i=i+1) begin {select,bit_a,bit_b}=i; #1; clk=1; #1; if(value !== (select ? bit_b : bit_a)) mismatches=mismatches+1; clk=0; #1; end $display("CAPABILITY_CHECKS=8 MISMATCHES=%0d",mismatches); $finish; end endmodule'

/** Source span oracle is used only after the model response, never in its request. */
export const capabilityFixtures = [
  { id: 'ControlComma', spec: 'On each positive clock edge, store bit_b when select is 1, otherwise store bit_a. Preserve the given one-bit ports.',
    source: prefix + 'always @(posedge clk) begin\n if (select) value, <= bit_b;\n else value <= bit_a;\nend\nendmodule\n',
    allowed: ['value, <= bit_b'], causeWords: /comma|syntax|lvalue/i, tb },
  { id: 'ControlEnum', spec: 'Use a typed state register: reset is not required; the selected input becomes the output on the next positive clock edge. The combinational state alias and state register must have consistent enum typing.',
    source: prefix + "typedef enum logic [1:0] {LOW=2'd0, HIGH=2'd1} level_t;\nlevel_t current_level;\nlogic [1:0] stored_level;\nassign current_level = stored_level;\nalways @(posedge clk) stored_level <= (select ? bit_b : bit_a) ? HIGH : LOW;\nalways_comb value = (current_level == HIGH);\nendmodule\n",
    allowed: ['logic [1:0] stored_level;', 'assign current_level = stored_level;'], causeWords: /enum|type|vector/i, tb },
  { id: 'ControlScalar', spec: 'Store bit_b when select is 1, otherwise store the scalar bit_a, at each positive clock edge. Both inputs and the output are one bit; this is one storage cell, not a parent vector.',
    source: prefix + 'always @(posedge clk) begin\n if (select) value <= bit_b;\n else value <= bit_a[2];\nend\nendmodule\n',
    allowed: ['bit_a[2]'], causeWords: /scalar|index|array|one.bit/i, tb },
]

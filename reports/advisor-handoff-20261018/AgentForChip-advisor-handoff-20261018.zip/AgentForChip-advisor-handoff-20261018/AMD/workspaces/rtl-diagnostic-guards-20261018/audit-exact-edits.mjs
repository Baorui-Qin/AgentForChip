import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { exactEdit } from './rtl-tools/src/phase1/p10-exact-edit.ts'
import { sourceLocations, planLocation } from './rtl-tools/src/phase1/p10-grounding.ts'
import { output, taskIds, hash } from './selection.mjs'

const json = async path => JSON.parse(await readFile(path, 'utf8'))
const models = await json(output + '/model-output-index.json'), calls = await json(output + '/call-index.json')
const rows = [], citations = []
for (const call of calls.filter(row => row.provider === 'cloud-coder')) {
  const model = models.find(row => row.request_sha256 === call.request_sha256)
  const result = await json(model.directory + '/model.json'), input = await json(model.directory + '/context.json')
  const tools = result.message?.content.filter(b => b.type === 'tool-call') ?? []
  if (tools.length !== 1 || tools[0].name !== 'edit_dut') continue
  const taskResult = await json(output + '/campaign/arms/' + call.arm + '/compare-' + call.task + '/result.json')
  const action = taskResult.actions.find(a => a.model_run === model.directory)
  let materialized = null, rejected = null
  try { materialized = exactEdit(tools[0].arguments, input.current.source, input.current.revision_id) }
  catch (error) { rejected = error.message }
  if (action?.accepted) {
    assert.ok(materialized)
    const revision = taskResult.revisions.find(r => r.revision === action.revision)
    assert.equal(await readFile(revision.directory + '/solution.sv', 'utf8'), materialized.source)
    assert.equal(hash(materialized.source), revision.sha256)
    assert.deepEqual(action.observation.exact_patch.spans, materialized.spans)
  }
  rows.push({ task: call.task, arm: call.arm, model_run: model.directory, action_accepted: action?.accepted ?? false,
    patch_applied_exactly: !!action?.accepted, untouched_bytes_preserved: materialized?.untouched_bytes_preserved ?? null,
    replacement_count: materialized?.spans.length ?? null, replaced_original_chars: materialized?.spans.reduce((n, s) => n + s.before.length, 0) ?? null,
    replacement_chars: materialized?.spans.reduce((n, s) => n + s.after.length, 0) ?? null,
    original_source_chars: input.current.source.length, materialization_error: rejected, host_error: action?.observation.error ?? null })
}
for (const call of calls.filter(row => row.provider === 'cloud-thinker')) {
  const model = models.find(row => row.request_sha256 === call.request_sha256), record = await json(model.directory + '/grounding-validation.json')
  if (record.location?.matched) assert.equal(record.location.semantics_verified, false)
  citations.push({ task: call.task, arm: call.arm, directory: model.directory, ...record })
}
const result = { status: 'PASS', scope: 'literal source citation and model-authored exact-patch materialization, not semantic correctness or globally minimal repair proof',
  question_tasks: taskIds.length, accepted_patches_checked: rows.filter(r => r.action_accepted).length,
  attempts: rows, planner_citations: citations, direct_host_answer_rewrites: 0 }
await writeFile(output + '/exact-edit-grounding-audit.json', JSON.stringify(result, null, 2), { flag: 'wx' })
console.log(JSON.stringify({ accepted_patches_checked: result.accepted_patches_checked, planner_calls_checked: citations.length }))

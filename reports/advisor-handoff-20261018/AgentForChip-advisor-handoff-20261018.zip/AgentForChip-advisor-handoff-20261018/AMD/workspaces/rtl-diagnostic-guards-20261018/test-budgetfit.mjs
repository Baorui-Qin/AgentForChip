import assert from 'node:assert/strict'
import test from 'node:test'
import { readFile, writeFile } from 'node:fs/promises'
import { compactPlan, plannerFormat } from './rtl-tools/src/phase1/p10-plan-format.ts'
import { buildContext } from './rtl-tools/src/phase1/p09-context.ts'
import { buildContext as oldBuild } from '../rtl-recovery-ablation-20261017/rtl-tools/src/phase1/p09-context.ts'
import { loadP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
import { hash, output } from './selection.mjs'

const json = async path => JSON.parse(await readFile(path, 'utf8'))
const base = (await json('D:/AMD/output/rtl-recovery-ablation-20261017/skills-unit-request-snapshot.json')).input
const bundle = await json(new URL('./skill-registry/bundle.json', import.meta.url))
const settings = { ...await json('D:/AMD/output/rtl-recovery-ablation-20261017/campaign/arms/on/p09.json'), ...bundle.settings }
const counter = { quality: 'estimated', identity: { implementation: 'explicit-keyless-unit-counter-not-native-model-count' },
  count: async view => Math.ceil(Buffer.byteLength(view.system + view.prompt) / 4) }
const build = input => buildContext(input, settings.limits, counter, new AbortController().signal, () => loadP09Skills(settings))
const plan = { cause: 'The enum repeats an encoding.', changes: ['Use unique values and a matching enum storage type.'], checks: ['Reset and all transitions.'] }
const withPlan = text => ({ ...structuredClone(base), planning: { task_id: base.task.id, source_sha256: base.current.source_sha256,
  feedback_sha256: hash(JSON.stringify(base.feedback)), plan_sha256: hash(text), text, directory: 'synthetic-plan-provenance' } })

test('normalizes only a complete compact plan, retaining its claims', () => {
  assert.equal(compactPlan(JSON.stringify(plan, null, 2)), JSON.stringify(plan))
  assert.match(plannerFormat, /1200 characters/)
})
for (const [name, bad] of [
  ['partial JSON', '{"cause":'], ['missing field', JSON.stringify({ cause: 'x', changes: ['y'] })],
  ['extra field', JSON.stringify({ ...plan, verdict: 'PASS' })], ['long cause', JSON.stringify({ ...plan, cause: 'x'.repeat(161) })],
  ['long edit', JSON.stringify({ ...plan, changes: ['x'.repeat(201)] })], ['empty edits', JSON.stringify({ ...plan, changes: [] })],
  ['too many edits', JSON.stringify({ ...plan, changes: ['1','2','3','4'] })], ['empty check', JSON.stringify({ ...plan, checks: [' '] })],
  ['too many checks', JSON.stringify({ ...plan, checks: ['1','2','3'] })], ['Markdown', '```json\n' + JSON.stringify(plan) + '\n```'],
  ['multiline content', JSON.stringify({ ...plan, changes: ['one\ntwo'] })], ['oversized output', ' '.repeat(1201) + JSON.stringify(plan)],
]) test('rejects ' + name + ' without clipping a draft into an accepted plan', () => assert.throws(() => compactPlan(bad), /PLANNER_PLAN_INVALID/))

test('keeps a fitting plan and all mandatory current evidence', async () => {
  const input = withPlan(JSON.stringify(plan)), view = await build(input), payload = JSON.parse(view.prompt)
  assert.equal(payload.planning.text, input.planning.text)
  assert.deepEqual(payload.current, input.current)
  assert.equal(payload.verification_key, input.binding.verification_key)
  assert.ok(payload.observed.errors.length)
})

test('drops verbose planning before skills, preserving full source, evidence and plan identity', async () => {
  const input = { ...withPlan('Repeated fallible planning. '.repeat(1000)), core_only: true }, before = structuredClone(input)
  await assert.rejects(oldBuild(input, settings.limits, counter, new AbortController().signal, () => loadP09Skills(settings)), /CONTEXT_UNSATISFIABLE/)
  const view = await build(input), payload = JSON.parse(view.prompt)
  assert.ok(view.audit.omissions.includes('planning:text:window'))
  assert.equal(payload.planning.text, undefined)
  assert.equal(payload.planning.plan_sha256, input.planning.plan_sha256)
  assert.equal(payload.planning.source_sha256, input.current.source_sha256)
  assert.deepEqual(payload.current, input.current)
  assert.equal(payload.verification_key, input.binding.verification_key)
  assert.deepEqual(payload.observed, JSON.parse((await build(base)).prompt).observed)
  assert.equal(payload.guidance.length, 2)
  assert.ok(view.audit.tokens <= view.audit.budget)
  assert.deepEqual(input, before)
  await writeFile(output + '/keyless-budgetfit-snapshot.json', JSON.stringify({ evidence: 'synthetic-keyless-estimated-counter-not-native-execution', input, view }, null, 2), { flag: 'wx' })
})

test('guidance changes do not change the mandatory core hash', async () => {
  assert.equal((await build(withPlan(JSON.stringify(plan)))).audit.core_sha256, (await build(base)).audit.core_sha256)
})

test('oversized mandatory specification still fails after the entire plan is omitted', async () => {
  const input = withPlan(JSON.stringify(plan))
  input.task.spec += 'Mandatory specification. '.repeat(2000)
  await assert.rejects(build(input), /CONTEXT_UNSATISFIABLE/)
})

test('skill-off remains skill-free when the planner text needs omission', async () => {
  const input = { ...withPlan('Long planning. '.repeat(2000)), variant_id: 'B', core_only: true }
  const view = await buildContext(input, settings.limits, counter, new AbortController().signal, () => { throw new Error('SKILL_OFF_LEAK') })
  assert.deepEqual(JSON.parse(view.prompt).guidance, [])
  assert.ok(view.audit.omissions.includes('planning:text:window'))
})

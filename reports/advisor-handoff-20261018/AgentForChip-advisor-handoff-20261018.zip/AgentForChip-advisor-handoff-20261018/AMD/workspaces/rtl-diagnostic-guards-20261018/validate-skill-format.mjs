import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { output } from './selection.mjs'

const yaml = createRequire(import.meta.url)('js-yaml'), results = []
for (const folder of ['rtl-assignment-integrity', 'rtl-interface-type-repair', 'rtl-stateful-specification']) {
  const bytes = await readFile(new URL('./skills/' + folder + '/SKILL.md', import.meta.url), 'utf8')
  const match = bytes.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n/)
  assert.ok(match)
  const metadata = yaml.load(match[1])
  assert.deepEqual(Object.keys(metadata).sort(), ['description', 'name'])
  assert.equal(metadata.name, folder)
  assert.match(metadata.name, /^[a-z0-9]+(?:-[a-z0-9]+)*$/)
  assert.ok(metadata.name.length <= 64 && typeof metadata.description === 'string' && metadata.description.length <= 1024)
  assert.doesNotMatch(metadata.description, /[<>]|\[TODO:/)
  assert.doesNotMatch(bytes.slice(match[0].length), /^\s*\[TODO:.*\]\s*$/m)
  results.push({ folder, valid_yaml_and_required_fields: true, valid_naming: true, no_scaffold_placeholders: true })
}
await writeFile(output + '/skill-format-validation.json', JSON.stringify({ status: 'PASS',
  validator: 'installed js-yaml plus equivalent required-field/name/placeholder checks',
  bundled_python_quick_validator: 'not rerun; local js-yaml validation used without installing dependencies', results }, null, 2), { flag: 'wx' })
console.log(JSON.stringify({ status: 'PASS', skills: results.length }))

"""Keep diagnostic and corrected observations separate; never select the best answer."""
import csv
import hashlib
import json
from pathlib import Path

OUT = Path('D:/AMD/output/rtl-diagnostic-guards-20261018')
ROOTS = {
    'previous_semantic': Path('D:/AMD/output/rtl-semantic-skills-ablation-20261017'),
    'retained_diagnostic': Path('D:/AMD/output/rtl-grounded-minimal-ablation-20261018'),
    'corrected': OUT,
}
STAGES = ('compile', 'elaborate', 'simulation', 'synthesis')


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


records, counts = [], {}
initials = {}
for generation, root in ROOTS.items():
    with (root / 'tasks.csv').open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    counts[generation] = {}
    for arm in ('on', 'off'):
        selected = [r for r in rows if r['arm'] == arm]
        counts[generation][arm] = {
            'rtl_pass': sum(all(r[s] == 'PASS' for s in STAGES) for r in selected),
            'tasks': len(selected),
            'question_calls': sum(int(r['model_calls']) for r in selected),
        }
    for row in rows:
        file = Path(row['comparison_result'])
        result = load(file)
        key = (row['task'], row['arm'])
        source = result['shared_initial_sha256']
        assert initials.setdefault(key, source) == source
        records.append({
            'generation': generation, 'task': row['task'], 'arm': row['arm'],
            'same_initial_sha256': source, 'rtl_pass': all(row[s] == 'PASS' for s in STAGES),
            'terminal': row['terminal'], 'question_calls': int(row['model_calls']),
            'result_file': str(file), 'result_sha256': hashlib.sha256(file.read_bytes()).hexdigest(),
        })
receipt = {
    'same_initial_arm_pairs': len(initials), 'counts': counts, 'records': records,
    'historical_generations_are_not_current_controls': True,
    'best_of_generations_selection': False,
    'corrected_run_does_not_erase_diagnostic_failures': True,
    'official_score': None,
}
with (OUT / 'three-generation-comparison.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
print(json.dumps(counts))

/** Off-target syntax/type/width counterexamples, run only through a dsh profile. */
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import { runCommand } from './rtl-tools/src/process.ts'
import { vivadoArgv } from './rtl-tools/src/synthesis.ts'
import { sha256 } from './rtl-tools/src/phase1/snapshots.ts'

export const name = 'rtl-semantic-eda-controls'
export const inject = ['cmdlineArgs', 'appReady', 'subprocess']

/** Register bounded local controls; no model service or question answers. */
export function apply(ctx: Context, config: { root: string }): void {
  if (ctx.get('llm') || ctx.cmdlineArgs!.get().join(' ') !== 'semantic') throw new Error('MODEL_FREE_CONTROLS_REQUIRED')
  const controller = new AbortController(); let pending: Promise<void> | undefined
  ctx.effect(() => async () => { controller.abort(); await pending })
  ctx.effect(() => ctx.get('appReady')!.onReady(() => {
    pending = run(ctx, config.root, controller.signal).then(() => ctx.get('appExit')!(0)).catch(error => {
      process.stderr.write(String(error) + '\n'); ctx.get('appExit')!(1)
    })
  }))
}

async function run(ctx: Context, root: string, signal: AbortSignal) {
  const freeze = JSON.parse(await readFile(join(root, 'preflight/freeze.json'), 'utf8')) as { files: Record<string, string> }
  for (const [file, digest] of Object.entries(freeze.files)) if (sha256(await readFile(file)) !== digest) throw new Error('CONTROL_SOURCE_CHANGED')
  const directory = join(root, 'semantic-controls'); await mkdir(directory)
  const base = 'D:/AMDDesignTools/2026.1/Vivado/bin/', cases = [
    { id: 'braced-concatenation', source: 'module Check(input a,b,output logic[1:0] y); always_comb {y[1],y[0]}={a,b}; endmodule', failure: null },
    { id: 'unbraced-comma', source: 'module Check(input a,b,output logic y); always_comb y, = a; endmodule', failure: 'front_end' },
    { id: 'dangling-comma', source: 'module Check(input a,b,output wire y); assign y=a,; endmodule', failure: 'front_end' },
    { id: 'enum-capacity', source: 'module Check; typedef enum logic[2:0]{A=0,B=1,C=2,D=3,E=4,F=5} kind_t; kind_t s,n; assign s=n; endmodule', failure: null },
    { id: 'enum-narrowed-duplicate', source: "module Check; typedef enum logic[1:0]{A=2'd0,B=2'd1,C=2'd2,D=2'd3,E=2'd0,F=2'd1} kind_t; kind_t s; endmodule", failure: 'front_end' },
    { id: 'enum-same-typedef', source: 'module Check; typedef enum logic[2:0]{A=0,B=1} kind_t; kind_t s,n; assign s=n; endmodule', failure: null },
    { id: 'enum-vector-alias', source: 'module Check; typedef enum logic[2:0]{A=0,B=1} kind_t; kind_t s; logic[2:0] alias_bits; assign s=alias_bits; endmodule', failure: 'front_end' },
    ...[ ['low-data', '{a,b,b}', null], ['low-constant', "{a,b,1'b0}", 'simulation'], ['low-feedback', '{a,b,a}', 'simulation'] ]
      .map(([id, rhs, failure]) => ({ id: 'scalar-' + id, failure,
        source: 'module Check(input a,b,output y); assign y=' + rhs + '; endmodule\n' +
          'module tb; reg a,b; wire y; integer i; Check dut(a,b,y); initial begin for(i=0;i<4;i=i+1) begin {a,b}=i; #1; if(y!==b) $fatal(1,"SCALAR_LOW_BIT_MISMATCH"); end $display("SCALAR_CHECK_PASS"); $finish; end endmodule' }))
  ]
  const results = []
  const cmd = await ctx.subprocess.resolveExecutable('cmd.exe', undefined, signal)
  for (const fixture of cases) {
    const cwd = join(directory, fixture.id); await mkdir(cwd)
    await writeFile(join(cwd, 'fixture.sv'), fixture.source, { flag: 'wx' })
    const stages = []
    for (const [stage, tool, argv] of [
      ['compile', 'xvlog', ['--sv', 'fixture.sv']],
      ['elaborate', 'xelab', [fixture.id.startsWith('scalar-') ? 'tb' : 'Check', '-s', 'check_snapshot']],
      ...(fixture.id.startsWith('scalar-') ? [['simulation', 'xsim', ['check_snapshot', '-runall']]] : [])
    ] as [string, string, string[]][]) {
      const executable = await ctx.subprocess.resolveExecutable(base + tool + '.bat', undefined, signal)
      const receipt = await runCommand(ctx.subprocess, { timeoutMs: 30000, graceMs: 1000, maxLogBytes: 1048576,
        maxLineChars: 4096, stopOnLogLimit: true }, vivadoArgv(executable, argv, process.platform, cmd), cwd, stage, signal, { accept() {} })
      if (receipt.timedOut || receipt.aborted || receipt.signal || receipt.logTruncated) throw new Error('CONTROL_PROCESS_INCOMPLETE')
      stages.push({ stage, ...receipt })
      if (receipt.exitCode !== 0) break
    }
    const failed = stages.find(s => s.exitCode !== 0)
    const simulation = stages.find(s => s.stage === 'simulation')
    const simulationText = simulation ? await readFile(simulation.stdoutLog, 'utf8') : ''
    const assertionFailed = /^Fatal: SCALAR_LOW_BIT_MISMATCH\s*$/m.test(simulationText)
    if (simulation && !assertionFailed && !/^SCALAR_CHECK_PASS\s*$/m.test(simulationText)) throw new Error('SCALAR_VERDICT_MISSING')
    const actual = assertionFailed ? 'simulation' : failed ? failed.stage === 'simulation' ? 'simulation' : 'front_end' : null
    const matched = actual === fixture.failure
    results.push({ id: fixture.id, expected_failure: fixture.failure, actual_failure: actual, matched, stages })
    await writeFile(join(cwd, 'result.json'), JSON.stringify(results.at(-1), null, 2), { flag: 'wx' })
    if (!matched) throw new Error('SEMANTIC_CONTROL_MISMATCH:' + fixture.id)
  }
  await writeFile(join(directory, 'results.json'), JSON.stringify({ status: 'PASS', controls: results.length,
    model_calls: 0, scope: 'generic fixtures only; no generated task candidate is modified', results }, null, 2), { flag: 'wx' })
}

import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises'
import { join, dirname } from 'node:path'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { output, hash } from './selection.mjs'

const here = dirname(fileURLToPath(import.meta.url)), root = output + '/campaign'
const resume = output + '/capability-resume-driver', home = resume + '/dsh-home'
const repo = 'D:/AMD/workspaces/http-paired-20261016/harness'
const json = async p => JSON.parse(await readFile(p, 'utf8'))
const put = (p, v) => writeFile(p, JSON.stringify(v, null, 2), { flag: 'wx' })
if (process.argv[2] === 'prepare') {
  await mkdir(resume)
  const original = await json(root + '/campaign-freeze.json'), files = { ...original.files }
  for (const arm of ['on', 'off']) {
    const old = await json(root + '/capability/' + arm + '/results.json')
    if (old.controls !== 3 || old.results.some(r => !r.status.startsWith('ENOENT:') || r.patch_accepted)) throw new Error('RESUME_PRECONDITION_FAILED')
    for (const fixture of old.results) for (const name of ['input.json', 'result.json']) {
      const file = root + '/capability/' + arm + '/' + fixture.task + '/' + name
      files[file] = hash(await readFile(file))
    }
    for (const fixture of old.results) files[fixture.plan.directory + '/plan.json'] = hash(await readFile(fixture.plan.directory + '/plan.json'))
    const rows = (await json(root + '/dsh-home/profiles/rtl-p10-model-' + arm + '/cordis.patch.yml'))[0].insert
      .filter(row => row.id !== 'p10-model')
    rows.find(row => row.id === 'llama').config.evidenceRoot = root + '/capability-resume/http'
    rows.push({ id: 'capability-resume', name: here + '/capability-resume.ts', config: { root, arm, freeze: resume + '/freeze.json' } })
    const path = home + '/profiles/rtl-capability-resume-' + arm
    await mkdir(path, { recursive: true })
    await put(path + '/package.json', { name: 'rtl-capability-resume-' + arm, private: true, dependencies: {}, dsh: { profile: { bundles: [], patchReload: 'startup' } } })
    await put(path + '/cordis.yml', [])
    await put(path + '/cordis.patch.yml', [{ insert: rows }])
    for (const name of ['package.json', 'cordis.patch.yml']) files[path + '/' + name] = hash(await readFile(path + '/' + name))
  }
  for (const name of ['capability-resume.ts', 'resume-capability.mjs', 'resume-capability.py']) files[here + '/' + name] = hash(await readFile(here + '/' + name))
  await put(resume + '/freeze.json', { deadline: original.protocol.deadline, files,
    original_freeze_sha256: hash(await readFile(root + '/campaign-freeze.json')), new_planner_calls: 0,
    original_task_budgets_not_reset: true, shared_arm_dispatch_pool: true })
  console.log('Prepared missing coder-step continuation without altering frozen question code.')
} else if (process.argv[2] === 'run') {
  if (!(await json(root + '/diagnostic-ended.json'))) throw new Error('QUESTIONS_MUST_FINISH_FIRST')
  for (const arm of ['on', 'off']) {
    const argv = ['--import', 'tsx/esm', 'apps/cli/src/bin.ts', '--profile', 'rtl-capability-resume-' + arm, 'capability-resume']
    const log = await import('node:fs/promises').then(fs => fs.open(resume + '/' + arm + '.log', 'wx'))
    let child, code
    try {
      child = spawn(process.execPath, argv, { cwd: repo, windowsHide: true, stdio: ['ignore', log.fd, log.fd],
        env: { ...Object.fromEntries(Object.entries(process.env).filter(([key]) => !/KEY|SECRET|TOKEN|PASSWORD|PROXY/i.test(key))),
          XILINXD_LICENSE_FILE: 'D:/AMDDesignTools/Xilinx.lic', DSH_HOME: home, NODE_OPTIONS: '--max-old-space-size=4096' } })
      code = await new Promise((resolve, reject) => { child.once('exit', resolve); child.once('error', reject) })
    } finally { await log.close() }
    await put(resume + '/' + arm + '-process.json', { pid: child.pid, exit_code: code, reaped: true, argv })
    if (code !== 0) throw new Error('RESUME_PROFILE_FAILED')
  }
} else throw new Error('Use prepare|run')

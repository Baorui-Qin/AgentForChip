"""Index every actual RTL verification, including rejected and rolled-back candidates."""
import csv
import hashlib
import json
from pathlib import Path

OUT = Path('D:/AMD/output/rtl-diagnostic-guards-20261018')
ROOT = OUT / 'campaign'


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


rows, records = [], []
for task in load(ROOT / 'manifest-7.json')['task_ids']:
    for arm in ('on', 'off'):
        result_file = ROOT / 'arms' / arm / ('compare-' + task) / 'result.json'
        result = load(result_file)
        for number, run in enumerate(result['verification_runs']):
            path = Path(run) / 'result.json'
            value = load(path)
            assert value['task_id'] == task
            records.append({'task': task, 'arm': arm, 'index': number, 'kind': 'initial' if number == 0 else 'repair',
                'source_sha256': value['final_source_sha256'], 'result_file': str(path),
                'result_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'stages': value['stages']})
            for stage, evidence in value['stages'].items():
                rows.append({'task': task, 'arm': arm, 'index': number, 'kind': 'initial' if number == 0 else 'repair',
                    'stage': stage, 'status': evidence['status'], 'source_sha256': value['final_source_sha256'],
                    'failure_domain': evidence.get('failure_domain'),
                    'message_ids': '|'.join(error.get('message_id') or error.get('category') or '' for error in evidence['errors']),
                    'messages': '|'.join(error['message'] for error in evidence['errors']),
                    'checks': evidence['evidence'].get('checks_executed'), 'mismatches': evidence['evidence'].get('mismatch_count'),
                    'raw_log': str(Path(run) / evidence['raw_log_path']) if evidence.get('raw_log_path') else '', 'result_file': str(path)})
with (OUT / 'verification-index.json').open('x', encoding='utf-8') as stream:
    json.dump(records, stream, ensure_ascii=False, indent=2)
with (OUT / 'verification-stages.csv').open('x', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
print(json.dumps({'verification_runs': len(records), 'stage_rows': len(rows)}))

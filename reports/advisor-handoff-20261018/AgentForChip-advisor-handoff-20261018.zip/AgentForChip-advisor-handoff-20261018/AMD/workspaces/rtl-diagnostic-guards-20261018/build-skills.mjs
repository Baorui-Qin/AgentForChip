import assert from 'node:assert/strict'
import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { skillHash } from './rtl-tools/src/phase1/p09-context.ts'
import { loadP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
import { hash, control, taskIds } from './selection.mjs'

const here = dirname(fileURLToPath(import.meta.url)), root = join(here, 'skill-registry')
const json = async path => JSON.parse(await readFile(path, 'utf8'))
const put = async (path, value) => writeFile(path, JSON.stringify(value, null, 2), { flag: 'wx' })
await mkdir(root)
const previousSettings = await json(control + '/campaign/p09.json')
const oldEntries = await loadP09Skills(previousSettings)
for (const entry of oldEntries) for (const record of entry.validation_records) {
  const target = join(root, record.path)
  await mkdir(dirname(target), { recursive: true })
  await copyFile(join(dirname(previousSettings.skillsFile), record.path), target)
}

// Off-target semantic checks validate the proposed rule, not a model or RTL score.
const pattern = '101', streams = []
function detect(bits) {
  let prefix = '', latched = false
  for (const bit of bits) {
    if (latched) continue
    const candidate = prefix + bit
    if (candidate.endsWith(pattern)) { latched = true; continue }
    prefix = ''
    for (let n = Math.min(pattern.length - 1, candidate.length); n > 0; n--) {
      if (candidate.endsWith(pattern.slice(0, n))) { prefix = pattern.slice(0, n); break }
    }
  }
  return latched
}
for (let length = 0; length <= 8; length++) for (let bits = 0; bits < 2 ** length; bits++) {
  const text = length ? bits.toString(2).padStart(length, '0') : ''
  assert.equal(detect(text), text.includes(pattern))
  streams.push(text)
}
assert.equal(detect('101000'), true)
assert.equal(detect(''), false)
const muxRows = []
for (const load of [0, 1]) for (const data of [0, 1]) for (const replacement of [0, 1]) for (const current of [0, 1]) {
  const selected = load ? replacement : data, erroneousHold = load ? replacement : current
  muxRows.push({ load, data, replacement, current, selected, erroneousHold })
}
assert.ok(muxRows.some(row => row.selected !== row.erroneousHold))
const encodings = Array.from({ length: 9 }, (_, n) => n)
assert.equal(new Set(encodings).size, encodings.length)
assert.ok(encodings.every(n => n < 2 ** Math.ceil(Math.log2(encodings.length))))
assert.notEqual(new Set([0, 1, 1]).size, 3)
const reviewedCases = []
for (const task of taskIds) {
  const path = control + '/campaign/compare-' + task + '/result.json'
  const result = await json(path)
  const initial = await json(result.baseline_run + '/result.json')
  const errors = Object.values(initial.stages).flatMap(stage => stage.errors)
  reviewedCases.push({ task, control_result: path, control_result_sha256: hash(await readFile(path)),
    initial_errors: errors, terminal_status: result.status,
    source_sha256: result.shared_initial_sha256, repair_attempts: result.repair_attempts,
    evidence_use: 'historical source for reviewed rules, never live execution evidence' })
}
await mkdir(join(root, 'evidence/new-rules'), { recursive: true })
const validation = { validation_kind: 'reviewed_rule_invariants_not_empirical_model_effectiveness',
  model_calls: 0, eda_calls: 0, generalization_tested: false,
  sequence_test_pattern: pattern, binary_streams_checked: streams.length, longest_prefix_matches_direct_search: true,
  selected_data_truth_table: muxRows, wrong_hold_counterexamples: muxRows.filter(row => row.selected !== row.erroneousHold).length,
  unique_enum_encodings_checked: encodings, duplicate_encoding_rejected: true,
  limits: 'Local rule checks and historical EDA support; validated status does not establish model compliance, gain or hidden-test generalization.' }
await put(join(root, 'evidence/new-rules/validation.json'), validation)
await put(join(root, 'evidence/new-rules/reviewed-cases.json'), reviewedCases)
const commonRecords = await Promise.all(['validation.json', 'reviewed-cases.json'].map(async name => ({
  path: 'evidence/new-rules/' + name, sha256: hash(await readFile(join(root, 'evidence/new-rules', name))) })))
const definitions = [
  { folder: 'rtl-interface-type-repair', id: 'rtl.interface_type_repair',
    tags: ['syntax', 'type_or_port', 'declaration_order', 'name_resolution', 'functional_mismatch'],
    scope: 'DUT declarations and fixed-interface submodules',
    limitations: 'Apply only relevant clauses. Type correctness is not functional verification; never change trusted ports or tests.' },
  { folder: 'rtl-stateful-specification', id: 'rtl.sequence_state_repair',
    tags: ['type_or_port', 'functional_mismatch'], scope: 'Specification-driven sequential DUT behavior',
    limitations: 'Derive the sequence and timing from this task. Aggregate mismatches do not prove a cause; only fresh EDA can validate a repair.' },
]
const newEntries = []
for (const definition of definitions) {
  const file = join(here, 'skills', definition.folder, 'SKILL.md'), markdown = await readFile(file, 'utf8')
  const rule = markdown.split(/^---\s*$/m).slice(2).join('---').trim()
  assert.ok(rule.length > 0)
  assert.doesNotMatch(rule, /Prob\d+|1101|q_in|out_always|TopModule\s*\(/)
  const source = 'evidence/new-rules/' + definition.folder + '.md'
  await copyFile(file, join(root, source))
  const entry = { id: definition.id, version: '1.0.0', status: 'validated', trigger_tags: definition.tags,
    scope: definition.scope, rule, limitations: definition.limitations,
    source_cases: reviewedCases.map(row => row.task + ':' + row.control_result_sha256),
    validation_records: [...commonRecords, { path: source, sha256: hash(await readFile(file)) }], content_hash: '' }
  entry.content_hash = skillHash(entry)
  newEntries.push(entry)
}
const file = join(root, 'skills.validated.json')
await put(file, [...oldEntries, ...newEntries])
const config = { ...previousSettings, skillsFile: file.replaceAll('\\', '/'), skillsSha256: hash(await readFile(file)) }
assert.equal((await loadP09Skills(config)).length, oldEntries.length + 2)
await put(join(root, 'bundle.json'), { status: 'LOCALLY_RULE_VALIDATED_EMPIRICAL_EFFECT_NOT_YET_MEASURED',
  settings: { skillsFile: config.skillsFile, skillsSha256: config.skillsSha256 },
  new_ids: newEntries.map(entry => entry.id), preserved_old_ids: oldEntries.map(entry => entry.id),
  previous_skill_registry: previousSettings.skillsFile, previous_skill_sha256: previousSettings.skillsSha256,
  runtime_integration: 'existing C diagnostic selection and retrieve_skill; no loop, routing or budget changes' })
console.log(JSON.stringify({ old_entries: oldEntries.length, new_entries: newEntries.length,
  registry_sha256: config.skillsSha256, sequence_streams_checked: streams.length, mux_truth_table_rows: muxRows.length }))

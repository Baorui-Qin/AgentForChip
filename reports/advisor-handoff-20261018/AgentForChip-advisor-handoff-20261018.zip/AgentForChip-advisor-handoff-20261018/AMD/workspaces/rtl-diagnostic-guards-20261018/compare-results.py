"""Paired same-batch results; prior experiments are references, not the control arm."""
from collections import Counter
import csv
import difflib
import json
from pathlib import Path
from result_evidence import best_evidence

OUT = Path('D:/AMD/output/rtl-diagnostic-guards-20261018')
ROOT = OUT / 'campaign'
STAGES = ('compile', 'elaborate', 'simulation', 'synthesis')


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(name, value):
    with (OUT / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


with (OUT / 'tasks.csv').open(encoding='utf-8-sig', newline='') as stream:
    task_rows = {(row['arm'], row['task']): row for row in csv.DictReader(stream)}
usage = {(row['arm'], row['task']): row for row in load(OUT / 'skill-usage-audit.json')['tasks']}
rows, details = [], []
for task in load(ROOT / 'manifest-7.json')['task_ids']:
    row = {'task': task}
    arm_details = {}
    for arm in ('on', 'off'):
        root = ROOT / 'arms' / arm
        path = root / ('compare-' + task) / 'result.json'
        result, t = load(path), task_rows[arm, task]
        row['same_initial_sha256'] = result['shared_initial_sha256']
        for key in ('terminal', 'model_calls', 'planner_calls', 'coder_calls', 'valid_repair_attempts', 'final_simulation_checks', 'final_simulation_mismatches', 'final_binding_reported', 'stage_evidence_source', *STAGES):
            row[arm + '_' + key] = t[key]
        row[arm + '_rtl_pass'] = all(t[stage] == 'PASS' for stage in STAGES)
        row[arm + '_full_accepted'] = result['status'] == 'VERIFIED'
        row[arm + '_guidance_calls'] = usage[arm, task]['calls_with_guidance']
        row[arm + '_unchanged_rejections'] = usage[arm, task]['unchanged_rejections']
        row[arm + '_result'] = str(path)
        initial = (root / ('generate-' + task) / 'initial.sv').read_text(encoding='utf-8')
        diffs = []
        for revision in result['revisions'][1:]:
            source = Path(revision['directory']) / 'solution.sv'
            diffs.append({'revision': revision['revision'], 'source': str(source), 'sha256': revision['sha256'],
                'diff_from_initial': ''.join(difflib.unified_diff(initial.splitlines(True), source.read_text(encoding='utf-8').splitlines(True), fromfile='shared-initial.sv', tofile=str(source)))})
        run, evidence_source = best_evidence(result, path.parent)
        final = load(run / 'result.json')
        arm_details[arm] = {'usage': usage[arm, task], 'result': str(path), 'stage_evidence_run': str(run), 'stage_evidence_source': evidence_source,
            'stage_failures': [{'stage': stage, 'errors': value['errors'], 'evidence': value['evidence']} for stage, value in final['stages'].items() if value['status'] in ('FAIL', 'INCONCLUSIVE')],
            'actions': result['actions'], 'repair_attempts': result['repair_attempts'], 'revision_decisions': result['revision_decisions'], 'source_diffs': diffs}
    assert load(Path(row['on_result']))['shared_initial_sha256'] == load(Path(row['off_result']))['shared_initial_sha256']
    for stage in STAGES:
        assert task_rows['on', task]['initial_' + stage] == task_rows['off', task]['initial_' + stage]
    rows.append(row)
    details.append({'task': task, 'comparison': row, 'arms': arm_details})
with (OUT / 'comparison.csv').open('x', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
save('comparison.json', details)
summary = {'protocol': 'same-batch-paired-recovery-ablation-v1', 'tasks': len(rows), 'same_initials': len(rows), 'arm_runs': 2 * len(rows),
    'skill_off_ablation': True, 'off_is_naked_baseline': False, 'new_generation_calls': 0,
    'on_rtl_pass': sum(row['on_rtl_pass'] for row in rows), 'off_rtl_pass': sum(row['off_rtl_pass'] for row in rows),
    'on_only_pass': [row['task'] for row in rows if row['on_rtl_pass'] and not row['off_rtl_pass']],
    'off_only_pass': [row['task'] for row in rows if row['off_rtl_pass'] and not row['on_rtl_pass']],
    'arms': {arm: {'terminal_counts': dict(Counter(row[arm + '_terminal'] for row in rows)),
        'model_calls': sum(int(row[arm + '_model_calls']) for row in rows),
        'valid_repair_attempts': sum(int(row[arm + '_valid_repair_attempts']) for row in rows),
        'full_accepted': sum(row[arm + '_full_accepted'] for row in rows)} for arm in ('on', 'off')},
    'held_out_generalization_tested': False, 'statistical_significance_tested': False, 'official_score': None}
save('comparison-summary.json', summary)
print(json.dumps(summary))

import assert from 'node:assert/strict'
import { readFile, readdir, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { hash, output, control, semanticPrevious, taskIds } from './selection.mjs'
import { loadP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
import { validateProfileFiles } from './validate-profile.mjs'
import { isUnchangedRecovery } from './rtl-tools/src/phase1/p10-repair-recovery.ts'
import { compactPlan } from './rtl-tools/src/phase1/p10-plan-format.ts'

const here = dirname(fileURLToPath(import.meta.url)), root = output + '/campaign'
const json = async path => JSON.parse(await readFile(path, 'utf8'))
await validateProfileFiles(root)
const settings = await json(root + '/arms/on/p09.json'), off = await json(root + '/arms/off/p09.json')
assert.deepEqual(settings.limits, (await json(semanticPrevious + '/campaign/arms/on/p09.json')).limits)
assert.deepEqual(await json(root + '/p10-budgets.json'), await json(semanticPrevious + '/campaign/p10-budgets.json'))
for (const arm of ['on', 'off']) {
  const configAt = async parent => (await json(parent + '/dsh-home/profiles/rtl-p10-model-' + arm + '/cordis.patch.yml'))[0].insert.find(row => row.id === 'p10-model').config
  const currentConfig = await configAt(root), previousConfig = await configAt(semanticPrevious + '/campaign')
  for (const key of ['maxTokens', 'repairMaxTokens', 'forcedActionMaxTokens', 'generationRecoveryMaxTokens', 'maxResponseBytes',
    'repairMaxResponseBytes', 'generationRecoveryMaxResponseBytes', 'maxRepairRounds', 'maxAgentRequests', 'activeMs', 'timeoutMs',
    'maxTransportRetries', 'maxGenerationResumes', 'maxCandidateRecoveryAttempts', 'maxOutputRecoveryAttempts', 'compactThreshold']) {
    assert.deepEqual(currentConfig[key], previousConfig[key], key)
  }
  assert.ok(currentConfig.campaignMaxDispatches <= previousConfig.campaignMaxDispatches)
  for (const key of ['maxPlans', 'thinkerContextWindow', 'thinkerMaxTokens', 'thinkerMaxResponseBytes']) assert.deepEqual(currentConfig.cloud[key], previousConfig.cloud[key], key)
}
const entries = await loadP09Skills(settings)
assert.deepEqual(await loadP09Skills(off), [])
assert.equal(settings.skillsFile, off.skillsFile)
assert.equal(settings.skillsSha256, off.skillsSha256)
const oldEntries = await json(semanticPrevious.replace('/output/', '/workspaces/') + '/skill-registry/skills.validated.json')
assert.equal(entries.length, 6)
assert.deepEqual(entries, oldEntries)
assert.equal(entries.find(e => e.id === 'rtl.interface_type_repair').version, '2.0.0')
assert.ok(entries.some(e => e.id === 'rtl.assignment_integrity'))
const identity = await json(root + '/cloud-identity.json'), oldIdentity = await json(control + '/campaign/cloud-identity.json')
for (const role of ['thinker', 'coder']) for (const key of ['alias', 'template_sha256', 'model_manifest_sha256', 'context_window', 'build_info', 'model_path']) {
  assert.deepEqual(identity[role][key], oldIdentity[role][key], role + '.' + key)
}
const changed = [], compared = []
async function compareSources(directory, relative = '') {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = relative + entry.name
    if (entry.isDirectory()) await compareSources(join(directory, entry.name), path + '/')
    else if (entry.isFile()) {
      compared.push(path)
      if (hash(await readFile(join(directory, entry.name))) !== hash(await readFile(here + '/rtl-tools/src/' + path))) changed.push(path)
    }
  }
}
await compareSources('D:/AMD/workspaces/rtl-semantic-skills-ablation-20261017/rtl-tools/src')
assert.deepEqual(changed.sort(), ['phase1/p09-action-call.ts', 'phase1/p09-auto-policy.ts', 'phase1/p09-context.ts', 'phase1/p10-model.ts', 'phase1/p10-plan-format.ts', 'phase1/p10-planner.ts'])
const calls = await json(output + '/call-index.json'), models = await json(output + '/model-output-index.json')
const requests = [], recoveries = [], tasks = [], preparationFailures = [], plans = []
for (const arm of ['on', 'off']) {
  for (const task of taskIds) {
    for (const binding of await readdir(root + '/arms/' + arm + '/plans/' + task)) {
      const directory = root + '/arms/' + arm + '/plans/' + task + '/' + binding
      try {
        const plan = await json(directory + '/plan.json')
        assert.equal(compactPlan(plan.text), plan.text)
        assert.equal(hash(plan.text), plan.plan_sha256)
        plans.push({ arm, task, directory, chars: plan.text.length, plan_sha256: plan.plan_sha256, complete_compact_json: true })
      } catch (error) { if (error.code !== 'ENOENT') throw error }
    }
  }
}
for (const call of calls) {
  const wire = await json(call.request_file)
  assert.equal(wire.temperature, 0); assert.equal(wire.top_p, 1)
  assert.equal(wire.reasoning_effort, 'none'); assert.equal(wire.chat_template_kwargs.enable_thinking, false)
  const linked = models.filter(model => model.request_sha256 === call.request_sha256)
  assert.ok(linked.length)
  const payload = wire.messages.filter(m => m.role === 'user' && typeof m.content === 'string')
    .map(m => JSON.parse(m.content)).find(value => value.task?.id === call.task && Array.isArray(value.guidance))
  assert.ok(payload, call.request_file)
  if (call.arm === 'off') assert.deepEqual(payload.guidance, [])
  assert.doesNotMatch(JSON.stringify(payload.guidance), /Prob\d+|source_cases|validation_records|q_in|out_always/)
  for (const guidance of payload.guidance) {
    const entry = entries.find(entry => entry.id === guidance.id)
    assert.ok(entry)
    assert.deepEqual(guidance, { id: entry.id, version: entry.version, scope: entry.scope, rule: entry.rule, limitations: entry.limitations })
  }
  const audit = await json(linked[0].directory + '/context-audit.json')
  assert.deepEqual(audit.selected_skills, payload.guidance.map(entry => entry.id))
  assert.ok(audit.tokens <= audit.budget)
  if (call.provider === 'cloud-coder') {
    assert.equal(audit.budget, 8192 - wire.max_tokens - 1024)
    const input = await json(linked[0].directory + '/context.json')
    assert.equal(payload.current.source, input.current.source)
    assert.equal(hash(input.current.source), input.current.source_sha256)
    if (input.pending_verification) assert.deepEqual(payload.guidance, [])
    if (audit.omissions.includes('planning:text:window')) {
      assert.equal(payload.planning.text, undefined)
      assert.equal(payload.planning.plan_sha256, input.planning.plan_sha256)
      assert.equal(payload.planning.source_sha256, input.planning.source_sha256)
      assert.equal(payload.planning.feedback_sha256, input.planning.feedback_sha256)
    }
    if (input.previous_tool_result?.observation?.error === 'REPEATED_CANDIDATE') {
      assert.equal(isUnchangedRecovery(input), true)
      assert.match(payload.host_action_error, /REPEATED_CANDIDATE/)
      assert.equal(payload.planning, undefined)
      assert.equal(wire.messages.filter(message => message.role === 'user').length, 1)
      assert.equal(wire.messages.filter(message => message.role === 'tool').length, 0)
      assert.ok(wire.messages.filter(message => message.role === 'assistant')
        .every(message => message.content === '<tool_call>\n' && !message.tool_calls))
      recoveries.push({ arm: call.arm, task: call.task, request_file: call.request_file,
        current_source_sha256: input.current.source_sha256, verification_key: input.binding.verification_key,
        no_rejected_replay: true, no_cached_plan: true, live_binding_valid: true })
    }
  }
  requests.push({ arm: call.arm, task: call.task, phase: call.phase, provider: call.provider, request_sha256: call.request_sha256,
    selected_skills: audit.selected_skills, omissions: audit.omissions, context_compacted: audit.context_compacted ?? false,
    pending_verification: audit.pending_verification ?? false, input_tokens: audit.tokens, input_budget: audit.budget,
    request_file: call.request_file, model_directory: linked[0].directory })
}
for (const task of taskIds) {
  const results = {}, first = {}
  for (const arm of ['on', 'off']) {
    const directory = root + '/arms/' + arm + '/compare-' + task, result = await json(directory + '/result.json')
    results[arm] = result
    const initial = await json(result.baseline_run + '/result.json')
    assert.equal(initial.final_source_sha256, result.shared_initial_sha256)
    const feedback = await json(directory + '/feedback-1.json')
    assert.equal(feedback.evidence_kind, 'live_verification')
    const selected = requests.filter(row => row.task === task && row.arm === arm)
    const firstCall = calls.find(row => row.task === task && row.arm === arm && row.provider === 'cloud-coder')
    first[arm] = firstCall ? JSON.parse((await json(firstCall.request_file)).messages.find(message => message.role === 'user').content) : null
    tasks.push({ task, arm, terminal: result.status, initial_source_sha256: initial.final_source_sha256,
      calls_with_guidance: selected.filter(row => row.selected_skills.length).length,
      compressed_calls_with_guidance: selected.filter(row => row.context_compacted && row.selected_skills.length).length,
      calls_with_skill_omissions: selected.filter(row => row.omissions.some(value => value.startsWith('skill:'))).length,
      unchanged_rejections: result.actions.filter(a => a.observation.error === 'REPEATED_CANDIDATE').length,
      unchanged_recovery_requests: recoveries.filter(row => row.task === task && row.arm === arm).length,
      explicit_retrieve_skill_calls: result.actions.filter(a => a.tool === 'retrieve_skill').length })
  }
  assert.equal(results.on.shared_initial_sha256, results.off.shared_initial_sha256)
  if (first.on && first.off) {
    assert.deepEqual(first.on.task, first.off.task)
    assert.equal(first.on.current.source, first.off.current.source)
    assert.equal(first.on.observed.stage, first.off.observed.stage)
    assert.equal(first.on.observed.status, first.off.observed.status)
  }
}
for (const model of models.filter(model => !model.request_sha256)) {
  const record = await json(model.directory + '/model.json')
  assert.equal(record.dispatched, false)
  preparationFailures.push({ arm: model.arm, task: model.task, directory: model.directory, code: record.error_code, dispatched: false })
}
const result = { status: 'PASS', protocol: 'same-batch-paired-recovery-ablation-v1', off_is_naked_baseline: false,
  same_models_templates_and_build: true, same_per_task_budgets: true, skill_contents_unchanged: true,
  same_bundle_both_arms: true, old_rules_preserved: 6, added_rule: null, revised_rule: null,
  previous_runtime_files_compared: compared.length, changed_runtime_source_files: changed,
  new_runtime_source_files: ['phase1/p10-exact-edit.ts', 'phase1/p10-grounding.ts'], tasks, requests, recoveries, preparation_failures: preparationFailures, plans,
  guidance_exposure_by_role: Object.fromEntries(['on', 'off'].map(arm => [arm, Object.fromEntries(['cloud-thinker', 'cloud-coder'].map(role => [role,
    { calls: requests.filter(r => r.arm === arm && r.provider === role).length, with_guidance: requests.filter(r => r.arm === arm && r.provider === role && r.selected_skills.length).length }]))])),
  planner_format: 'p10-compact-plan-1', complete_compact_plans: plans.length,
  planning_text_omitted_requests: requests.filter(row => row.omissions.includes('planning:text:window')).length,
  on_tasks_with_guidance: tasks.filter(row => row.arm === 'on' && row.calls_with_guidance).length,
  off_requests_with_guidance: requests.filter(row => row.arm === 'off' && row.selected_skills.length).length,
  compressed_on_requests_with_guidance: requests.filter(row => row.arm === 'on' && row.context_compacted && row.selected_skills.length).length,
  unchanged_recovery_requests_checked: recoveries.length, new_generation_calls: 0, official_score: null }
await writeFile(output + '/skill-usage-audit.json', JSON.stringify(result, null, 2), { flag: 'wx' })
console.log(JSON.stringify({ on_tasks_with_guidance: result.on_tasks_with_guidance, off_requests_with_guidance: result.off_requests_with_guidance,
  compressed_on_requests_with_guidance: result.compressed_on_requests_with_guidance, unchanged_recovery_requests_checked: recoveries.length }))

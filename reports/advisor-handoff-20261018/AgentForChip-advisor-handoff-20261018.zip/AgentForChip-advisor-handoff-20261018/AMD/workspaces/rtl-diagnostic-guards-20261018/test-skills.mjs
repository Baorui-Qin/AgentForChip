import assert from 'node:assert/strict'
import test from 'node:test'
import { readFile, writeFile, mkdir, mkdtemp, cp } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { buildContext, selectSkills, skillHash } from './rtl-tools/src/phase1/p09-context.ts'
import { loadP09Skills, retrieveP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
import { isUnchangedRecovery, unchangedFeedback } from './rtl-tools/src/phase1/p10-repair-recovery.ts'
import { hash, output, control } from './selection.mjs'

const here = dirname(fileURLToPath(import.meta.url))
const json = async path => JSON.parse(await readFile(path, 'utf8'))
const bundle = await json(join(here, 'skill-registry/bundle.json'))
const settings = { ...await json(control + '/campaign/p09.json'), ...bundle.settings }
const entries = await loadP09Skills(settings), oldEntries = await loadP09Skills(await json(control + '/campaign/p09.json'))
const ids = bundle.new_ids
const source = 'module TopModule(input clk,input load,input data,output reg result); always @(posedge clk) if(load) result <= data; endmodule\n'
const makeInput = (kind = 'type_or_port', variant_id = 'C') => ({
  task: { id: 'unit-scalar-cell', spec: 'One bit storage with specified input selection.',
    interface: { top: 'TopModule', ports: [{ name: 'clk', direction: 'input', width: 1, signed: false }, { name: 'load', direction: 'input', width: 1, signed: false },
      { name: 'data', direction: 'input', width: 1, signed: false }, { name: 'result', direction: 'output', width: 1, signed: false }] }, constraints: 'Only this DUT.' },
  sample_id: 'unit-only-no-model-or-eda-dispatch', variant_id, current: { revision_id: 'unit-revision', source, source_sha256: hash(source) },
  binding: { revision_id: 'unit-revision', source_sha256: hash(source), verification_key: 'sha256:' + 'a'.repeat(64) },
  feedback: { schema_version: '1.4', evidence_kind: 'live_verification', eda_rerun: false, model_repair_executed: false,
    original_run: 'synthetic-unit-fixture-not-execution', result_sha256: 'b'.repeat(64), parser_version: 'unit', parser_sha256: 'c'.repeat(64), inputs: [], old_diagnostics: {},
    stages: ['compile', 'elaborate', 'simulation', 'synthesis'].map((stage, index) => ({ stage, status: index ? 'SKIPPED' : 'FAIL', complete: true,
      process_normal: true, process_clean: false, functional_failure: false,
      diagnostics: index ? [] : [{ category: 'error', severity: 'ERROR', message_id: 'VRFC 10-3186', kind, origin: 'dut',
        attribution: 'DUT_COMPILE_ERROR', repairable_by_model: true, invocation: 'unit', file: 'rtl/solution.sv', line: 1,
        message: 'unit type diagnostic' }], verdict: { records: 0, checks: null, mismatches: null, fatal: false, completed: false } })) },
  ledger: [], purpose: 'repair', tool_mode: true, pending_verification: false,
})
const counter = { quality: 'estimated', identity: { implementation: 'explicit-keyless-unit-counter-not-production' },
  count: async view => Math.ceil(Buffer.byteLength(view.system + view.prompt) / 4) }
const build = (input, limits = settings.limits, load = () => loadP09Skills(settings)) => buildContext(input, limits, counter, new AbortController().signal, load)

test('preserves old rules and loads reviewed semantic rules with verified evidence', async () => {
  assert.equal(entries.length, 6)
  assert.deepEqual(entries.slice(0, 3), oldEntries)
  const preceding = await json('D:/AMD/workspaces/rtl-budgetfit-ablation-20261017/skill-registry/skills.validated.json')
  assert.deepEqual(entries.find(e => e.id === 'rtl.sequence_state_repair'), preceding.find(e => e.id === 'rtl.sequence_state_repair'))
  assert.ok(ids.every(id => entries.some(e => e.id === id)))
  for (const entry of entries) assert.equal(entry.content_hash, skillHash(entry))
})
for (const kind of ['type_or_port', 'functional_mismatch']) {
  test(kind + ': normal selector chooses the two new rules', () => assert.deepEqual(selectSkills(entries, [kind]).map(e => e.id), ids))
}
test('syntax selects assignment integrity and interface types through the unchanged selector', () => {
  assert.deepEqual(selectSkills(entries, ['syntax']).map(e => e.id), ids)
})
test('environment and unknown diagnostics do not activate these skills', () => {
  assert.deepEqual(selectSkills(entries, ['tool_environment', 'unknown']), [])
})
test('normal C request contains new guidance but no provenance or task answers', async () => {
  const input = makeInput(), view = await build(input), prompt = JSON.parse(view.prompt)
  assert.deepEqual(view.audit.selected_skills, ids)
  assert.deepEqual(prompt.guidance.map(e => e.id), ids)
  assert.ok(prompt.guidance.every(e => !('validation_records' in e) && !('source_cases' in e)))
  assert.equal(prompt.current.source, source)
  assert.doesNotMatch(JSON.stringify(prompt.guidance), /Prob\d+|1101|q_in|out_always/)
  const snapshot = { evidence: 'keyless-unit-context-only', input, view }
  try { await writeFile(output + '/skills-unit-request-snapshot.json', JSON.stringify(snapshot, null, 2), { flag: 'wx' }) }
  catch (error) { if (error.code !== 'EEXIST') throw error; assert.deepEqual(await json(output + '/skills-unit-request-snapshot.json'), snapshot) }
})
test('the skill change affects guidance, not core source or trusted observations', async () => {
  const input = makeInput(), old = await build(input, settings.limits, async () => oldEntries), current = await build(input)
  assert.equal(old.audit.core_sha256, current.audit.core_sha256)
  assert.notEqual(old.audit.prompt_sha256, current.audit.prompt_sha256)
})
test('retrieve_skill uses the same current-stage selection as automatic loading', async () => {
  const observed = await retrieveP09Skills(settings, makeInput().feedback)
  assert.equal(observed.enabled, true)
  assert.deepEqual(observed.skills.map(e => e.id), ids)
  assert.deepEqual(await retrieveP09Skills(settings, null), { enabled: true, skills: [] })
})
for (const variant of ['A', 'B']) {
  test(variant + ': no skill files read, no skill guidance exposed', async () => {
    const badSettings = { ...settings, variant, skillsFile: 'D:/not-existing/unit-skills.json' }
    assert.deepEqual(await loadP09Skills(badSettings), [])
    assert.deepEqual(await retrieveP09Skills(badSettings, makeInput().feedback), { enabled: false, skills: [] })
    const view = await build(makeInput('type_or_port', variant), settings.limits, async () => { throw new Error('SKILLS_MUST_NOT_BE_READ') })
    assert.deepEqual(JSON.parse(view.prompt).guidance, [])
  })
}
test('native initial generation does not load skills', async () => {
  const input = { ...makeInput(), variant_id: 'A', current: null, binding: null, feedback: null,
    purpose: 'generation', generation_mode: 'native-tool', tool_mode: false }
  const view = await build(input, settings.limits, async () => { throw new Error('GENERATION_SKILL_LEAK') })
  assert.deepEqual(view.audit.selected_skills, [])
})
test('pending verification exposes no diagnostic-selected skills', async () => {
  const input = { ...makeInput(), pending_verification: true, binding: null, feedback: null }
  const view = await build(input)
  assert.deepEqual(view.audit.selected_skills, [])
})
test('normal soft-budget pruning removes guidance instead of weakening the context budget', async () => {
  const view = await build(makeInput(), { ...settings.limits, skills: 1 })
  assert.deepEqual(view.audit.selected_skills, [])
  assert.ok(ids.every(id => view.audit.omissions.includes('skill:' + id)))
  assert.ok(view.audit.tokens <= view.audit.budget)
})
test('context recovery retains validated guidance within the unchanged budget', async () => {
  const view = await build({ ...makeInput(), core_only: true })
  assert.deepEqual(view.audit.selected_skills, ids)
  assert.ok(view.audit.tokens <= view.audit.budget)
  assert.equal(JSON.parse(view.prompt).current.source, source)
})

test('compression still rejects a mandatory core that cannot fit', async () => {
  await assert.rejects(build({ ...makeInput(), core_only: true }, { ...settings.limits,
    window: settings.limits.output + settings.limits.margin + 1 }), /CONTEXT_UNSATISFIABLE/)
})

test('unchanged recovery is bound, corrective and does not change the DUT', () => {
  const input = makeInput(), original = structuredClone(input), observation = unchangedFeedback(input)
  assert.deepEqual(input, original)
  assert.equal(observation.unchanged_source_sha256, input.current.source_sha256)
  assert.equal(observation.verification_key, input.binding.verification_key)
  assert.equal(observation.blocking_stage, 'compile')
  assert.ok(!JSON.stringify(observation).includes(input.current.source))
  assert.equal(isUnchangedRecovery({ ...input, previous_tool_result: { tool: 'edit_dut', accepted: false, observation } }), true)
})

for (const change of ['revision', 'source', 'key', 'pending', 'replay', 'tool', 'accepted']) {
  test('unchanged recovery refuses ' + change + ' mismatches', () => {
    const input = makeInput(), observation = unchangedFeedback(input)
    input.previous_tool_result = { tool: 'edit_dut', accepted: false, observation }
    if (change === 'revision') input.current.revision_id += '-foreign'
    if (change === 'source') input.current.source += ' '
    if (change === 'key') observation.verification_key += '-foreign'
    if (change === 'pending') input.pending_verification = true
    if (change === 'replay') input.feedback.evidence_kind = 'replay'
    if (change === 'tool') input.previous_tool_result.tool = 'verify_rtl'
    if (change === 'accepted') input.previous_tool_result.accepted = true
    assert.equal(isUnchangedRecovery(input), false)
  })
}

test('unchanged recovery rejects incomplete evidence without issuing a correction', () => {
  const input = makeInput()
  input.feedback.stages[0].complete = false
  assert.throws(() => unchangedFeedback(input), /UNCHANGED_RECOVERY_EVIDENCE_INVALID/)
})
test('changed content cannot reuse an old rule digest', () => {
  assert.throws(() => selectSkills([{ ...entries[3], rule: entries[3].rule + ' changed' }], ['type_or_port']), /SKILL_EVIDENCE_INVALID/)
})
test('changed evidence is rejected before any model dispatch', async () => {
  await mkdir(output + '/offline-checks', { recursive: true })
  const temporary = join(await mkdtemp(output + '/offline-checks/skill-tamper-'), 'registry')
  await cp(join(here, 'skill-registry'), temporary, { recursive: true, errorOnExist: true, force: false })
  await writeFile(join(temporary, entries[3].validation_records[0].path), 'unit tampered evidence\n')
  await assert.rejects(loadP09Skills({ ...settings, skillsFile: temporary + '/skills.validated.json' }), /SKILL_EVIDENCE_INVALID/)
})

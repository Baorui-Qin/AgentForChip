import assert from 'node:assert/strict'
import { readdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { output, hash } from './selection.mjs'
const root=output+'/campaign', base=root+'/capability'
const json=async p=>JSON.parse(await readFile(p,'utf8'))
const models=[],controls=[]
async function modelDirs(parent,arm,task) {
  for(const entry of await readdir(parent,{withFileTypes:true})) if(entry.isDirectory()&&entry.name.startsWith('run-')) {
    const directory=join(parent,entry.name)
    let dispatch
    try { dispatch=await json(directory+'/dispatch.json') } catch(e) { if(e.code!=='ENOENT')throw e; continue }
    models.push({directory,arm,task,request_sha256:dispatch.request_sha256,audit:await json(directory+'/context-audit.json')})
  }
}
for(const arm of ['on','off']) {
  const results=await json(base+'/'+arm+'/results.json')
  assert.equal(results.status,'COMPLETED')
  for(const row of results.results) {
    controls.push({arm,task:row.task,status:row.status,passed:row.passed,minimal_changed_spans:row.minimal_changed_spans,
      plan_citation_matched:row.plan_citation_matched,patch_accepted:row.patch_accepted,result_file:base+'/'+arm+'/'+row.task+'/result.json'})
    await modelDirs(base+'/'+arm+'/'+row.task+'/models',arm,row.task)
    for(const binding of await readdir(base+'/'+arm+'/plans/'+row.task,{withFileTypes:true})) if(binding.isDirectory()) await modelDirs(base+'/'+arm+'/plans/'+row.task+'/'+binding.name,arm,row.task)
  }
}
const calls=[], usage={prompt_tokens:0,completion_tokens:0}
for(const entry of await readdir(base+'/http',{withFileTypes:true})) if(entry.isDirectory()) {
  const directory=base+'/http/'+entry.name, request=await json(directory+'/request.json'), transport=await json(directory+'/transport.json')
  const digest=hash(JSON.stringify(request)), model=models.find(m=>m.request_sha256===digest)
  assert.ok(model); assert.equal(digest,transport.request_sha256)
  assert.ok(model.audit.tokens<=model.audit.budget)
  const payload=request.messages.filter(m=>m.role==='user').map(m=>JSON.parse(m.content)).find(p=>p.task?.id===model.task&&p.guidance)
  assert.ok(payload); if(model.arm==='off')assert.deepEqual(payload.guidance,[])
  assert.doesNotMatch(JSON.stringify(request),/CAPABILITY_CHECKS|causeWords|MISMATCHES/)
  let tokens=null
  for(const line of (await readFile(directory+'/sse.jsonl','utf8')).trim().split('\n')) {
    const envelope=JSON.parse(line)
    let value=envelope.data
    if(typeof value==='string') { try {value=JSON.parse(value)} catch {continue} }
    if(value?.usage)tokens=value.usage
  }
  if(tokens) {usage.prompt_tokens+=tokens.prompt_tokens;usage.completion_tokens+=tokens.completion_tokens}
  calls.push({arm:model.arm,task:model.task,provider:transport.provider,model_directory:model.directory,request_file:directory+'/request.json',
    request_sha256:digest,http_status:transport.http_status,stream_complete:transport.stream_complete,input_tokens:model.audit.tokens,input_budget:model.audit.budget,
    new_skill:payload.guidance.some(g=>g.id==='rtl.00_diagnostic_reasoning'),usage:tokens})
}
const questions=await json(output+'/call-index.json'), claims={}
for(const arm of ['on','off']) {
  const tickets=(await readdir(root+'/arms/'+arm+'/dispatches')).filter(n=>/^\d+\.json$/.test(n))
  const q=questions.filter(r=>r.arm===arm).length,c=calls.filter(r=>r.arm===arm).length
  assert.equal(tickets.length,q+c);assert.ok(tickets.length<=100)
  claims[arm]={question_calls:q,capability_calls:c,reserved_dispatches:tickets.length,limit:100}
}
await writeFile(output+'/capability-audit.json',JSON.stringify({status:'EVIDENCE_AUDIT_PASS',controls,calls,usage,claims,
  probe_before_questions:true,new_user_requested_campaign:true,previous_campaign_not_extended:true,
  inference_calls:calls.length,question_calls:questions.length,combined_inference_calls:calls.length+questions.length,
  no_control_oracle_in_requests:true,off_guidance:0},null,2),{flag:'wx'})
console.log(JSON.stringify({controls:controls.length,passed:controls.filter(c=>c.passed).length,calls:calls.length,claims}))

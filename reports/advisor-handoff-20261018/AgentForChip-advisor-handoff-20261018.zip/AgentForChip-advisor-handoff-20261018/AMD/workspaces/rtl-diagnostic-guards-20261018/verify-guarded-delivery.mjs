import assert from 'node:assert/strict'
import { readFile, readdir, writeFile } from 'node:fs/promises'
import { output, hash } from './selection.mjs'
const json=async p=>JSON.parse(await readFile(p,'utf8'))
const root=output+'/campaign'
const freeze=await json(root+'/campaign-freeze.json')
for(const [path,digest] of Object.entries(freeze.files))assert.equal(hash(await readFile(path)),digest,path)
const comparison=await json(output+'/comparison-summary.json'), guarded=await json(output+'/guarded-output-audit.json')
const skills=await json(output+'/skill-usage-audit.json'), capability=await json(output+'/capability-audit.json')
assert.equal(comparison.tasks,7);assert.equal(comparison.same_initials,7);assert.equal(comparison.arm_runs,14)
assert.equal(guarded.status,'PASS');assert.equal(skills.status,'PASS');assert.equal(skills.off_requests_with_guidance,0)
assert.equal(skills.six_prior_skills_unchanged,true)
assert.equal(capability.controls.length,6)
for(const row of Object.values(capability.claims))assert.ok(row.reserved_dispatches<=100)
for(const r of skills.requests)assert.ok(r.input_tokens<=r.input_budget)
for(const name of ['previous','control','skills','recovery','budgetfit','semantic','grounded'])assert.equal((await json(output+'/'+name+'-round-preservation.json')).unchanged,true)
assert.equal((await json(output+'/additional-history-preservation.json')).status,'PASS')
assert.equal((await json(output+'/preservation.json')).status,'PASS')
const post=await json(output+'/post-run-checks.json')
assert.equal(post.ssh_original_hash_matches,true)
assert.ok(post.loopback_ports.every(p=>p.connection_refused))
assert.ok(Object.values(post.stages).every(s=>s.reaped&&s.exit_code===0&&!s.watchdog_timeout))
assert.match(await readFile(output+'/unit-loop-pass.log','utf8'),/Tests\s+90 passed/)
assert.match(await readFile(output+'/unit-guards-complete.log','utf8'),/pass 19\b/)
assert.deepEqual(await readFile(output+'/typecheck-final.log'),await readFile(output+'/typecheck-previous.log'))
assert.equal((await readFile(output+'/typecheck-final.log','utf8')).match(/error TS\d+/g).length,70)
const documents=['REPORT.zh.md','FAILURE_ANALYSIS.zh.md','LOG_INDEX.md']
let linkCount=0
for(const document of documents) for(const match of (await readFile(output+'/'+document,'utf8')).matchAll(/\]\(([^)]+)\)/g)) {
  if(match[1]!==output+'/delivery-verification.json') await readFile(match[1])
  linkCount++
}
const sourceFiles={}
for(const entry of await readdir('D:/AMD/workspaces/rtl-diagnostic-guards-20261018',{withFileTypes:true})) if(entry.isFile()&&entry.name.startsWith('audit-')) {
  const p='D:/AMD/workspaces/rtl-diagnostic-guards-20261018/'+entry.name
  sourceFiles[p]=hash(await readFile(p))
}
const receipt={status:'EVIDENCE_AUDIT_PASS',not_a_claim_all_tasks_repaired:true,paired_tasks:7,arm_runs:14,
  rtl_pass:{on:comparison.on_rtl_pass,off:comparison.off_rtl_pass},capability_pass:capability.controls.filter(c=>c.passed).length,
  question_inference_calls:capability.question_calls,capability_inference_calls:capability.inference_calls,total_inference_calls:capability.combined_inference_calls,
  arm_claims:capability.claims,accepted_model_patches_recomputed:guarded.accepted_patches_recomputed,
  guarded_both_arms:true,normal_skill_route:true,new_skill_calls:skills.requests.filter(r=>r.selected_skills.includes('rtl.00_diagnostic_reasoning')).length,
  off_requests_with_skills:0,prior_six_skills_preserved:true,new_unit_tests:24,total_focused_tests_passed:109,
  full_typecheck_passed:false,preexisting_dependency_diagnostics:70,added_type_diagnostics:0,
  source_freeze_files_checked:Object.keys(freeze.files).length,original_and_historical_results_preserved:true,handoff_updated:false,
  temporary_tunnel_closed_and_ssh_restored:true,formal_competition_score:null,checked_document_links:linkCount,analysis_source_files:sourceFiles,
  attribution_limit:'Current ON/OFF isolates skill under shared guards. Historical before/after is not a contemporaneous guard-only control or statistical proof of understanding.'}
await writeFile(output+'/delivery-verification.json',JSON.stringify(receipt,null,2),{flag:'wx'})
console.log(JSON.stringify(receipt))

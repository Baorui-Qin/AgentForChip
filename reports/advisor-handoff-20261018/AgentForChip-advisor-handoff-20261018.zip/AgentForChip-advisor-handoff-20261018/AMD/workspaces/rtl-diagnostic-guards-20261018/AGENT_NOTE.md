# Diagnostic Repair Constraints

The preserved audit found that literal error citation did not ensure coherent repairs: enum proposals contradicted uniqueness checks, fixed-width inputs were widened, and no-op plans or repeated verify calls survived until rejection. These outputs show ineffective diagnostic use, not proof that the model internally did not read the error.

Structured before/after planning makes substantive-change and public-interface checks deterministic. Preview only validates model text and never applies it to live RTL. Known literal packed enums receive bounded capacity/duplicate/value checks; unsupported forms remain explicitly unknown. Format and constraint failures share the existing single recovery and output caps.

ExactPatchError adds entry-index and occurrence evidence. RepairGuardError adds fixed-port, enum and token-replay evidence. The normal action observation and subsequent serialized request retain those details. Token rejections are session-local and ignore ordinary comments/whitespace, not synthesis controls. They do not imply semantic equivalence or final correctness.

Both arms receive the same checked workflow. Only C receives the new normally selected generic skill; B loads no skills. Tests include positive fixes, constraint failures, detailed anchor errors, replay isolation and real frozen failures. Campaign evidence must distinguish fewer invalid actions, accepted candidates, actual EDA progress and final pass. Any negative result remains immutable, and historical comparisons remain non-causal references.

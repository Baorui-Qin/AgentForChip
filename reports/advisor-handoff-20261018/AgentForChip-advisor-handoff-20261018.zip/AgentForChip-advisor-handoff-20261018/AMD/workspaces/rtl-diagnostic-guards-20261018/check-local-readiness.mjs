import assert from 'node:assert/strict'
import { readFile, writeFile, readdir } from 'node:fs/promises'
import { dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { output, hash, budgetfitPrevious } from './selection.mjs'

const here = dirname(fileURLToPath(import.meta.url)), root = output + '/campaign'
const json = async p => JSON.parse(await readFile(p, 'utf8'))
const freeze = await json(root + '/preflight/freeze.json')
for (const [file, digest] of Object.entries(freeze.files)) assert.equal(hash(await readFile(file)), digest, file)
const controls = await json(root + '/preflight/results.json'), semantic = await json(root + '/semantic-controls/results.json')
assert.equal(controls.status, 'PASS'); assert.equal(controls.controls, 16)
assert.equal(semantic.status, 'PASS'); assert.equal(semantic.controls, 10)
assert.ok(semantic.results.every(r => r.matched))
assert.deepEqual(await json(here + '/budgets.json'), await json(budgetfitPrevious + '/campaign/p10-budgets.json'))
assert.equal(await readFile(output + '/typecheck-current.log', 'utf8'), await readFile(output + '/typecheck-previous.log', 'utf8'))
assert.equal(await readFile(output + '/typecheck-semantic.log', 'utf8'), await readFile(output + '/typecheck-previous.log', 'utf8'))
assert.match(await readFile(output + '/unit-loop-final.log', 'utf8'), /Tests\s+83 passed/)
for (const [file, count] of [['unit-skills-budget.log', 47], ['unit-profile.log', 8], ['unit-planner.log', 3]]) {
  const log = await readFile(output + '/' + file, 'utf8')
  assert.match(log, new RegExp('pass\\s+' + count + '\\b')); assert.match(log, /fail\s+0\b/)
}
const models = await readdir(root)
assert.ok(!models.includes('http'))
const result = { status: 'LOCAL_READY_AWAITING_EXPLICIT_CLOUD_DATA_AUTHORIZATION', local_tests_passed: 141,
  generic_eda_controls_passed: 10, task_eda_controls_passed: 16, frozen_inputs_checked: Object.keys(freeze.files).length,
  per_task_budgets_unchanged: true, no_added_type_diagnostics_in_runtime_or_control_helper: true,
  upstream_flat_type_errors: 70, full_typecheck_passed: false, current_inference_calls: 0,
  network_guard: 'Cloud execution was rejected before process creation; no workaround used.' }
await writeFile(output + '/local-readiness.json', JSON.stringify(result, null, 2), { flag: 'wx' })
console.log(JSON.stringify(result))

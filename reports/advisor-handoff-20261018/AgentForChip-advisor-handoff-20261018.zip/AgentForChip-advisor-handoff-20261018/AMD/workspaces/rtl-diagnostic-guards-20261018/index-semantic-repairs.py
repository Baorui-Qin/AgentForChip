"""Link target-task plans, generated revisions and actual EDA evidence without judging hidden reasoning."""
import hashlib
import json
from pathlib import Path

OUT = Path('D:/AMD/output/rtl-diagnostic-guards-20261018')
OLD = Path('D:/AMD/output/rtl-grounded-minimal-fixed-20261018')
TARGETS = ('Prob096_review2015_fsmseq', 'Prob142_lemmings2', 'Prob104_mt2015_muxdff')


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


rows = []
for label, root in [('previous', OLD), ('current', OUT)]:
    comparisons = {row['task']: row for row in load(root / 'comparison.json')}
    verifications = load(root / 'verification-index.json')
    for task in TARGETS:
        for arm in ('on', 'off'):
            result_file = root / 'campaign/arms' / arm / ('compare-' + task) / 'result.json'
            result = load(result_file)
            plans = []
            for file in sorted((root / 'campaign/arms' / arm / 'plans' / task).glob('*/plan.json')):
                plan = load(file)
                plans.append({'file': str(file), 'source_sha256': plan['source_sha256'],
                    'feedback_sha256': plan['feedback_sha256'], 'review_sha256': plan.get('review_sha256'),
                    'text': plan['text'], 'plan_sha256': plan['plan_sha256']})
            observed = [row for row in verifications if row['task'] == task and row['arm'] == arm]
            errors = [{'index': row['index'], 'source_sha256': row['source_sha256'], 'stage': stage,
                'message_id': error.get('message_id'), 'message': error.get('message'), 'result_file': row['result_file']}
                for row in observed for stage, value in row['stages'].items() for error in value['errors']]
            rows.append({'round': label, 'task': task, 'arm': arm, 'terminal': result['status'],
                'result_file': str(result_file), 'result_sha256': hashlib.sha256(result_file.read_bytes()).hexdigest(),
                'same_initial_sha256': result['shared_initial_sha256'],
                'rtl_pass': comparisons[task]['comparison'][arm + '_rtl_pass'],
                'plans': plans, 'candidate_diffs': comparisons[task]['arms'][arm]['source_diffs'],
                'revision_decisions': result['revision_decisions'], 'verifications': observed,
                'diagnosed_comma_errors': [e for e in errors if 'syntax error' in (e['message'] or '').lower() and "','" in (e['message'] or '')],
                'diagnosed_enum_type_errors': [e for e in errors if e['message_id'] == 'VRFC 10-2649'],
                'diagnosed_duplicate_enum_errors': [e for e in errors if e['message_id'] == 'VRFC 10-3279'],
                'all_tool_errors': errors,
                'skill_requests': [r for r in load(root / 'skill-usage-audit.json')['requests'] if r['task'] == task and r['arm'] == arm]})
report = {'evidence_kind': 'observed_plan_text_generated_diffs_and_eda_only',
    'previous_is_historical_reference_not_current_control': True,
    'no_reference_answers_or_candidate_postprocessing': True, 'records': rows, 'official_score': None}
with (OUT / 'semantic-repair-evidence.json').open('x', encoding='utf-8') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
print(json.dumps({'records': len(rows), 'current': [{'task': r['task'], 'arm': r['arm'], 'rtl_pass': r['rtl_pass'],
    'comma_errors': len(r['diagnosed_comma_errors']), 'enum_type_errors': len(r['diagnosed_enum_type_errors'])}
    for r in rows if r['round'] == 'current']}))

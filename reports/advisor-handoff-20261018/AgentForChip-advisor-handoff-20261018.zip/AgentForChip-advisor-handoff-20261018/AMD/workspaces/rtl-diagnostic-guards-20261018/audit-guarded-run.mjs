import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { output, hash, taskIds } from './selection.mjs'
import { validateProfileFiles } from './validate-profile.mjs'
import { loadP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
import { compactPlan } from './rtl-tools/src/phase1/p10-plan-format.ts'
import { guardPlan, guardRepair, repairCodeHash } from './rtl-tools/src/phase1/p10-repair-guards.ts'
import { exactEdit } from './rtl-tools/src/phase1/p10-exact-edit.ts'

const root=output+'/campaign', old='D:/AMD/output/rtl-grounded-minimal-fixed-20261018'
const json=async p=>JSON.parse(await readFile(p,'utf8'))
const put=async (name,value)=>writeFile(output+'/'+name,JSON.stringify(value,null,2),{flag:'wx'})
await validateProfileFiles(root)
const on=await json(root+'/arms/on/p09.json'), off=await json(root+'/arms/off/p09.json')
const entries=await loadP09Skills(on)
assert.equal(entries.length,7); assert.deepEqual(await loadP09Skills(off),[])
assert.deepEqual(entries.slice(0,6),await json('D:/AMD/workspaces/rtl-grounded-minimal-fixed-20261018/skill-registry/skills.validated.json'))
assert.deepEqual(on.limits,(await json(old+'/campaign/arms/on/p09.json')).limits)
const identity=await json(root+'/cloud-identity.json'), previousIdentity=await json(old+'/campaign/cloud-identity.json')
for(const role of ['thinker','coder']) for(const field of ['alias','template_sha256','model_manifest_sha256','context_window','build_info','model_path']) assert.deepEqual(identity[role][field],previousIdentity[role][field])
for(const arm of ['on','off']) {
  const config=async r=>(await json(r+'/dsh-home/profiles/rtl-p10-model-'+arm+'/cordis.patch.yml'))[0].insert.find(row=>row.id==='p10-model').config
  const a=await config(root),b=await config(old+'/campaign')
  for(const key of ['maxRepairRounds','maxAgentRequests','activeMs','repairMaxTokens','forcedActionMaxTokens','timeoutMs','maxOutputRecoveryAttempts','maxCandidateRecoveryAttempts']) assert.deepEqual(a[key],b[key])
  for(const key of ['thinkerMaxTokens','thinkerContextWindow','maxPlans']) assert.deepEqual(a.cloud[key],b.cloud[key])
}
const calls=await json(output+'/call-index.json'), models=await json(output+'/model-output-index.json')
const requests=[], plans=[], patches=[], tasks=[]
for(const call of calls) {
  const model=models.find(m=>m.request_sha256===call.request_sha256), wire=await json(call.request_file)
  const payload=wire.messages.filter(m=>m.role==='user'&&typeof m.content==='string').map(m=>JSON.parse(m.content)).find(p=>p.task?.id===call.task&&Array.isArray(p.guidance))
  assert.ok(payload)
  const audit=await json(model.directory+'/context-audit.json')
  assert.deepEqual(audit.selected_skills,payload.guidance.map(g=>g.id)); assert.ok(audit.tokens<=audit.budget)
  assert.equal(wire.temperature,0);assert.equal(wire.top_p,1);assert.equal(wire.chat_template_kwargs.enable_thinking,false)
  if(call.arm==='off') assert.deepEqual(payload.guidance,[])
  assert.doesNotMatch(JSON.stringify(payload.guidance),/Prob\d+|source_cases|validation_records|q_in|out_always/)
  for(const guidance of payload.guidance) {
    const entry=entries.find(e=>e.id===guidance.id)
    assert.deepEqual(guidance,{id:entry.id,version:entry.version,scope:entry.scope,rule:entry.rule,limitations:entry.limitations})
  }
  if(call.provider==='cloud-thinker') {
    const check=await json(model.directory+'/constraint-validation.json')
    const raw=await json(model.directory+'/model.json')
    plans.push({task:call.task,arm:call.arm,directory:model.directory,request_file:call.request_file,valid:check.valid,checks:check.checks,issues:check.issues,output:raw.content,raw_output_sha256:hash(raw.content)})
    if(check.valid) {
      const binding=await json(dirname(model.directory)+'/binding.json')
      const result=await json(root+'/arms/'+call.arm+'/compare-'+call.task+'/result.json')
      const revision=result.revisions.find(r=>r.sha256===binding.source_sha256)
      assert.ok(revision)
      const source=await readFile(revision.directory+'/solution.sv','utf8')
      const canonical=compactPlan(raw.content,true)
      const expected=(await json(root+'/preflight/catalog.json')).find(t=>t.task_id===call.task).interface
      assert.deepEqual(guardPlan(canonical,source,expected),check.checks)
    }
  } else {
    const input=await json(model.directory+'/context.json')
    assert.equal(payload.current.source,input.current.source)
    if(input.pending_verification) assert.deepEqual(payload.guidance,[])
    const record=await json(model.directory+'/model.json'), tool=record.message?.content.filter(b=>b.type==='tool-call')??[]
    if(tool.length===1&&tool[0].name==='edit_dut') {
      let patch=null,error=null
      try { patch=exactEdit(tool[0].arguments,input.current.source,input.current.revision_id) } catch(e) { error={code:e.message,details:e.details??null} }
      const result=await json(root+'/arms/'+call.arm+'/compare-'+call.task+'/result.json')
      const action=result.actions.find(a=>resolve(a.model_run)===resolve(model.directory))
      if(action?.accepted) {
        assert.ok(patch)
        const revision=result.revisions.find(r=>r.revision===action.revision)
        assert.equal(await readFile(revision.directory+'/solution.sv','utf8'),patch.source)
        guardRepair(patch.source,input.current.source,input.task.interface)
      }
      patches.push({task:call.task,arm:call.arm,model_run:model.directory,arguments:JSON.parse(tool[0].arguments),accepted:action?.accepted??false,
        observation:action?.observation??null,materialization_error:error,code_sha256:patch?repairCodeHash(patch.source):null,untouched_bytes_preserved:patch?.untouched_bytes_preserved??null})
    }
  }
  requests.push({task:call.task,arm:call.arm,phase:call.phase,provider:call.provider,request_file:call.request_file,model_directory:model.directory,
    selected_skills:audit.selected_skills,input_tokens:audit.tokens,input_budget:audit.budget,pending_verification:audit.pending_verification??false,
    context_compacted:audit.context_compacted??false,omissions:audit.omissions})
}
for(const task of taskIds) for(const arm of ['on','off']) {
  const result=await json(root+'/arms/'+arm+'/compare-'+task+'/result.json'), selected=requests.filter(r=>r.task===task&&r.arm===arm)
  const other=await json(root+'/arms/'+(arm==='on'?'off':'on')+'/compare-'+task+'/result.json')
  assert.equal(result.shared_initial_sha256,other.shared_initial_sha256)
  tasks.push({task,arm,terminal:result.status,calls_with_guidance:selected.filter(r=>r.selected_skills.length).length,
    unchanged_rejections:result.actions.filter(a=>a.observation.error==='REPEATED_CANDIDATE').length,
    new_skill_calls:selected.filter(r=>r.selected_skills.includes('rtl.00_diagnostic_reasoning')).length})
}
await put('skill-usage-audit.json',{status:'PASS',tasks,requests,plans,off_requests_with_guidance:0,six_prior_skills_unchanged:true,normal_selector_unchanged:true,
  same_models_and_per_question_budgets:true,guarded_both_arms:true,off_is_naked_baseline:false})
await put('guarded-output-audit.json',{status:'PASS',plans,patches,accepted_patches_recomputed:patches.filter(p=>p.accepted).length,
  plan_previews_never_applied_by_host:true,host_authored_answer_rewrites:0,
  limitation:'Passing constraints does not prove diagnosis/behavior correctness. Fewer coder calls due to a rejected plan are not a successful repair.'})
console.log(JSON.stringify({requests:requests.length,plans:plans.length,valid_plans:plans.filter(p=>p.valid).length,patches:patches.length,accepted_patches:patches.filter(p=>p.accepted).length,new_skill_calls:requests.filter(r=>r.selected_skills.includes('rtl.00_diagnostic_reasoning')).length}))

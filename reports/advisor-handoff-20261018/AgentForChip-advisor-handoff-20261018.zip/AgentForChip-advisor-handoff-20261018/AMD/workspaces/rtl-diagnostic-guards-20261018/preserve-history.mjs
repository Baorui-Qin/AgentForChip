import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { inventory, output } from './selection.mjs'
const roots=['D:/AMD/workspaces/rtl-grounded-minimal-fixed-20261018','D:/AMD/output/rtl-grounded-minimal-fixed-20261018','D:/AMD/workspaces/rtl-plan-effectiveness-audit-20261018','D:/AMD/output/rtl-plan-effectiveness-audit-20261018']
if(process.argv[2]==='before') {
  const files={}
  for(const root of roots) Object.assign(files,await inventory(root))
  await writeFile(output+'/additional-history-before.json',JSON.stringify(files),{flag:'wx'})
  console.log(JSON.stringify({preserved_roots:roots,files:Object.keys(files).length}))
} else {
  const before=JSON.parse(await readFile(output+'/additional-history-before.json','utf8')), files={}
  for(const root of roots) Object.assign(files,await inventory(root))
  assert.deepEqual(files,before)
  await writeFile(output+'/additional-history-preservation.json',JSON.stringify({status:'PASS',roots,files_checked:Object.keys(files).length,unchanged:true}),{flag:'wx'})
  console.log(JSON.stringify({status:'PASS',files:Object.keys(files).length}))
}

import assert from 'node:assert/strict'
import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { skillHash, selectSkills } from './rtl-tools/src/phase1/p09-context.ts'
import { loadP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
import { hash } from './selection.mjs'

const here=dirname(fileURLToPath(import.meta.url)), root=here+'/skill-registry'
const old='D:/AMD/workspaces/rtl-grounded-minimal-fixed-20261018/skill-registry/skills.validated.json'
const entries=JSON.parse(await readFile(old,'utf8'))
const markdown=await readFile(here+'/skills/rtl-diagnostic-reasoning/SKILL.md','utf8')
const rule=markdown.split(/^---\s*$/m).slice(2).join('---').trim()
assert.doesNotMatch(rule,/Prob\d+|q_in|out_always|1101/)
await mkdir(root+'/evidence/diagnostic-guards',{recursive:true})
await copyFile(here+'/skills/rtl-diagnostic-reasoning/SKILL.md',root+'/evidence/diagnostic-guards/SKILL.md')
const evidence=[]
for(const [name,path] of Object.entries({audit:'D:/AMD/output/rtl-plan-effectiveness-audit-20261018/summary.json',feedback:'D:/AMD/output/rtl-plan-effectiveness-audit-20261018/feedback-projection.json',tests:'D:/AMD/output/rtl-diagnostic-guards-20261018/unit-guards.log'})) {
  const bytes=await readFile(path), target='evidence/diagnostic-guards/'+name+(name==='tests'?'.log':'.json')
  await writeFile(root+'/'+target,bytes,{flag:'wx'}); evidence.push({path:target,sha256:hash(bytes)})
}
evidence.push({path:'evidence/diagnostic-guards/SKILL.md',sha256:hash(markdown)})
const entry={id:'rtl.00_diagnostic_reasoning',version:'1.0.0',status:'validated',trigger_tags:['syntax','type_or_port','declaration_order','name_resolution','functional_mismatch','multiple_drivers','unknown'],scope:'Interpret live diagnostic and repair rejection constraints',rule,
  limitations:'Local rule and guard tests only; not proof of model understanding, EDA success or generalization.',source_cases:['frozen-seven-paired-20261018'],validation_records:evidence,content_hash:''}
entry.content_hash=skillHash(entry); entries.push(entry)
await writeFile(root+'/skills.validated.json',JSON.stringify(entries,null,2))
const settings={skillsFile:root+'/skills.validated.json',skillsSha256:hash(await readFile(root+'/skills.validated.json'))}
assert.equal((await loadP09Skills({variant:'C',...settings})).length,7)
for(const tag of entry.trigger_tags) assert.ok(selectSkills(entries,[tag]).some(s=>s.id===entry.id))
await writeFile(root+'/bundle.json',JSON.stringify({status:'LOCAL_TESTS_ONLY_REAL_MODEL_GAIN_UNMEASURED',settings,new_ids:[entry.id],preserved_old_ids:entries.slice(0,-1).map(e=>e.id),previous_skill_registry:old},null,2))
console.log(JSON.stringify({entries:entries.length,new_id:entry.id,normal_selector_reachable:true}))

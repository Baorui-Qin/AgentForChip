"""Select persisted stage evidence without pretending an exception wrote final binding fields."""
import hashlib
import json
from pathlib import Path


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def best_evidence(result, directory):
    reported = result.get('final_verification_run')
    if reported:
        return Path(reported), 'reported_final_binding'
    decisions = result.get('revision_decisions', [])
    decision = decisions[-1] if decisions else None
    if not decision:
        if not result.get('baseline_run'):
            raise RuntimeError('NO_BOUND_STAGE_EVIDENCE:' + str(directory))
        return Path(result['baseline_run']), 'initial_binding_only_no_final_fields'
    revision, source_hash = decision['best_revision_id'], decision['best_source_sha256']
    events = [json.loads(line) for line in (Path(directory) / 'tool-trace.jsonl').read_text(encoding='utf-8').splitlines()]
    matches = [event for event in events if event.get('event') == 'verification' and
               event['revision_id'] == revision and event['source_sha256'] == source_hash]
    if not matches:
        raise RuntimeError('BEST_BINDING_TRACE_MISSING:' + str(directory))
    event = matches[-1]
    run = Path(event['verification_run_id'])
    assert hashlib.sha256((run / 'result.json').read_bytes()).hexdigest() == event['result_sha256']
    assert load(run / 'result.json')['final_source_sha256'] == source_hash
    return run, 'reconstructed_best_binding_from_persisted_revision_trace_not_export'

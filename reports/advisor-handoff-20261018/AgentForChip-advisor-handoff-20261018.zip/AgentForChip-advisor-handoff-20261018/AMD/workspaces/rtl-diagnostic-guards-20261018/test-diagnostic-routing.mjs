import assert from 'node:assert/strict'
import test from 'node:test'
import { readFile, writeFile } from 'node:fs/promises'
import { diagnosticKind, normalizeStage, readDiagnostics } from './rtl-tools/src/phase1/repair-diagnostics.ts'
import { decideRepair } from './rtl-tools/src/phase1/repair-policy.ts'
import { readDiagnostics as oldRead } from '../cloud-agent-questions50-20261017/rtl-tools/src/phase1/repair-diagnostics.ts'
import { decideRepair as oldDecide } from '../cloud-agent-questions50-20261017/rtl-tools/src/phase1/repair-policy.ts'
import { SimulationEvidence } from './rtl-tools/src/phase1/simulation-evidence.ts'
import { taskIds, previous, output } from './selection.mjs'

const context = { calibrated: true, bound: true, attempts: 0, maxAttempts: 2, top: 'TopModule' }
const json = async path => JSON.parse(await readFile(path, 'utf8'))
const replay = []
for (const task of taskIds) {
  const before = await json(previous + '/campaign/compare-' + task + '/result.json')
  const old = await oldRead(before.baseline_run, 'diagnostic_replay')
  const current = await readDiagnostics(before.baseline_run, 'diagnostic_replay')
  // These in-memory clones exercise the pure policy only, never authorize a run.
  const unitLive = receipt => ({ ...structuredClone(receipt), evidence_kind: 'live_verification' })
  const oldDecision = oldDecide(unitLive(old.receipt), context)
  const newDecision = decideRepair(unitLive(current.receipt), context)
  replay.push({ task, before_result: previous + '/campaign/compare-' + task + '/result.json',
    old_receipt: old.receipt, new_receipt: current.receipt, unit_old_decision: oldDecision, unit_new_decision: newDecision,
    replay_is_execution_evidence: false, actual_eda_rerun: false, actual_model_calls: 0 })
  test(task + ': reproduces old block and routes only a synthetic live policy fixture', () => {
    assert.equal(before.status, 'POLICY_BLOCKED')
    assert.equal(oldDecision.rule, 'UNCLASSIFIED_FAILURE')
    assert.equal(newDecision.action, 'propose_repair')
    assert.equal(newDecision.rule, 'DUT_COMPILE')
    assert.equal(decideRepair(current.receipt, context).rule, 'UNTRUSTED_EVIDENCE')
    const failed = current.receipt.stages.find(s => s.status !== 'PASS')
    assert.equal(failed.complete, true)
    assert.equal(failed.process_normal, true)
    assert.equal(failed.process_clean, false)
  })
  for (const origin of ['testbench', 'reference', 'unknown', 'tool']) {
    test(task + ': rejects primary owned by ' + origin, () => {
      const facts = unitLive(current.receipt)
      for (const d of facts.stages.find(s => s.status !== 'PASS').diagnostics) {
        if (d.origin === 'dut') { d.origin = origin; d.repairable_by_model = false; d.attribution = 'UNKNOWN' }
      }
      assert.equal(decideRepair(facts, context).action, 'blocked')
    })
  }
  for (const [label, mutate] of [
    ['incomplete evidence', f => { f.complete = false }],
    ['abnormal process', f => { f.process_normal = false }],
    ['unknown extra error', f => { f.diagnostics.push({ ...f.diagnostics[0], kind: 'unknown', origin: 'unknown', attribution: 'UNKNOWN', repairable_by_model: false }) }],
    ['tool environment error', f => { f.diagnostics.push({ ...f.diagnostics[0], kind: 'tool_environment', origin: 'tool', attribution: 'TOOL_ENVIRONMENT', repairable_by_model: false }) }],
  ]) {
    test(task + ': rejects ' + label, () => {
      const facts = unitLive(current.receipt)
      mutate(facts.stages.find(s => s.status !== 'PASS'))
      assert.equal(decideRepair(facts, context).action, 'blocked')
    })
  }
  for (const [label, patch, expected] of [['uncalibrated', { calibrated: false }, 'blocked'],
    ['unbound', { bound: false }, 'blocked'], ['budget exhausted', { attempts: 2 }, 'stop']]) {
    test(task + ': ' + label, () => assert.equal(decideRepair(unitLive(current.receipt), { ...context, ...patch }).action, expected))
  }
  const failed = current.receipt.stages.find(s => s.status !== 'PASS')
  for (const [label, mutate] of [
    ['other invocation', d => { d.invocation += '-foreign' }],
    ['other source', d => { d.file = 'D:/foreign/solution.sv' }],
    ['other message', d => { d.message += ' unexpected' }],
  ]) {
    test(task + ': refuses consequential summary from ' + label, () => {
      const facts = unitLive(current.receipt)
      const summary = facts.stages.find(s => s.status !== 'PASS').diagnostics.find(d => ['VRFC 10-8530', 'XSIM 43-3322'].includes(d.message_id))
      assert.ok(summary)
      mutate(summary)
      assert.equal(decideRepair(facts, context).action, 'blocked')
    })
  }
  test(task + ': wrong diagnostic code is not routed through the new patterns', () => {
    for (const d of failed.diagnostics.filter(d => ['VRFC 10-1280', 'VRFC 10-5010', 'VRFC 10-3279', 'VRFC 10-3186', 'VRFC 10-2649'].includes(d.message_id))) {
      assert.equal(diagnosticKind('VRFC 99-9999', d.message), 'unknown')
      assert.equal(diagnosticKind(d.message_id, d.message + ' unexpected'), 'unknown')
    }
  })
}

const enumReplay = replay.find(row => row.task === 'Prob096_review2015_fsmseq')
const enumStage = enumReplay.new_receipt.stages.find(s => s.stage === 'elaborate')
const record = (await json(enumReplay.new_receipt.original_run + '/result.json')).stages.elaborate
for (const flag of ['cancelled', 'timed_out', 'log_truncated']) {
  test('normalization refuses elaboration summary shortcut after ' + flag, () => {
    const changed = structuredClone(record)
    for (const invocation of changed.invocations.filter(i => i.version_matches !== true)) invocation.process[flag] = true
    const parsed = enumStage.diagnostics.map(d => ({ ...d, kind: diagnosticKind(d.message_id, d.message), repairable_by_model: false }))
    const normalized = normalizeStage(changed, parsed, new SimulationEvidence(true), true)
    assert.equal(normalized.process_normal, false)
    assert.ok(normalized.diagnostics.filter(d => d.origin === 'dut').every(d => !d.repairable_by_model))
  })
}
test('existing multiple-driver rule retains its exact same-invocation behavior', () => {
  const facts = structuredClone(enumReplay.new_receipt)
  facts.evidence_kind = 'live_verification'
  const stage = facts.stages.find(s => s.stage === 'elaborate')
  const primary = stage.diagnostics.find(d => d.origin === 'dut')
  primary.kind = 'multiple_drivers'; primary.message_id = 'VRFC 10-3818'
  primary.message = "variable 'state' is driven by invalid combination of procedural drivers"
  assert.equal(decideRepair(facts, context).rule, 'DUT_MULTIPLE_DRIVERS')
})
test('missing stage and dirty preceding stage are rejected', () => {
  for (const mutate of [f => f.stages.pop(), f => { f.stages[0].process_clean = false }]) {
    const facts = structuredClone(enumReplay.new_receipt); facts.evidence_kind = 'live_verification'
    mutate(facts)
    assert.equal(decideRepair(facts, context).rule, 'EXECUTION_OR_EVIDENCE')
  }
})
test('replay receipts are retained as non-execution diagnostic evidence', async () => {
  try { await writeFile(output + '/diagnostic-replay.json', JSON.stringify(replay, null, 2), { flag: 'wx' }) }
  catch (error) { if (error.code !== 'EEXIST') throw error; assert.deepEqual(await json(output + '/diagnostic-replay.json'), replay) }
})

import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { output, taskIds } from './selection.mjs'
import { projectedFeedback } from '../rtl-plan-effectiveness-audit-20261018/projection.mjs'
const json=async p=>JSON.parse(await readFile(p,'utf8'))
const indexed=(await json(output+'/planner-coder-evidence.json')).rows
const verifications=await json(output+'/verification-index.json')
const rows=[],decisions=[]
for(const task of taskIds)for(const arm of ['on','off']) {
  const result=await json(output+'/campaign/arms/'+arm+'/compare-'+task+'/result.json')
  decisions.push(...result.revision_decisions.map(d=>({task,arm,...d})))
  for(const [i,prior]of result.actions.entries())if(!prior.accepted) {
    const next=result.actions[i+1]
    if(!next){rows.push({task,arm,prior_index:i+1,terminal_without_followup:true});continue}
    const indexedNext=indexed.find(r=>r.model_run===next.model_run),request=await json(indexedNext.http_request)
    const feedback=projectedFeedback(request,prior)
    const matches=verifications.filter(v=>v.task===task&&v.arm===arm&&v.source_sha256===next.observation.source_sha256)
    const rtlPass=matches.some(v=>['compile','elaborate','simulation','synthesis'].every(s=>v.stages[s].status==='PASS'))
    rows.push({task,arm,prior_index:i+1,prior_error:prior.observation.error,next_index:i+2,next_tool:next.tool,
      next_accepted:next.accepted,next_model_run:next.model_run,next_request:indexedNext.http_request,feedback,
      new_edit_after_refusal:next.accepted&&next.tool==='edit_dut',
      verified_rtl_recovery:next.accepted&&next.tool==='edit_dut'&&rtlPass})
  }
}
const value={status:'EVIDENCE_AUDIT_PASS',tool_refusals:rows.length,followups:rows.filter(r=>!r.terminal_without_followup).length,
  feedback_delivered:rows.filter(r=>r.feedback?.delivered).length,
  changed_to_accepted_edit:rows.filter(r=>r.new_edit_after_refusal).length,
  verified_rtl_recoveries:rows.filter(r=>r.verified_rtl_recovery).length,rows,revision_decisions:decisions,
  limitation:'Only the three verify-without-pending refusals occurred in this batch. Concrete anchor and cosmetic-replay refusals were tested offline, not re-observed as real-model recovery opportunities.'}
assert.equal(rows.length,3)
await writeFile(output+'/recovery-effectiveness.json',JSON.stringify(value,null,2),{flag:'wx'})
console.log(JSON.stringify({refusals:value.tool_refusals,feedback:value.feedback_delivered,recovered:value.verified_rtl_recoveries,decisions:decisions.length}))

/** Resume only unissued coder steps after the probe's missing-model-directory bootstrap failure. */
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { randomUUID } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import { runCommand } from './rtl-tools/src/process.ts'
import { vivadoArgv } from './rtl-tools/src/synthesis.ts'
import { VivadoDiagnostics } from './rtl-tools/src/vivado-parser.ts'
import { readP09Settings, loadP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
import { callAction, type AutoSettings } from './rtl-tools/src/phase1/p09-action-call.ts'
import { exactEdit } from './rtl-tools/src/phase1/p10-exact-edit.ts'
import { checkAutoSource, parseAutoAction } from './rtl-tools/src/phase1/p09-auto-policy.ts'
import { sourceLocations, planLocation } from './rtl-tools/src/phase1/p10-grounding.ts'
import { sha256 } from './rtl-tools/src/phase1/snapshots.ts'
import type { ContextInput } from './rtl-tools/src/phase1/p09-context.ts'
import { capabilityFixtures } from './capability-fixtures.ts'

export const name = 'rtl-capability-coder-resume'
export const inject = ['cmdlineArgs', 'appReady', 'subprocess', 'llm']
const put = (path: string, value: unknown) => writeFile(path, JSON.stringify(value, null, 2), { flag: 'wx' })

/** Resume a frozen failed probe without overwriting its input, planning or failure records. */
export function apply(ctx: Context, config: { root: string; arm: 'on' | 'off'; freeze: string }): void {
  if (ctx.cmdlineArgs!.get().join(' ') !== 'capability-resume') throw new Error('CAPABILITY_RESUME_COMMAND_REQUIRED')
  const controller = new AbortController(); let pending: Promise<void> | undefined
  ctx.effect(() => async () => { controller.abort(); await pending })
  ctx.effect(() => ctx.get('appReady')!.onReady(() => {
    pending = run(ctx, config, controller.signal).then(() => ctx.get('appExit')!(0)).catch(error => {
      process.stderr.write(String(error) + '\n'); ctx.get('appExit')!(1)
    })
  }))
}

async function run(ctx: Context, config: { root: string; arm: 'on' | 'off'; freeze: string }, caller: AbortSignal) {
  const { root, arm } = config, armRoot = join(root, 'arms', arm), probe = join(root, 'capability-resume', arm)
  await mkdir(probe, { recursive: true })
  const frozenBytes = await readFile(config.freeze), frozen = JSON.parse(frozenBytes.toString()) as { files: Record<string, string>; deadline: string }
  const assertFreeze = async () => {
    if (sha256(await readFile(config.freeze)) !== sha256(frozenBytes)) throw new Error('RESUME_FREEZE_CHANGED')
    for (const [file, digest] of Object.entries(frozen.files)) if (sha256(await readFile(file)) !== digest) throw new Error('RESUME_SOURCE_CHANGED')
  }
  await assertFreeze()
  const identity = JSON.parse(await readFile(join(root, 'cloud-identity.json'), 'utf8'))
  const auto = JSON.parse(await readFile(join(armRoot, 'auto.json'), 'utf8')) as AutoSettings
  auto.llama = { baseURL: 'http://127.0.0.1:18081/v1', identity: identity.coder }
  const p09 = await readP09Settings(join(armRoot, 'p09.json')), results = []
  for (const fixture of capabilityFixtures) {
    const prior = join(root, 'capability', arm, fixture.id)
    const failed = JSON.parse(await readFile(join(prior, 'result.json'), 'utf8'))
    if (!failed.status.startsWith('ENOENT:') || failed.patch_accepted || !failed.plan) throw new Error('RESUME_NOT_UNISSUED_CODER_STEP')
    const input = JSON.parse(await readFile(join(prior, 'input.json'), 'utf8')) as ContextInput
    const plan = failed.plan as NonNullable<ContextInput['planning']>
    if (sha256(plan.text) !== plan.plan_sha256 || plan.source_sha256 !== sha256(input.current!.source) || plan.feedback_sha256 !== sha256(JSON.stringify(input.feedback))) throw new Error('RESUME_PLAN_BINDING_INVALID')
    input.planning = plan
    const directory = join(probe, fixture.id)
    await mkdir(join(directory, 'models'), { recursive: true })
    await put(join(directory, 'input.json'), input)
    const remaining = Math.min(240000, Date.parse(frozen.deadline) - Date.now())
    if (remaining <= 0) throw new Error('CAMPAIGN_TIME_BUDGET')
    const signal = AbortSignal.any([caller, AbortSignal.timeout(remaining)])
    const experiment = input.sample_id, result: Record<string, unknown> = {
      task: fixture.id, arm, status: 'NOT_REPAIRED', resumed_from: join(prior, 'result.json'), cached_plan: plan,
      new_planner_calls: 0, bootstrap_error_not_model_failure: true, oracle_not_in_request: true,
      plan_citation_matched: planLocation(plan.text, sourceLocations(input)).matched,
      plan_explanation_keyword_check: fixture.causeWords.test(JSON.parse(plan.text).cause),
      patch_accepted: false, minimal_changed_spans: false, verification_requested: false, passed: false }
    try {
      const call = (view: ContextInput, sequence: number) => callAction({ root: directory, experiment, sequence, input: view, history: [], auto,
        p09: { ...p09, limits: { ...p09.limits, window: 8192, output: 2048 } },
        model: { provider: 'cloud-coder', model: 'siliconmind-qwen3-8b', maxTokens: 2048, maxResponseBytes: 65536, temperature: 0, timeoutMs: 60000 },
        runtime: ctx.llm, subprocess: ctx.subprocess, signal, maxEventBytes: 1048576, loadSkills: () => loadP09Skills(p09), expectedRequestHash: null, claim: async () => {} })
      const response = await call(input, 1), calls = response.message?.content.filter(b => b.type === 'tool-call') ?? []
      if (response.error_code || calls.length !== 1 || calls[0]!.name !== 'edit_dut') throw new Error(response.error_code ?? 'CAPABILITY_EDIT_REQUIRED')
      const patch = exactEdit(calls[0]!.arguments, input.current!.source, input.current!.revision_id)
      checkAutoSource(patch.source, input.task.interface)
      result.patch = patch; result.patch_accepted = true
      result.minimal_changed_spans = patch.spans.every(span => {
        let left = 0, right = 0
        while (left < Math.min(span.before.length, span.after.length) && span.before[left] === span.after[left]) left++
        while (right < Math.min(span.before.length, span.after.length) - left && span.before.at(-1 - right) === span.after.at(-1 - right)) right++
        return fixture.allowed.some(text => { const start = fixture.source.indexOf(text); return span.start + left >= start && span.end - right <= start + text.length })
      })
      const revision = randomUUID(), pending: ContextInput = { ...input, current: { revision_id: revision, source_sha256: sha256(patch.source), source: patch.source },
        feedback: null, binding: null, pending_verification: true }
      const verification = await call(pending, 2), verifyCalls = verification.message?.content.filter(b => b.type === 'tool-call') ?? []
      if (verification.error_code || verifyCalls.length !== 1) throw new Error(verification.error_code ?? 'CAPABILITY_VERIFY_REQUIRED')
      const action = parseAutoAction(verifyCalls[0]!.name, verifyCalls[0]!.arguments)
      if (action.name !== 'verify_rtl' || action.revision_id !== revision || action.test_suite_id !== fixture.id) throw new Error('CAPABILITY_VERIFY_REQUIRED')
      result.verification_requested = true
      const cwd = join(directory, 'candidate'); await mkdir(cwd)
      await writeFile(join(cwd, 'solution.sv'), patch.source, { flag: 'wx' })
      await writeFile(join(cwd, 'tb.sv'), fixture.tb, { flag: 'wx' })
      const stages = [], parser = new VivadoDiagnostics(32, 4096), cmd = await ctx.subprocess.resolveExecutable('cmd.exe', undefined, signal)
      for (const [stage, tool, argv] of [ ['compile', 'xvlog', ['--sv', 'solution.sv', 'tb.sv']],
        ['elaborate', 'xelab', ['tb', '-s', 'probe_snapshot']], ['simulation', 'xsim', ['probe_snapshot', '-runall']]
      ] as [string, string, string[]][]) {
        const executable = await ctx.subprocess.resolveExecutable('D:/AMDDesignTools/2026.1/Vivado/bin/' + tool + '.bat', undefined, signal)
        const process = await runCommand(ctx.subprocess, { timeoutMs: 30000, graceMs: 1000, maxLogBytes: 1048576, maxLineChars: 4096, stopOnLogLimit: true },
          vivadoArgv(executable, argv, globalThis.process.platform, cmd), cwd, stage, signal, parser)
        if (process.timedOut || process.aborted || process.signal || process.logTruncated || parser.environmentFailure) throw new Error('CAPABILITY_EDA_INFRA_FAILURE')
        stages.push({ stage, process }); if (process.exitCode !== 0 || parser.errorSeen) break
      }
      const simulation = stages.find(s => s.stage === 'simulation'), text = simulation ? await readFile(simulation.process.stdoutLog, 'utf8') : ''
      const verdict = /CAPABILITY_CHECKS=(\d+) MISMATCHES=(\d+)/.exec(text)
      result.eda = { stages, errors: parser.errors, checks: verdict ? Number(verdict[1]) : null, mismatches: verdict ? Number(verdict[2]) : null }
      result.passed = !!verdict && Number(verdict[1]) === 8 && Number(verdict[2]) === 0
      result.status = result.passed ? 'REPAIRED' : 'EDA_FAILED'
    } catch (error) {
      const code = error instanceof Error ? error.message : 'CAPABILITY_UNKNOWN'
      if (/ENOENT|EACCES|EPERM|CAMPAIGN_|TOKENIZER_|IDENTITY|TRANSPORT|HOST_OR_MODEL|CAPABILITY_EDA_INFRA/.test(code)) throw error
      result.status = code
    }
    await put(join(directory, 'result.json'), result); results.push(result)
  }
  await assertFreeze()
  await put(join(probe, 'results.json'), { status: 'COMPLETED', controls: 3, results, cached_plans_reused: true,
    note: 'Only coder steps that never dispatched were resumed; no new planner call, no question rerun or task-budget reset.' })
}

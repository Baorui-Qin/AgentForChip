import assert from 'node:assert/strict'
import { readFile, stat, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { output, hash } from './selection.mjs'
const json = async p => JSON.parse(await readFile(p, 'utf8'))
const ready = await json(output + '/local-readiness.json'), cloud = await json(output + '/cloud-execution-status.json')
assert.equal(ready.current_inference_calls, 0)
assert.equal(cloud.execution_started, false)
const preservation = await json(output + '/preservation.json')
assert.ok(Object.values(preservation.checks).every(Boolean))
const previous = {}
for (const name of ['previous', 'control', 'skills', 'recovery', 'budgetfit']) {
  previous[name] = await json(output + '/' + name + '-round-preservation.json')
  assert.ok(previous[name].unchanged)
}
const frozen = await json(output + '/campaign/preflight/freeze.json')
for (const [p, digest] of Object.entries(frozen.files)) assert.equal(hash(await readFile(p)), digest, p)
for (const name of ['semantic', 'preflight']) {
  const process = await json(output + '/' + name + '-driver-process.json')
  assert.ok(process.reaped && process.exit_code === 0 && !process.watchdog_timeout)
}
const report = await readFile(output + '/PRE_RUN_REPORT.zh.md', 'utf8'), links = []
for (const match of report.matchAll(/\]\(([^)]+)\)/g)) {
  const target = resolve(output, match[1]); await stat(target); links.push(target)
}
const result = { status: 'LOCAL_VALIDATION_AND_PRESERVATION_PASS_CLOUD_PENDING_AUTHORIZATION',
  local_tests_passed: ready.local_tests_passed, generic_eda_controls_passed: 10, task_eda_controls_passed: 16,
  frozen_inputs_rechecked: Object.keys(frozen.files).length, original_entries_checked: preservation.original_entries_checked,
  protected_previous_output_roots: Object.keys(previous).length, unchanged_previous_files: Object.values(previous).reduce((sum, r) => sum + r.files_checked, 0),
  original_uncommitted_changes_preserved: true, handoff_unchanged: true, real_inference_calls: 0,
  actual_cloud_comparison_done: false, local_processes_reaped: true, report_links_checked: links.length,
  full_typecheck_passed: false, introduced_type_diagnostics: 0, official_score: null }
await writeFile(output + '/local-delivery-verification.json', JSON.stringify(result, null, 2), { flag: 'wx' })
console.log(JSON.stringify(result))

import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { inventory, output, previous, control, skillPrevious, recoveryPrevious, budgetfitPrevious, hash } from './selection.mjs'

const json = async path => JSON.parse(await readFile(path, 'utf8'))
const phase = process.argv[2]
assert.ok(['before', 'after'].includes(phase))
const frozen = await json(output + '/campaign/' + (phase === 'after' ? 'campaign-freeze.json' : 'preflight/freeze.json'))
for (const [path, digest] of Object.entries(frozen.files)) assert.equal(hash(await readFile(path)), digest, path)
const protectedRoots = {}
for (const [name, root] of Object.entries({ previous, control, skills: skillPrevious, recovery: recoveryPrevious, budgetfit: budgetfitPrevious })) {
  const original = await json(output + '/' + name + '-round-before.json'), current = await inventory(root)
  assert.deepEqual(current, original, root)
  protectedRoots[name] = { root, files_checked: Object.keys(original).length, unchanged: true }
}
if (phase === 'after') {
  const preservation = await json(output + '/continuation-preservation/preservation.json')
  assert.equal(preservation.status, 'PASS')
}
await writeFile(output + '/continuation-' + phase + '-checks.json', JSON.stringify({ phase, checked_at: new Date().toISOString(),
  status: 'PASS', frozen_inputs_checked: Object.keys(frozen.files).length, protected_roots: protectedRoots }, null, 2), { flag: 'wx' })
console.log(JSON.stringify({ phase, protected_previous_roots: 5, frozen_inputs_checked: Object.keys(frozen.files).length, status: 'PASS' }))

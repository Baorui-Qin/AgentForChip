import assert from 'node:assert/strict'
import test from 'node:test'
import { readFile, writeFile } from 'node:fs/promises'
import { sourceLocations, planLocation } from './rtl-tools/src/phase1/p10-grounding.ts'
import { exactEdit } from './rtl-tools/src/phase1/p10-exact-edit.ts'
import { autoTools } from './rtl-tools/src/phase1/p09-auto-policy.ts'
import { buildContext } from './rtl-tools/src/phase1/p09-context.ts'
import { hash, output, semanticPrevious } from './selection.mjs'

const base = JSON.parse(await readFile(semanticPrevious + '/skills-unit-request-snapshot.json', 'utf8')).input
const source = 'module Example;\n/* retained\n comment */\ntypedef enum logic [1:0] {A=0,B=1} tag_t;\ntag_t current;\nlogic [1:0] stored;\nassign current = stored; // wrong type\nendmodule\n'
const input = () => {
  const value = structuredClone(base)
  value.edit_protocol = 'exact-replacements'
  value.current.source = source; value.current.source_sha256 = value.binding.source_sha256 = hash(source)
  Object.assign(value.feedback.stages[0].diagnostics[0], { line: 7, message_id: 'VRFC 10-2649', message: 'enum type assignment error', kind: 'type_or_port' })
  return value
}
const patch = replacements => JSON.stringify({ expected_revision_id: 'current-revision', replacements })

test('locates the actual assignment and operand references without changing source', () => {
  const value = input(), before = structuredClone(value), rows = sourceLocations(value)
  assert.deepEqual(rows, [{ line: 7, code: 'assign current = stored;', references: [{ line: 5, code: 'tag_t current;' }, { line: 6, code: 'logic [1:0] stored;' }] }])
  assert.deepEqual(value, before)
})
for (const name of ['pending', 'no-receipt', 'foreign-origin', 'invalid-line', 'legacy']) test('does not invent a location for ' + name, () => {
  const value = input()
  if (name === 'pending') value.pending_verification = true
  if (name === 'no-receipt') value.feedback = null
  if (name === 'foreign-origin') value.feedback.stages[0].diagnostics[0].origin = 'testbench'
  if (name === 'invalid-line') value.feedback.stages[0].diagnostics[0].line = 999
  if (name === 'legacy') delete value.edit_protocol
  assert.deepEqual(sourceLocations(value), [])
})
for (const [cause, expected] of [ ['L7: assign current = stored; enum/vector mismatch', true],
  ['L6: assign current = stored; enum/vector mismatch', false], ['L7: next = state; enum/vector mismatch', false] ]) {
  test('literal plan citation: ' + cause, () => {
    const result = planLocation(JSON.stringify({ cause }), sourceLocations(input()))
    assert.equal(result.matched, expected); assert.equal(result.semantics_verified, false)
  })
}
test('applies only model-selected unique disjoint replacements, preserving all other bytes', () => {
  const result = exactEdit(patch([{ before: 'logic [1:0] stored;', after: 'tag_t stored;' }]), source, 'current-revision')
  assert.equal(result.source, source.replace('logic [1:0] stored;', 'tag_t stored;'))
  assert.equal(result.untouched_bytes_preserved, true)
})
test('multiple edits refer to original source, not a previous replacement', () => {
  const result = exactEdit(patch([{ before: 'red', after: 'green' }, { before: 'blue', after: 'black' }]), 'red blue', 'current-revision')
  assert.equal(result.source, 'green black')
})
test('a genuine repair with an unchanged disjoint context is not an unchanged candidate', () => {
  const value = exactEdit(patch([{ before: 'value, <= data;', after: 'value <= data;' }, { before: 'hold;', after: 'hold;' }]), 'value, <= data; hold;', 'current-revision')
  assert.equal(value.source, 'value <= data; hold;')
  assert.equal(value.untouched_bytes_preserved, true)
})
for (const [name, value, original, code] of [
  ['stale revision', JSON.stringify({ expected_revision_id: 'stale', replacements: [{ before: 'ab', after: 'xy' }] }), 'abc', 'PATCH_REVISION_REJECTED'],
  ['ambiguous anchor', patch([{ before: 'ab', after: 'xy' }]), 'ab ab', 'PATCH_ANCHOR_NOT_UNIQUE'],
  ['missing anchor', patch([{ before: 'missing', after: 'xy' }]), 'abc', 'PATCH_ANCHOR_NOT_UNIQUE'],
  ['overlap', patch([{ before: 'abc', after: 'xy' }, { before: 'bc', after: 'z' }]), 'abc', 'PATCH_OVERLAP'],
  ['no-op', patch([{ before: 'ab', after: 'ab' }]), 'abc', 'REPEATED_CANDIDATE'],
  ['empty anchor', patch([{ before: '', after: 'x' }]), 'abc', 'INVALID_PATCH'],
  ['extra fields', JSON.stringify({ expected_revision_id: 'current-revision', replacements: [{ before: 'ab', after: 'x', reason: 'fix' }] }), 'abc', 'INVALID_PATCH'],
  ['partial JSON', '{', 'abc', null],
]) test('refuses ' + name + ' without inventing repair text', () => assert.throws(() => exactEdit(value, original, 'current-revision'), code ? new RegExp(code) : undefined))

test('exact tool schema does not offer a full-source field and pending mode is verify-only', () => {
  const tools = autoTools('full', false, { revision_id: 'r', test_suite_id: 't' }, false, 'exact')
  const schema = tools.find(t => t.name === 'edit_dut').parameters
  assert.ok(schema.properties.replacements); assert.equal(schema.properties.source, undefined)
  assert.deepEqual(autoTools('full', true, undefined, false, 'exact').map(t => t.name), ['verify_rtl'])
})
test('exact context is fully counted and exposes no inferred answer', async () => {
  const value = input()
  const counter = { quality: 'estimated', identity: { implementation: 'keyless-test-only' }, count: async v => Math.ceil(Buffer.byteLength(v.system + v.prompt) / 4) }
  const limits = { window: 8192, output: 2048, margin: 1024, feedback: 2048, ledger: 512, skills: 768, sourceWarning: 3072 }
  const view = await buildContext(value, limits, counter, new AbortController().signal)
  const payload = JSON.parse(view.prompt)
  assert.equal(payload.current.source, source)
  assert.deepEqual(payload.source_locations, sourceLocations(value))
  assert.ok(view.audit.tokens <= 5120)
  await writeFile(output + '/grounded-minimal-unit-snapshot.json', JSON.stringify({ value, view, evidence: 'keyless-estimated-counter-not-real-model-test' }, null, 2), { flag: 'wx' })
})

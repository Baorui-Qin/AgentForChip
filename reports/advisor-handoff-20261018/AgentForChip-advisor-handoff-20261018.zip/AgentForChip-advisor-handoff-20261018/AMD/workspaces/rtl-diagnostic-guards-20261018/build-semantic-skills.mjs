import assert from 'node:assert/strict'
import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { skillHash } from './rtl-tools/src/phase1/p09-context.ts'
import { loadP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
import { hash, budgetfitPrevious, taskIds } from './selection.mjs'
import { semanticExamples } from './test-semantic-rules.mjs'

const here = dirname(fileURLToPath(import.meta.url)), root = join(here, 'skill-registry')
const json = async p => JSON.parse(await readFile(p, 'utf8'))
const put = async (p, v) => writeFile(p, JSON.stringify(v, null, 2), { flag: 'wx' })
const oldRoot = 'D:/AMD/workspaces/rtl-budgetfit-ablation-20261017/skill-registry'
const prior = await json(oldRoot + '/skills.validated.json')
await mkdir(root + '/evidence/semantic-review')
const history = []
for (const task of taskIds) for (const arm of ['on', 'off']) {
  const path = budgetfitPrevious + '/campaign/arms/' + arm + '/compare-' + task + '/result.json'
  history.push({ task, arm, path, sha256: hash(await readFile(path)), status: (await json(path)).status })
}
await put(root + '/evidence/semantic-review/reviewed-results.json', history)
await put(root + '/evidence/semantic-review/validation.json', { ...semanticExamples(), model_calls: 0,
  eda_calls: 0, generalization_tested: false, limitation: 'Reviewed generic rules; validated evidence does not establish a model gain.' })
const records = await Promise.all(['reviewed-results.json', 'validation.json'].map(async name => ({
  path: 'evidence/semantic-review/' + name, sha256: hash(await readFile(root + '/evidence/semantic-review/' + name)) })))
const definitions = [
  { id: 'rtl.interface_type_repair', folder: 'rtl-interface-type-repair', version: '2.0.0', scope: 'Fixed-interface enum and width-sensitive assignments' },
  { id: 'rtl.assignment_integrity', folder: 'rtl-assignment-integrity', version: '1.0.0', scope: 'Complete changed RTL assignment statements' },
]
const entries = structuredClone(prior)
for (const d of definitions) {
  const file = join(here, 'skills', d.folder, 'SKILL.md'), markdown = await readFile(file, 'utf8')
  const rule = markdown.split(/^---\s*$/m).slice(2).join('---').trim()
  assert.doesNotMatch(rule, /Prob\d+|1101|q_in|out_always|TopModule\s*\(/)
  const evidence = 'evidence/semantic-review/' + d.folder + '.md'
  await copyFile(file, join(root, evidence))
  const entry = { id: d.id, version: d.version, status: 'validated',
    trigger_tags: ['syntax', 'type_or_port', 'declaration_order', 'name_resolution', 'functional_mismatch'],
    scope: d.scope, rule, limitations: 'Apply relevant clauses only. Guidance is not verification or permission to change trusted assets.',
    source_cases: history.map(r => r.task + ':' + r.arm + ':' + r.sha256),
    validation_records: [...records, { path: evidence, sha256: hash(markdown) }], content_hash: '' }
  entry.content_hash = skillHash(entry)
  const index = entries.findIndex(e => e.id === d.id)
  if (index < 0) entries.push(entry)
  else entries[index] = entry
}
await writeFile(root + '/skills.validated.json', JSON.stringify(entries, null, 2))
const settings = { skillsFile: (root + '/skills.validated.json').replaceAll('\\', '/'),
  skillsSha256: hash(await readFile(root + '/skills.validated.json')) }
assert.equal((await loadP09Skills({ variant: 'C', ...settings })).length, 6)
await writeFile(root + '/bundle.json', JSON.stringify({ status: 'LOCAL_RULE_REVIEW_ONLY_MODEL_EFFECT_NOT_YET_MEASURED', settings,
  new_ids: ['rtl.assignment_integrity', 'rtl.interface_type_repair'], added_ids: ['rtl.assignment_integrity'],
  revised_ids: ['rtl.interface_type_repair'], preserved_old_ids: prior.filter(e => e.id !== 'rtl.interface_type_repair').map(e => e.id),
  previous_skill_registry: oldRoot + '/skills.validated.json', previous_skill_sha256: hash(await readFile(oldRoot + '/skills.validated.json')),
  runtime_integration: 'normal C diagnostic selection for planner and coder; B and generation have no guidance; max two rules unchanged' }, null, 2))
console.log(JSON.stringify({ registry: settings.skillsFile, entries: entries.length, new_rules_locally_reviewed: true }))

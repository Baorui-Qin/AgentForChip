import assert from 'node:assert/strict'
import { readFile, readdir, writeFile } from 'node:fs/promises'
import { hash, groundedPrevious } from './selection.mjs'
const json = async p => JSON.parse(await readFile(p, 'utf8'))
const freeze = await json(groundedPrevious + '/campaign/campaign-freeze.json')
const used = {}, files = {}
for (const arm of ['on', 'off']) {
  const root = groundedPrevious + '/campaign/arms/' + arm + '/dispatches'
  const names = (await readdir(root)).filter(p => p.endsWith('.json'))
  used[arm] = names.length
  for (const name of names) files[root + '/' + name] = hash(await readFile(root + '/' + name))
}
assert.deepEqual(used, { on: 44, off: 41 })
const remaining = Math.min(...Object.values(used).map(n => 100 - n))
assert.ok(remaining > 0 && Date.parse(freeze.protocol.deadline) > Date.now())
const value = { previous_output: groundedPrevious, original_per_arm_limit: 100, previous_used: used,
  same_remaining_limit_both_arms: remaining, deadline: freeze.protocol.deadline, no_deadline_reset: true,
  per_question_limits_unchanged_per_independent_run: true, previous_claim_files: files,
  note: 'The failed diagnostic generation is preserved. The corrected independent comparison uses the remaining pool, not a new 100-call allowance; both generations are reported separately.' }
await writeFile(new URL('./continuation-budget.json', import.meta.url), JSON.stringify(value, null, 2), { flag: 'wx' })
console.log(JSON.stringify({ remaining, used, deadline: value.deadline }))

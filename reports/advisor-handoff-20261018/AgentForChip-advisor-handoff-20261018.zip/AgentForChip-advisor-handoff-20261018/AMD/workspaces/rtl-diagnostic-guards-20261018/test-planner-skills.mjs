import assert from 'node:assert/strict'
import test from 'node:test'
import { readFile, readdir } from 'node:fs/promises'
import { output } from './selection.mjs'
for (const arm of ['on', 'off', 'generation']) test('real-planner snapshot: ' + arm, async () => {
  const paths = (await readdir(output + '/unit-loop')).filter(p => p.startsWith('planner-skills-' + arm) && p.endsWith('.json'))
  assert.ok(paths.length)
  for (const path of paths) {
  const record = JSON.parse(await readFile(output + '/unit-loop/' + path, 'utf8'))
  assert.deepEqual(record.input.guidance.map(e => e.id), arm === 'on' ? ['rtl.assignment_integrity', 'rtl.interface_type_repair'] : [])
  if (arm === 'off') assert.equal(record.skill_storage_reads, 0)
  assert.ok(record.input.task.spec)
  if (arm !== 'generation') assert.ok(record.input.current.source && record.input.observed)
  assert.doesNotMatch(JSON.stringify(record.input.guidance), /Prob\d+|source_cases|validation_records|q_in/)
  }
})

import { readFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { Config as ModelConfig } from './rtl-tools/src/phase1/p10-model.ts'
import { Config as LlamaConfig } from './rtl-tools/src/phase1/p10-llama.ts'
import { assertProfileBudgets } from './p10-profile.mjs'

const json = async path => JSON.parse(await readFile(path, 'utf8'))

/** Use the actual Harness schemas without mounting plugins, networking or running EDA. */
export function validateProfile(value) {
  ModelConfig(value.config)
  LlamaConfig(value.llama)
  assertProfileBudgets(value)
  return { status: 'PASS', model_calls: 0, eda_runs: 0, budgets: value.budgets }
}

export async function validateProfileFiles(root) {
  const results = {}, normalized = []
  for (const arm of ['on', 'off']) {
    const patch = await json(join(root, `dsh-home/profiles/rtl-p10-model-${arm}/cordis.patch.yml`)), rows = patch[0].insert
    const value = { config: rows.find(row => row.id === 'p10-model').config,
      llama: rows.find(row => row.id === 'llama').config, p09: await json(join(root, `arms/${arm}/p09.json`)),
      budgets: await json(join(root, 'p10-budgets.json')), identity: await json(join(root, 'cloud-identity.json')) }
    const auto = await json(value.config.autoFile)
    if (auto.editMode !== 'exact') throw new Error('EXACT_EDIT_PROFILE_REQUIRED')
    if (value.p09.variant !== (arm === 'on' ? 'C' : 'B')) throw new Error('ARM_VARIANT_MISMATCH')
    results[arm] = validateProfile(value)
    const equal = JSON.parse(JSON.stringify(value).replaceAll('/arms/' + arm, '/arms/ARM'))
    delete equal.p09.variant
    normalized.push(JSON.stringify(equal))
  }
  if (normalized[0] !== normalized[1]) throw new Error('ARM_CONFIG_DRIFT')
  return { status: 'PASS', model_calls: 0, eda_runs: 0, same_except_variant_and_owned_paths: true, arms: results }
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  console.log(JSON.stringify(await validateProfileFiles(resolve(process.argv[2])), null, 2))
}

# Diagnostic Skill and Repair Constraints

This independent successor preserves both the preceding seven-task experiment and the offline effectiveness audit. It does not edit answers or update the handoff. Prior outputs demonstrate contradictory or ineffectual proposals, not direct evidence of the model's private understanding.

Repair planning now uses 1-3 exact before/after objects, within the original 1200-character object limit and 1024-token planner output limit. The Host previews those MODEL-AUTHORED edits without changing the live DUT. It rejects no-code-change plans, ambiguous/missing spans, fixed-interface violations and definite literal packed-enum capacity/uniqueness errors. Legacy one-shot planning remains unchanged. Unknown enum expressions/forms are explicitly reported as unknown and still require EDA; the checker is not a complete HDL parser.

The coder still authors its own edits through edit_dut. The same guards validate candidates. Refusals identify the port or replacement index, missing/ambiguous kind, count and up to three occurrence lines. Session-local token fingerprints reject cosmetic replays of earlier rejected candidates. No host code supplies an alternative repair. Real EDA and rollback remain authoritative.

The new diagnostic-reasoning skill maps observed VRFC errors and tool refusals to general reasoning obligations. It contains no task IDs or answers, is selected through the existing C diagnostic selector, and is absent in B. The six prior rules are preserved. The local validated flag means reviewed/tested guidance, not measured model improvement.

Both current arms use identical guards, models and per-question budgets: two accepted modifications, eight coder requests, four plan bindings, 240-second activity budget, 8192 contexts, 1024 margin, planner output 1024, coder output 2048. The single original planner format recovery also covers constraint rejection; no extra recovery allowance is granted. Six off-target real-model controls precede the same seven imported initials, with alternating ON/OFF order.

This NEW user-requested experiment freezes a separate 100-dispatch allowance per arm and a 60-minute deadline, including the controls. It does not resume or alter the expired preceding experiment. The contemporaneous contrast measures skill ON/OFF under shared new guards. Historical before/after results are descriptive and cannot isolate the effect of guards from format changes or prove statistical causality.

Run focused tests, build-diagnostic-skill.mjs, selection.mjs, experiment.mjs prepare, main_run.py preflight, then main_run.py models. Only dsh profiles launch applications. The local Vivado 2026.1 / pinned 2025.2 netlist-library mismatch remains unchanged; this is development evidence, not official competition scoring or single-32GB compliance.

import assert from 'node:assert/strict'
import test from 'node:test'
import { readFile, writeFile } from 'node:fs/promises'
import { buildContext } from './rtl-tools/src/phase1/p09-context.ts'
import { buildContext as previousBuild } from '../rtl-repair-skills7-20261017/rtl-tools/src/phase1/p09-context.ts'
import { loadP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
import { unchangedFeedback } from './rtl-tools/src/phase1/p10-repair-recovery.ts'
import { output } from './selection.mjs'

const json = async path => JSON.parse(await readFile(path, 'utf8'))
const fixture = await json(output + '/skills-unit-request-snapshot.json')
const settings = { ...await json('D:/AMD/output/rtl-recovery-ablation-20261017/campaign/arms/on/p09.json'),
  ...(await json(new URL('./skill-registry/bundle.json', import.meta.url))).settings }
const counter = { quality: 'estimated', identity: { implementation: 'keyless-regression-snapshot-not-native-count-or-execution' },
  count: async view => Math.ceil(Buffer.byteLength(view.system + view.prompt) / 4) }
const snapshots = []
for (const kind of ['type_or_port', 'functional_mismatch']) {
  test('compressed ' + kind + ' keeps reviewed guidance instead of unconditional omission', async () => {
    const input = structuredClone(fixture.input)
    input.core_only = true
    input.feedback.stages[0].diagnostics[0].kind = kind
    const args = [input, settings.limits, counter, new AbortController().signal, () => loadP09Skills(settings)]
    const before = await previousBuild(...args), after = await buildContext(...args)
    assert.deepEqual(before.audit.selected_skills, [])
    assert.equal(after.audit.selected_skills.length, 2)
    assert.equal(before.audit.core_sha256, after.audit.core_sha256)
    assert.equal(JSON.parse(before.prompt).current.source, JSON.parse(after.prompt).current.source)
    snapshots.push({ kind, input, before, after })
  })
}
test('corrective no-change observation reaches the next keyless request', async () => {
  const input = structuredClone(fixture.input)
  input.previous_tool_result = { tool: 'edit_dut', accepted: false, observation: unchangedFeedback(input) }
  input.action_error = 'REPEATED_CANDIDATE: submit a genuinely changed DUT for the bound failure; keep the trusted interface.'
  const view = await buildContext(input, settings.limits, counter, new AbortController().signal, () => loadP09Skills(settings))
  const payload = JSON.parse(view.prompt)
  assert.equal(payload.planning, undefined)
  assert.match(payload.host_action_error, /REPEATED_CANDIDATE/)
  assert.equal(payload.previous_tool_result.observation.unchanged_source_sha256, input.current.source_sha256)
  snapshots.push({ kind: 'unchanged-recovery', input, view })
  await writeFile(output + '/keyless-recovery-snapshots.json', JSON.stringify({ evidence: 'synthetic-keyless-request-regression-not-model-or-eda', snapshots }, null, 2), { flag: 'wx' })
})

"""Verify evidence completeness and unchanged budgets, not model repair success."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

OUT = Path('D:/AMD/output/rtl-diagnostic-guards-20261018')


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


summary, usage, capability, patches = (load(OUT / name) for name in
    ('comparison-summary.json', 'skill-usage-audit.json', 'capability-audit.json', 'exact-edit-grounding-audit.json'))
assert summary['tasks'] == summary['same_initials'] == 7 and summary['arm_runs'] == 14
assert summary['new_generation_calls'] == 0 and not summary['off_is_naked_baseline']
assert usage['status'] == patches['status'] == 'PASS'
assert usage['skill_contents_unchanged'] and usage['old_rules_preserved'] == 6
assert usage['same_models_templates_and_build'] and usage['same_per_task_budgets'] and usage['same_bundle_both_arms']
assert usage['off_requests_with_guidance'] == 0
assert patches['direct_host_answer_rewrites'] == 0
calls = load(OUT / 'call-index.json')
assert len(calls) == sum(r['model_calls'] for r in summary['arms'].values()) == len(usage['requests'])
assert all(r['task'] != 'UNLINKED' and r['arm'] in ('on', 'off') for r in calls)
assert all(r['http_status'] == 200 and r['stream_complete'] for r in calls)
assert all(r['input_tokens'] <= r['input_budget'] for r in usage['requests'])
assert capability['status'] == 'EVIDENCE_AUDIT_PASS' and capability['controls_completed'] == 6
assert capability['probe_completed_before_questions'] and capability['bootstrap_directory_fix_active']
assert all(r['reserved_dispatches'] <= r['current_remaining_limit'] == 56 and r['total_used_across_generations'] <= r['unchanged_original_limit'] == 100
    for r in capability['shared_arm_claim_audit'].values())
for r in capability['calls']:
    assert r['http_status'] == 200 and r['stream_complete'] and r['input_tokens'] <= r['input_budget']
frozen_files = 0
for root in [OUT, *(Path('D:/AMD/output') / name for name in ('diagnostic-route-fix7-20261017', 'rtl-repair-skills7-20261017',
    'rtl-recovery-ablation-20261017', 'rtl-budgetfit-ablation-20261017', 'rtl-semantic-skills-ablation-20261017', 'rtl-grounded-minimal-ablation-20261018'))]:
    values = load(root / 'campaign/campaign-freeze.json')['files']
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == digest for p, digest in values.items())
    frozen_files += len(values)
continuation = load(OUT / 'campaign/campaign-freeze.json')['protocol']['continuation_budget']
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == digest for p, digest in continuation['previous_claim_files'].items())
assert continuation['deadline'] == load(OUT / 'campaign/campaign-freeze.json')['protocol']['deadline']
assert continuation['deadline'] == load(Path(continuation['previous_output']) / 'campaign/campaign-freeze.json')['protocol']['deadline']
assert all(load(OUT / 'preservation.json')['checks'].values())
for name in ('previous', 'control', 'skills', 'recovery', 'budgetfit', 'semantic', 'grounded'):
    assert load(OUT / (name + '-round-preservation.json'))['unchanged']
post = load(OUT / 'post-run-checks.json')
assert not post['failure_notes_missing'] and post['ssh_original_hash_matches']
assert all(r['connection_refused'] for r in post['loopback_ports'])
assert all(r['reaped'] and r['exit_code'] == 0 for r in post['stages'].values())
cleanup = load(OUT / 'cleanup.json')
assert cleanup['ssh_original_hash_matches'] and cleanup['tunnel']['reaped']
assert re.search(r'Tests\s+85 passed', (OUT / 'unit-loop-host.log').read_text(encoding='utf-8-sig'))
for name, expected in [('unit-skills-grounding.log', 69), ('unit-profile-planner.log', 11)]:
    text = (OUT / name).read_text(encoding='utf-8-sig')
    assert re.search(r'pass\s+' + str(expected) + r'\b', text) and re.search(r'fail\s+0\b', text)
assert (OUT / 'typecheck-current.log').read_bytes() == (OUT / 'typecheck-previous.log').read_bytes()
assert len(re.findall(r'error TS\d+', (OUT / 'typecheck-current.log').read_text())) == 70
assert load(OUT / 'campaign/preflight/results.json')['controls'] == 16
assert load(OUT / 'campaign/semantic-controls/results.json')['controls'] == 10
manifest = load(OUT / 'campaign/manifest-7.json')
progress = [json.loads(line) for line in (OUT / 'campaign/progress.jsonl').read_text().splitlines()]
assert [(r['task'], r['arm']) for r in progress] == [(r['task'], r['arm']) for r in manifest['execution_order']]
for task in manifest['task_ids']:
    for arm in ('on', 'off'):
        result = load(OUT / 'campaign/arms' / arm / ('compare-' + task) / 'result.json')
        assert len(result['model_runs']) <= 8 and result.get('semantic_repairs', 0) <= 2
links = []
for document in ('REPORT.zh.md', 'FAILURE_ANALYSIS.zh.md', 'LOG_INDEX.md'):
    for target in re.findall(r'\]\(([^)]+)\)', (OUT / document).read_text(encoding='utf-8')):
        path = (OUT / target).resolve()
        assert path.exists() or path == (OUT / 'delivery-verification.json').resolve(), target
        links.append({'document': document, 'target': target})
receipt = {'status': 'EVIDENCE_AUDIT_PASS', 'not_a_claim_all_tasks_repaired': True, 'paired_tasks': 7, 'arm_runs': 14,
    'question_inference_calls': len(calls), 'capability_inference_calls': capability['inference_calls'],
    'combined_inference_calls': capability['combined_inference_calls'], 'question_calls_by_role': dict(Counter(c['provider'] for c in calls)),
    'capability_quality': capability['quality_summary'], 'previous_bootstrap_failure_retained_separately': True,
    'corrected_probe_completed_before_questions': True, 'shared_claim_pool_with_original_limits': capability['shared_arm_claim_audit'],
    'accepted_exact_patches_checked': patches['accepted_patches_checked'], 'question_model_errors': len(load(OUT / 'model-errors.json')),
    'frozen_files_rechecked_across_seven_campaigns': frozen_files, 'unit_tests_passed': 165, 'eda_calibration_controls': 26,
    'requested_problem_rtl_designs_solved': {r['task']: {a: r['comparison'][a + '_rtl_pass'] for a in ('on', 'off')}
        for r in load(OUT / 'comparison.json') if r['task'].startswith(('Prob096_', 'Prob142_', 'Prob104_'))},
    'original_and_all_seven_previous_outputs_preserved': True, 'handoff_unchanged': True,
    'tunnel_closed_and_ssh_restored': True, 'original_deadline_not_extended': True, 'typecheck_added_diagnostics': 0, 'full_typecheck_passed': False,
    'unchanged_upstream_type_diagnostics': 70, 'artifact_links_checked': len(links), 'links': links, 'official_score': None}
with (OUT / 'delivery-verification.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
print(json.dumps({k: v for k, v in receipt.items() if k != 'links'}))

import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { buildContext, selectSkills } from './rtl-tools/src/phase1/p09-context.ts'
import { loadP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
const yaml=createRequire(import.meta.url)('js-yaml'), here=dirname(fileURLToPath(import.meta.url))
const markdown=await readFile(here+'/skills/rtl-diagnostic-reasoning/SKILL.md','utf8')
const front=yaml.load(/^---\r?\n([\s\S]*?)\r?\n---/.exec(markdown)[1])
assert.deepEqual(Object.keys(front).sort(),['description','name'])
assert.match(front.name,/^[a-z0-9]+(?:-[a-z0-9]+)*$/); assert.ok(front.name.length<=64)
assert.equal(typeof front.description,'string'); assert.ok(front.description.length<=1024 && !/[<>]|TODO/.test(front.description))
const bundle=JSON.parse(await readFile(here+'/skill-registry/bundle.json','utf8'))
const entries=await loadP09Skills({variant:'C',...bundle.settings})
const prior=JSON.parse(await readFile(bundle.previous_skill_registry,'utf8'))
assert.deepEqual(entries.slice(0,6),prior)
const original=JSON.parse(await readFile('D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/on/compare-Prob096_review2015_fsmseq/models/run-NkpwIg/context.json','utf8'))
const selected=selectSkills(entries,original.feedback.stages.find(s=>s.status!=='PASS').diagnostics.map(d=>d.kind))
assert.ok(selected.some(s=>s.id==='rtl.00_diagnostic_reasoning'))
const limits={window:8192,output:2048,margin:1024,feedback:2048,ledger:512,skills:768,sourceWarning:3072}
const views=[]
for(const variant of ['C','B']) {
  const input={...original,variant_id:variant,ledger:[],core_only:true,previous_tool_result:{tool:'edit_dut',accepted:false,observation:{error:'PATCH_ANCHOR_NOT_UNIQUE',details:{replacement_index:2,kind:'ambiguous',occurrences:2,lines:[12,15]}}}}
  const view=await buildContext(input,limits,{quality:'estimated',identity:{test:'offline_projection'},count:async v=>Math.ceil((v.system.length+v.prompt.length)/4)},new AbortController().signal,async()=>entries)
  const prompt=JSON.parse(view.prompt)
  assert.deepEqual(prompt.previous_tool_result.observation.details,input.previous_tool_result.observation.details)
  if(variant==='C') assert.ok(prompt.guidance.some(s=>s.id==='rtl.00_diagnostic_reasoning'))
  else assert.equal(prompt.guidance.length,0)
  views.push({variant,prompt,audit:view.audit})
}
await writeFile('D:/AMD/output/rtl-diagnostic-guards-20261018/skill-request-snapshot.json',JSON.stringify({status:'PASS',frontmatter_parser:'existing js-yaml; Python quick_validate unavailable without PyYAML',six_prior_entries_unchanged:true,views},null,2),{flag:'wx'})
console.log(JSON.stringify({status:'PASS',frontmatter_valid:true,new_skill_normally_selected:true,compressed_feedback_preserved:true,off_guidance:0}))

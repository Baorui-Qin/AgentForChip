import assert from 'node:assert/strict'
import test from 'node:test'

// Off-target algebraic examples, not an RTL parser or a production candidate filter.
export function semanticExamples() {
  const enumValues = [0, 1, 2, 3, 4, 5]
  const fit = (values, width) => values.map(v => v & ((1 << width) - 1))
  const unique = values => new Set(values).size === values.length
  assert.equal(unique(fit(enumValues, 2)), false)
  assert.equal(unique(fit(enumValues, 3)), true)
  assert.equal(unique(fit([0, 1, 2, 2], 3)), false)
  const rows = []
  for (const a of [0, 1]) for (const b of [0, 1]) for (const old of [0, 1]) for (const sel of [0, 1]) {
    const expected = sel ? a : b
    const correct = sel ? a : ((a << 2) | (old << 1) | b) & 1
    const lowConstant = sel ? a : ((b << 2) | (a << 1)) & 1
    const lowFeedback = sel ? a : ((b << 2) | (a << 1) | old) & 1
    rows.push({ a, b, old, sel, expected, correct, lowConstant, lowFeedback })
  }
  assert.ok(rows.every(r => r.correct === r.expected))
  assert.ok(rows.some(r => r.lowConstant !== r.expected))
  assert.ok(rows.some(r => r.lowFeedback !== r.expected))
  return { enum_values: enumValues, duplicate_after_narrowing: true, scalar_rows: rows,
    evidence_kind: 'local_algebraic_review_not_eda_or_model_effectiveness' }
}

test('enum encodings remain unique after declared-width sizing', () => {
  assert.equal(semanticExamples().duplicate_after_narrowing, true)
})
test('scalar concatenation checks distinguish a valid low data bit from constants and feedback', () => {
  assert.equal(semanticExamples().scalar_rows.length, 16)
})
test('enum identity is stricter than equal packed width', () => {
  const enumType = { width: 3 }, vectorType = { width: 3 }
  assert.equal(enumType.width, vectorType.width)
  assert.notEqual(enumType, vectorType)
  assert.equal(enumType, enumType)
})

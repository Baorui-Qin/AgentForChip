import assert from 'node:assert/strict'
import test from 'node:test'
import { readFile } from 'node:fs/promises'
import { guardRepair, guardPlan, repairCodeHash, enumConstraints, RepairGuardError } from './rtl-tools/src/phase1/p10-repair-guards.ts'
import { exactEdit, ExactPatchError } from './rtl-tools/src/phase1/p10-exact-edit.ts'
import { compactPlan } from './rtl-tools/src/phase1/p10-plan-format.ts'

const iface = { top: 'TopModule', ports: [{name:'a',direction:'input',width:1},{name:'q',direction:'output',width:1}] }
const source = 'module TopModule(input a, output q); assign q=a; endmodule'
const changed = source.replace('output q', 'output logic q')
const plan = (before, after) => JSON.stringify({cause:'The destination must be a variable.', changes:[{before,after}], checks:['Verify the output behavior.']})
const patch = replacements => JSON.stringify({expected_revision_id:'r',replacements})
test('structured plans preserve the original field and total output limits', () => {
  assert.equal(compactPlan(plan('output q','output logic q'), true), plan('output q','output logic q'))
  assert.throws(() => compactPlan(plan('x'.repeat(201),'y'),true), /PLANNER_PLAN_INVALID/)
  assert.throws(() => compactPlan(JSON.stringify({cause:'why',changes:['free text'],checks:['test']}),true), /PLANNER_PLAN_INVALID/)
})
test('legacy planning remains separate from structured repair planning', () => {
  assert.doesNotThrow(() => compactPlan('{"cause":"why","changes":["change"],"checks":["test"]}'))
})
test('a plan preview does not mutate the source and accepts a fixed-interface qualifier fix', () => {
  const result = guardPlan(plan('output q','output logic q'),source,iface)
  assert.equal(result.interface_checked,true)
  assert.equal(source.includes('output logic'),false)
})
test('noop and comment-only plans are refused', () => {
  assert.throws(() => guardPlan(plan('output q','output q'),source,iface),/REPEATED_CANDIDATE/)
  assert.throws(() => guardPlan(plan('q=a;','q=a; /* changed */'),source,iface),/REPEATED_CANDIDATE/)
})
test('fixed-port refusal names the exact conflicting port and widths', () => {
  assert.throws(() => guardRepair(source.replace('input a','input [2:0] a'),source,iface), e =>
    e instanceof RepairGuardError && e.details[0].port==='a' && e.details[0].expected.width===1 && e.details[0].actual.width===3)
})
test('unsupported ANSI syntax remains rejected rather than silently repaired', () => {
  assert.throws(() => guardRepair(source.replace('output q','output reg q;'),source,iface),/UNSUPPORTED_INTERFACE/)
})
test('literal enum capacity and duplicate checks reject the actual generic failure', () => {
  const result=enumConstraints("typedef enum logic [0:0] {A=1'b0,B=1'b1,C=1'b0} e_t;")
  assert.ok(result.issues.some(i=>i.code==='ENUM_CAPACITY'))
  assert.ok(result.issues.some(i=>i.code==='ENUM_DUPLICATE'))
})
test('sufficient enum capacity with unique values passes the bounded checker', () => {
  assert.equal(enumConstraints("typedef enum logic [2:0] {A=3'd0,B=3'd1,C=3'd2} e_t;").issues.length,0)
})
test('out-of-width enum values are refused', () => {
  assert.ok(enumConstraints("typedef enum logic [0:0] {A=2'd2} e_t;").issues.some(i=>i.code==='ENUM_VALUE_WIDTH'))
})
test('a literal requiring compiler truncation is unknown, not falsely rejected', () => {
  const result=enumConstraints("typedef enum logic [0:0] {A=1'd2} e_t;")
  assert.equal(result.issues.length,0)
  assert.equal(result.declarations[0].coverage,'unknown_expression')
})
test('trailing enum separators are not counted as additional states', () => {
  assert.equal(enumConstraints("typedef enum logic [0:0] {A=1'b0,B=1'b1,} e_t;").issues.length,0)
})
test('unsupported enum expressions are reported as unknown, not proved correct', () => {
  assert.equal(enumConstraints('typedef enum logic [2:0] {A=PARAM} e_t;').declarations[0].coverage,'unknown_expression')
  assert.equal(enumConstraints('typedef enum int {A,B} e_t;').coverage,'partial_unknown_forms')
})
test('token replay ignores ordinary comments but retains operator and token boundaries', () => {
  assert.equal(repairCodeHash('q = a; // note'),repairCodeHash('q=a; /* other */'))
  assert.notEqual(repairCodeHash('a/**/b'),repairCodeHash('ab'))
  assert.notEqual(repairCodeHash('q<=a;'),repairCodeHash('q < = a;'))
})
test('synthesis controls and strings are not erased by replay fingerprints', () => {
  assert.notEqual(repairCodeHash('q=a; // synthesis translate_off'),repairCodeHash('q=a;'))
  assert.notEqual(repairCodeHash('"a // x"'),repairCodeHash('"a // y"'))
})
test('session-local rejected code includes cosmetic replay and does not leak to another session', () => {
  const rejected = new Map([[repairCodeHash(changed),'NO_IMPROVEMENT']])
  assert.throws(() => guardRepair(changed+' // different note',source,iface,rejected),/REJECTED_CODE_REPLAY/)
  assert.doesNotThrow(() => guardRepair(changed,source,iface,new Map()))
})
test('missing anchor refusal identifies replacement number and leaves source unchanged', () => {
  assert.throws(() => exactEdit(patch([{before:'output q',after:'output logic q'},{before:'missing',after:'new'}]),source,'r'), e =>
    e instanceof ExactPatchError && e.details.replacement_index===2 && e.details.kind==='missing' && e.details.occurrences===0)
  assert.equal(source.includes('output logic'),false)
})
test('ambiguous anchor refusal contains occurrence lines', () => {
  assert.throws(() => exactEdit(patch([{before:'q',after:'new'}]),source,'r'),e=>
    e instanceof ExactPatchError && e.details.kind==='ambiguous' && e.details.occurrences===2 && e.details.lines.length===2)
})
test('correcting a refused anchor enables a genuinely different local edit', () => {
  assert.throws(()=>exactEdit(patch([{before:'q',after:'new'}]),source,'r'),/PATCH_ANCHOR_NOT_UNIQUE/)
  const candidate=exactEdit(patch([{before:'output q',after:'output logic q'}]),source,'r')
  assert.equal(guardRepair(candidate.source,source,iface).interface_checked,true)
})
test('legacy frozen failures remain identifiable as invalid without changing their answers', async () => {
  const old=JSON.parse(await readFile('D:/AMD/output/rtl-plan-effectiveness-audit-20261018/submissions.json','utf8'))
  const counts={port:0,enum:0,noop:0}
  for(const row of old.filter(r=>r.tool==='edit_dut')) {
    const context=JSON.parse(await readFile(row.context_file,'utf8'))
    try { const candidate=exactEdit(JSON.stringify(row.arguments),context.current.source,context.current.revision_id); guardRepair(candidate.source,context.current.source,context.task.interface) }
    catch(e) { if(e.message==='INVALID_OUTPUT') counts.port++; if(e.message==='ENUM_CONSTRAINT_REJECTED') counts.enum++; if(e.message==='REPEATED_CANDIDATE') counts.noop++ }
  }
  assert.equal(counts.port,5); assert.equal(counts.enum,2); assert.equal(counts.noop,3)
})

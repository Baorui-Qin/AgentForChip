"""Final local control verification, explicitly no paid API and no EDA."""
from pathlib import Path
import os
import shutil
import subprocess
import sys

from launch import profile, run
from api_client import save
from pilot import load, sha

HERE = Path(__file__).resolve().parent
OUT = Path('D:/AMD/output/rtl-api-distillation-20261017/control-fix-06-r3')
env = dict(os.environ, TEMP='D:/AMD/tmp/knowledge-live-tests', TMP='D:/AMD/tmp/knowledge-live-tests')
tests = subprocess.run([sys.executable, '-X', 'utf8', '-B', '-m', 'unittest', 'test_agent', 'test_budget',
                        'test_context_completion'], cwd=HERE, env=env, capture_output=True, text=True)
save(OUT / 'unit-tests-final.json', {'exit_code': tests.returncode, 'stdout': tests.stdout, 'stderr': tests.stderr,
     'api_requests': 0, 'eda_runs': 0})
assert tests.returncode == 0
source = OUT / 'native-smoke'
root = OUT / 'native-smoke-final'
task = root / 'tasks/Q114'
for name in ('work', 'seed'):
    shutil.copytree(source / 'tasks/Q114' / name, task / name)
for name in ('seed-manifest.json', 'completion-contract.json', 'question.json'):
    shutil.copyfile(source / 'tasks/Q114' / name, task / name)
shutil.copyfile(source / 'plan.json', root / 'plan.json')
profile(root)
assert run(root, keyless=True) == 0
assert len(list((task / 'checkpoints').glob('*/checkpoint-audit.json'))) == 2
assert not (task / 'api').exists() and not list((task / 'operations').glob('*/process.json'))
before = load(OUT / 'historical-files-before.json')
assert all(sha(Path(path)) == digest for path, digest in before.items())
proposal = load(OUT / 'budget-proposal.json')
assert proposal['status'] == 'AWAITING_EXPLICIT_USER_CONFIRMATION_NOT_AUTHORIZATION'
for key in ('requests', 'reported_tokens', 'eda'):
    assert proposal['current_remaining'][key] + proposal['requested_addition'][key] == proposal['proposed_next_run_caps'][key]
    assert proposal['current_cumulative_used'][key] + proposal['proposed_next_run_caps'][key] == proposal['proposed_cumulative_caps'][key]
    assert sum(t[key] for t in proposal['proposed_tasks'].values()) == proposal['proposed_next_run_caps'][key]
assert sum(t['existing_requests_reallocated'] for t in proposal['proposed_tasks'].values()) == 6
assert sum(t['additional_requests'] for t in proposal['proposed_tasks'].values()) == 20
native = load(OUT / 'native-knowledge-regression/native-validation.json')
assert all(c['passed'] for c in native['checks']) and native['api_requests'] == native['eda_runs'] == 0
snapshot = OUT / 'verified-control-sources'
snapshot.mkdir()
names = ['agent.ts', 'api_worker.py', 'context_window.py', 'completion_gate.py', 'task_tools.py', 'launch.py',
         'test_context_completion.py', 'control_regression.py', 'finalize_control_regression.py']
for name in names:
    shutil.copyfile(HERE / name, snapshot / name)
shutil.copyfile(HERE.parent / 'knowledge-runtime/plugin.ts', snapshot / 'knowledge-plugin.ts')
save(OUT / 'final-control-validation.json', {'passed': True, 'scope': 'CONTROL_FIX_ONLY_NOT_MODEL_REPAIR_OR_GAIN',
     'unit_tests': 50, 'historical_payload_replays': 4, 'native_checkpoint_steps': 2,
     'retrieval_regressions': 16, 'native_knowledge_regressions': len(native['checks']),
     'counterevidence_handoff_and_parent_ledger': load(OUT / 'launch-validation.json')['passed'],
     'prior_q114_false_completion_rejected': load(OUT / 'q114-old-pass-rejection.json')['rejected'],
     'api_requests': 0, 'eda_runs': 0, 'historical_files_unchanged': len(before),
     'native_process_reaped': load(root / 'harness-process.json')['reaped'],
     'budget_proposal_validated_but_not_approved': True,
     'source_sha256': {p.name: sha(p) for p in snapshot.iterdir()},
     'earlier_failed_offline_checks_preserved': [str(OUT.with_name('control-fix-06')), str(OUT.with_name('control-fix-06-r2'))],
     'limits': ['No real API or EDA exercised these control changes.',
                'Read-only semantic review is required; token changes and passing self-tests cannot prove arbitrary testbench correctness.']})
print('Final validation passed: 50 unit tests, 4 archived payload replays, native checkpoint and retrieval tests; API=0, EDA=0. Budget proposal only.')

"""Prepare the approved per-call-gated v2 probe without API/EDA execution."""
import os
from pathlib import Path
import shutil
import subprocess
import sys

from launch import initialize
from api_client import save
from pilot import load, sha
from prepare_round6 import inventory

HERE = Path(__file__).resolve().parent
BASE = Path('D:/AMD/output/rtl-api-distillation-20261017')
PARENT = BASE / 'agent-knowledge-06'
ROOT = BASE / 'agent-knowledge-07-smallstep'
REVIEW = BASE / 'round7-handoff-review.json'
selected = ['Q123', 'Q114']
review = {}
for qid in selected:
    task = PARENT / 'tasks' / qid
    handoff = load(task / 'work/handoff.json')
    review[qid] = {'file_sha256': {n: sha(task / 'work' / n) for n in ('dut.sv', 'diag_tb.sv')},
                  'required_changed_files': handoff['completion_contract']['required_changed_files'],
                  'findings': [{**{k: f[k] for k in ('id', 'file', 'observation', 'resolution_condition')},
                                'evidence': ['work/handoff.json', 'work/' + f['file']]}
                               for f in handoff['unresolved_findings']]}
save(REVIEW, {'scope': 'INHERITED_UNRESOLVED_FINDINGS_NO_NEW_EXECUTION_OR_REPLACEMENT_CODE', 'tasks': review})
initialize(ROOT, continuation=PARENT, maximum_tokens=164315, selected_ids=selected,
           task_limits=HERE / 'round7-limits.json', handoff_review=REVIEW,
           authorization=BASE / 'round7-human-authorization.json', stepwise_review=True)
plan = load(ROOT / 'plan.json')
assert plan['context_policy']['kind'] == 'artifact_checkpoint_v2' and plan['stepwise_review']
assert (plan['max_requests'], plan['max_reported_tokens'], plan['max_eda_cumulative']) == (100, 1150000, 54)
assert (plan['prior_usage']['calls'], plan['prior_usage']['total'], plan['prior_eda_runs']) == (96, 903935, 36)
checks = []
for qid in selected:
    task = ROOT / 'tasks' / qid
    for name in ('dut.sv', 'diag_tb.sv'):
        assert sha(task / 'work' / name) == sha(task / 'seed' / name) == sha(PARENT / 'tasks' / qid / 'work' / name)
    checks.append({'id': qid, 'exact_prior_model_files': True, 'handoff_present': True, 'passed': True})
save(ROOT / 'continuation-input-audit.json', {'passed': True, 'checks': checks,
     'scope': 'SMALL_STEP_CONTINUATION_NOT_ORIGINAL_INPUT_REPAIR', 'context_version': 'v2',
     'per_call_host_review': True, 'no_developer_corrected_artifacts': True})
save(ROOT / 'parent-preservation-before.json', {'scope': 'Evidence excluding dependency junctions/node_modules',
     'runs': {str(PARENT): inventory(PARENT)}})
snapshot = ROOT / 'verified-runtime-sources'
snapshot.mkdir()
for name in ('agent.ts', 'api_worker.py', 'context_window.py', 'completion_gate.py', 'task_tools.py',
             'launch.py', 'step_review.py', 'round7-limits.json', 'test_step_review.py'):
    shutil.copyfile(HERE / name, snapshot / name)
env = dict(os.environ, TEMP='D:/AMD/tmp/knowledge-live-tests', TMP='D:/AMD/tmp/knowledge-live-tests')
tests = subprocess.run([sys.executable, '-X', 'utf8', '-B', '-m', 'unittest', 'test_agent', 'test_budget',
                        'test_context_completion', 'test_step_review'], cwd=HERE, env=env, capture_output=True, text=True)
save(ROOT / 'preflight-validation.json', {'passed': tests.returncode == 0, 'unit_tests': 59,
     'stdout': tests.stdout, 'stderr': tests.stderr, 'new_api_requests': 0, 'new_eda_runs': 0,
     'control_sources_sha256': {p.name: sha(p) for p in snapshot.iterdir()}})
assert tests.returncode == 0
save(ROOT / 'step-policy.json', {'scope': 'READ_ONLY_ACTION_CHECK_AFTER_EVERY_REAL_RESPONSE',
     'initial_relevant_nonduplicate_lookup_may_continue_once': True,
     'repeated_preloaded_file_reads_or_duplicate_lookup_without_new_evidence': 'stop_run',
     'identical_or_comment_only_write_is_not_substantive': True,
     'second_call_requires_previous_explicit_host_decision': True,
     'after_second_call': 'inspect_and_stop_at_cap_even_with_partial_progress',
     'model_tests_only': True, 'developer_supplemental_eda': False,
     'editing_or_testing_alone_is_not_task_completion': True})
print('v2 probe prepared: Q123/Q114 at most 2 calls each, no cap increase, per-call review gate, 59 offline tests passed.')

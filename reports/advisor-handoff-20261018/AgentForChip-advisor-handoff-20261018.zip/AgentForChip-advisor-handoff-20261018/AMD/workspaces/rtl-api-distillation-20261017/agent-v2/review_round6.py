"""Record the failed real continuation and offline-only follow-up, without DUT edits or EDA."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from prepare_round6 import inventory
from launch import profile, run
from context_window import checkpoint_payload, encoded_size
from api_client import save
from pilot import load, sha

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-06')
POST = ROOT / 'post-run-context-v2'


def persist(path, value):
    if path.exists():
        assert load(path) == value
    else:
        save(path, value)


def prepare_review():
    plan = load(ROOT / 'plan.json')
    audit = load(ROOT / 'knowledge-use-audit/evidence.json')
    totals = {'requests': 0, 'prompt_tokens': 0, 'completion_tokens': 0, 'total_tokens': 0}
    tasks, role_records, reviews = {}, [], []
    for qid in plan['execution_order']:
        task = ROOT / 'tasks' / qid
        usage = {key: 0 for key in totals}
        for path in sorted((task / 'api').glob('*/request.json')):
            directory = path.parent
            value = load(directory / 'response.json')['usage']
            request, original = load(path), load(directory / 'payload.json')
            usage['requests'] += 1
            for key in ('prompt_tokens', 'completion_tokens', 'total_tokens'):
                usage[key] += value[key]
            states = [json.loads(m['content']) for m in request['messages'] if m['role'] == 'user' and
                      isinstance(m.get('content'), str) and m['content'].startswith('{"kind":"HOST_CHECKPOINT')]
            assert len(states) == 1
            handoff = json.loads(states[0]['artifacts']['handoff.json']['content'])
            assert handoff['unresolved_findings']
            assert not any(m['role'] in ('assistant', 'tool') for m in request['messages'])
            assert encoded_size(request) <= 65536
            role_records.append({'task': qid, 'request': directory.name,
                 'native_assistant_messages': sum(m['role'] == 'assistant' for m in original['messages']),
                 'native_tool_results': sum(m['role'] == 'tool' for m in original['messages']),
                 'dispatched_assistant_messages': 0, 'dispatched_tool_results': 0,
                 'handoff_findings_preserved': [f['id'] for f in handoff['unresolved_findings']],
                 'request_sha256': sha(path), 'checkpoint_bytes': encoded_size(request)})
        usage['eda'] = len(list((task / 'operations').glob('*/process.json')))
        assert usage['eda'] == 0 and not (task / 'teacher-summary.json').exists()
        for name in ('dut.sv', 'diag_tb.sv'):
            assert sha(task / 'work' / name) == sha(task / 'seed' / name)
        for path in (task / 'operations').glob('*/call.json'):
            assert load(path)['name'] == 'read_file'
        tasks[qid] = usage
        for key in totals:
            totals[key] += usage[key]
        reviews.append({'id': qid, 'run': 'round6', 'verdict': 'INCOMPLETE_NO_EDIT_NO_EDA_NO_MODEL_SUMMARY',
             'reason': 'Relevant counterevidence was actually sent, but only lookups/reads occurred. The v1 checkpoint '
                       'removed every native assistant/tool message before dispatch. This is a confirmed controller '
                       'semantic change and a possible contributor to repeated cold-start behavior; exclusive causation '
                       'is not established without a real controlled comparison. No RTL attempt or skill benefit inferred.',
             'applied_rules': [], 'adoption_extent': 'receipt_only_no_modified_artifact',
             'evidence': ['work/handoff.json', 'work/dut.sv', 'work/diag_tb.sv', 'api/001/request.json', 'agent-result.json']})
    assert totals['requests'] == 22 and totals['total_tokens'] == 216301
    persist(ROOT / 'api-usage.json', {'scope': 'THIS_REAL_CONTINUATION_ONLY', 'totals': totals, 'tasks': tasks,
         'cumulative': {'requests': 96, 'total_tokens': 903935, 'eda': 36},
         'remaining': {'requests': 4, 'total_tokens': 246065, 'eda': 18},
         'remaining_tasks': {q: {'requests': plan['task_limits'][q]['requests'] - u['requests'],
              'tokens': plan['task_limits'][q]['tokens'] - u['total_tokens'], 'eda': plan['task_limits'][q]['eda']}
              for q, u in tasks.items()},
         'automatic_retry': False, 'unknown_outcomes': [], 'billing_inquiry': False, 'currency_cost': None})
    persist(ROOT / 'checkpoint-semantic-review.json', {'scope': 'CONFIRMED_MESSAGE_TRANSFORMATION_NOT_CAUSAL_PROOF',
         'records': role_records, 'confirmed': 'All dispatched requests contained system/user messages only, although native history accumulated assistant/tool rounds.',
         'hypothesis': 'Loss of recent conversational feedback may contribute to repeated lookups and reads; the model may also fail independently.',
         'comparison_not_performed': 'No paid v2 comparison, no RTL revalidation and no developer supplemental EDA.'})
    persist(ROOT / 'reviewed-lessons.json', {'scope': 'FAILED_REAL_AGENT_CONTINUATION_NOT_RTL_REPAIR_OR_GAIN_TEST',
         'runs': {'round4': str(ROOT.with_name('agent-knowledge-04')), 'round5': str(ROOT.with_name('agent-knowledge-05')), 'round6': str(ROOT)},
         'input_audits': {'round5': 'continuation-input-audit.json', 'round6': 'continuation-input-audit.json'},
         'continuations': [{'from': a, 'to': b, 'task': q} for a, b in [('round4', 'round5'), ('round5', 'round6')] for q in plan['execution_order']],
         'tasks': reviews, 'strict_completed': 0, 'strict_total': 4,
         'model_writes': 0, 'model_eda': 0, 'model_summaries': 0, 'developer_supplemental_eda': 0,
         'skill_updates': [{'rule': 'H07', 'basis': ['round6:' + q for q in plan['execution_order']]}],
         'expected_rule_count': 46, 'budget': {'requests': 100, 'tokens': 1150000},
         'regression_files': [str(ROOT / 'preflight-validation.json'), str(POST / 'validation.json')],
         'new_guidance_loaded_in_this_paid_run': False,
         'new_guidance_authorship': 'Codex read-only review of visible requests/operations, not teacher rule summaries.',
         'post_run_context_v2_paid_validation': False})
    POST.mkdir(exist_ok=True)
    env = dict(os.environ, TEMP='D:/AMD/tmp/knowledge-live-tests', TMP='D:/AMD/tmp/knowledge-live-tests')
    tests = subprocess.run([sys.executable, '-X', 'utf8', '-B', '-m', 'unittest', 'test_agent', 'test_budget', 'test_context_completion'],
                           cwd=HERE, env=env, capture_output=True, text=True)
    if not (POST / 'unit-tests.json').exists():
        save(POST / 'unit-tests.json', {'exit_code': tests.returncode, 'stdout': tests.stdout, 'stderr': tests.stderr,
             'fixture_only': True, 'api_requests': 0, 'eda_runs': 0})
    assert tests.returncode == 0
    records = []
    for qid in plan['execution_order']:
        task = ROOT / 'tasks' / qid
        payload = load(sorted((task / 'api').glob('*/payload.json'))[-1])
        # Replay the ledger as visible at that payload, not contexts prepared after it was dispatched.
        shadow = POST / ('replay-' + qid)
        destination = shadow / 'tasks' / qid
        for name in ('work', 'seed'):
            shutil.copytree(task / name, destination / name, dirs_exist_ok=True)
        for name in ('seed-manifest.json', 'completion-contract.json', 'session-identity.json'):
            shutil.copyfile(task / name, destination / name)
        ids = {c['id'] for m in payload['messages'] for c in m.get('tool_calls', [])}
        for directory in (task / 'operations').glob('*'):
            dispatch = task / ('tool-dispatch-' + directory.name + '.json')
            if dispatch.exists() and load(dispatch)['tool_call_id'] in ids:
                target = destination / 'operations' / directory.name
                target.mkdir(parents=True, exist_ok=True)
                for name in ('call.json', 'result.json'):
                    shutil.copyfile(directory / name, target / name)
        contents = {m.get('content') for m in payload['messages'] if m['role'] == 'user' and isinstance(m.get('content'), str)}
        sid = load(task / 'session-identity.json')['session_id']
        ledger = ROOT / 'knowledge-runtime/retrieval'
        target = shadow / 'knowledge-runtime/retrieval'
        target.mkdir(parents=True, exist_ok=True)
        visible, excluded = [], []
        for line in (ledger / 'retrieval.jsonl').read_text(encoding='utf-8').splitlines():
            event = json.loads(line)
            if event['session_id'] != sid:
                continue
            if event['event'] == 'context_prepared':
                text = (ledger / event['message_file']).read_text(encoding='utf-8')
                if text not in contents:
                    excluded.append(event['record_id'])
                    continue
                shutil.copyfile(ledger / event['message_file'], target / event['message_file'])
            elif event.get('tool_call_id') and event['tool_call_id'] not in ids:
                continue
            visible.append(event)
        (target / 'retrieval.jsonl').write_text('\n'.join(json.dumps(e, ensure_ascii=False) for e in visible), encoding='utf-8')
        compact, record = checkpoint_payload(shadow, destination / 'hypothetical-checkpoints/001', payload, preserve_recent=True)
        assert record['retained_round_tool_call_ids']
        assert encoded_size(compact) + 1500 <= 65536
        out = POST / 'as-of-replay' / qid
        persist(out / 'checkpoint-preview.json', compact)
        persist(out / 'checkpoint-audit.json', record)
        records.append({'task': qid, **record, 'api_dispatched': False, 'post_payload_prepared_contexts_excluded': excluded})
    save(POST / 'replay.json', {'records': records, 'api_requests': 0, 'eda_runs': 0})
    smoke = POST / 'native-smoke'
    source = ROOT.with_name('control-fix-06-r3') / 'native-smoke-final'
    for name in ('work', 'seed'):
        shutil.copytree(source / 'tasks/Q114' / name, smoke / 'tasks/Q114' / name)
    for name in ('seed-manifest.json', 'question.json', 'completion-contract.json'):
        shutil.copyfile(source / 'tasks/Q114' / name, smoke / 'tasks/Q114' / name)
    smoke_plan = load(source / 'plan.json')
    smoke_plan['context_policy']['kind'] = 'artifact_checkpoint_v2'
    save(smoke / 'plan.json', smoke_plan)
    profile(smoke)
    snapshot = POST / 'source-version'
    snapshot.mkdir()
    for name in ('context_window.py', 'launch.py', 'test_context_completion.py'):
        shutil.copyfile(HERE / name, snapshot / name)
    print(json.dumps({'requests': totals['requests'], 'tokens': totals['total_tokens'], 'EDA': 0,
                      'post_v2_replays': [{'task': r['task'], 'bytes': r['checkpoint_bytes']} for r in records]}))


def native():
    smoke = POST / 'native-smoke'
    assert run(smoke, keyless=True) == 0
    audits = list((smoke / 'tasks/Q114/checkpoints').glob('*/checkpoint-audit.json'))
    assert len(audits) == 2
    assert all(load(p)['policy'] == 'artifact_checkpoint_v2' for p in audits)
    assert load(sorted(audits)[-1])['retained_round_tool_call_ids'] == ['KEYLESS_NATIVE_LOOP_SMOKE_ONLY']
    assert not (smoke / 'tasks/Q114/api').exists() and not list(smoke.glob('tasks/*/operations/*/process.json'))
    save(POST / 'validation.json', {'passed': True, 'unit_tests': 55, 'archived_payload_replays': 4,
         'native_round_trip_steps': 2, 'last_complete_round_preserved': True,
         'api_requests': 0, 'eda_runs': 0, 'paid_v2_validation': False,
         'native_process_reaped': load(smoke / 'harness-process.json')['reaped'],
         'limit': 'Preserving causal messages is locally verified. Actual model progress with v2 is not verified.'})
    print('Post-run v2 offline/native validation passed, no API/EDA.')


def validate():
    plan = load(ROOT / 'plan.json')
    usage = load(ROOT / 'api-usage.json')
    checks = []
    def check(name, passed):
        checks.append({'name': name, 'passed': bool(passed)})
    check('trajectory_integrity', load(ROOT / 'knowledge-use-audit/evidence.json')['integrity_passed'])
    check('harness_reaped', load(ROOT / 'harness-process.json')['reaped'])
    check('budget_caps', (plan['max_requests'], plan['max_reported_tokens'], plan['max_eda_cumulative']) == (100, 1150000, 54))
    for qid, u in usage['tasks'].items():
        limits = plan['task_limits'][qid]
        check(qid + ':task_budget', u['requests'] <= limits['requests'] and u['total_tokens'] <= limits['tokens'] and u['eda'] == 0)
    check('cumulative_budget', usage['cumulative']['requests'] <= 100 and usage['cumulative']['total_tokens'] <= 1150000 and usage['cumulative']['eda'] <= 54)
    for p in (ROOT / 'verified-runtime-sources').iterdir():
        check('paid_source_snapshot:' + p.name, sha(p) == load(ROOT / 'runtime-source-manifest.json')[p.name])
    for path, before in load(ROOT / 'parent-preservation-before.json')['runs'].items():
        check('prior_run_unchanged:' + path, inventory(Path(path)) == before)
    check('original_materials', load(ROOT.with_name('knowledge-round6-preservation') / 'preservation.json')['status'] == 'PASS')
    check('publication', load(ROOT / 'publication-validation.json')['passed'])
    check('post_run_v2_not_paid', load(POST / 'validation.json')['paid_v2_validation'] is False)
    check('no_supplemental_eda', not list(ROOT.glob('tasks/*/operations/*/process.json')) and not any((ROOT / p).exists() for p in ('independent-diagnostics', 'independent-protocol-review')))
    result = {'scope': 'INTEGRITY_NOT_TASK_SUCCESS', 'passed': all(c['passed'] for c in checks), 'checks': checks,
         'this_run': {'requests': 22, 'tokens': 216301, 'eda': 0}, 'cumulative': usage['cumulative'],
         'remaining': usage['remaining'], 'strict_completed': 0, 'strict_total': 4,
         'model_writes': 0, 'model_summaries': 0, 'post_run_v2_paid_validation': False}
    save(ROOT / 'final-validation.json', result)
    print(json.dumps({'passed': result['passed'], 'checks': len(checks), 'failed': [c for c in checks if not c['passed']]}))
    assert result['passed']


if __name__ == '__main__':
    {'prepare': prepare_review, 'native': native, 'validate': validate}[sys.argv[1]]()

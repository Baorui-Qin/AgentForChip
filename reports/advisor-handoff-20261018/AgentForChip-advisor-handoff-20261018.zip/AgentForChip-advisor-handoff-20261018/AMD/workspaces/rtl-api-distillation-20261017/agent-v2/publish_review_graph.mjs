// Publish reviewed provenance separately from immutable runtime/trajectory graphs.
import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
import { loadBundle } from '../knowledge-runtime/core.mjs'

const require = createRequire(import.meta.url)
const YAML = require('D:/deepseek-harness/node_modules/.pnpm/yaml@2.9.0/node_modules/yaml')
const root = path.resolve(process.argv[2])
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'))
const hash = p => createHash('sha256').update(fs.readFileSync(p)).digest('hex')
const artifact = p => ({ path: path.resolve(p), sha256: hash(p) })
const save = (p, value) => fs.writeFileSync(p, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' })
const reviewPath = path.join(root, 'reviewed-lessons.json')
const review = read(reviewPath)
const nodes = [], edges = [], checks = []
const check = (name, passed) => checks.push({ name, passed: Boolean(passed) })
const usage = { requests: 0, prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
const evidence = {}
for (const [run, directory] of Object.entries(review.runs)) {
  const graph = read(path.join(directory, 'knowledge-use-audit/graph.json'))
  nodes.push(...graph.nodes.map(n => ({ ...n, id: run + ':' + n.id })))
  edges.push(...graph.edges.map(e => ({ ...e, source: run + ':' + e.source, target: run + ':' + e.target })))
  evidence[run] = read(path.join(directory, 'knowledge-use-audit/evidence.json'))
  for (const key of Object.keys(usage)) usage[key] += evidence[run].usage[key] ?? 0
  check(run + ':integrity', evidence[run].integrity_passed)
  check(run + ':input_provenance', read(path.join(directory,
    review.input_audits?.[run] ?? 'original-input-audit.json')).passed)
}
nodes.push({ id: 'review', kind: 'IndependentReviewNotCausalProof', artifact: artifact(reviewPath) })
for (const item of review.tasks) {
  const taskRoot = path.join(review.runs[item.run], 'tasks', item.id)
  const id = 'review:' + item.run + ':' + item.id
  const facts = evidence[item.run].tasks.find(t => t.id === item.id)
  const artifacts = item.evidence.map(p => artifact(path.join(taskRoot, p)))
  nodes.push({ id, kind: 'IndependentTaskVerdict', verdict: item.verdict, reason: item.reason, artifacts })
  edges.push({ source: 'review', target: id, relationship: 'contains_verdict' },
    { source: item.run + ':' + item.id, target: id, relationship: 'independently_reviewed_as' })
  const calls = new Map()
  for (const dir of fs.readdirSync(path.join(taskRoot, 'api'))) {
    const file = path.join(taskRoot, 'api', dir, 'response.json')
    if (!fs.existsSync(file)) continue
    for (const call of read(file).choices[0].message.tool_calls ?? []) calls.set(call.id, Number(dir))
  }
  for (const rule of item.applied_rules) {
    const writes = facts.operations.filter(o => o.name === 'write_file' && o.result.no_change === false &&
      o.result.path === (item.alignment_files?.[rule] ?? item.alignment_file ?? (facts.scenario_text_only ? 'answer.md' : 'dut.sv')))
    const contexts = facts.contexts.filter(c => c.rules.includes(rule))
    check(id + ':delivered_before_change:' + rule, writes.length && contexts.some(c =>
      c.actual_requests.some(r => Number(r.split(':').at(-1)) <= calls.get(writes[0].tool_call_id))))
    edges.push({ source: item.run + ':knowledge:' + rule, target: id, relationship: 'observed_action_alignment_not_causality' })
  }
}
for (const item of review.continuations ?? []) {
  const id = 'continuation:' + item.to + ':' + item.task
  const file = path.join(review.runs[item.to], 'tasks', item.task, 'continuation-provenance.json')
  nodes.push({ id, kind: 'ExactPriorModelArtifactsNotDeveloperReplacement', artifact: artifact(file) })
  edges.push({ source: item.from + ':' + item.task, target: id, relationship: 'preserved_original_error_history' },
    { source: id, target: item.to + ':' + item.task, relationship: 'seeds_continuation_not_new_from_original_run' })
}
const bundle = loadBundle(path.join(root, 'published-knowledge'))
nodes.push({ id: 'published', kind: 'PostRunGuidanceNotLoadedInPaidRuns',
  artifact: artifact(path.join(root, 'published-knowledge/manifest.json')) })
for (const node of bundle.graph.nodes) nodes.push({ id: 'published:' + node.id, kind: node.type, content: node })
for (const edge of bundle.graph.edges) edges.push({ source: 'published:' + edge.from, target: 'published:' + edge.to, relationship: edge.type })
for (const node of bundle.graph.nodes.filter(n => n.type === 'skill')) {
  const entry = path.join(bundle.root, node.entry)
  const raw = fs.readFileSync(entry, 'utf8')
  const metadata = YAML.parse(raw.match(/^---\r?\n([\s\S]*?)\r?\n---/)[1])
  check('skill_frontmatter:' + node.name, metadata.name === node.name && typeof metadata.description === 'string')
  const catalog = read(path.join(bundle.root, node.catalog))[node.catalog_field]
  check('skill_ids:' + node.name, new Set(catalog.map(r => r.id)).size === catalog.length)
  check('skill_no_task_leakage:' + node.name, !/\bQ\d{3}\b|[A-Z]:[/\\]|module\s+top_module/.test(raw + JSON.stringify(catalog)))
  edges.push({ source: 'published', target: 'published:' + node.id, relationship: 'freezes_for_future_use' })
}
for (const update of review.skill_updates) for (const basis of update.basis) {
  edges.push({ source: 'review:' + basis, target: 'published:' + update.rule, relationship: 'informs_conditional_guidance_not_proof' })
}
const regressionFiles = review.regression_files ?? [
  'D:/AMD/output/rtl-api-distillation-20261017/knowledge-fix-02-unit/unit-validation.json',
  'D:/AMD/output/rtl-api-distillation-20261017/knowledge-fix-02-native/native-validation.json',
  'D:/AMD/output/rtl-api-distillation-20261017/knowledge-fix-02-real-diagnostic-r2/validation.json',
  'D:/AMD/output/rtl-api-distillation-20261017/knowledge-published-02-unit/unit-validation.json',
]
regressionFiles.forEach((p, i) => {
  nodes.push({ id: 'regression:' + i, kind: 'HostRegressionNotModelGain', artifact: artifact(p) })
  edges.push({ source: 'review', target: 'regression:' + i, relationship: 'supported_by_scoped_host_regression' })
})
const ids = new Set(nodes.map(n => n.id))
check('unique_nodes', ids.size === nodes.length)
check('no_dangling_edges', edges.every(e => ids.has(e.source) && ids.has(e.target)))
check('approved_budget', usage.requests <= (review.budget?.requests ?? 120) && usage.total_tokens <= (review.budget?.tokens ?? 600000))
check('rule_count', bundle.graph.nodes.filter(n => n.type === 'rule').length === (review.expected_rule_count ?? 45))
for (const n of nodes) for (const a of [...(n.artifact ? [n.artifact] : []), ...(n.artifacts ?? [])]) {
  check('artifact:' + n.id + ':' + a.path, hash(a.path) === a.sha256)
}
const out = path.join(root, 'reviewed-knowledge')
fs.mkdirSync(out)
save(path.join(out, 'graph.json'), { scope: 'REVIEWED_TRAJECTORIES_AND_VERSIONED_GUIDANCE_NOT_CAUSAL_GAIN', nodes, edges })
const escape = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c]))
fs.writeFileSync(path.join(out, 'graph.graphml'), '<?xml version="1.0" encoding="UTF-8"?>\n' +
  '<graphml xmlns="http://graphml.graphdrawing.org/xmlns"><key id="record" for="all" attr.name="record" attr.type="string"/><graph id="reviewed" edgedefault="directed">' +
  nodes.map(n => `<node id="${escape(n.id)}"><data key="record">${escape(JSON.stringify(n))}</data></node>`).join('') +
  edges.map((e, i) => `<edge id="e${i}" source="${escape(e.source)}" target="${escape(e.target)}"><data key="record">${escape(e.relationship)}</data></edge>`).join('') +
  '</graph></graphml>\n', { flag: 'wx' })
const result = { passed: checks.every(c => c.passed), usage, checks, nodes: nodes.length, edges: edges.length,
  skill_validation: 'Existing local yaml parser; official quick_validate unavailable because PyYAML is missing',
  behavioral_gain_established: false, artifacts: [artifact(reviewPath), artifact(path.join(out, 'graph.json')),
    artifact(path.join(out, 'graph.graphml')), artifact(path.join(root, 'published-knowledge/manifest.json'))] }
save(path.join(root, 'publication-validation.json'), result)
console.log(JSON.stringify({ passed: result.passed, usage, nodes: nodes.length, edges: edges.length,
  checks: checks.length, failed: checks.filter(c => !c.passed) }))
if (!result.passed) process.exitCode = 1

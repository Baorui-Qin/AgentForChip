import json
from pathlib import Path
import tempfile
import unittest
from api_worker import check_budget, prepare_payload
from task_tools import execute
from launch import authorized_caps


class BudgetTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.directory = self.root / 'tasks/Q123/api/002'
        self.directory.mkdir(parents=True)
        self.plan = {'max_requests': 80, 'max_reported_tokens': 900000,
                     'task_limits': {'Q123': {'requests': 22, 'tokens': 260000, 'eda': 7}},
                     'reserved_closing_calls': 3}
        self.payload = {'max_tokens': 6000, 'messages': []}
        self.save_plan()

    def tearDown(self):
        self.temp.cleanup()

    def save_plan(self):
        (self.root / 'plan.json').write_text(json.dumps(self.plan))

    def receipt(self, qid, number, tokens, complete=True):
        directory = self.root / 'tasks' / qid / 'api' / f'{number:03d}'
        directory.mkdir(parents=True, exist_ok=True)
        (directory / 'reservation.json').write_text('{}')
        if complete:
            (directory / 'receipt.json').write_text('{}')
            (directory / 'response.json').write_text(json.dumps({'usage': {'total_tokens': tokens}}))

    def test_task_and_global_usage_are_separate(self):
        self.receipt('Q123', 1, 9000)
        self.receipt('Q155', 1, 10000)
        value = check_budget(self.root, self.directory, self.payload)
        self.assertEqual((value['previous_actual_tokens'], value['previous_task_tokens']), (19000, 9000))
        self.assertEqual((value['call_number'], value['task_call_number']), (3, 2))

    def test_task_cannot_borrow_unused_other_budget(self):
        self.receipt('Q123', 1, 255000)
        with self.assertRaisesRegex(ValueError, 'Per-task approved budget'):
            check_budget(self.root, self.directory, self.payload)

    def test_unknown_prior_outcome_stops_all_tasks(self):
        self.receipt('Q155', 1, 0, False)
        with self.assertRaisesRegex(ValueError, 'outcome unknown'):
            check_budget(self.root, self.directory, self.payload)

    def test_task_request_cap(self):
        self.plan['task_limits']['Q123']['requests'] = 1
        self.save_plan()
        self.receipt('Q123', 1, 1000)
        with self.assertRaisesRegex(ValueError, 'Per-task approved budget'):
            check_budget(self.root, self.directory, self.payload)

    def test_global_request_and_token_caps(self):
        self.receipt('Q155', 1, 1000)
        for key, value in [('max_requests', 1), ('max_reported_tokens', 1001)]:
            old = self.plan[key]
            self.plan[key] = value
            self.save_plan()
            with self.assertRaises(ValueError):
                check_budget(self.root, self.directory, self.payload)
            self.plan[key] = old

    def test_closing_phase_rejects_and_records_edit(self):
        task = self.root / 'tasks/Q123'
        (task / 'work').mkdir()
        (task / 'question.json').write_text('{"task_type":"rtl_generation"}')
        self.plan['task_limits']['Q123']['requests'] = 4
        self.save_plan()
        self.receipt('Q123', 1, 1)
        self.receipt('Q123', 2, 1)
        result = execute(task, 1, 'write_file', {'path': 'dut.sv', 'content': 'module top_module; endmodule'})
        self.assertTrue(result['operation_rejected'])
        self.assertFalse((task / 'work/dut.sv').exists())
        self.assertTrue((task / 'operations/001/result.json').exists())

    def test_approved_allocations(self):
        limits = json.loads((Path(__file__).parent / 'round4-limits.json').read_text())
        self.assertEqual(sum(v['requests'] for v in limits.values()), 80)
        self.assertEqual(sum(v['tokens'] for v in limits.values()), 900000)
        self.assertEqual(sum(v['eda'] for v in limits.values()) + 7, 34)

    def continuation_policy(self):
        self.plan.update(max_requests_this_run=34, max_tokens_this_run=523517,
                         closing_policy='token_aware_correction_allowed')
        self.save_plan()

    def test_continuation_allocations(self):
        limits = json.loads((Path(__file__).parent / 'round5-limits.json').read_text())
        self.assertEqual(sum(v['requests'] for v in limits.values()) + 46, 80)
        self.assertEqual(sum(v['tokens'] for v in limits.values()) + 376483, 900000)
        self.assertEqual(sum(v['eda'] for v in limits.values()) + 29, 45)

    def test_run_budget_is_not_cumulative_budget(self):
        self.continuation_policy()
        parent = self.root / 'parent'
        old = parent / 'tasks/Q123/api/001'
        old.mkdir(parents=True)
        for name, value in [('reservation', {}), ('receipt', {}), ('response', {'usage': {'total_tokens': 376483}})]:
            (old / (name + '.json')).write_text(json.dumps(value))
        self.plan['budget_roots'] = [str(parent), str(self.root)]
        self.save_plan()
        # Distinct run roots are normally siblings; use the exact tasks subtree, not containment.
        result = check_budget(self.root, self.directory, self.payload)
        self.assertEqual(result['previous_task_tokens'], 0)
        self.assertEqual(result['previous_run_tokens'], 0)
        self.assertEqual(result['previous_actual_tokens'], 376483)

    def test_new_run_caps(self):
        self.continuation_policy()
        self.receipt('Q155', 1, 1000)
        for key, value in [('max_requests_this_run', 1), ('max_tokens_this_run', 1001)]:
            old = self.plan[key]
            self.plan[key] = value
            self.save_plan()
            with self.assertRaisesRegex(ValueError, 'This-run approved budget'):
                check_budget(self.root, self.directory, self.payload)
            self.plan[key] = old

    def test_new_closing_phase_allows_real_corrective_write(self):
        self.continuation_policy()
        task = self.root / 'tasks/Q123'
        (task / 'work').mkdir()
        (task / 'question.json').write_text('{"task_type":"rtl_generation"}')
        self.plan['task_limits']['Q123']['requests'] = 2
        self.save_plan()
        self.receipt('Q123', 1, 1000)
        self.receipt('Q123', 2, 1000)
        result = execute(task, 1, 'write_file', {'path': 'dut.sv', 'content': 'module top_module; endmodule'})
        self.assertFalse(result.get('operation_rejected', False))
        self.assertFalse(result['no_change'])

    def test_output_cap_reduced_without_relaxing_budget(self):
        self.continuation_policy()
        self.plan['task_limits']['Q123']['tokens'] = 4000
        self.save_plan()
        payload, decision = prepare_payload(self.root, self.directory, self.payload)
        self.assertGreaterEqual(payload['max_tokens'], 1024)
        self.assertLess(payload['max_tokens'], 6000)
        self.assertTrue(decision['closing_priority'])
        self.assertLessEqual(check_budget(self.root, self.directory, payload)['reserved_upper_bound'], 4000)

    def test_input_cannot_fit_stops_before_reservation(self):
        self.continuation_policy()
        self.plan['task_limits']['Q123']['tokens'] = 1000
        self.save_plan()
        with self.assertRaisesRegex(ValueError, 'stop before dispatch'):
            prepare_payload(self.root, self.directory, self.payload)
        self.assertFalse((self.directory / 'reservation.json').exists())

    def test_new_policy_does_not_bypass_unknown_outcome(self):
        self.continuation_policy()
        self.receipt('Q155', 1, 0, False)
        with self.assertRaisesRegex(ValueError, 'outcome unknown'):
            prepare_payload(self.root, self.directory, self.payload)

    def test_cumulative_eda_guard_rejects_before_process(self):
        task = self.root / 'tasks/Q123'
        (task / 'question.json').write_text('{"task_type":"rtl_generation"}')
        self.plan.update(max_eda_this_run=16, prior_eda_runs=45, max_eda_cumulative=45)
        self.save_plan()
        result = execute(task, 1, 'run_diagnostic', {})
        self.assertTrue(result['operation_rejected'])
        self.assertIn('cumulative EDA', result['error'])
        self.assertFalse((task / 'operations/001/process.json').exists())

    def test_explicit_amendment_only(self):
        limits = json.loads((Path(__file__).parent / 'round6-limits.json').read_text())
        prior = {'max_requests': 80, 'max_reported_tokens': 900000, 'max_eda_cumulative': 45}
        usage = {'calls': 74, 'total': 687634}
        approval = {'status': 'EXPLICITLY_APPROVED_BY_USER', 'task_limits': limits,
                    'previous_used': {'requests': 74, 'tokens': 687634, 'eda': 36},
                    'previous_caps': {'requests': 80, 'tokens': 900000, 'eda': 45},
                    'cumulative_caps': {'requests': 100, 'tokens': 1150000, 'eda': 54}}
        with self.assertRaises(ValueError):
            authorized_caps(prior, usage, limits)
        self.assertEqual(authorized_caps(prior, usage, limits, approval)['requests'], 100)
        approval['status'] = 'AWAITING_CONFIRMATION'
        with self.assertRaises(ValueError):
            authorized_caps(prior, usage, limits, approval)

    def test_round6_allocations(self):
        limits = json.loads((Path(__file__).parent / 'round6-limits.json').read_text())
        self.assertEqual(sum(v['requests'] for v in limits.values()) + 74, 100)
        self.assertEqual(sum(v['tokens'] for v in limits.values()) + 687634, 1150000)
        self.assertEqual(sum(v['eda'] for v in limits.values()) + 36, 54)


if __name__ == '__main__':
    unittest.main()

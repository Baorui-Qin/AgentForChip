"""Verify current API-authored RTL with corrected developer TBs; never complete its agent session."""
import argparse
from pathlib import Path
import shutil
from task_tools import execute, load, save, sha

parser = argparse.ArgumentParser()
parser.add_argument('--run', type=Path, required=True)
args = parser.parse_args()
root = args.run
out = root / 'independent-protocol-review'
out.mkdir(exist_ok=False)
plan = load(root / 'plan.json')
checks = []
for qid in ('Q193', 'Q114'):
    original = root / 'tasks' / qid
    if not (original / 'agent-result.json').exists():
        raise ValueError('Agent task must be stopped before review')
    required = 2 if qid == 'Q193' else 1
    used = len(list((original / 'operations').glob('*/process.json')))
    if used + required > plan['task_limits'][qid]['eda']:
        raise ValueError('Insufficient per-task EDA allocation')
    task = out / qid
    work = task / 'work'
    work.mkdir(parents=True)
    shutil.copyfile(original / 'question.json', task / 'question.json')
    shutil.copyfile(original / 'work/dut.sv', work / 'dut.sv')
    shutil.copyfile(Path(__file__).parent / 'fixtures' / (qid.lower() + '_protocol_tb.sv'), work / 'diag_tb.sv')
    results = [execute(task, 1, 'run_diagnostic', {})]
    if qid == 'Q193':
        results.append(execute(task, 2, 'evaluate_rtl', {}))
    checks.append({'id': qid, 'model_final_source_sha256': sha(original / 'work/dut.sv'),
                   'dut_matches_model_final': sha(original / 'work/dut.sv') == sha(work / 'dut.sv'),
                   'developer_testbench_sha256': sha(work / 'diag_tb.sv'),
                   'passed': all(c['status'] in ('simulation_pass', 'synthesis_pass') for r in results for c in r['cases']),
                   'results': results, 'not_model_requested': True, 'agent_completion_unchanged': True})
    print(qid, [c['status'] for r in results for c in r['cases']], flush=True)
save(out / 'validation.json', {'api_requests': 0, 'developer_correction_and_verification_only': True, 'checks': checks})
assert all(c['passed'] for c in checks)

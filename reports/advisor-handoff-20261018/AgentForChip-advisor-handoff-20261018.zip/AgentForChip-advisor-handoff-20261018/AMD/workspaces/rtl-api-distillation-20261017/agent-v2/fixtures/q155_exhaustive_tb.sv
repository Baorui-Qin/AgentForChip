module tb(output reg done);
  reg signed [15:0] product;
  wire signed [7:0] y;
  top_module dut(.*);
  integer p,mag,quot,remn,expected,checks;
  initial begin
    done=0;checks=0;
    for(p=-32768;p<=32767;p=p+1) begin
      product=p;
      mag=p<0?-p:p;
      quot=mag/128;remn=mag%128;
      if(remn>64 || (remn==64 && quot%2==1)) quot=quot+1;
      expected=p<0?-quot:quot;
      if(expected>127) expected=127;
      if(expected< -128) expected=-128;
      #1;
      if($signed(y)!==expected) $fatal(1,"rounding p=%0d got=%0d expected=%0d",p,$signed(y),expected);
      checks=checks+1;
    end
    if(checks!=65536) $fatal(1,"incomplete enumeration");
    $display("EXHAUSTIVE_CHECKS=%0d",checks);done=1;
  end
endmodule

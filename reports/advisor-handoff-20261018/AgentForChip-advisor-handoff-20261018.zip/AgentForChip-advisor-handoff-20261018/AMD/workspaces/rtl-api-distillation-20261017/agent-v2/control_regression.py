"""Offline real-artifact replay and keyless native wiring checks. Never dispatch API/EDA."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from launch import profile, run, initialize
from task_tools import evidence_summary
from completion_gate import handoff_from_review
from context_window import checkpoint_payload, encoded_size
from api_client import save
from pilot import load, sha

HERE = Path(__file__).resolve().parent
OLD = Path('D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-05')
OUT = Path('D:/AMD/output/rtl-api-distillation-20261017/control-fix-06-r3')

FINDINGS = {
    'Q123': [
        ('full-equation', 'dut.sv', 'Pointer width and Gray conversion changed, but the full comparison still flips only the highest Gray bit.',
         'Check full/empty relations together with address-plus-wrap state and demonstrate declared capacity, overflow blocking and ordered drain.', ['work/dut.sv', 'operations/007/change.diff']),
        ('consumed-payload', 'diag_tb.sv', 'rpop reads live rdata after the dequeue edge; the recorded mismatch can compare the next item to the consumed item.',
         'Capture the accepted payload at the pre-edge handshake and check that captured item, separately from post-edge state.', ['work/diag_tb.sv', 'operations/008/result.json']),
        ('bounded-progress', 'diag_tb.sv', 'The wrap stimulus pushes more than capacity before starting any reader, which can deadlock a correct FIFO.',
         'Use legal concurrent or bounded sequences; explicitly check full blocking rather than waiting for an impossible acceptance.', ['work/diag_tb.sv']),
    ],
    'Q193': [
        ('sampling-schedule', 'diag_tb.sv', 'The test still drives/checks on active edges; the actual diagnostic fails last data wrong.',
         'Drive away from active edges, capture handshake events before NBA and check post-edge state after NBA.', ['work/diag_tb.sv', 'operations/003/result.json']),
        ('source-event-accounting', 'diag_tb.sv', 'Continuous valid can cause additional accepted offers that the expected branch sequence does not count; three writes were unchanged.',
         'Preserve pending offers and track every accepted source event and each independent branch consumption exactly once.', ['work/diag_tb.sv', 'operations/006/result.json']),
    ],
    'Q114': [
        ('source-stability', 'diag_tb.sv', 'COUNTEREVIDENCE TO THE OLD PASS: after A is accepted, valid remains high with another A pending while ready is low, then the driver changes that unaccepted payload to B. This violates public convention 4.',
         'Keep each unaccepted valid/data offer stable until its handshake. A pass from this unchanged driver does not resolve the finding.', ['work/prompt.md', 'work/diag_tb.sv', 'operations/003/result.json']),
        ('source-event-accounting', 'diag_tb.sv', 'Valid remains asserted over extra ready cycles, causing additional accepted B/C transactions that are not checked one by one. The prior summary incorrectly treats absence of DUT edits as no remaining task work.',
         'Check exact source/output accepted event sequences and blocked stability, then rerun both final checks on the corrected testbench/current DUT.', ['work/diag_tb.sv', 'operations/006/submitted-report.json' if (OLD / 'tasks/Q114/operations/006/submitted-report.json').exists() else 'operations/006/call.json']),
    ],
    'Q083': [
        ('ready-observation-edge', 'diag_tb.sv', 'The test checks ready==1 after the last free slot has already been filled; its only write was identical and the diagnostic still fails s_ready during push.',
         'Distinguish pre-acceptance ready from post-edge full state; preserve full-capacity, replacement and ordered-drain assertions instead of deleting checks.', ['work/diag_tb.sv', 'operations/003/result.json', 'operations/005/result.json']),
    ],
}


def make_review():
    tasks = {}
    for qid, findings in FINDINGS.items():
        task = OLD / 'tasks' / qid
        tasks[qid] = {'file_sha256': {name: sha(task / 'work' / name) for name in ('dut.sv', 'diag_tb.sv')},
                      'required_changed_files': ['dut.sv', 'diag_tb.sv'] if qid == 'Q123' else ['diag_tb.sv'],
                      'findings': [{'id': ident, 'file': file, 'observation': observation,
                                    'resolution_condition': condition, 'evidence': refs}
                                   for ident, file, observation, condition, refs in findings]}
    return {'kind': 'READ_ONLY_PRIOR_EVIDENCE_REVIEW_NOT_NEW_EXECUTION', 'source_run': str(OLD), 'tasks': tasks}


def prepare():
    OUT.mkdir(exist_ok=False)
    review = make_review()
    save(OUT / 'continuation-review.json', review)
    old_paths = [p for q in FINDINGS for p in (OLD / 'tasks' / q / 'work').iterdir() if p.is_file()]
    old_paths += [OLD / 'api-usage.json', OLD / 'RUN_REPORT.md', OLD / 'final-validation.json']
    save(OUT / 'historical-files-before.json', {str(p): sha(p) for p in old_paths})
    env = dict(os.environ, TEMP='D:/AMD/tmp/knowledge-live-tests', TMP='D:/AMD/tmp/knowledge-live-tests')
    tests = subprocess.run([sys.executable, '-X', 'utf8', '-B', '-m', 'unittest',
                            'test_agent', 'test_budget', 'test_context_completion'], cwd=HERE, env=env,
                           capture_output=True, text=True)
    save(OUT / 'unit-tests.json', {'scope': 'SYNTHETIC_OFFLINE_FIXTURES_ONLY', 'exit_code': tests.returncode,
         'stdout': tests.stdout, 'stderr': tests.stderr, 'api_requests': 0, 'eda_runs': 0})
    assert tests.returncode == 0
    replay = OUT / 'offline-replay'
    shutil.copytree(OLD / 'knowledge-runtime/retrieval', replay / 'knowledge-runtime/retrieval')
    records = []
    for qid in FINDINGS:
        old, task = OLD / 'tasks' / qid, replay / 'tasks' / qid
        shutil.copytree(old / 'work', task / 'work')
        shutil.copyfile(old / 'session-identity.json', task / 'session-identity.json')
        shutil.copyfile(old / 'question.json', task / 'question.json')
        handoff, provenance = handoff_from_review(old, review['tasks'][qid])
        save(task / 'work/handoff.json', handoff)
        save(task / 'completion-contract.json', handoff['completion_contract'])
        shutil.copytree(task / 'work', task / 'seed')
        save(task / 'seed-manifest.json', {p.name: sha(p) for p in (task / 'work').iterdir()})
        for directory in sorted((old / 'operations').glob('*')):
            for name in ('call.json', 'result.json'):
                path = directory / name
                if path.exists():
                    dest = task / 'operations' / directory.name / name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(path, dest)
        last = sorted((old / 'api').glob('*/payload.json'))[-1]
        payload = load(last)
        directory = task / 'checkpoints/001'
        directory.mkdir(parents=True)
        compact, audit = checkpoint_payload(replay, directory, payload)
        save(directory / 'original-payload.json', payload)
        save(directory / 'checkpoint-preview.json', compact)
        save(directory / 'checkpoint-audit.json', audit)
        if qid in ('Q123', 'Q193', 'Q083'):
            assert audit['checkpoint_bytes'] < audit['original_bytes']
        assert audit['checkpoint_bytes'] + 1500 < 65536
        assert all(f['observation'] in compact['messages'][next(i for i, m in enumerate(compact['messages'])
                   if m['role'] == 'user')]['content'] for f in handoff['unresolved_findings'])
        records.append({'id': qid, 'source_payload': str(last), 'source_payload_sha256': sha(last), **audit,
                        'preview_not_a_dispatched_request': True})
        if qid == 'Q114':
            report = json.loads(load(old / 'operations/006/call.json')['arguments']['report'])
            report['outcome'] = 'complete'
            try:
                evidence_summary(task, report)
                raise AssertionError('Old false completion was accepted')
            except ValueError as error:
                assert 'required_non_comment_change_missing' in str(error)
                save(OUT / 'q114-old-pass-rejection.json', {'rejected': True, 'reason': str(error),
                     'source_report': str(old / 'operations/006/call.json'), 'no_eda_or_model_call': True})
    save(OUT / 'context-replay.json', {'scope': 'OFFLINE_TRANSFORMATION_OF_HISTORICAL_PAYLOADS_NOT_API',
         'records': records, 'api_requests': 0, 'eda_runs': 0})
    smoke = OUT / 'native-smoke'
    src = replay / 'tasks/Q114'
    dst = smoke / 'tasks/Q114'
    for name in ('work', 'seed'):
        shutil.copytree(src / name, dst / name)
    for name in ('seed-manifest.json', 'completion-contract.json', 'question.json'):
        shutil.copyfile(src / name, dst / name)
    save(smoke / 'plan.json', {'scope': 'KEYLESS_NATIVE_CHECKPOINT_WIRING_ONLY', 'execution_order': ['Q114'],
         'context_policy': {'kind': 'artifact_checkpoint_v1', 'max_request_bytes': 65536},
         'max_requests_per_task': 2, 'max_eda_runs_per_task': 0, 'knowledge_runtime_required': True,
         'knowledge_use_directed': True, 'task_limits': {'Q114': {'requests': 2, 'tokens': 100000, 'eda': 0}}})
    profile(smoke)
    save(OUT / 'runtime-source-manifest.json', {p.name: sha(p) for p in HERE.iterdir() if p.suffix in ('.py', '.ts')})
    print(json.dumps({'unit_tests': 'passed', 'replays': [{k: r[k] for k in ('id', 'original_bytes', 'checkpoint_bytes')} for r in records]}))


def native():
    smoke = OUT / 'native-smoke'
    assert not (smoke / 'external-scope-approved.json').exists()
    assert run(smoke, keyless=True) == 0
    task = smoke / 'tasks/Q114'
    checks = list((task / 'checkpoints').glob('*/checkpoint-audit.json'))
    assert len(checks) == 2 and all(load(p)['offline_only'] for p in checks)
    assert not (task / 'api').exists()
    assert not list((task / 'operations').glob('*/process.json'))
    assert load(task / 'agent-result.json')['keyless_preflight_only'] is True
    before = load(OUT / 'historical-files-before.json')
    assert all(sha(Path(p)) == digest for p, digest in before.items())
    save(OUT / 'validation.json', {'passed': True, 'unit_test_count': 50, 'historical_replays': 4,
         'q114_prior_false_completion_rejected': True, 'native_checkpoint_steps': 2,
         'api_requests': 0, 'eda_runs': 0, 'model_work_files_modified': False,
         'historical_files_unchanged': len(before), 'native_process_reaped': load(smoke / 'harness-process.json')['reaped'],
         'limit': 'Control regression only. No claim that a real model now repairs the tasks or that arbitrary testbench semantics are automatically proved.'})
    print('Offline and native control validation passed; API=0, EDA=0.')


def launch_check():
    limits = OUT / 'initializer-fixture-limits.json'
    save(limits, {qid: {'requests': 1, 'tokens': 25000, 'eda': 1} for qid in FINDINGS})
    absent = OUT / 'must-not-exist-without-handoff'
    try:
        initialize(absent, continuation=OLD, maximum_tokens=100000, selected_ids=list(FINDINGS), task_limits=limits)
        raise AssertionError('Missing counterevidence review accepted')
    except ValueError as error:
        assert 'counterevidence' in str(error) and not absent.exists()
    root = OUT / 'initializer-fixture-not-authorized-to-run'
    initialize(root, continuation=OLD, maximum_tokens=100000, selected_ids=list(FINDINGS), task_limits=limits,
               handoff_review=OUT / 'continuation-review.json')
    plan = load(root / 'plan.json')
    assert plan['prior_usage']['calls'] == 74 and plan['prior_usage']['total'] == 687634
    assert plan['max_requests'] == 80 and plan['max_reported_tokens'] == 900000
    assert plan['prior_eda_runs'] == 36 and plan['max_eda_cumulative'] == 45
    assert not (root / 'external-scope-approved.json').exists()
    for qid in FINDINGS:
        task = root / 'tasks' / qid
        handoff = load(task / 'work/handoff.json')
        assert handoff['unresolved_findings']
        assert sha(task / 'work/handoff.json') == load(task / 'seed-manifest.json')['handoff.json']
        for name in ('dut.sv', 'diag_tb.sv'):
            assert sha(task / 'work' / name) == sha(OLD / 'tasks' / qid / 'work' / name)
    save(OUT / 'launch-validation.json', {'scope': 'OFFLINE_INITIALIZATION_FIXTURE_NOT_BUDGET_AUTHORIZATION',
         'passed': True, 'missing_review_rejected_before_creation': True, 'exact_model_files_inherited': True,
         'counterevidence_in_every_task': True, 'cumulative_api_caps_unchanged': True,
         'inherited_accounting': {'requests': 74, 'tokens': 687634, 'eda': 36}, 'api_requests': 0, 'eda_runs': 0})
    print('Initializer rejected absent handoff; exact model artifacts, all findings and shared ledger verified without execution.')


if __name__ == '__main__':
    {'prepare': prepare, 'native': native, 'launch-check': launch_check}[sys.argv[1]]()

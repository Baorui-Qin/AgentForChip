"""Independent public-contract review, never sent to or attributed to the API model."""
import argparse
from pathlib import Path
import shutil
from task_tools import execute, load, save, sha

parser = argparse.ArgumentParser()
parser.add_argument('--run', type=Path, required=True)
args = parser.parse_args()
root = args.run
out = root / 'independent-diagnostics'
out.mkdir(exist_ok=False)
plan = load(root / 'plan.json')
checks = []
for qid, fixture, expected in [('Q123', 'q123_capacity_tb.sv', 'simulate_failed'),
                               ('Q155', 'q155_exhaustive_tb.sv', 'simulation_pass')]:
    original = root / 'tasks' / qid
    if not (original / 'agent-result.json').exists():
        raise ValueError('Wait for the model task to finish before independent review')
    used = len(list((original / 'operations').glob('*/process.json')))
    if used + 1 > plan['task_limits'][qid]['eda']:
        raise ValueError('No remaining EDA allocation for independent review')
    task = out / qid
    (task / 'work').mkdir(parents=True)
    shutil.copyfile(original / 'question.json', task / 'question.json')
    shutil.copyfile(original / 'work/dut.sv', task / 'work/dut.sv')
    shutil.copyfile(Path(__file__).parent / 'fixtures' / fixture, task / 'work/diag_tb.sv')
    result = execute(task, 1, 'run_diagnostic', {})
    checks.append({'id': qid, 'dut_matches_model_final': sha(original / 'work/dut.sv') == sha(task / 'work/dut.sv'),
                   'expected_review_outcome': expected, 'actual': result,
                   'passed': result['cases'][0]['status'] == expected,
                   'not_model_requested': True, 'not_bank_acceptance': True})
    print(qid, result['cases'][0]['status'], flush=True)
save(out / 'validation.json', {'api_requests': 0, 'review_only': True, 'checks': checks})
assert all(c['passed'] for c in checks)

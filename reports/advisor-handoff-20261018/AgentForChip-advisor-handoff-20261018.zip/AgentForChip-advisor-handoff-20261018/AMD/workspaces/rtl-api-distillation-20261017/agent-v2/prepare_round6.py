"""Freeze authorized continuation inputs and controls; no model/EDA execution."""
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import load, sha

HERE = Path(__file__).resolve().parent
ROOT = Path('D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-06')
PARENT = ROOT.with_name('agent-knowledge-05')


def inventory(root):
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = [n for n in dirs if n != 'node_modules' and not (Path(directory) / n).is_junction()
                   and not (Path(directory) / n).is_symlink()]
        for name in files:
            path = Path(directory) / name
            if not path.is_symlink():
                result[path.relative_to(root).as_posix()] = sha(path)
    return result


def main():
    plan = load(ROOT / 'plan.json')
    assert (plan['max_requests'], plan['max_reported_tokens'], plan['max_eda_cumulative']) == (100, 1150000, 54)
    assert (plan['max_requests_this_run'], plan['max_tokens_this_run'], plan['max_eda_this_run']) == (26, 462366, 18)
    assert plan['prior_usage']['calls'] == 74 and plan['prior_usage']['total'] == 687634 and plan['prior_eda_runs'] == 36
    checks = []
    for qid in plan['execution_order']:
        task = ROOT / 'tasks' / qid
        for name in ('dut.sv', 'diag_tb.sv'):
            assert sha(task / 'seed' / name) == sha(task / 'work' / name) == sha(PARENT / 'tasks' / qid / 'work' / name)
        handoff = load(task / 'work/handoff.json')
        assert handoff['unresolved_findings'] and handoff['completion_contract'] == load(task / 'completion-contract.json')
        assert sha(task / 'work/handoff.json') == load(task / 'seed-manifest.json')['handoff.json']
        checks.append({'task': qid, 'passed': True, 'exact_model_files': True,
                       'unresolved_finding_ids': [v['id'] for v in handoff['unresolved_findings']]})
    graph = load(ROOT / 'knowledge-runtime/runtime-graph.json')
    assert sum(n['type'] == 'rule' for n in graph['nodes']) == 46
    save(ROOT / 'continuation-input-audit.json', {'passed': True, 'checks': checks,
         'scope': 'EXACT_PRIOR_MODEL_ARTIFACTS_PLUS_READ_ONLY_COUNTEREVIDENCE_NOT_NEW_FROM_ORIGINAL_REPAIR',
         'runtime_rules': 46, 'runtime_nodes': len(graph['nodes']), 'runtime_edges': len(graph['edges']),
         'developer_corrected_artifacts_inherited': False})
    save(ROOT / 'parent-preservation-before.json', {'scope': 'Prior run artifacts excluding dependency junctions/node_modules',
         'runs': {str(p): inventory(p) for p in (PARENT.with_name('agent-knowledge-04'), PARENT)}})
    snapshot = ROOT / 'verified-runtime-sources'
    snapshot.mkdir()
    for name in ('agent.ts', 'api_worker.py', 'context_window.py', 'completion_gate.py', 'task_tools.py',
                 'launch.py', 'round6-limits.json', 'test_budget.py', 'test_context_completion.py'):
        shutil.copyfile(HERE / name, snapshot / name)
    env = dict(os.environ, TEMP='D:/AMD/tmp/knowledge-live-tests', TMP='D:/AMD/tmp/knowledge-live-tests')
    tests = subprocess.run([sys.executable, '-X', 'utf8', '-B', '-m', 'unittest', 'test_agent', 'test_budget',
                            'test_context_completion'], cwd=HERE, env=env, capture_output=True, text=True)
    save(ROOT / 'preflight-validation.json', {'passed': tests.returncode == 0, 'unit_tests': 52,
         'stdout': tests.stdout, 'stderr': tests.stderr, 'new_api_requests': 0, 'new_eda_runs': 0,
         'prior_control_validation': {'path': str(ROOT.with_name('control-fix-06-r3') / 'final-control-validation.json'),
             'sha256': sha(ROOT.with_name('control-fix-06-r3') / 'final-control-validation.json')},
         'authorization_extension': 'Only explicit cumulative-cap amendment support added; tested with no API.',
         'runtime_sha256': {p.name: sha(p) for p in snapshot.iterdir()}})
    assert tests.returncode == 0
    print('Authorized 26 requests / 462366 tokens / 18 EDA frozen; prior ledger 74 / 687634 / 36; exact model seeds and 46 rules verified.')


if __name__ == '__main__':
    main()

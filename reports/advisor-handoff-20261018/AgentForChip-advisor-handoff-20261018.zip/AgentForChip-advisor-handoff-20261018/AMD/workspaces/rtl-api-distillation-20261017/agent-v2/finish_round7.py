"""Read-only verification of the gated v2 probe; no API or EDA execution."""
import json
from pathlib import Path

from api_worker import budget_state
from context_window import recent_round, content_hash, encoded_size
from step_review import digest
from prepare_round6 import inventory
from api_client import save
from pilot import load, sha

ROOT = Path('D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep')
task = ROOT / 'tasks/Q123'
plan = load(ROOT / 'plan.json')
checks = []


def check(name, value):
    checks.append({'name': name, 'passed': bool(value)})


totals = {'requests': 0, 'prompt_tokens': 0, 'completion_tokens': 0, 'total_tokens': 0}
for directory in sorted((task / 'api').glob('*')):
    if not (directory / 'reservation.json').exists():
        continue
    request, response = load(directory / 'request.json'), load(directory / 'response.json')
    receipt = load(directory / 'receipt.json')
    reservation = load(directory / 'reservation.json')
    number = int(directory.name)
    bound = encoded_size(request) + request['max_tokens']
    totals['requests'] += 1
    for key in ('prompt_tokens', 'completion_tokens', 'total_tokens'):
        totals[key] += response['usage'][key]
    check(directory.name + ':known_http_receipt', receipt['status'] == 200)
    check(directory.name + ':exact_reservation', reservation['reserved_upper_bound'] == bound)
    check(directory.name + ':global_preflight', reservation['previous_actual_tokens'] + bound <= 1150000 and reservation['call_number'] <= 100)
    check(directory.name + ':task_preflight', reservation['previous_task_tokens'] + bound <= 107332 and reservation['task_call_number'] <= 2)
    check(directory.name + ':request_byte_cap', encoded_size(request) <= 65536)
    pending = load(task / f'step-review-pending-{number:03d}.json')
    decision = load(task / 'step-decisions' / f'after-{number:03d}.json')
    check(directory.name + ':review_bound_to_observation', decision['observation_sha256'] == digest(pending['observation']))
    check(directory.name + ':review_bound_to_real_response', pending['observation']['response_sha256'] == sha(directory / 'response.json'))
check('two_confirmed_requests_only', totals['requests'] == 2 and totals['total_tokens'] == 18164)
check('first_review_allowed_once', load(task / 'step-decisions/after-001.json')['action'] == 'continue')
check('second_review_stopped_entire_probe', load(task / 'step-decisions/after-002.json')['action'] == 'stop_run')
check('q114_not_started', not (ROOT / 'tasks/Q114/api').exists() and not (ROOT / 'tasks/Q114/session-identity.json').exists())
check('no_third_request', not (task / 'api/003').exists())
check('host_stop_after_second_q123', load(ROOT / 'step-stop-run.json')['task'] == 'Q123' and load(ROOT / 'step-stop-run.json')['call'] == 2)
check('no_eda', not list(ROOT.glob('tasks/*/operations/*/process.json')))
check('no_writes', all(load(p)['name'] == 'read_file' for p in ROOT.glob('tasks/*/operations/*/call.json')))
for qid in plan['execution_order']:
    for name in ('dut.sv', 'diag_tb.sv'):
        check(qid + ':unchanged:' + name, sha(ROOT / 'tasks' / qid / 'work' / name) == sha(ROOT / 'tasks' / qid / 'seed' / name))
request2 = load(task / 'api/002/request.json')
native2 = load(task / 'api/002/payload.json')
tail = recent_round(native2['messages'])
record = load(task / 'api/002/context-checkpoint.json')
check('v2_used', record['policy'] == 'artifact_checkpoint_v2')
check('recent_round_retained_exactly', bool(tail) and request2['messages'][-len(tail):] == tail)
check('recent_round_hash_matches', content_hash(tail) == record['retained_round_sha256'])
check('recent_two_tool_calls_retained', len(record['retained_round_tool_call_ids']) == 2)
state = next(json.loads(m['content']) for m in request2['messages'] if m['role'] == 'user' and m.get('content', '').startswith('{"kind":"HOST_CHECKPOINT'))
for path in sorted((task / 'operations').glob('*/result.json')):
    result = load(path)
    check('read_already_preloaded:' + path.parent.name,
          result['content'] == state['artifacts'][result['path']]['content'] and
          result['sha256'] == state['artifacts'][result['path']]['sha256'])
check('all_receipts_and_usage_known', load(ROOT / 'knowledge-use-audit/evidence.json')['integrity_passed'])
check('harness_reaped', load(ROOT / 'harness-process.json')['reaped'])
_, ledger = budget_state(ROOT, ROOT / 'tasks/_audit/api/000')
check('cumulative_actual', ledger['calls'] == 98 and ledger['total'] == 922099)
for path in (ROOT / 'verified-runtime-sources').iterdir():
    check('paid_source_snapshot:' + path.name, sha(path) == load(ROOT / 'runtime-source-manifest.json')[path.name])
for path, old in load(ROOT / 'parent-preservation-before.json')['runs'].items():
    check('parent_unchanged:' + path, inventory(Path(path)) == old)
check('original_materials_unchanged', load(ROOT.with_name('knowledge-round7-preservation') / 'preservation.json')['status'] == 'PASS')
save(ROOT / 'api-usage.json', {'scope': 'THIS_SMALL_STEP_PROBE_ONLY', 'totals': totals,
     'tasks': {'Q123': {'requests': 2, 'total_tokens': 18164, 'eda': 0, 'writes': 0},
               'Q114': {'requests': 0, 'total_tokens': 0, 'eda': 0, 'writes': 0, 'status': 'not_started_due_to_repeat_stop'}},
     'cumulative': {'requests': 98, 'total_tokens': 922099, 'eda': 36},
     'remaining': {'requests': 2, 'total_tokens': 227901, 'eda': 18},
     'remaining_request_allocation': {'Q123': 0, 'Q193': 0, 'Q114': 2, 'Q083': 0},
     'automatic_retry': False, 'unknown_outcomes': [], 'billing_inquiry': False, 'currency_cost': None})
save(ROOT / 'probe-conclusion.json', {'scope': 'BOUNDED_REAL_V2_PROBE_NOT_CONTROLLED_GAIN_EXPERIMENT',
     'q123': {'calls': 2, 'observed_sequence': ['two distinct relevant lookups', 'read two unchanged preloaded files'],
              'substantive_modification': False, 'model_verification': False, 'model_summary': False,
              'transition_to_edit_and_validation_observed': False, 'completed': False},
     'q114': {'calls': 0, 'status': 'not_started_due_to_entire_probe_repeat_stop', 'no_model_result_inferred': True},
     'confirmed_data_path': 'The real second API request preserved the exact previous assistant/tool round and delivered retrieved rules.',
     'limits': ['No improvement into substantive work was observed within this two-call Q123 window.',
                'This does not prove v2 can never work or that a later call would never edit.',
                'Q114 was not tested; no result is extrapolated to it.',
                'No developer DUT/TB edit or supplemental EDA was performed.'],
     'planned_tasks': 2, 'attempted_tasks': 1, 'completed_tasks': 0, 'unattempted_tasks': 1})
result = {'passed': all(c['passed'] for c in checks), 'scope': 'RECORD_AND_STOP_POLICY_INTEGRITY_NOT_REPAIR_SUCCESS',
          'checks': checks, 'this_run': {'requests': 2, 'tokens': 18164, 'eda': 0},
          'cumulative': {'requests': 98, 'tokens': 922099, 'eda': 36},
          'model_writes': 0, 'model_tests': 0, 'completed_tasks': 0, 'attempted_tasks': 1, 'unattempted_tasks': 1}
save(ROOT / 'final-validation.json', result)
print(json.dumps({'passed': result['passed'], 'checks': len(checks), 'failed': [c for c in checks if not c['passed']],
                  'requests': 2, 'tokens': 18164, 'EDA': 0, 'Q114': 'not_started'}))
assert result['passed']

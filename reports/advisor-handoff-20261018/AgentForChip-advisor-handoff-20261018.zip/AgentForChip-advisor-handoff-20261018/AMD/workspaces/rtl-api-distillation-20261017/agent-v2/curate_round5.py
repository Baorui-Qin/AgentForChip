"""Persist read-only trajectory review and accounting; no model artifacts are edited."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import load, sha

ROOT = Path('D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-05')
parent = ROOT.with_name('agent-knowledge-04')
plan = load(ROOT / 'plan.json')
audit = load(ROOT / 'knowledge-use-audit/evidence.json')
tasks = [
    {'id': 'Q123', 'run': 'round5', 'verdict': 'INCOMPLETE_PARTIAL_CHANGE_FAILED_DIAGNOSTIC',
     'reason': 'DUT binary pointers changed to address plus wrap and full-width Gray at operation 007. Full comparison still inverts only the highest Gray bit: static inconsistency, not a newly observed capacity failure. Operation 005 moved TB drive/reset to negedges but rpop compares live rdata after dequeue; operation 008 actually reports rdata=22 exp=11. Serial over-capacity stimulus also remains. No final bank or summary. Local attempt 011 did not dispatch because conservative full-input reservation could not fit.',
     'applied_rules': ['R-CDC', 'T-021'], 'alignment_files': {'R-CDC': 'dut.sv', 'T-021': 'diag_tb.sv'},
     'adoption_extent': 'partial observable alignment only, not complete rule compliance or successful repair',
     'evidence': ['continuation-provenance.json', 'operations/005/change.diff', 'operations/007/change.diff',
                  'operations/008/result.json', 'operations/009/result.json', 'work/dut.sv', 'work/diag_tb.sv', 'agent-result.json']},
    {'id': 'Q193', 'run': 'round5', 'verdict': 'INCOMPLETE_NO_PROGRESS',
     'reason': 'Current TB still fails last data check. T-021 was actually delivered before write attempts 004-006, but all three hashes are unchanged. Active-edge driving/sampling and uncounted continuous-valid extra offers remain. The no-progress guard stopped further calls; no final frozen-bank evaluation or summary. Prior repaired DUT and developer tests are not new closure.',
     'applied_rules': [], 'adoption_extent': 'delivered guidance but no actual correction',
     'evidence': ['continuation-provenance.json', 'operations/003/result.json', 'operations/004/result.json',
                  'operations/005/result.json', 'operations/006/result.json', 'work/diag_tb.sv', 'host-stop.jsonl', 'agent-result.json']},
    {'id': 'Q114', 'run': 'round5', 'verdict': 'INCOMPLETE_UNCORRECTED_TESTBENCH_DESPITE_PASSES',
     'reason': 'No writes. Model reran unchanged diagnostic at 003 and frozen bank at 004, both passed, then submitted a structurally accepted summary. The inherited TB still holds valid with A while stalled then changes its pending payload to B without acceptance. Required testbench-change flag is false. Initial compact context also omitted the known invalid-driver review, an actual controller handoff omission. The raw completed label and model remaining=no defect do not establish task completion.',
     'applied_rules': [], 'adoption_extent': 'R-STALL delivered and old DUT inspected, not new correction',
     'evidence': ['continuation-provenance.json', 'work/initial-evidence.json', 'work/diag_tb.sv',
                  'operations/003/result.json', 'operations/004/result.json', 'teacher-summary.json', 'completion-audit.json', 'agent-result.json']},
    {'id': 'Q083', 'run': 'round5', 'verdict': 'INCOMPLETE_UNCHANGED_TESTBENCH_AND_MISSING_FINAL_BANK',
     'reason': 'Write 003 was byte-identical. Diagnostic call 004 supplied a forbidden path argument and was rejected without EDA; corrected tool invocation 005 actually ran and still failed s_ready during push. The TB compares pre-acceptance ready after filling the final slot. No final bank or summary in this run. Local attempt 006 was blocked before dispatch by the full-input budget reservation. Prior three-configuration bank pass is historical only.',
     'applied_rules': [], 'adoption_extent': 'rule receipt and tool-argument correction, no RTL/TB correction',
     'evidence': ['continuation-provenance.json', 'operations/003/result.json', 'operations/004/call.json',
                  'operations/004/result.json', 'operations/005/result.json', 'work/diag_tb.sv', 'agent-result.json']},
]
updates = [
    ('R-CDC', ['Q123']), ('T-021', ['Q123', 'Q193']), ('H03', ['Q193']), ('H06', ['Q123', 'Q083']),
    ('H07', ['Q114', 'Q123']), ('H08', ['Q114']), ('H09', ['Q123', 'Q114']),
    ('H12', ['Q114']), ('H13', ['Q123', 'Q193']),
]
review = {'scope': 'REAL_API_CONTINUATION_REVIEW_NOT_NEW_FROM_ORIGINAL_REPAIR_OR_GAIN_TEST',
          'runs': {'round4': str(parent), 'round5': str(ROOT)},
          'input_audits': {'round5': 'continuation-input-audit.json'},
          'continuations': [{'from': 'round4', 'to': 'round5', 'task': qid} for qid in plan['execution_order']],
          'tasks': tasks, 'strict_completed': 0, 'strict_total': 4, 'developer_supplemental_eda': 0,
          'skill_updates': [{'rule': rule, 'basis': ['round5:' + q for q in qs]} for rule, qs in updates],
          'expected_rule_count': 46, 'budget': {'requests': 80, 'tokens': 900000},
          'regression_files': [str(ROOT / 'python-test-validation.json'), str(ROOT / 'preflight-validation.json'),
                               str(ROOT / 'published-retrieval-regression/unit-validation.json')],
          'new_guidance_loaded_in_this_paid_run': False,
          'new_guidance_authorship': 'Codex post-run review of visible API actions, diffs and tool results; not new teacher summaries',
          'review_limit': 'Read-only source and evidence review, no new simulation, formal proof, timing or physical CDC sign-off.'}
save(ROOT / 'reviewed-lessons.json', review)
totals = {'requests': 0, 'prompt_tokens': 0, 'completion_tokens': 0, 'total_tokens': 0}
by_task = {}
for qid in plan['execution_order']:
    counts = dict(totals)
    counts.update({key: 0 for key in totals})
    for path in sorted((ROOT / 'tasks' / qid / 'api').glob('*/response.json')):
        value = load(path)['usage']
        counts['requests'] += 1
        for key in ('prompt_tokens', 'completion_tokens', 'total_tokens'):
            counts[key] += value[key]
    counts['eda'] = len(list((ROOT / 'tasks' / qid / 'operations').glob('*/process.json')))
    by_task[qid] = counts
    for key in totals:
        totals[key] += counts[key]
save(ROOT / 'api-usage.json', {'scope': 'THIS_CONTINUATION_ONLY', 'totals': totals, 'tasks': by_task,
     'cumulative': {'requests': 46 + totals['requests'], 'total_tokens': 376483 + totals['total_tokens'],
                    'eda': 29 + sum(t['eda'] for t in by_task.values())},
     'remaining_under_unchanged_global_caps': {'requests': 80 - 46 - totals['requests'],
                                              'tokens': 900000 - 376483 - totals['total_tokens'],
                                              'eda': 45 - 29 - sum(t['eda'] for t in by_task.values())},
     'automatic_retry': False, 'unknown_outcomes': [], 'billing_inquiry': False, 'currency_cost': None})
save(ROOT / 'knowledge-revision.json', {'loaded_manifest': {'path': str(ROOT / 'knowledge-runtime/manifest.json'),
     'sha256': sha(ROOT / 'knowledge-runtime/manifest.json')}, 'post_run_rules_updated': [u[0] for u in updates],
     'new_rules_added': 0, 'total_rules': 46, 'source_review_sha256': sha(ROOT / 'reviewed-lessons.json'),
     'post_run_revision_not_used_by_paid_model': True})
print('Strict completion 0/4; reviewed failures retained; requests=' + str(totals['requests']))

"""Correct diagnostic phases independently; retain the model's failed original diagnostic."""
import argparse
from pathlib import Path
import shutil
from task_tools import execute, load, save, sha

parser = argparse.ArgumentParser()
parser.add_argument('--run', type=Path, required=True)
root = parser.parse_args().run
original = root / 'tasks/Q083'
if not (original / 'agent-result.json').exists():
    raise ValueError('Agent must finish before review')
if len(list((original / 'operations').glob('*/process.json'))) + 1 > load(root / 'plan.json')['task_limits']['Q083']['eda']:
    raise ValueError('Insufficient per-task EDA allocation')
task = root / 'independent-fifo-review/Q083'
(task / 'work').mkdir(parents=True, exist_ok=False)
shutil.copyfile(original / 'question.json', task / 'question.json')
shutil.copyfile(original / 'work/dut.sv', task / 'work/dut.sv')
shutil.copyfile(Path(__file__).parent / 'fixtures/q083_protocol_tb.sv', task / 'work/diag_tb.sv')
result = execute(task, 1, 'run_diagnostic', {})
save(task.parent / 'validation.json', {'api_requests': 0, 'developer_review_only': True,
    'dut_matches_model_final': sha(original / 'work/dut.sv') == sha(task / 'work/dut.sv'),
    'result': result, 'passed': result['cases'][0]['status'] == 'simulation_pass'})
print(result['cases'][0]['status'])
assert result['cases'][0]['status'] == 'simulation_pass'

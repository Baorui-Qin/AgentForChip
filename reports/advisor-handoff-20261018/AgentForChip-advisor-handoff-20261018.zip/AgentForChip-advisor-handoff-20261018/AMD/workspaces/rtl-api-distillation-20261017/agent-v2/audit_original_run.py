"""Check original-input provenance and host gates after a real run has stopped."""
import argparse
import json
from pathlib import Path

from audit_knowledge_run import audit, artifact, lines
from task_tools import load, save, sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, required=True)
    args = parser.parse_args()
    root = args.run
    audit(root)
    evidence = load(root / 'knowledge-use-audit/evidence.json')
    plan = load(root / 'plan.json')
    initial = Path(plan['initial'])
    rows, checks = [], []

    def check(name, value):
        checks.append({'name': name, 'passed': bool(value)})

    for row in evidence['tasks']:
        task = root / 'tasks' / row['id']
        state = load(task / 'start-state.json')
        q = load(task / 'question.json')
        primary = 'answer.md' if row['scenario_text_only'] else 'dut.sv'
        seed = task / 'seed' / primary
        if state['origin'] == 'public_original_buggy_starter':
            expected = q['starter_code']
        elif state['origin'] == 'first_api_candidate_never_repaired':
            expected = (initial / 'candidates-initial' / row['id'] / 'dut.sv').read_text(encoding='utf-8')
        elif state['origin'] == 'first_api_scenario_answer':
            expected = (initial / 'answers' / row['id'] / 'initial/answer.txt').read_text(encoding='utf-8')
        elif state['origin'] == 'empty_generation_candidate':
            expected = ''
        else:
            raise ValueError('Unknown source origin')
        check(row['id'] + ':exact_original_input', seed.read_text(encoding='utf-8') == expected)
        check(row['id'] + ':seed_hash', sha(seed) == load(task / 'seed-manifest.json')[primary])
        check(row['id'] + ':no_inherited_tb', not (task / 'seed/diag_tb.sv').exists())
        writes = [op for op in row['operations'] if op['name'] == 'write_file' and
                  op['result'].get('path') == primary and not op['result'].get('no_change')]
        baselines = [op for op in row['operations'] if op['result'].get('kind') == 'frozen_bank_evaluation'
                     and op['result'].get('source_sha256') == sha(seed)]
        if state['baseline_required'] and writes:
            check(row['id'] + ':baseline_before_write', any(op['operation'] < writes[0]['operation'] for op in baselines))
        completion_path = task / 'completion-audit.json'
        completion = load(completion_path) if completion_path.exists() else None
        limits = plan.get('task_limits', {}).get(row['id'])
        if limits:
            responses = list((task / 'api').glob('*/response.json'))
            tokens = sum(load(p)['usage']['total_tokens'] for p in responses)
            check(row['id'] + ':request_allocation', len(responses) <= limits['requests'])
            check(row['id'] + ':token_allocation', tokens <= limits['tokens'])
            check(row['id'] + ':eda_allocation', len(list((task / 'operations').glob('*/process.json'))) <= limits['eda'])
            for response in responses:
                reservation = load(response.parent / 'reservation.json')
                check(row['id'] + ':reserved_upper_bound:' + response.parent.name,
                      load(response)['usage']['total_tokens'] <= reservation['reserved_upper_bound'])
        if completion:
            check(row['id'] + ':completion_final_hash', completion['final_sha256'] == sha(task / 'work' / primary))
            if not row['scenario_text_only']:
                check(row['id'] + ':completion_current_tb', all(
                    v['testbench_sha256'] == sha(task / 'work/diag_tb.sv')
                    for k, v in completion['final_tests'].items() if k == 'teacher_authored_public_diagnostic'))
            finish = next(op for op in row['operations'] if op['name'] == 'finish_task' and op['result'].get('accepted'))
            call = finish['tool_call_id']
            request_number = next(int(p.parent.name) for p in (task / 'api').glob('*/response.json')
                                  if any(c['id'] == call for c in load(p)['choices'][0]['message'].get('tool_calls', [])))
            check(row['id'] + ':no_paid_call_after_acceptance', request_number == row['model_requests'])
        for log in row['diagnostic_log_reviews']:
            if log['nominal_pass_with_failure_prints']:
                tool = next(op['result'] for op in row['operations'] if op['operation'] == log['operation'])
                check(row['id'] + ':printed_failure_not_accepted', all(c['status'] == 'simulate_failed' for c in tool['cases']))
        rows.append({'id': row['id'], 'origin': state['origin'], 'seed': artifact(seed),
                     'current': artifact(task / 'work' / primary),
                     'baseline_operations': [op['operation'] for op in baselines],
                     'changed_write_operations': [op['operation'] for op in writes],
                     'completion': completion, 'host_stops': lines(task / 'host-stop.jsonl'),
                     'independent_knowledge_alignment': 'PENDING_REVIEW_NOT_INFERRED_FROM_HOST_GATE'})
    save(root / 'original-input-audit.json', {'scope': 'ORIGINAL_INPUT_AND_HOST_GATE_PROVENANCE',
        'tasks': rows, 'checks': checks, 'passed': all(c['passed'] for c in checks)})
    print(json.dumps({'original_checks': len(checks), 'passed': all(c['passed'] for c in checks),
                      'failed': [c for c in checks if not c['passed']]}, ensure_ascii=False))
    raise SystemExit(0 if all(c['passed'] for c in checks) else 1)


if __name__ == '__main__':
    main()

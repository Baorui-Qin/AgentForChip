"""Read-only provenance checks and runtime snapshot; no API or EDA execution."""
from pathlib import Path
import os
import shutil
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import load, sha


def persist(path, value):
    if path.exists():
        assert load(path) == value
    else:
        save(path, value)


def inventory(root):
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = [name for name in dirs if name != 'node_modules' and
                   not (Path(directory) / name).is_junction() and not (Path(directory) / name).is_symlink()]
        for name in files:
            path = Path(directory) / name
            if not path.is_symlink():
                result[path.relative_to(root).as_posix()] = sha(path)
    return result


HERE = Path(__file__).resolve().parent
ROOT = Path('D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-05')
PARENT = ROOT.with_name('agent-knowledge-04')
plan = load(ROOT / 'plan.json')
assert (plan['max_requests'], plan['max_reported_tokens']) == (80, 900000)
assert (plan['max_requests_this_run'], plan['max_tokens_this_run']) == (34, 523517)
assert (plan['prior_eda_runs'], plan['max_eda_this_run'], plan['max_eda_cumulative']) == (29, 16, 45)
checks = []
for qid in plan['execution_order']:
    task = ROOT / 'tasks' / qid
    provenance = load(task / 'continuation-provenance.json')
    for name, item in provenance['files'].items():
        assert sha(task / 'seed' / name) == sha(task / 'work' / name) == sha(Path(item['prior_path'])) == item['sha256']
    assert sha(task / 'work/prompt.md') == sha(PARENT / 'tasks' / qid / 'work/prompt.md')
    checks.append({'task': qid, 'model_files_only': True, 'seed_exact': True,
                   'prior_original_error_trajectory': provenance['original_input_audit'], 'passed': True})
persist(ROOT / 'continuation-input-audit.json', {'passed': True, 'checks': checks,
     'historical_edits_not_new_repair': True, 'developer_artifacts_inherited': False})
persist(ROOT / 'parent-preservation-before.json', {'scope': 'prior run evidence, excludes dependency junctions and node_modules',
                                                'files': inventory(PARENT)})
snapshot = ROOT / 'verified-runtime-sources'
snapshot.mkdir()
for name in ('agent.ts', 'api_worker.py', 'task_tools.py', 'launch.py', 'round5-limits.json', 'test_budget.py'):
    shutil.copyfile(HERE / name, snapshot / name)
env = dict(os.environ, TEMP='D:/AMD/tmp/knowledge-live-tests', TMP='D:/AMD/tmp/knowledge-live-tests')
result = subprocess.run([sys.executable, '-X', 'utf8', '-B', '-m', 'unittest', 'test_agent', 'test_budget'],
                        cwd=HERE, env=env, capture_output=True, text=True)
save(ROOT / 'python-test-validation.json', {'exit_code': result.returncode, 'stdout': result.stdout,
     'stderr': result.stderr, 'sources': {p.name: sha(p) for p in snapshot.iterdir()}})
assert result.returncode == 0
save(ROOT / 'preflight-validation.json', {'passed': True, 'python_tests': 31, 'retrieval_tests': 15,
     'native_smoke': load(ROOT.with_name('knowledge-round5-native-smoke') / 'harness-process.json'),
     'new_eda_runs': 0, 'new_api_requests': 0,
     'test_invocation_errors': ['Initial node --test invocation omitted required output argument',
                                'Second invocation pointed to an existing bundle directory; both stopped before tests'],
     'final_retrieval_test': str(ROOT / 'retrieval-regression')})
print('Continuation inputs, unchanged global caps, 46-rule runtime and regression snapshot verified.')

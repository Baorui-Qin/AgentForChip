"""Check the approved five-task run, final publication, and local regression evidence."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from task_tools import load, save, sha

parser = argparse.ArgumentParser()
parser.add_argument('--run', type=Path, required=True)
args = parser.parse_args()
root = args.run
base = root.parent
checks = []
def check(name, value):
    checks.append({'name': name, 'passed': bool(value)})

plan = load(root / 'plan.json')
evidence = load(root / 'knowledge-use-audit/evidence.json')
by_task = {}
for qid in plan['execution_order']:
    rows = [load(p)['usage'] for p in (root / 'tasks' / qid / 'api').glob('*/response.json')]
    by_task[qid] = {'requests': len(rows), **{key: sum(row[key] for row in rows)
        for key in ('prompt_tokens', 'completion_tokens', 'total_tokens')}}
save(root / 'api-usage.json', {'scope': 'THIS_ADDITIONAL_AUTHORIZATION_ONLY', 'approved_requests': 80,
    'approved_tokens': 900000, 'actual': evidence['usage'], 'by_task': by_task,
    'automatic_retry': False, 'billing_queried': False, 'currency_cost': None,
    'unknown_outcomes': evidence['unknown']})
check('authorized_order', plan['execution_order'] == ['Q123', 'Q155', 'Q193', 'Q114', 'Q083'])
check('fresh_budget_only', plan['budget_roots'] == [str(root)])
check('approved_global_limits', plan['max_requests'] == 80 and plan['max_reported_tokens'] == 900000)
check('request_budget', evidence['usage']['requests'] <= 80)
check('token_budget', evidence['usage']['total_tokens'] <= 900000)
check('known_outcomes', not evidence['unknown'])
check('original_inputs', load(root / 'original-input-audit.json')['passed'])
check('trajectory_integrity', evidence['integrity_passed'])
process = load(root / 'harness-process.json')
check('harness_reaped', process['reaped'] and process['exit_code'] == 0)
manifest = load(root / 'runtime-source-manifest.json')
for name in ('agent.ts', 'api_worker.py', 'task_tools.py', 'launch.py', 'round4-limits.json'):
    check('runtime_frozen:' + name, sha(root / 'verified-runtime-sources' / name) == manifest[name])
for name, expected in load(root / 'knowledge-runtime/manifest.json')['files'].items():
    check('knowledge_frozen:' + name, sha(root / 'knowledge-runtime' / name) == expected)
eda_runs = len(list((root / 'tasks').glob('*/operations/*/process.json')))
review_eda = len(list((root / 'independent-diagnostics').glob('*/operations/*/process.json')))
review_eda += len(list((root / 'independent-protocol-review').glob('*/operations/*/process.json')))
review_eda += len(list((root / 'independent-fifo-review').glob('*/operations/*/process.json')))
check('total_eda_budget', eda_runs + review_eda + 7 <= 34)
check('independent_diagnostic_review', all(c['passed'] and c['dut_matches_model_final'] for c in
    load(root / 'independent-diagnostics/validation.json')['checks']))
check('corrected_protocol_review', all(c['passed'] and c['dut_matches_model_final'] for c in
    load(root / 'independent-protocol-review/validation.json')['checks']))
check('corrected_fifo_review', load(root / 'independent-fifo-review/validation.json')['passed'])
for qid, limit in plan['task_limits'].items():
    used = len(list((root / 'tasks' / qid / 'operations').glob('*/process.json')))
    used += len(list((root / 'independent-diagnostics' / qid / 'operations').glob('*/process.json')))
    used += len(list((root / 'independent-protocol-review' / qid / 'operations').glob('*/process.json')))
    used += len(list((root / 'independent-fifo-review' / qid / 'operations').glob('*/process.json')))
    check(qid + ':combined_eda_limit', used <= limit['eda'])
for name in ('knowledge-round4-protocol', 'knowledge-round4-failure-propagation'):
    regression = load(base / name / 'validation.json')
    check(name, all(c['passed'] for c in regression['checks']) and regression['api_requests'] == 0)
check('native_loop_regression', all(c['passed'] for c in load(base / 'knowledge-round4-native/native-validation.json')['checks']))
check('retrieval_regression', load(base / 'knowledge-round4-unit/unit-validation.json')['passed'] == 14)
check('published_retrieval_regression', load(base / 'knowledge-round4-published-unit/unit-validation.json')['passed'] == 15)
q083 = root / 'tasks/Q083'
check('rejected_fifo_write_was_identical', load(q083 / 'operations/006/call.json')['arguments']['content'] ==
      (q083 / 'work/diag_tb.sv').read_text(encoding='utf-8'))
check('fifo_eighth_request_not_dispatched', (q083 / 'api/008/payload.json').exists() and
      not (q083 / 'api/008/reservation.json').exists() and not (q083 / 'api/008/request.json').exists())
check('rounding_directed_cases', len(re.findall(r'^\s+check\(', (root / 'tasks/Q155/work/diag_tb.sv').read_text(), re.M)) == 23)
env = os.environ.copy()
env.update(TEMP='D:/AMD/tmp/knowledge-live-tests', TMP='D:/AMD/tmp/knowledge-live-tests')
unit = subprocess.run([sys.executable, '-B', '-m', 'unittest', 'test_agent', 'test_budget', '-v'],
    cwd=Path(__file__).parent, env=env, capture_output=True, text=True)
save(root / 'python-test-validation.json', {'exit_code': unit.returncode, 'stdout': unit.stdout, 'stderr': unit.stderr,
    'api_requests': 0, 'fixture_only': True})
check('unit_tests', unit.returncode == 0 and 'Ran 23 tests' in unit.stderr)
graph = load(root / 'reviewed-knowledge/graph.json')
xml = ET.parse(root / 'reviewed-knowledge/graph.graphml')
ns = {'g': 'http://graphml.graphdrawing.org/xmlns'}
check('graphml_nodes', len(xml.findall('.//g:node', ns)) == len(graph['nodes']))
check('graphml_edges', len(xml.findall('.//g:edge', ns)) == len(graph['edges']))
check('publication', load(root / 'publication-validation.json')['passed'])
check('preservation', load(base / 'knowledge-round4-preservation/preservation.json')['status'] == 'PASS')
for link in re.findall(r'\]\((D:/[^)]+)\)', (root / 'RUN_REPORT.md').read_text(encoding='utf-8')):
    # The result below is created exclusively after these checks, not before them.
    if Path(link) == root / 'final-validation.json':
        check('report_self_link_targets_output', Path(link).parent == root)
    else:
        check('report_link:' + link, Path(link).exists())
save(root / 'final-validation.json', {'scope': 'INTEGRITY_AND_REGRESSION_NOT_MODEL_SUCCESS',
    'passed': all(c['passed'] for c in checks), 'checks': checks, 'usage': evidence['usage'],
    'agent_eda_runs': eda_runs, 'preflight_eda_runs': 7, 'independent_review_eda_runs': review_eda,
    'artifacts': [{'path': str(root / p), 'sha256': sha(root / p)} for p in
                  ('RUN_REPORT.md', 'reviewed-lessons.json', 'publication-validation.json', 'reviewed-knowledge/graph.json')]})
print(json.dumps({'passed': all(c['passed'] for c in checks), 'checks': len(checks), 'eda_runs': eda_runs + review_eda + 7,
                  'failed': [c for c in checks if not c['passed']]}))
raise SystemExit(0 if all(c['passed'] for c in checks) else 1)

"""Post-run evidence audit only. Never repairs or evaluates the model's files."""
import json
import os
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import load, sha

ROOT = Path('D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-05')
HERE = Path(__file__).resolve().parent
plan = load(ROOT / 'plan.json')
parent = Path(plan['continues_native_run'])
checks = []


def check(name, passed):
    checks.append({'name': name, 'passed': bool(passed)})


def inventory(root):
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = [name for name in dirs if name != 'node_modules' and
                   not (Path(directory) / name).is_junction() and not (Path(directory) / name).is_symlink()]
        for name in files:
            path = Path(directory) / name
            if not path.is_symlink():
                result[path.relative_to(root).as_posix()] = sha(path)
    return result


check('cumulative_api_caps_unchanged', (plan['max_requests'], plan['max_reported_tokens']) == (80, 900000))
check('run_caps_approved', (plan['max_requests_this_run'], plan['max_tokens_this_run'], plan['max_eda_this_run']) == (34, 523517, 16))
check('continuation_provenance', load(ROOT / 'continuation-input-audit.json')['passed'])
check('trajectory_integrity', load(ROOT / 'knowledge-use-audit/evidence.json')['integrity_passed'])
check('harness_reaped', load(ROOT / 'harness-process.json')['reaped'])
totals = {'requests': 0, 'tokens': 0, 'eda': 0}
task_totals = {}
for qid in plan['execution_order']:
    task = ROOT / 'tasks' / qid
    usage = {'requests': 0, 'tokens': 0, 'eda': 0}
    for reservation_path in sorted((task / 'api').glob('*/reservation.json')):
        directory = reservation_path.parent
        check(qid + ':' + directory.name + ':known_outcome', (directory / 'receipt.json').exists() and (directory / 'response.json').exists())
        if not (directory / 'response.json').exists():
            continue
        request, response = load(directory / 'request.json'), load(directory / 'response.json')
        reservation = load(reservation_path)
        actual = response['usage']['total_tokens']
        bound = len(json.dumps(request, ensure_ascii=False).encode('utf-8')) + request['max_tokens']
        usage['requests'] += 1
        usage['tokens'] += actual
        check(qid + ':' + directory.name + ':exact_reservation', reservation['reserved_upper_bound'] == bound)
        check(qid + ':' + directory.name + ':actual_within_reservation', actual <= bound)
        check(qid + ':' + directory.name + ':global_preflight', reservation['previous_actual_tokens'] + bound <= 900000 and reservation['call_number'] <= 80)
        check(qid + ':' + directory.name + ':run_preflight', reservation['previous_run_tokens'] + bound <= 523517 and reservation['run_call_number'] <= 34)
        check(qid + ':' + directory.name + ':task_preflight', reservation['previous_task_tokens'] + bound <= plan['task_limits'][qid]['tokens'] and
              reservation['task_call_number'] <= plan['task_limits'][qid]['requests'])
        check(qid + ':' + directory.name + ':new_closing_policy', load(directory / 'budget-decision.json')['policy'] == 'token_aware_correction_allowed')
    eda = list((task / 'operations').glob('*/process.json'))
    usage['eda'] = len(eda)
    for process in eda:
        check(qid + ':' + process.parent.name + ':eda_reserved', (process.parent / 'eda-reservation.json').exists())
        check(qid + ':' + process.parent.name + ':eda_reaped', load(process)['reaped'])
    for name in ('dut.sv', 'diag_tb.sv'):
        latest = sha(task / 'seed' / name)
        for path in sorted((task / 'operations').glob('*/result.json')):
            result = load(path)
            if result.get('path') == name and 'previous_sha256' in result:
                check(qid + ':' + path.parent.name + ':write_continuity', result['previous_sha256'] == latest)
                latest = result['sha256']
        check(qid + ':' + name + ':final_model_authorship', latest == sha(task / 'work' / name))
    limit = plan['task_limits'][qid]
    check(qid + ':allocation', usage['requests'] <= limit['requests'] and usage['tokens'] <= limit['tokens'] and usage['eda'] <= limit['eda'])
    task_totals[qid] = usage
    for key in totals:
        totals[key] += usage[key]
check('only_model_eda_in_run', len(list((ROOT / 'tasks').glob('*/operations/*/process.json'))) == totals['eda'] and
      not any((ROOT / name).exists() for name in ('independent-diagnostics', 'independent-protocol-review', 'independent-fifo-review')))
prior = plan['prior_usage']
check('total_budget', totals['requests'] <= 34 and totals['tokens'] <= 523517 and totals['eda'] <= 16 and
      totals['requests'] + prior['calls'] <= 80 and totals['tokens'] + prior['total'] <= 900000 and totals['eda'] + 29 <= 45)
for path in (ROOT / 'verified-runtime-sources').iterdir():
    check('runtime_unchanged:' + path.name, sha(path) == sha(HERE / path.name))
check('prior_evidence_unchanged', inventory(parent) == load(ROOT / 'parent-preservation-before.json')['files'])
check('original_materials_unchanged', load(ROOT.with_name('knowledge-round5-preservation') / 'preservation.json')['status'] == 'PASS')
check('python_regression', load(ROOT / 'python-test-validation.json')['exit_code'] == 0)
check('publication', load(ROOT / 'publication-validation.json')['passed'])
graph = load(ROOT / 'reviewed-knowledge/graph.json')
xml = ET.parse(ROOT / 'reviewed-knowledge/graph.graphml').getroot()
check('graphml_node_count', len(xml.findall('.//{*}node')) == len(graph['nodes']))
check('graphml_edge_count', len(xml.findall('.//{*}edge')) == len(graph['edges']))
review = load(ROOT / 'reviewed-lessons.json')
result = {'scope': 'READ_ONLY_INTEGRITY_REVIEW_NOT_ADDITIONAL_EDA_OR_CAUSAL_GAIN',
          'passed': all(c['passed'] for c in checks), 'checks': checks, 'this_run': totals, 'tasks': task_totals,
          'cumulative': {'requests': prior['calls'] + totals['requests'], 'tokens': prior['total'] + totals['tokens'], 'eda': 29 + totals['eda']},
          'strict_verdicts': [t for t in review['tasks'] if t['run'] == 'round5']}
save(ROOT / 'final-validation.json', result)
print(json.dumps({'passed': result['passed'], 'this_run': totals, 'cumulative': result['cumulative'],
                  'checks': len(checks), 'failed': [c for c in checks if not c['passed']]}, ensure_ascii=False))
assert result['passed']

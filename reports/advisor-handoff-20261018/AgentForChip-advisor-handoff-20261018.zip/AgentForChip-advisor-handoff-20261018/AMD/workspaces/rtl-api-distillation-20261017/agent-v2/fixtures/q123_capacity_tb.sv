module tb(output reg done);
  reg wclk=0,rclk=0,wrst_n=0,rrst_n=0,wvalid=0,rready=0;
  reg [7:0] wdata=0;
  wire wready,rvalid;
  wire [7:0] rdata;
  top_module dut(.*);
  always #5 wclk=~wclk;
  always #7 rclk=~rclk;
  integer i,waits;
  reg accepted;
  task push(input [7:0] value);
    begin
      @(negedge wclk);wvalid=1;wdata=value;accepted=0;waits=0;
      while(!accepted && waits<32) begin
        @(posedge wclk);accepted=wready===1'b1;waits=waits+1;
      end
      if(!accepted) $fatal(1,"capacity: write %0d blocked before filling specified depth; no reads occurred",i+1);
      @(negedge wclk);wvalid=0;
    end
  endtask
  initial begin
    done=0;
    #102;wrst_n=1;rrst_n=1;
    repeat(10) @(negedge wclk);
    for(i=0;i<4;i=i+1) push(i+1);
    repeat(4) @(negedge wclk);
    if(wready!==0) $fatal(1,"capacity: FIFO not full after four writes");
    $display("CAPACITY_CHECK: accepted four writes with reader idle");done=1;
  end
endmodule

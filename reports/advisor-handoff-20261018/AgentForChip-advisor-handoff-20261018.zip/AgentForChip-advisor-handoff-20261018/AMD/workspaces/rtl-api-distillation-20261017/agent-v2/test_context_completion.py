"""Offline fixtures only: no API client, no EDA, no edits to historical model work."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from task_tools import execute, evidence_summary, completion_status, sha
from completion_gate import handoff_from_review, source_tokens
from context_window import checkpoint_payload, bound_context, encoded_size
from api_worker import prepare_payload, run


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')


class ContextCompletionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.task = self.root / 'tasks/Q114'
        work = self.task / 'work'
        work.mkdir(parents=True)
        (work / 'prompt.md').write_text('Public contract: keep the pending source offer stable until handshake.')
        (work / 'dut.sv').write_text('module top_module; endmodule\n')
        (work / 'diag_tb.sv').write_text('module tb(output reg done); initial done=1; endmodule\n')
        write(work / 'initial-evidence.json', {'historical_result': 'simulation_pass', 'not_new_verification': True})
        write(self.task / 'question.json', {'task_type': 'rtl_repair'})
        self.contract = {'schema': 'continuation-completion-v1', 'required_changed_files': ['diag_tb.sv'],
                         'required_resolutions': ['source-stability'], 'read_only_semantic_review_required': True}
        self.handoff = {'completion_contract': self.contract, 'unresolved_findings': [
            {'id': 'source-stability', 'observation': 'Prior pass is countered by an illegal pending A-to-B offer change.',
             'resolution_condition': 'Hold pending source payload until accepted; count every handshake.'}]}
        write(work / 'handoff.json', self.handoff)
        write(self.task / 'completion-contract.json', self.contract)
        (self.task / 'seed').mkdir()
        for p in work.iterdir():
            (self.task / 'seed' / p.name).write_bytes(p.read_bytes())
        write(self.task / 'seed-manifest.json', {p.name: sha(p) for p in work.iterdir()})
        write(self.task / 'start-state.json', {'baseline_required': False, 'required_changed_files': ['diag_tb.sv']})
        write(self.task / 'session-identity.json', {'session_id': 'offline-fixture'})
        self.retrieval = self.root / 'knowledge-runtime/retrieval'
        self.retrieval.mkdir(parents=True)
        self.catalog = 'Guidance catalog: lookup_knowledge routes to T-021.'
        self.rule = 'T-021: capture consumed payload before the edge; preserve every stalled source offer.'
        (self.retrieval / '001-message.txt').write_text(self.rule)
        self.events = [{'event': 'catalog_prepared', 'session_id': 'offline-fixture',
                        'message_sha256': hashlib.sha256(self.catalog.encode()).hexdigest()},
                       {'event': 'context_prepared', 'session_id': 'offline-fixture', 'message_file': '001-message.txt',
                        'message_sha256': sha(self.retrieval / '001-message.txt')},
                       {'event': 'lookup', 'session_id': 'offline-fixture', 'query': 'unknown term', 'matched': [], 'selected': []}]
        (self.retrieval / 'retrieval.jsonl').write_text('\n'.join(json.dumps(e) for e in self.events))
        self.payload = {'model': 'OFFLINE_FIXTURE', 'max_tokens': 6000, 'tools': [], 'messages': [
            {'role': 'system', 'content': 'Authority, scope and tool boundaries must survive.'},
            {'role': 'user', 'content': 'Full old task history'},
            {'role': 'user', 'content': self.catalog}, {'role': 'user', 'content': self.rule}]}
        self.plan = {'max_requests': 80, 'max_reported_tokens': 900000, 'max_requests_this_run': 6,
                     'max_tokens_this_run': 212366, 'closing_policy': 'token_aware_correction_allowed',
                     'context_policy': {'kind': 'artifact_checkpoint_v1', 'max_request_bytes': 60000},
                     'task_limits': {'Q114': {'requests': 6, 'tokens': 50000, 'eda': 3}}}
        write(self.root / 'plan.json', self.plan)
        self.directory = self.task / 'api/001'
        self.directory.mkdir(parents=True)

    def tearDown(self):
        self.temp.cleanup()

    def report(self, changes=None, tests=None, outcome='complete'):
        return {'outcome': outcome, 'diagnosis': 'Offline fixture only', 'remaining': '',
                'change_operations': changes or [], 'verification_operations': tests or [],
                'rules': [{'trigger': 'x', 'action': 'y', 'check': 'z', 'caveat': 'not a real model run'}]}

    def bind_model_call(self, op, name, arguments):
        ident = 'OFFLINE_FIXTURE_' + op
        write(self.task / ('tool-dispatch-' + op + '.json'), {'tool_call_id': ident})
        write(self.task / 'api' / op / 'response.json', {'offline_fixture': True, 'choices': [{'message': {
            'tool_calls': [{'id': ident, 'function': {'name': name, 'arguments': json.dumps(arguments)}}]}}]})

    def fake_tests(self, diagnostic_pass=True):
        for op, name, kind, status in [('010', 'run_diagnostic', 'teacher_authored_public_diagnostic', 'simulation_pass' if diagnostic_pass else 'simulate_failed'),
                                       ('011', 'evaluate_rtl', 'frozen_bank_evaluation', 'synthesis_pass')]:
            write(self.task / 'operations' / op / 'call.json', {'name': name, 'arguments': {}})
            write(self.task / 'operations' / op / 'result.json', {'kind': kind, 'source_sha256': sha(self.task / 'work/dut.sv'),
                  'testbench_sha256': sha(self.task / 'work/diag_tb.sv'), 'cases': [{'status': status}]})
            self.bind_model_call(op, name, {})

    def changed_tb(self, comments_only=False):
        old = (self.task / 'work/diag_tb.sv').read_text()
        content = old + '// Not a repair\n' if comments_only else old.replace('done=1', 'done=0; #1; done=1')
        args = {'path': 'diag_tb.sv', 'content': content}
        execute(self.task, 1, 'write_file', args)
        self.bind_model_call('001', 'write_file', args)

    def test_repeated_source_history_no_longer_grows_active_request(self):
        original = copy.deepcopy(self.payload)
        small, _ = checkpoint_payload(self.root, self.directory, self.payload)
        for n in range(25):
            self.payload['messages'] += [{'role': 'assistant', 'tool_calls': [{'id': str(n), 'function': {'name': 'write_file', 'arguments': 'x' * 9000}}]},
                                         {'role': 'tool', 'tool_call_id': str(n), 'content': 'old-source' * 1000}]
        large, record = checkpoint_payload(self.root, self.directory, self.payload)
        self.assertEqual(small, large)
        self.assertGreater(record['original_bytes'], record['checkpoint_bytes'] * 20)
        self.assertEqual(original['messages'], self.payload['messages'][:4])
        self.assertEqual(self.payload['messages'][-1]['role'], 'tool')

    def test_counterevidence_rules_and_failed_observations_survive(self):
        write(self.task / 'operations/001/call.json', {'name': 'run_diagnostic', 'arguments': {}})
        write(self.task / 'operations/001/result.json', {'kind': 'teacher_authored_public_diagnostic',
              'cases': [{'status': 'simulate_failed', 'diagnostics': ['Fatal: source offer changed']}], 'evidence_id': '001'})
        write(self.task / 'operations/002/call.json', {'name': 'evaluate_rtl', 'arguments': {}})
        write(self.task / 'operations/002/result.json', {'kind': 'infrastructure_failure', 'exit_code': 2,
              'diagnostics': ['ERROR: tool did not start']})
        compact, _ = checkpoint_payload(self.root, self.directory, self.payload)
        text = json.dumps(compact)
        self.assertIn('illegal pending A-to-B', text)
        self.assertIn('simulation_pass', text)
        self.assertIn('Fatal: source offer changed', text)
        self.assertIn('ERROR: tool did not start', text)
        self.assertIn('unknown term', text)
        self.assertIn({'role': 'user', 'content': self.rule}, compact['messages'])
        self.assertIn(self.payload['messages'][0], compact['messages'])

    def test_knowledge_omission_rejected(self):
        self.payload['messages'].pop()
        with self.assertRaisesRegex(ValueError, 'silent omission'):
            checkpoint_payload(self.root, self.directory, self.payload)

    def test_pending_or_unmatched_tool_round_rejected(self):
        for tail in ([{'role': 'assistant', 'tool_calls': [{'id': 'pending'}]}],
                     [{'role': 'tool', 'tool_call_id': 'not-called'}]):
            payload = {**self.payload, 'messages': self.payload['messages'] + tail}
            with self.assertRaises(ValueError):
                checkpoint_payload(self.root, self.directory, payload)

    def test_read_only_handoff_tampering_rejected(self):
        write(self.task / 'work/handoff.json', {**self.handoff, 'unresolved_findings': []})
        with self.assertRaisesRegex(ValueError, 'Read-only task context changed'):
            checkpoint_payload(self.root, self.directory, self.payload)

    def test_input_cap_does_not_drop_required_material(self):
        self.plan['context_policy']['max_request_bytes'] = 200
        with self.assertRaisesRegex(ValueError, 'do not truncate'):
            bound_context(self.root, self.directory, self.payload, self.plan)

    def test_checkpoint_fits_budget_without_relaxing_it(self):
        huge = copy.deepcopy(self.payload)
        huge['messages'].append({'role': 'user', 'content': 'repeated old material' * 20000})
        with self.assertRaisesRegex(ValueError, 'stop before dispatch'):
            prepare_payload(self.root, self.directory, huge)
        compact, _ = bound_context(self.root, self.directory, huge, self.plan)
        ready, decision = prepare_payload(self.root, self.directory, compact)
        self.assertLessEqual(encoded_size(ready) + ready['max_tokens'], 50000)
        self.assertEqual(decision['remaining_tokens'], 50000)

    def test_local_stop_never_constructs_network_client(self):
        self.plan['context_policy']['max_request_bytes'] = 200
        write(self.root / 'plan.json', self.plan)
        with patch('api_worker.Client', side_effect=AssertionError('Network forbidden')) as client:
            with self.assertRaises(ValueError):
                run(self.root, self.directory, self.payload)
        client.assert_not_called()
        self.assertFalse((self.directory / 'reservation.json').exists())

    def test_review_requires_counterevidence_and_current_hash(self):
        review = {'file_sha256': {p: sha(self.task / 'work' / p) for p in ('dut.sv', 'diag_tb.sv')},
                  'required_changed_files': ['diag_tb.sv'], 'findings': [{'id': 'source-stability', 'file': 'diag_tb.sv',
                  'observation': 'Illegal pending payload change despite old pass', 'resolution_condition': 'Stable source and exact event counts',
                  'evidence': ['work/diag_tb.sv']}]}
        handoff, refs = handoff_from_review(self.task, review)
        self.assertEqual(handoff['unresolved_findings'][0]['status'], 'unresolved')
        self.assertEqual(len(refs), 1)
        review['file_sha256']['dut.sv'] = 'stale'
        with self.assertRaisesRegex(ValueError, 'Stale handoff'):
            handoff_from_review(self.task, review)
        review['findings'] = []
        with self.assertRaisesRegex(ValueError, 'explicit unresolved'):
            handoff_from_review(self.task, review)

    def test_unchanged_tb_cannot_succeed_even_when_both_tests_pass(self):
        self.fake_tests()
        result = execute(self.task, 12, 'finish_task', {'report': json.dumps(self.report(tests=['010', '011']))})
        self.assertTrue(result['operation_rejected'])
        self.assertIn('required_non_comment_change_missing', result['error'])
        self.assertEqual(completion_status(self.task), 'incomplete')
        self.assertFalse((self.task / 'teacher-summary.json').exists())
        self.assertTrue((self.task / 'operations/012/submitted-report.json').exists())

    def test_comment_only_change_cannot_succeed(self):
        self.changed_tb(comments_only=True)
        self.fake_tests()
        with self.assertRaisesRegex(ValueError, 'required_non_comment_change_missing'):
            evidence_summary(self.task, self.report(['001'], ['010', '011']))

    def test_token_scan_preserves_comment_markers_inside_strings(self):
        self.assertNotEqual(source_tokens('initial $display("// old");'), source_tokens('initial $display("// new");'))
        self.assertEqual(source_tokens('a <= b; // one'), source_tokens('a<=b; /* two */'))

    def test_unattributed_host_write_cannot_succeed(self):
        self.changed_tb()
        (self.task / 'tool-dispatch-001.json').unlink()
        self.fake_tests()
        with self.assertRaisesRegex(ValueError, 'final_model_write_missing'):
            evidence_summary(self.task, self.report(['001'], ['010', '011']))

    def test_failed_diagnostic_cannot_succeed(self):
        self.changed_tb()
        self.fake_tests(False)
        with self.assertRaisesRegex(ValueError, 'tests_not_passed'):
            evidence_summary(self.task, self.report(['001'], ['010', '011']))

    def test_developer_test_cannot_replace_model_test(self):
        self.changed_tb()
        self.fake_tests()
        (self.task / 'tool-dispatch-010.json').unlink()
        with self.assertRaisesRegex(ValueError, 'not_model_requested'):
            evidence_summary(self.task, self.report(['001'], ['010', '011']))

    def test_explicit_incomplete_summary_can_preserve_missing_tests(self):
        result = execute(self.task, 1, 'finish_task', {'report': json.dumps(self.report(outcome='incomplete'))})
        self.assertTrue(result['accepted'])
        self.assertEqual(result['completion_status'], 'incomplete')
        self.assertEqual(completion_status(self.task), 'incomplete')

    def submit_pending_review(self):
        self.changed_tb()
        self.fake_tests()
        result = execute(self.task, 12, 'finish_task', {'report': json.dumps(self.report(['001'], ['010', '011']))})
        self.assertTrue(result['accepted'])
        self.assertEqual(result['completion_status'], 'pending_review')
        return {'kind': 'read_only_semantic_review_no_source_edits_or_eda',
                'file_sha256': {name: sha(self.task / 'work' / name) for name in ('dut.sv', 'diag_tb.sv')},
                'submitted_report_sha256': sha(self.task / 'submitted-report.json'),
                'test_result_sha256': {op: sha(self.task / 'operations' / op / 'result.json') for op in ('010', '011')},
                'findings': [{'id': 'source-stability', 'resolved': True, 'source_evidence': 'OFFLINE FIXTURE ONLY', 'explanation': 'Synthetic gate exercise, not a real correctness review'}]}

    def test_receipt_and_passing_tests_still_need_read_only_review(self):
        self.submit_pending_review()
        self.assertEqual(completion_status(self.task), 'pending_review')

    def test_unresolved_or_stale_review_cannot_succeed(self):
        review = self.submit_pending_review()
        review['findings'][0]['resolved'] = False
        write(self.task / 'read-only-completion-review.json', review)
        self.assertEqual(completion_status(self.task), 'incomplete')
        review['findings'][0]['resolved'] = True
        review['file_sha256']['diag_tb.sv'] = 'stale'
        write(self.task / 'read-only-completion-review.json', review)
        self.assertEqual(completion_status(self.task), 'incomplete')

    def test_current_complete_review_then_later_edit_is_invalid(self):
        review = self.submit_pending_review()
        write(self.task / 'read-only-completion-review.json', review)
        self.assertEqual(completion_status(self.task), 'completed')
        (self.task / 'work/diag_tb.sv').write_text('module tb(output reg done); initial done=0; endmodule')
        self.assertEqual(completion_status(self.task), 'incomplete')

    def test_v2_keeps_the_actual_latest_tool_round(self):
        tail = [{'role': 'assistant', 'content': 'Read the observed file.', 'tool_calls': [
                    {'id': 'recent', 'function': {'name': 'read_file', 'arguments': '{"path":"dut.sv"}'}}]},
                {'role': 'tool', 'tool_call_id': 'recent', 'content': json.dumps({'path': 'dut.sv',
                    'sha256': sha(self.task / 'work/dut.sv'), 'content': (self.task / 'work/dut.sv').read_text()})}]
        self.payload['messages'] += tail
        compact, record = checkpoint_payload(self.root, self.directory, self.payload, preserve_recent=True)
        self.assertEqual(compact['messages'][-2:], tail)
        self.assertEqual(record['retained_round_tool_call_ids'], ['recent'])
        state = next(json.loads(m['content']) for m in compact['messages'] if m['role'] == 'user' and m['content'].startswith('{'))
        self.assertNotIn('content', state['artifacts']['dut.sv'])
        self.assertEqual(state['artifacts']['dut.sv']['content_in_retained_round']['tool_call_id'], 'recent')

    def test_v2_preserves_user_intent_and_guidance_without_old_source_growth(self):
        self.payload['messages'][1]['content'] = 'Correct the known issue.\n--- prompt.md ---\nold seed repeated here'
        tail = [{'role': 'assistant', 'tool_calls': [{'id': 'latest', 'function': {
                    'name': 'lookup_knowledge', 'arguments': '{"query":"T-021"}'}}]},
                {'role': 'tool', 'tool_call_id': 'latest', 'content': '{"matched":["T-021"],"status":"already_in_session"}'}]
        small = {**self.payload, 'messages': self.payload['messages'] + tail}
        old = []
        for n in range(20):
            old += [{'role': 'assistant', 'tool_calls': [{'id': str(n), 'function': {'name': 'read_file', 'arguments': '{}'}}]},
                    {'role': 'tool', 'tool_call_id': str(n), 'content': 'historical source' * 1000}]
        large = {**self.payload, 'messages': self.payload['messages'] + old + tail}
        a, _ = checkpoint_payload(self.root, self.directory, small, preserve_recent=True)
        b, _ = checkpoint_payload(self.root, self.directory, large, preserve_recent=True)
        self.assertEqual(a, b)
        self.assertIn({'role': 'user', 'content': 'Correct the known issue.'}, a['messages'])
        self.assertIn({'role': 'user', 'content': self.rule}, a['messages'])

    def test_v2_write_arguments_supply_current_content_once(self):
        content = (self.task / 'work/diag_tb.sv').read_text()
        tail = [{'role': 'assistant', 'tool_calls': [{'id': 'write', 'function': {'name': 'write_file',
                    'arguments': json.dumps({'path': 'diag_tb.sv', 'content': content})}}]},
                {'role': 'tool', 'tool_call_id': 'write', 'content': json.dumps({'path': 'diag_tb.sv',
                    'sha256': sha(self.task / 'work/diag_tb.sv'), 'no_change': False})}]
        self.payload['messages'] += tail
        compact, _ = checkpoint_payload(self.root, self.directory, self.payload, preserve_recent=True)
        state = next(json.loads(m['content']) for m in compact['messages'] if m['role'] == 'user' and m['content'].startswith('{'))
        self.assertNotIn('content', state['artifacts']['diag_tb.sv'])
        self.assertEqual(compact['messages'][-2:], tail)


if __name__ == '__main__':
    unittest.main()

"""Run the existing dsh CLI with an isolated, no-network scripted adapter."""
import argparse
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'agent-v2'))
from launch import profile, run

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--disabled', action='store_true')
    args = parser.parse_args()
    if args.disabled and not str(args.out).endswith('disabled'):
        raise ValueError('Control directory must end with disabled')
    args.out.mkdir(parents=True, exist_ok=False)
    profile(args.out, driver=HERE / 'smoke.ts', knowledge=not args.disabled)
    raise SystemExit(run(args.out, keyless=True))

import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, mkdirSync, readdirSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import { hash, read, loadBundle, catalogText } from './core.mjs'

const here = dirname(fileURLToPath(import.meta.url))
const base = resolve(process.argv[2])
const out = join(base, 'knowledge-runtime-verification')
mkdirSync(out)
const enabled = join(base, 'knowledge-runtime-verified-enabled')
const disabled = join(base, 'knowledge-runtime-verified-disabled')
const preflight = join(base, 'knowledge-runtime-verified-dev-preflight')
const bundle = loadBundle(join(enabled, 'knowledge-runtime'))
const native = read(join(enabled, 'native-validation.json'))
const control = read(join(disabled, 'native-validation.json'))
const unit = read(join(base, 'knowledge-runtime-verified-unit/unit-validation.json'))
const checks = []
const check = (name, test) => { test(); checks.push({ name, passed: true }) }
check('all native and unit cases passed; keyless scope explicit', () => {
  assert.equal(native.checks.length, 8); assert(native.checks.every(item => item.passed))
  assert.equal(control.checks.length, 1); assert.equal(control.checks[0].contexts, 0)
  assert.equal(unit.passed, 10)
  for (const value of [native, control]) {
    assert.equal(value.api_requests, 0); assert.equal(value.eda_runs, 0); assert.equal(value.behavioral_gain_tested, false)
  }
})
check('every prepared context is in its own native session and subsequent adapter request', () => {
  const ledger = readFileSync(join(enabled, 'knowledge-runtime/retrieval/retrieval.jsonl'), 'utf8').trim().split('\n').map(JSON.parse)
  for (const record of ledger.filter(item => item.event === 'context_prepared')) {
    const text = readFileSync(join(enabled, 'knowledge-runtime/retrieval', record.message_file), 'utf8')
    assert.equal(hash(text), record.message_sha256)
    const directories = readdirSync(enabled).filter(name => /^\d+-/.test(name))
    const owner = directories.find(name => read(join(enabled, name, 'session-events.json')).some(event =>
      event.type === 'session/start' && event.data.sessionId === record.session_id))
      ?? directories.find(name => native.checks[Number(name.split('-')[0]) - 1]?.session_id === record.session_id)
    assert(owner)
    const events = read(join(enabled, owner, 'session-events.json'))
    assert(events.some(event => event.type === 'user/message' && event.data.source?.name === 'rtl-knowledge-runtime'
      && event.data.content.some(block => block.type === 'text' && block.text === text)))
    const requests = readdirSync(join(enabled, owner)).filter(name => /^request-\d+\.json$/.test(name)).map(name => read(join(enabled, owner, name)))
    assert(requests.some(request => request.messages.some(message => message.role === 'user' && message.content === text)))
  }
})
check('native profile pins manifest and uses frozen loader, not original baseline injection', () => {
  const patch = read(join(enabled, 'home/profiles/rtl-teacher-agent-v2/cordis.patch.yml'))[0].insert
  const plugin = patch.find(item => item.id === 'rtl-knowledge-runtime')
  assert.equal(plugin.config.manifestSha256, hash(readFileSync(join(enabled, 'knowledge-runtime/manifest.json'))))
  assert.equal(resolve(plugin.name), resolve(join(enabled, 'knowledge-runtime/runtime/plugin.ts')))
  for (const name of ['core.mjs', 'plugin.ts']) {
    assert.equal(hash(readFileSync(join(here, name))), bundle.manifest.files['runtime/' + name])
  }
})
check('frozen skill files still match original curated files', () => {
  for (const [path, expected] of Object.entries(bundle.manifest.files).filter(([path]) => path.startsWith('skills/'))) {
    assert.equal(hash(readFileSync(join(dirname(here), 'skill', path.slice('skills/'.length)))), expected)
  }
})
check('actual development preflight requires and admits discovery before scripted requests', () => {
  assert.equal(read(join(preflight, 'plan.json')).knowledge_runtime_required, true)
  const result = read(join(preflight, 'tasks/Q123/agent-result.json'))
  assert.equal(result.status, 'completed'); assert.equal(result.keyless_preflight_only, true)
  const events = readFileSync(join(preflight, 'tasks/Q123/session-events.jsonl'), 'utf8').trim().split('\n').map(JSON.parse)
  assert(events.some(event => event.type === 'request/header' && event.data.header.tools.some(tool => tool.name === 'lookup_knowledge')))
  assert(events.some(event => event.type === 'user/message' && event.data.content.some(block => block.type === 'text' && block.text === catalogText)))
})
const regression = spawnSync('C:/Users/qbr/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
  ['-B', '-m', 'unittest', 'test_pipeline.py'], { cwd: dirname(here), encoding: 'utf8', windowsHide: true })
writeFileSync(join(out, 'pipeline-tests.log'), regression.stdout + regression.stderr, { flag: 'wx' })
check('existing eight pipeline regression tests pass', () => assert.equal(regression.status, 0))
const evidence = [join(enabled, 'native-validation.json'), join(disabled, 'native-validation.json'),
  join(base, 'knowledge-runtime-verified-unit/unit-validation.json'), join(preflight, 'tasks/Q123/agent-result.json'),
  join(enabled, 'knowledge-runtime/manifest.json')].map(path => ({ path, sha256: hash(readFileSync(path)) }))
const sources = [...readdirSync(here).filter(name => /\.(mjs|ts|py)$/.test(name)).map(name => join(here, name)),
  join(dirname(here), 'agent-v2/agent.ts'), join(dirname(here), 'agent-v2/launch.py')]
writeFileSync(join(out, 'verification.json'), JSON.stringify({
  scope: 'NATIVE_HARNESS_KNOWLEDGE_DELIVERY_NOT_REAL_MODEL_BENEFIT_TEST', checks,
  tests: { unit: 10, native_enabled: 8, native_disabled: 1, actual_development_keyless_preflight: 1, existing_pipeline: 8 },
  graph: { nodes: bundle.graph.nodes.length, edges: bundle.graph.edges.length, rules: 44, skills: 3 },
  new_api_requests: 0, new_eda_runs: 0, real_model_compliance_tested: false, behavioral_gain_tested: false,
  global_installation: false, original_baseline_profile_changed: false,
  evidence, runtime_source_hashes: sources.map(path => ({ path, sha256: hash(readFileSync(path)) })),
  limitations: ['Curated lexical retrieval, not general semantic recall.', 'Only listed structured signals auto-route.',
    'Existing frozen profiles require explicit migration; no retroactive change.', 'No context compaction plugin tested.',
    'Skill delivery does not implement cancellation or repair old DUT failures.'],
  preserved_failed_attempts: ['knowledge-runtime-01-enabled', 'knowledge-runtime-02-enabled'],
}, null, 2) + '\n', { flag: 'wx' })
process.stdout.write(JSON.stringify({ audit_checks: checks.length, passed: true, report: join(out, 'verification.json') }) + '\n')

import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

export const hash = value => createHash('sha256').update(value).digest('hex')
export const read = path => JSON.parse(readFileSync(path, 'utf8'))

export function loadBundle(root) {
  const manifest = read(join(root, 'manifest.json'))
  for (const [path, expected] of Object.entries(manifest.files)) {
    if (path.includes('..') || path.startsWith('/') || path.includes(':')) throw new Error('Invalid bundle path')
    if (hash(readFileSync(join(root, path))) !== expected) throw new Error('Knowledge bundle hash mismatch: ' + path)
  }
  const graph = read(join(root, 'runtime-graph.json'))
  const nodes = new Map(graph.nodes.map(node => [node.id, node]))
  if (nodes.size !== graph.nodes.length) throw new Error('Duplicate graph node')
  for (const edge of graph.edges) {
    if (!nodes.has(edge.from) || !nodes.has(edge.to)) throw new Error('Dangling graph edge')
  }
  return { root, graph, nodes, manifest }
}

function tokens(text) {
  const forms = { shifts: 'shift', shifting: 'shift', shifted: 'shift', registers: 'register',
    replaces: 'replacement', replace: 'replacement', replacing: 'replacement',
    overwrites: 'overwrite', overwritten: 'overwrite', parameters: 'parameter',
    hashes: 'hash', sampling: 'sample', signedness: 'signed' }
  return new Set((text.match(/[a-z0-9]+/g) ?? []).map(word => forms[word] ?? word))
}

// Match all words in a curated concept, allowing intervening modifiers and inflections.
export function retrieve(bundle, query) {
  if (typeof query !== 'string' || query.length > 500) throw new Error('Query must be a string of at most 500 characters')
  const text = query.toLowerCase().trim()
  const words = tokens(text)
  const ids = new Set(text.toUpperCase().match(/\b(?:H\d{2}|R-[A-Z]+|T-\d{3})\b/g) ?? [])
  const matches = bundle.graph.nodes.filter(node => node.type === 'symptom').map(node => ({
    node,
    score: ids.has(node.rule_id) ? 1000 : node.aliases.reduce((score, alias) => {
      const term = alias.toLowerCase()
      const hit = /^[a-z0-9 -]+$/.test(term)
        ? [...tokens(term)].every(word => words.has(word))
        : text.includes(term)
      return score + (hit ? term.length : 0)
    }, 0),
  })).filter(item => item.score > 0).sort((a, b) => b.score - a.score || a.node.id.localeCompare(b.node.id))
  const selected = matches.slice(0, 3)
  const paths = selected.map(({ node }) => {
    const ruleEdge = bundle.graph.edges.find(edge => edge.from === node.id && edge.type === 'routes_to')
    const rule = bundle.nodes.get(ruleEdge?.to)
    const skillEdge = bundle.graph.edges.find(edge => edge.from === rule?.id && edge.type === 'loaded_from')
    const skill = bundle.nodes.get(skillEdge?.to)
    if (!rule || !skill) throw new Error('Broken symptom-rule-skill route')
    return { symptom: node, rule, skill, edges: [ruleEdge, skillEdge] }
  })
  return { paths, truncated: matches.length > selected.length }
}

export function signalsFor(name, value, state) {
  const signals = []
  if (name === 'write_file' && value.no_change === true && /^[a-f0-9]{64}$/.test(value.sha256)
    && value.sha256 === value.previous_sha256) signals.push('H03')
  if (['evaluate_rtl', 'run_diagnostic'].includes(name) && /^[a-f0-9]{64}$/.test(value.source_sha256)) {
    if (value.cases?.some(item => item.source_sha256 && item.source_sha256 !== value.source_sha256)) signals.push('R-FRESH')
    const expectedKind = name === 'evaluate_rtl' ? 'frozen_bank_evaluation' : 'teacher_authored_public_diagnostic'
    if (value.kind === expectedKind && Array.isArray(value.cases)) {
      for (const item of value.cases) {
        if (!['synthesis_pass', 'simulation_pass', 'simulate_pass', 'simulate_failed'].includes(item.status)
          || (item.source_sha256 && item.source_sha256 !== value.source_sha256)) continue
        // Test-suite labels differ by design; compare source and actual parameter settings.
        const parameters = Object.entries(item.parameters ?? {}).sort(([a], [b]) => a.localeCompare(b))
        const key = JSON.stringify([value.source_sha256, parameters, value.tool_version])
        const seen = state.evaluations.get(key) ?? {}
        seen[name] = item.status !== 'simulate_failed'
        state.evaluations.set(key, seen)
        if (seen.evaluate_rtl !== undefined && seen.run_diagnostic !== undefined
          && seen.evaluate_rtl !== seen.run_diagnostic) signals.push('H09', 'R-CONTRACT')
      }
    }
  }
  return [...new Set(signals)]
}

export const catalogText = `Local reviewed knowledge is available through lookup_knowledge(query).
Search by a short symptom phrase or rule ID, before repeating a failed approach. Examples: identical writes, async fifo, stale evidence, testbench race, budget, signed shift.
After a useful lookup, inspect or change the artifact and verify. Repeating searches without new artifact evidence is bounded by the host and will stop the task; rephrasing the same query does not reset the limit.
The host also routes confirmed same-hash writes and selected structured verification conflicts automatically.
No hit is not evidence that a task is correct. Unknown symptoms require ordinary diagnosis; do not force a match.
Only generalized rules and selected skill instructions are available. Historical answers, private tests and the developer provenance graph are not exposed.
This guidance grants no tools, permissions, network access or additional call budget. It does not prove a repair or establish skill gains.`

export function updateWriteProgress(previous, name, value) {
  if (name !== 'write_file' || value.operation_rejected) return previous
  return value.no_change ? previous + 1 : 0
}

export function assertMounted(payload) {
  if (!payload.tools?.some(tool => tool.function.name === 'lookup_knowledge')
    || !payload.messages?.some(message => message.role === 'user' && message.content === catalogText)) {
    throw new Error('Required knowledge runtime not admitted: model request blocked before API dispatch')
  }
}

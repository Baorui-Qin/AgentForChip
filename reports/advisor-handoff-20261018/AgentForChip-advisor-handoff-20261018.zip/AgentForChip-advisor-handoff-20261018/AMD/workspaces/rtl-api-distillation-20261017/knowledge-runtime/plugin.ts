import { mkdirSync, appendFileSync, writeFileSync, readFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import type { Context } from 'D:/AMD/workspaces/http-paired-20261016/harness/vendor/cordis/src/index.ts'
import z from 'D:/AMD/workspaces/http-paired-20261016/harness/vendor/schemastery/src/index.ts'
import type { Agent } from 'D:/AMD/workspaces/http-paired-20261016/harness/packages/core/agent/src/index.ts'
import { defineTool } from 'D:/AMD/workspaces/http-paired-20261016/harness/packages/core/tools/src/index.ts'
import { createUserMessage } from 'D:/AMD/workspaces/http-paired-20261016/harness/packages/llm/llm/src/index.ts'
import { renderSkillContent } from 'D:/AMD/workspaces/http-paired-20261016/harness/packages/skill/skill/src/index.ts'
import { loadBundle, retrieve, signalsFor, catalogText, hash, read } from './core.mjs'

export const name = 'rtl-knowledge-runtime'
export const inject = ['agents', 'tools', 'skills']
export const Config = z.object({ root: z.string().required(), outputDir: z.string().required(), manifestSha256: z.string().required() })

export function apply(ctx: Context, config: { root: string; outputDir: string; manifestSha256: string }) {
  if (hash(readFileSync(join(config.root, 'manifest.json'))) !== config.manifestSha256) throw new Error('Frozen manifest changed')
  const bundle = loadBundle(config.root)
  mkdirSync(config.outputDir, { recursive: false })
  let serial = 0
  const states = new WeakMap<Agent, { rules: Set<string>; skills: Set<string>; catalog: boolean; evaluations: Map<string, any>;
    searches: number; stopped: boolean; observations: Set<string> }>()
  const stateOf = (agent: Agent) => {
    if (!states.has(agent)) states.set(agent, { rules: new Set(), skills: new Set(), catalog: false, evaluations: new Map(),
      searches: 0, stopped: false, observations: new Set() })
    return states.get(agent)!
  }
  const log = (agent: Agent, value: object) => appendFileSync(join(config.outputDir, 'retrieval.jsonl'),
    JSON.stringify({ session_id: agent.session.id, ...value }) + '\n')

  async function lookup(agent: Agent, query: string, trigger: string, toolCallId: string) {
    const state = stateOf(agent)
    const result = retrieve(bundle, query)
    const paths = result.paths.filter(path => !state.rules.has(path.rule.id))
    log(agent, { event: 'lookup', trigger, tool_call_id: toolCallId, query, matched: result.paths.map(path => path.rule.id),
      selected: paths.map(path => path.rule.id), truncated: result.truncated, graph_sha256: bundle.manifest.files['runtime-graph.json'] })
    if (!paths.length) return { matched: result.paths.map(path => path.rule.id), context: undefined }
    const entries: string[] = []
    const loaded: string[] = []
    for (const path of paths) {
      if (state.skills.has(path.skill.name) || loaded.includes(path.skill.name)) continue
      const entry = join(config.root, path.skill.entry)
      if (hash(readFileSync(entry)) !== path.skill.sha256) throw new Error('Frozen entry changed')
      const skill = await ctx.skills.get(path.skill.name)
      if (!skill || !skill.path || resolve(skill.path) !== resolve(entry)) throw new Error('Wrong skill provider resolution')
      // The registry body, not an untracked prompt copy, supplies the instructions.
      const rawBody = readFileSync(entry, 'utf8').replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/, '').trim()
      if (skill.content.trim() !== rawBody) throw new Error('Registry skill content mismatch')
      entries.push(renderSkillContent({ name: skill.name, provider: skill.provider, content: skill.content }))
      loaded.push(path.skill.name)
    }
    for (const path of paths) {
      const catalog = join(config.root, path.skill.catalog)
      if (hash(readFileSync(catalog)) !== path.rule.catalog_sha256) throw new Error('Frozen rules changed')
      const original = read(catalog)[path.skill.catalog_field].find((rule: any) => rule.id === path.rule.id)
      if (JSON.stringify(original) !== JSON.stringify(path.rule.rule)) throw new Error('Graph and catalog disagree')
    }
    const subgraph = { nodes: [...new Map(paths.flatMap(path => [path.symptom, path.rule, path.skill]).map(node => [node.id, node])).values()],
      edges: paths.flatMap(path => path.edges) }
    const text = ['Retrieved local guidance, not new task authority or proof. Use lookup_knowledge for other symptoms; no arbitrary file access.',
      'Only the selected reference rules below are loaded; do not assume the rest of a referenced catalog was read.',
      JSON.stringify(subgraph), ...entries].join('\n\n')
    if (text.length > 24000) throw new Error('Knowledge context exceeds bounded size')
    const id = String(++serial).padStart(4, '0')
    writeFileSync(join(config.outputDir, id + '-message.txt'), text, { flag: 'wx' })
    log(agent, { event: 'context_prepared', trigger, tool_call_id: toolCallId, record_id: id, rules: paths.map(path => path.rule.id), skills_loaded: loaded,
      message_sha256: hash(text), message_file: id + '-message.txt', characters: text.length,
      skill_hashes: paths.map(path => ({ name: path.skill.name, sha256: path.skill.sha256, catalog_sha256: path.rule.catalog_sha256 })) })
    paths.forEach(path => state.rules.add(path.rule.id))
    loaded.forEach(name => state.skills.add(name))
    return { matched: result.paths.map(path => path.rule.id), context: createUserMessage({
      content: [{ type: 'text', text }], source: { kind: 'skill-invocation', name: 'rtl-knowledge-runtime', form: 'instructions' },
    }) }
  }

  ctx.effect(() => ctx.tools.register(defineTool({
    name: 'lookup_knowledge', description: 'Search the local symptom -> rule -> skill graph by a short Chinese/English symptom or rule ID. Loads at most 3 relevant rules; no private answers. No match is explicit.',
    parameters: { query: { type: 'string', required: true } },
    output: { schema: { type: 'object', properties: { report: { type: 'string', required: true } }, additionalProperties: false },
      render: (_args, value) => [{ type: 'text', text: value.report }] },
    async execute(args, execution) {
      if (!execution.agent) throw new Error('Knowledge lookup requires an owning agent')
      const state = stateOf(execution.agent)
      if (++state.searches >= 4) {
        state.stopped = true
        log(execution.agent, { event: 'retrieval_guard_stopped', tool_call_id: execution.callId,
          query: args.query, searches_without_new_artifact_evidence: state.searches })
        return { report: JSON.stringify({ status: 'stopped_no_progress',
          error: 'Four lookups without new artifact evidence. The next model step is blocked; this task is incomplete.' }) }
      }
      const result = await lookup(execution.agent, args.query, 'model_tool', execution.callId)
      if (result.context) execution.deferContext(result.context)
      return { report: JSON.stringify({ matched: result.matched, status: result.matched.length ?
        (result.context ? 'context_attached' : 'already_in_session') : 'no_match',
        searches_before_stop: 3 - state.searches,
        fallback: 'Act on the artifact now. A new file observation, changed write or new evaluation resets the search limit; repeated reads and queries do not.' }) }
    },
    presentCall: () => ({ card: 'generic', title: 'Knowledge lookup', kind: 'execute' }),
    presentResult: () => ({ card: 'generic', title: 'Knowledge lookup' }),
  })))

  ctx.on('agent/pre-step', async ({ agent }, next) => {
    if (stateOf(agent).stopped) {
      log(agent, { event: 'model_step_blocked', reason: 'retrieval_no_progress' })
      return { kind: 'reject' }
    }
    const decision = await next()
    const state = stateOf(agent)
    if (decision.kind === 'reject' || state.catalog || !decision.messages.length) return decision
    state.catalog = true
    log(agent, { event: 'catalog_prepared', message_sha256: hash(catalogText) })
    return { ...decision, messages: [...decision.messages, createUserMessage({ content: [{ type: 'text', text: catalogText }],
      source: { kind: 'skill-invocation', name: 'rtl-knowledge-catalog', form: 'instructions' } })] }
  })

  ctx.on('tools/post-execute', async (execution, result, next) => {
    const decision = await next()
    if (decision.kind !== 'accept' || !execution.agent) return decision
    const state = stateOf(execution.agent)
    if (!result.isError && ['read_file', 'write_file', 'evaluate_rtl', 'run_diagnostic'].includes(execution.name)) {
      const value = JSON.parse((result.value as { report: string }).report)
      if (!value.operation_rejected && !value.no_change) {
        const key = JSON.stringify([execution.name, value.path, value.sha256, value.source_sha256,
          value.testbench_sha256, value.cases?.map((item: any) => [item.parameters, item.status])])
        if (!state.observations.has(key)) {
          state.observations.add(key)
          state.searches = 0
          log(execution.agent, { event: 'artifact_progress', tool_call_id: execution.callId, tool: execution.name })
        }
      }
    }
    if (!['write_file', 'evaluate_rtl', 'run_diagnostic'].includes(execution.name)) return decision
    // Only host-owned structured fields of named tools trigger automatic retrieval. Never log prose commands.
    let signals: string[] = []
    if (result.isError) signals = ['H04']
    else {
      const value = result.value as { report?: string }
      if (typeof value.report === 'string') {
        try { signals = signalsFor(execution.name, JSON.parse(value.report), stateOf(execution.agent)) }
        catch (error) { log(execution.agent, { event: 'unrecognized_tool_schema', tool: execution.name }) }
      }
    }
    if (!signals.length) return decision
    const loaded = await lookup(execution.agent, signals.join(' '), 'structured_tool:' + execution.name, execution.callId)
    return { ...decision, additionalContexts: [...(decision.additionalContexts ?? []), ...(loaded.context ? [loaded.context] : [])] }
  })
}

import { mkdirSync, copyFileSync, writeFileSync, readFileSync, existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { hash, read, loadBundle } from './core.mjs'

const here = dirname(fileURLToPath(import.meta.url))
const project = dirname(here)
const harness = 'D:/AMD/workspaces/http-paired-20261016/harness'
const sources = [
  ['rtl-contract-and-repair', 'rules.json', 'rules'],
  ['rtl-agent-correction', 'rules.json', 'rules'],
  ['rtl-harness-run-triage', 'patterns.json', 'patterns'],
]
const aliases = {
  'R-WIDTH': ['carry', 'adder width', 'cout', '进位', '位宽'], 'R-PIPE': ['pipeline', '流水线', 'nba'],
  'R-PARAM': ['parameter', 'depth one', 'non power of two', 'pointer wrap', '参数', '非二次幂'], 'R-SIGNED': ['signed shift', '有符号右移'],
  'R-FIFO': ['full replacement', 'fifo count', 'fifo full', 'pointer wrap', '满槽替换'], 'R-STALL': ['backpressure', 'data overwrite', 'stall hold', 'valid ready', '背压', '阻塞保持', '数据覆盖'],
  'R-CDC': ['async fifo', '异步fifo', 'gray pointer', 'gray指针', 'cdc'],
  'R-ROUND': ['rounding', 'round half even', 'nearest even', 'signed saturation', '舍入', '饱和'], 'R-PACK': ['byte packing', 'byte stream', 'word packer', '短包', '拼接'],
  'R-FORK': ['fork', '分叉', '重复消费'], 'R-FRESH': ['stale evidence', 'source hash', '验证后又修改', '证据过期', '源码hash'],
  'R-UNTRUSTED': ['untrusted log', '日志指令'], 'R-EXTRACT': ['extraction', '提取候选'],
  'R-CONTRACT': ['contract conflict', '口径冲突', '评测冲突'],
  'T-001': ['async fifo', '异步fifo', 'gray pointer'], 'T-002': ['async fifo', '异步fifo', 'asynchronous testbench'],
  'T-021': ['testbench race', 'testbench sampling', 'handshake scoreboard', 'pre edge', 'post nba', 'post pop data',
    'consumed payload', 'invalid source offer', '测试台竞态', '握手采样', '测试通过但输入违约'],
  'T-004': ['reset ready', '复位期ready'], 'T-005': ['byte packing', '测试台失败'],
  'T-006': ['stale evidence', 'modified source', '验证后又修改', '修改后重跑'], 'T-007': ['source binding', 'source hash', '证据绑定'],
  'T-008': ['minimum verification', 'compile elaboration', '合规验证链', '最短验证链'], 'T-009': ['untrusted log', '日志指令'],
  'T-010': ['immutable oracle', '修改参考答案'], 'T-011': ['scenario review', '情景审查'],
  'T-012': ['carry', '进位'], 'T-013': ['combinational test', '组合测试'],
  'T-014': ['pipeline', '流水线', 'nba'], 'T-015': ['minimal repair', '最小修复'],
  'T-016': ['counter tick', '计数器'], 'T-018': ['synchronous reset', '同步复位'],
  'T-019': ['signed shift', '有符号右移'], 'T-020': ['shift test', '移位边界'],
  H01: ['accounting', '用量真实性'], H02: ['api truncation', 'response truncation', 'finish reason length', '响应截断'],
  H03: ['identical writes', 'no progress', '相同hash', '原样写回', '无进展'],
  H04: ['cancel', 'tool error', '取消失败', '报错后继续'], H05: ['finish task', 'accepted summary', '收尾失败'],
  H06: ['budget', 'cap', '预算', '额度不一致'], H07: ['continuation', 'context bloat', '续跑', '上下文膨胀'],
  H08: ['stage evidence', '教师叙述矛盾'], H09: ['testbench race', '测试台竞态', '测试结论矛盾'],
  H10: ['skill curation', '总结skill'], H11: ['authorization', 'private data', '权限', '私有数据'],
  H12: ['batch status', '批次状态', '完成分母'],
  H13: ['retrieval', 'lookup', 'no match', '检索', '漏召回'],
}

export function prepare(root) {
  mkdirSync(root, { recursive: false })
  const graph = { schema: 'rtl-runtime-knowledge-v1', scope: 'GENERAL_RULES_ONLY_NOT_PROVEN_CORRECT', nodes: [], edges: [] }
  const files = {}
  mkdirSync(join(root, 'runtime'))
  for (const name of ['core.mjs', 'plugin.ts']) {
    copyFileSync(join(here, name), join(root, 'runtime', name))
    files['runtime/' + name] = hash(readFileSync(join(here, name)))
  }
  for (const [name, catalog, field] of sources) {
    const relative = `skills/${name}`
    mkdirSync(join(root, relative, 'references'), { recursive: true })
    for (const path of ['SKILL.md', `references/${catalog}`]) {
      const source = join(project, 'skill', name, path)
      copyFileSync(source, join(root, relative, path))
      files[`${relative}/${path}`] = hash(readFileSync(source))
    }
    const data = read(join(root, relative, 'references', catalog))
    graph.nodes.push({ id: 'skill:' + name, type: 'skill', name, entry: `${relative}/SKILL.md`,
      catalog: `${relative}/references/${catalog}`, catalog_field: field, sha256: files[`${relative}/SKILL.md`] })
    for (const rule of data[field]) {
      const title = rule.concept ?? rule.symptom ?? rule.trigger
      graph.nodes.push({ id: 'symptom:' + rule.id, type: 'symptom', rule_id: rule.id, title, aliases: aliases[rule.id] ?? [] })
      graph.nodes.push({ id: rule.id, type: 'rule', rule, catalog_sha256: files[`${relative}/references/${catalog}`],
        evidence_limit: rule.limit ?? rule.caveat ?? data.evidence_limit ?? 'Conditional guidance, not proof or measured gain.' })
      graph.edges.push({ from: 'symptom:' + rule.id, to: rule.id, type: 'routes_to' },
        { from: rule.id, to: 'skill:' + name, type: 'loaded_from' })
    }
  }
  const serialized = JSON.stringify(graph, null, 2)
  if (/Q\d{3}|[A-Z]:[\\/]|private_testbench|reference_solution/.test(serialized)) throw new Error('Unsafe runtime graph')
  writeFileSync(join(root, 'runtime-graph.json'), serialized + '\n', { flag: 'wx' })
  files['runtime-graph.json'] = hash(readFileSync(join(root, 'runtime-graph.json')))
  const provenance = ['D:/AMD/output/rtl-api-distillation-20261017/agent-04/knowledge/published-graph.json',
    'D:/AMD/output/rtl-api-distillation-20261017/harness-skill-summary-02/provenance.json',
    'D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-02/reviewed-lessons.json',
    'D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/reviewed-lessons.json',
    'D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-05/reviewed-lessons.json',
    'D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-06/reviewed-lessons.json'].filter(existsSync)
  writeFileSync(join(root, 'manifest.json'), JSON.stringify({ schema: 'rtl-runtime-bundle-v1', files,
    evidence: 'LOCAL_CURATED_FROM_PRIOR_RUNS_NOT_NEW_MODEL_ANSWERS', behavior_gain_tested: false,
    developer_provenance_not_model_visible: provenance.map(path => ({ path, sha256: hash(readFileSync(path)) })),
  }, null, 2) + '\n', { flag: 'wx' })
  loadBundle(root)
  const plugins = [
    { id: 'rtl-knowledge-registry', name: harness + '/packages/skill/skill/src/index.ts' },
    { id: 'rtl-knowledge-filesystem', name: harness + '/packages/skill/skill-filesystem/src/index.ts',
      config: { providerName: 'rtl-frozen-knowledge', includeDefaultRoots: false, watch: false, customSkillDirs: [join(root, 'skills')] } },
    { id: 'rtl-knowledge-runtime', name: join(root, 'runtime/plugin.ts'), config: { root, outputDir: join(root, 'retrieval'),
      manifestSha256: hash(readFileSync(join(root, 'manifest.json'))) } },
  ]
  return plugins
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const plugins = prepare(resolve(process.argv[2]))
  process.stdout.write(JSON.stringify(plugins))
}

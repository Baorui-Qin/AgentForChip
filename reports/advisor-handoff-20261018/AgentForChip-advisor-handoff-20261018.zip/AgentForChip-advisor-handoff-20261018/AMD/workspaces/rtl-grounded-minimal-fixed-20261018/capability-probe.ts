/** Bounded real-model localization and exact-edit controls through a dsh profile. */
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { randomUUID } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import { runCommand } from './rtl-tools/src/process.ts'
import { vivadoArgv } from './rtl-tools/src/synthesis.ts'
import { VivadoDiagnostics } from './rtl-tools/src/vivado-parser.ts'
import { diagnosticKind, type DiagnosticReceipt, type RepairStage } from './rtl-tools/src/phase1/repair-diagnostics.ts'
import { readP09Settings, loadP09Skills } from './rtl-tools/src/phase1/p09-proposal.ts'
import { planFor } from './rtl-tools/src/phase1/p10-planner.ts'
import { callAction, type AutoSettings } from './rtl-tools/src/phase1/p09-action-call.ts'
import { exactEdit } from './rtl-tools/src/phase1/p10-exact-edit.ts'
import { checkAutoSource, parseAutoAction } from './rtl-tools/src/phase1/p09-auto-policy.ts'
import { sourceLocations, planLocation } from './rtl-tools/src/phase1/p10-grounding.ts'
import { sha256 } from './rtl-tools/src/phase1/snapshots.ts'
import type { ContextInput } from './rtl-tools/src/phase1/p09-context.ts'
import { capabilityFixtures } from './capability-fixtures.ts'

export const name = 'rtl-grounded-capability-probe'
export const inject = ['cmdlineArgs', 'appReady', 'subprocess', 'llm']
const put = (path: string, value: unknown) => writeFile(path, JSON.stringify(value, null, 2), { flag: 'wx' })

/** Mount the bounded probe; accuracy failures are records, infrastructure failures stop the campaign. */
export function apply(ctx: Context, config: { root: string; arm: 'on' | 'off' }): void {
  if (ctx.cmdlineArgs!.get().join(' ') !== 'capability') throw new Error('CAPABILITY_COMMAND_REQUIRED')
  const controller = new AbortController(); let pending: Promise<void> | undefined
  ctx.effect(() => async () => { controller.abort(); await pending })
  ctx.effect(() => ctx.get('appReady')!.onReady(() => {
    pending = run(ctx, config, controller.signal).then(() => ctx.get('appExit')!(0)).catch(error => {
      process.stderr.write(String(error) + '\n'); ctx.get('appExit')!(1)
    })
  }))
}

async function run(ctx: Context, config: { root: string; arm: 'on' | 'off' }, caller: AbortSignal) {
  const { root, arm } = config, armRoot = join(root, 'arms', arm), probe = join(root, 'capability', arm)
  await mkdir(probe, { recursive: true })
  const freeze = JSON.parse(await readFile(join(root, 'campaign-freeze.json'), 'utf8')) as { files: Record<string, string>; protocol: { deadline: string } }
  const assertFreeze = async () => { for (const [file, digest] of Object.entries(freeze.files)) if (sha256(await readFile(file)) !== digest) throw new Error('CAPABILITY_SOURCE_CHANGED') }
  await assertFreeze()
  const identity = JSON.parse(await readFile(join(root, 'cloud-identity.json'), 'utf8'))
  const auto = JSON.parse(await readFile(join(armRoot, 'auto.json'), 'utf8')) as AutoSettings
  auto.llama = { baseURL: 'http://127.0.0.1:18081/v1', identity: identity.coder }
  const p09 = await readP09Settings(join(armRoot, 'p09.json'))
  const iface = { top: 'TopModule', ports: ['clk', 'select', 'bit_a', 'bit_b', 'value'].map(name => ({ name, direction: name === 'value' ? 'output' as const : 'input' as const, width: 1, signed: false })) }
  const results = []
  for (const fixture of capabilityFixtures) {
    const directory = join(probe, fixture.id); await mkdir(directory)
    await mkdir(join(directory, 'models'))
    const remaining = Math.min(240000, Date.parse(freeze.protocol.deadline) - Date.now())
    if (remaining <= 0) throw new Error('CAMPAIGN_TIME_BUDGET')
    const signal = AbortSignal.any([caller, AbortSignal.timeout(remaining)])
    const cmd = await ctx.subprocess.resolveExecutable('cmd.exe', undefined, signal)
    const verify = async (source: string, name: string, compileOnly = false) => {
      const cwd = join(directory, name); await mkdir(cwd)
      await writeFile(join(cwd, 'solution.sv'), source, { flag: 'wx' })
      await writeFile(join(cwd, 'tb.sv'), fixture.tb, { flag: 'wx' })
      const stages = [], parser = new VivadoDiagnostics(32, 4096)
      for (const [stage, tool, argv] of [ ['compile', 'xvlog', ['--sv', 'solution.sv', 'tb.sv']],
        ...(!compileOnly ? [['elaborate', 'xelab', ['tb', '-s', 'probe_snapshot']], ['simulation', 'xsim', ['probe_snapshot', '-runall']]] : [])
      ] as [string, string, string[]][]) {
        const executable = await ctx.subprocess.resolveExecutable('D:/AMDDesignTools/2026.1/Vivado/bin/' + tool + '.bat', undefined, signal)
        const process = await runCommand(ctx.subprocess, { timeoutMs: 30000, graceMs: 1000, maxLogBytes: 1048576, maxLineChars: 4096, stopOnLogLimit: true },
          vivadoArgv(executable, argv, globalThis.process.platform, cmd), cwd, stage, signal, parser)
        if (process.aborted || process.timedOut || process.signal || process.logTruncated || parser.environmentFailure) throw new Error('CAPABILITY_EDA_INFRA_FAILURE')
        stages.push({ stage, process })
        if (process.exitCode !== 0 || parser.errorSeen) break
      }
      const simulation = stages.find(row => row.stage === 'simulation')
      const text = simulation ? await readFile(simulation.process.stdoutLog, 'utf8') : ''
      const verdict = /CAPABILITY_CHECKS=(\d+) MISMATCHES=(\d+)/.exec(text)
      const value = { stages, errors: parser.errors, checks: verdict ? Number(verdict[1]) : null,
        mismatches: verdict ? Number(verdict[2]) : null, passed: !!verdict && Number(verdict[1]) === 8 && Number(verdict[2]) === 0 }
      await put(join(cwd, 'result.json'), value)
      return { ...value, path: join(cwd, 'result.json') }
    }
    const initial = await verify(fixture.source, 'initial', true)
    if (!initial.errors.length || initial.stages[0]?.process.exitCode === 0) throw new Error('CAPABILITY_NEGATIVE_NOT_OBSERVED')
    const feedback: DiagnosticReceipt = { schema_version: '1.4', evidence_kind: 'live_verification', eda_rerun: false, model_repair_executed: false,
      original_run: initial.path, result_sha256: sha256(await readFile(initial.path)), parser_version: 'capability-vivado-original-lines-1',
      parser_sha256: sha256(await readFile(new URL('./rtl-tools/src/vivado-parser.ts', import.meta.url))), old_diagnostics: {},
      inputs: [{ path: initial.path, sha256: sha256(await readFile(initial.path)), issue: null }],
      stages: ['compile', 'elaborate', 'simulation', 'synthesis'].map((stage, index): RepairStage => ({ stage, status: index ? 'SKIPPED' : 'FAIL', complete: true,
        process_clean: false, process_normal: true, functional_failure: false,
        verdict: { records: 0, checks: null, mismatches: null, fatal: false, completed: false },
        diagnostics: index ? [] : initial.errors.map(d => ({ category: d.type, message_id: d.code ?? null, message: d.message,
          severity: 'ERROR', file: 'rtl/solution.sv', line: d.line ?? null, origin: 'dut', attribution: 'DUT_COMPILE_ERROR',
          kind: diagnosticKind(d.code ?? null, d.message), invocation: 'compile', repairable_by_model: true })) })) }
    const revision = randomUUID(), experiment = randomUUID()
    const input: ContextInput = { task: { id: fixture.id, spec: fixture.spec, interface: iface, constraints: 'Only the single self-contained DUT. Keep every trusted port fixed.' },
      sample_id: experiment, variant_id: p09.variant, purpose: 'repair', tool_mode: true, edit_protocol: 'exact-replacements', ledger: [], pending_verification: false,
      current: { revision_id: revision, source: fixture.source, source_sha256: sha256(fixture.source) },
      binding: { revision_id: revision, source_sha256: sha256(fixture.source), verification_key: 'sha256:' + sha256(await readFile(initial.path)) }, feedback,
      repair_control: { mode: 'normal', compacted: false, must_continue: true, best_revision_id: revision, best_source_sha256: sha256(fixture.source), rejected: [] } }
    await put(join(directory, 'input.json'), input)
    const result: Record<string, unknown> = { task: fixture.id, arm, status: 'NOT_REPAIRED', plan_citation_matched: false,
      plan_explanation_keyword_check: false, patch_accepted: false, minimal_changed_spans: false, verification_requested: false, passed: false,
      oracle_not_in_request: true, shared_campaign_claim_pool: armRoot }
    try {
      const plan = await planFor({ root: probe, input, runtime: ctx.llm, auto, signal, maxEventBytes: 1048576,
        planner: { baseURL: 'http://127.0.0.1:18080/v1', identity: identity.thinker, provider: 'cloud-thinker', model: 'qwen3-coder-30b', maxPlans: 1 },
        model: { provider: 'cloud-thinker', model: 'qwen3-coder-30b', maxTokens: 1024, maxResponseBytes: 65536, temperature: 0, timeoutMs: 60000 },
        limits: { ...p09.limits, window: 8192, output: 1024 }, loadSkills: () => loadP09Skills(p09) })
      result.plan = plan; result.plan_citation_matched = planLocation(plan.text, sourceLocations(input)).matched
      result.plan_explanation_keyword_check = fixture.causeWords.test(JSON.parse(plan.text).cause)
      input.planning = plan
      const call = (view: ContextInput, sequence: number) => callAction({ root: directory, experiment, sequence, input: view, history: [], auto, p09: { ...p09, limits: { ...p09.limits, window: 8192, output: 2048 } },
        model: { provider: 'cloud-coder', model: 'siliconmind-qwen3-8b', maxTokens: 2048, maxResponseBytes: 65536, temperature: 0, timeoutMs: 60000 },
        runtime: ctx.llm, subprocess: ctx.subprocess, signal, maxEventBytes: 1048576, loadSkills: () => loadP09Skills(p09),
        expectedRequestHash: null, claim: async () => {} })
      const response = await call(input, 1)
      const calls = response.message?.content.filter(block => block.type === 'tool-call') ?? []
      if (response.error_code || calls.length !== 1 || calls[0]!.name !== 'edit_dut') throw new Error(response.error_code ?? 'CAPABILITY_EDIT_REQUIRED')
      const patch = exactEdit(calls[0]!.arguments, fixture.source, revision)
      checkAutoSource(patch.source, iface)
      result.patch = patch; result.patch_accepted = true
      result.minimal_changed_spans = patch.spans.every(span => {
        if (span.before === span.after) return true
        let left = 0, right = 0
        while (left < Math.min(span.before.length, span.after.length) && span.before[left] === span.after[left]) left++
        while (right < Math.min(span.before.length, span.after.length) - left && span.before.at(-1 - right) === span.after.at(-1 - right)) right++
        return fixture.allowed.some(text => { const start = fixture.source.indexOf(text); return span.start + left >= start && span.end - right <= start + text.length })
      })
      const next = randomUUID()
      const pending: ContextInput = { ...input, current: { revision_id: next, source_sha256: sha256(patch.source), source: patch.source },
        feedback: null, binding: null, pending_verification: true }
      const verification = await call(pending, 2), verifyCalls = verification.message?.content.filter(block => block.type === 'tool-call') ?? []
      if (verification.error_code || verifyCalls.length !== 1) throw new Error(verification.error_code ?? 'CAPABILITY_VERIFY_REQUIRED')
      const action = parseAutoAction(verifyCalls[0]!.name, verifyCalls[0]!.arguments)
      if (action.name !== 'verify_rtl' || action.revision_id !== next || action.test_suite_id !== fixture.id) throw new Error('CAPABILITY_VERIFY_REQUIRED')
      result.verification_requested = true
      result.eda = await verify(patch.source, 'candidate')
      result.passed = (result.eda as { passed: boolean }).passed
      result.status = result.passed ? 'REPAIRED' : 'EDA_FAILED'
    } catch (error) {
      const code = error instanceof Error ? error.message : 'CAPABILITY_UNKNOWN'
      if (/ENOENT|EACCES|EPERM|CAMPAIGN_|TOKENIZER_|IDENTITY|TRANSPORT|HOST_OR_MODEL|CAPABILITY_EDA_INFRA/.test(code)) throw error
      result.status = code
    }
    await put(join(directory, 'result.json'), result); results.push(result)
  }
  await assertFreeze()
  await put(join(probe, 'results.json'), { status: 'COMPLETED', controls: results.length, results,
    limitation: 'Keyword and span checks do not prove generalization; all model failures are retained. Probe calls consume the seven-task shared arm pool.' })
}

"""Join the actual coder input, bound plan, exact arguments and observed tool outcome."""
from collections import Counter
import hashlib
import json
from pathlib import Path

OUT = Path('D:/AMD/output/rtl-grounded-minimal-fixed-20261018')


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def matches(source, before):
    positions, start = [], 0
    while before:
        index = source.find(before, start)
        if index < 0:
            break
        positions.append(index)
        start = index + 1
    return positions


models = {r['request_sha256']: r for r in load(OUT / 'model-output-index.json')}
rows = []
for call in load(OUT / 'call-index.json'):
    if call['provider'] != 'cloud-coder':
        continue
    directory = Path(models[call['request_sha256']]['directory'])
    context = load(directory / 'context.json')
    response = load(directory / 'model.json')
    result_file = OUT / 'campaign/arms' / call['arm'] / ('compare-' + call['task']) / 'result.json'
    result = load(result_file)
    action = next(a for a in result['actions'] if Path(a['model_run']) == directory)
    source = context['current']['source']
    assert hashlib.sha256(source.encode()).hexdigest() == context['current']['source_sha256']
    planning = context.get('planning')
    if planning:
        if not context.get('pending_verification'):
            assert planning['source_sha256'] == context['current']['source_sha256']
        assert hashlib.sha256(planning['text'].encode()).hexdigest() == planning['plan_sha256']
    tools = [b for b in response['message']['content'] if b['type'] == 'tool-call']
    assert len(tools) == 1
    args = json.loads(tools[0]['arguments'])
    anchors = [{
        'before': r['before'], 'after': r['after'],
        'occurrences_in_bound_source': len(matches(source, r['before'])),
        'unchanged_entry': r['before'] == r['after'],
    } for r in args.get('replacements', [])]
    rows.append({
        'task': call['task'], 'arm': call['arm'], 'model_run': str(directory),
        'request_sha256': call['request_sha256'], 'http_request': call['request_file'],
        'http_sse': call['sse_file'], 'context_file': str(directory / 'context.json'),
        'model_output_file': str(directory / 'model.json'), 'task_result': str(result_file),
        'context_plan': planning, 'bound_source_sha256': context['current']['source_sha256'],
        'plan_targets_current_source': bool(planning and planning['source_sha256'] == context['current']['source_sha256']),
        'pending_verification': context.get('pending_verification'),
        'tool': tools[0]['name'], 'arguments': args, 'anchors': anchors,
        'accepted': action['accepted'], 'observation': action['observation'],
        'has_missing_anchor': any(r['occurrences_in_bound_source'] == 0 for r in anchors),
        'has_ambiguous_anchor': any(r['occurrences_in_bound_source'] > 1 for r in anchors),
    })
receipt = {
    'scope': 'recorded input/plan/patch/tool linkage, not a semantic correctness oracle',
    'coder_calls': len(rows), 'nonpending_plan_source_and_all_plan_text_hashes_checked': True,
    'pending_context_plan_note': 'Raw context can retain the pre-edit plan; pending verification targets the new candidate. Raw context is not the projected HTTP request.',
    'rejection_counts': dict(Counter(r['observation'].get('error') for r in rows if not r['accepted'])),
    'rows': rows,
}
with (OUT / 'planner-coder-evidence.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
print(json.dumps({k: v for k, v in receipt.items() if k != 'rows'}))

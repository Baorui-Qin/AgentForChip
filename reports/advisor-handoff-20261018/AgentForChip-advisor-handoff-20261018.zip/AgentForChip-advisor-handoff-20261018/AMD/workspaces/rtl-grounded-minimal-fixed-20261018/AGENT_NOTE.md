# Grounded Planning and Exact Edits

The first diagnostic generation is retained unchanged. Its probe bootstrap omitted the models directory, and its exact-edit validator rejected mixed genuine/no-op replacements atomically. This generation creates that directory before requests, treats filesystem errors as infrastructure failures, and rejects unchanged candidates only after all explicit replacements are materialized. A positive mixed-context regression test accompanies the fix. New dispatches are capped at the same 56 remaining tickets in each arm and use the original deadline; earlier consumption remains part of the total accounting.

The preceding experiment delivered skills but retained mislocalized enum repairs, malformed regenerated assignments and incorrect scalar behavior. This copy changes the planning/edit workflow rather than extending the rule text or adding answers.

The diagnostic line and bounded lexical references are derived mechanically from the bound current source. The plan must quote that line in cause when available, within existing limits; failure shares the existing compact-format recovery. This proves citation consistency only, not root-cause correctness. Missing locations remain explicitly absent.

Exact edit mode is frozen in each arm's auto settings. Model-authored replacements must be unique in original source and disjoint; unmatched, ambiguous, stale, overlapping and unchanged patches are refused. No answer-aware rewriting or automatic token repair exists. Accepted materialized candidates use the unchanged source/interface checks and two-edit budget, followed by normal verify_rtl and rollback.

Six real-model generic controls precede the seven task pairs. Their plans and coder calls share the existing per-arm dispatch tickets and campaign deadline. Model quality failures are recorded separately from infrastructure gates; no post-control tuning or hidden retry is allowed within the frozen campaign. The six skills, normal two-entry selector and OFF isolation remain unchanged, allowing comparison of workflow effects without silently changing the knowledge bundle again.

Validation covers literal location mismatch, foreign/missing diagnostics, exact-edit atomicity and unchanged bytes, legacy mode, pipeline acceptance/rejection, context budgets, projected request snapshots and source preservation. New source is checked against the preceding runtime's known flat dependency diagnostics. Reports retain model, HTTP/SSE, token counter, tool error, patch, EDA and process receipts.

"""Compare each current arm with the immutable previous same-initial arm, not a new control."""
import csv
import json
from pathlib import Path

OUT = Path('D:/AMD/output/rtl-grounded-minimal-fixed-20261018')
OLD = Path('D:/AMD/output/rtl-semantic-skills-ablation-20261017')
STAGES = ('compile', 'elaborate', 'simulation', 'synthesis')


def table(root):
    with (root / 'tasks.csv').open(encoding='utf-8-sig', newline='') as stream:
        return {(row['arm'], row['task']): row for row in csv.DictReader(stream)}


old, current = table(OLD), table(OUT)
assert old.keys() == current.keys()
rows = []
for arm, task in current:
    a, b = old[arm, task], current[arm, task]
    old_result = json.loads(Path(a['comparison_result']).read_text(encoding='utf-8'))
    new_result = json.loads(Path(b['comparison_result']).read_text(encoding='utf-8'))
    assert old_result['shared_initial_sha256'] == new_result['shared_initial_sha256']
    row = {'task': task, 'arm': arm, 'same_initial_sha256': new_result['shared_initial_sha256'],
        'previous_terminal': a['terminal'], 'current_terminal': b['terminal'],
        'previous_rtl_pass': all(a[s] == 'PASS' for s in STAGES), 'current_rtl_pass': all(b[s] == 'PASS' for s in STAGES),
        'previous_model_calls': int(a['model_calls']), 'current_model_calls': int(b['model_calls']),
        'previous_mismatches': a['final_simulation_mismatches'], 'current_mismatches': b['final_simulation_mismatches'],
        'previous_result': a['comparison_result'], 'current_result': b['comparison_result']}
    rows.append(row)
with (OUT / 'previous-vs-current.csv').open('x', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
summary = {'previous_is_historical_reference_not_current_control': True, 'same_initial_arm_runs': len(rows),
    'arms': {arm: {'previous_rtl_pass': sum(row['previous_rtl_pass'] for row in rows if row['arm'] == arm),
        'current_rtl_pass': sum(row['current_rtl_pass'] for row in rows if row['arm'] == arm),
        'newly_passed': [row['task'] for row in rows if row['arm'] == arm and row['current_rtl_pass'] and not row['previous_rtl_pass']],
        'regressed': [row['task'] for row in rows if row['arm'] == arm and not row['current_rtl_pass'] and row['previous_rtl_pass']]} for arm in ('on', 'off')},
    'official_score': None}
with (OUT / 'previous-vs-current.json').open('x', encoding='utf-8') as stream:
    json.dump(summary, stream, ensure_ascii=False, indent=2)
print(json.dumps(summary))

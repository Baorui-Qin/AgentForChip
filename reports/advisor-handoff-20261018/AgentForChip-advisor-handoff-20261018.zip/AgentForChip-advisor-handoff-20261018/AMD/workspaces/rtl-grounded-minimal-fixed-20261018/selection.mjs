import { createHash } from 'node:crypto'
import { readFile, writeFile, readdir, readlink, mkdir, copyFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

export const previous = 'D:/AMD/output/cloud-agent-questions50-20261017'
export const control = 'D:/AMD/output/diagnostic-route-fix7-20261017'
export const skillPrevious = 'D:/AMD/output/rtl-repair-skills7-20261017'
export const recoveryPrevious = 'D:/AMD/output/rtl-recovery-ablation-20261017'
export const budgetfitPrevious = 'D:/AMD/output/rtl-budgetfit-ablation-20261017'
export const semanticPrevious = 'D:/AMD/output/rtl-semantic-skills-ablation-20261017'
export const groundedPrevious = 'D:/AMD/output/rtl-grounded-minimal-ablation-20261018'
export const output = 'D:/AMD/output/rtl-grounded-minimal-fixed-20261018'
export const hash = bytes => createHash('sha256').update(bytes).digest('hex')
export const taskIds = ['Prob039_always_if', 'Prob060_m2014_q4k', 'Prob119_fsm3', 'Prob096_review2015_fsmseq',
  'Prob104_mt2015_muxdff', 'Prob142_lemmings2', 'Prob058_alwaysblock2']
const json = async path => JSON.parse(await readFile(path, 'utf8'))
const put = async (path, value) => writeFile(path, JSON.stringify(value, null, 2), { flag: 'wx' })

export async function inventory(root) {
  const files = {}
  async function visit(directory) {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const path = join(directory, entry.name)
      if (entry.isSymbolicLink()) files[path.replaceAll('\\', '/')] = hash('symlink\0' + await readlink(path))
      else if (entry.isDirectory()) await visit(path)
      else if (entry.isFile()) files[path.replaceAll('\\', '/')] = hash(await readFile(path))
    }
  }
  await visit(root)
  return files
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (process.argv[2] === 'after') {
    const before = await json(output + '/previous-round-before.json')
    const after = await inventory(previous)
    const changed = [...new Set([...Object.keys(before), ...Object.keys(after)])].filter(p => before[p] !== after[p])
    await put(output + '/previous-round-preservation.json', { files_checked: Object.keys(before).length, changed, unchanged: changed.length === 0 })
    if (changed.length) throw new Error('PREVIOUS_ROUND_CHANGED')
    const controlBefore = await json(output + '/control-round-before.json')
    const controlAfter = await inventory(control)
    const controlChanged = [...new Set([...Object.keys(controlBefore), ...Object.keys(controlAfter)])].filter(p => controlBefore[p] !== controlAfter[p])
    await put(output + '/control-round-preservation.json', { files_checked: Object.keys(controlBefore).length, changed: controlChanged, unchanged: controlChanged.length === 0 })
    if (controlChanged.length) throw new Error('CONTROL_ROUND_CHANGED')
    const skillsBefore = await json(output + '/skills-round-before.json'), skillsAfter = await inventory(skillPrevious)
    const skillsChanged = [...new Set([...Object.keys(skillsBefore), ...Object.keys(skillsAfter)])].filter(p => skillsBefore[p] !== skillsAfter[p])
    await put(output + '/skills-round-preservation.json', { files_checked: Object.keys(skillsBefore).length, changed: skillsChanged, unchanged: skillsChanged.length === 0 })
    if (skillsChanged.length) throw new Error('SKILLS_ROUND_CHANGED')
    const recoveryBefore = await json(output + '/recovery-round-before.json'), recoveryAfter = await inventory(recoveryPrevious)
    const recoveryChanged = [...new Set([...Object.keys(recoveryBefore), ...Object.keys(recoveryAfter)])].filter(p => recoveryBefore[p] !== recoveryAfter[p])
    await put(output + '/recovery-round-preservation.json', { files_checked: Object.keys(recoveryBefore).length, changed: recoveryChanged, unchanged: recoveryChanged.length === 0 })
    if (recoveryChanged.length) throw new Error('RECOVERY_ROUND_CHANGED')
    const budgetfitBefore = await json(output + '/budgetfit-round-before.json'), budgetfitAfter = await inventory(budgetfitPrevious)
    const budgetfitChanged = [...new Set([...Object.keys(budgetfitBefore), ...Object.keys(budgetfitAfter)])].filter(p => budgetfitBefore[p] !== budgetfitAfter[p])
    await put(output + '/budgetfit-round-preservation.json', { files_checked: Object.keys(budgetfitBefore).length, changed: budgetfitChanged, unchanged: budgetfitChanged.length === 0 })
    if (budgetfitChanged.length) throw new Error('BUDGETFIT_ROUND_CHANGED')
    const semanticBefore = await json(output + '/semantic-round-before.json'), semanticAfter = await inventory(semanticPrevious)
    const semanticChanged = [...new Set([...Object.keys(semanticBefore), ...Object.keys(semanticAfter)])].filter(p => semanticBefore[p] !== semanticAfter[p])
    await put(output + '/semantic-round-preservation.json', { files_checked: Object.keys(semanticBefore).length, changed: semanticChanged, unchanged: semanticChanged.length === 0 })
    if (semanticChanged.length) throw new Error('SEMANTIC_ROUND_CHANGED')
    const groundedBefore = await json(output + '/grounded-round-before.json'), groundedAfter = await inventory(groundedPrevious)
    const groundedChanged = [...new Set([...Object.keys(groundedBefore), ...Object.keys(groundedAfter)])].filter(p => groundedBefore[p] !== groundedAfter[p])
    await put(output + '/grounded-round-preservation.json', { files_checked: Object.keys(groundedBefore).length, changed: groundedChanged, unchanged: groundedChanged.length === 0 })
    if (groundedChanged.length) throw new Error('GROUNDED_ROUND_CHANGED')
  } else {
    await put(output + '/previous-round-before.json', await inventory(previous))
    await put(output + '/control-round-before.json', await inventory(control))
    await put(output + '/skills-round-before.json', await inventory(skillPrevious))
    await put(output + '/recovery-round-before.json', await inventory(recoveryPrevious))
    await put(output + '/budgetfit-round-before.json', await inventory(budgetfitPrevious))
    await put(output + '/semantic-round-before.json', await inventory(semanticPrevious))
    await put(output + '/grounded-round-before.json', await inventory(groundedPrevious))
    const sourceManifest = previous + '/campaign/manifest-50.json'
    const oldTasks = (await json(sourceManifest)).task_ids
    const blocked = []
    for (const id of oldTasks) {
      const path = previous + '/campaign/compare-' + id + '/result.json'
      try { if ((await json(path)).status === 'POLICY_BLOCKED') blocked.push(id) }
      catch (error) { if (error.code !== 'ENOENT') throw error }
    }
    if (blocked.length !== 7 || blocked.some(id => !taskIds.includes(id))) throw new Error('BLOCKED_SELECTION_CHANGED')
    const sources = { [sourceManifest]: hash(await readFile(sourceManifest)) }, imports = []
    const controlManifest = control + '/campaign/manifest-7.json'
    if (JSON.stringify((await json(controlManifest)).task_ids) !== JSON.stringify(taskIds)) throw new Error('CONTROL_SELECTION_CHANGED')
    sources[controlManifest] = hash(await readFile(controlManifest))
    for (const name of ['campaign/manifest-7.json', 'campaign/campaign-freeze.json', 'comparison-summary.json']) {
      const path = recoveryPrevious + '/' + name
      sources[path] = hash(await readFile(path))
    }
    for (const name of ['campaign/manifest-7.json', 'campaign/campaign-freeze.json', 'comparison-summary.json']) {
      const path = budgetfitPrevious + '/' + name
      sources[path] = hash(await readFile(path))
    }
    for (const id of taskIds) {
      const source = previous + '/campaign/generate-' + id
      const targets = ['on', 'off'].map(arm => output + '/campaign/arms/' + arm + '/generate-' + id)
      for (const target of targets) await mkdir(target, { recursive: true })
      for (const name of ['initial.sv', 'result.json']) {
        const path = source + '/' + name
        sources[path] = hash(await readFile(path))
        for (const target of targets) await copyFile(path, target + '/' + name)
      }
      const initial = await json(source + '/result.json')
      if (initial.status !== 'GENERATED_UNVERIFIED') throw new Error('INITIAL_BINDING_INVALID')
      for (const target of targets) if (hash(await readFile(target + '/initial.sv')) !== initial.source_sha256) throw new Error('INITIAL_BINDING_INVALID')
      const comparison = control + '/campaign/compare-' + id + '/result.json'
      sources[comparison] = hash(await readFile(comparison))
      imports.push({ task_id: id, source_directory: source, imported_directories: targets,
        source_sha256: initial.source_sha256, initial_generation_reused: true, new_generation_requests: 0,
        original_generation_result_sha256: sources[source + '/result.json'], previous_comparison_result: comparison,
        original_generation_logs: source + '/models' })
    }
    await put(output + '/campaign/imported-initials.json', { protocol: 'same-batch-paired-recovery-ablation-v1',
      note: 'Byte-identical generated initials and their original results are imported, not regenerated. All EDA and model repairs are new. Historical generation dispatch counts are not current calls.', imports })
    await put(new URL('./selection.json', import.meta.url), { protocol: 'previous-policy-blocked-seven-v1',
      task_ids: taskIds, count: 7, execution_order: taskIds.flatMap((task, index) => (index % 2 ? ['off', 'on'] : ['on', 'off']).map(arm => ({ task, arm }))),
      excluded_previous_tasks: [], excluded_control: 'Prob038_count15', sources })
    console.log(JSON.stringify({ selected: taskIds, previous_initials_reused: true, new_generation_requests: 0 }))
  }
}

"""Own one bounded tunnel for the never-dispatched coder steps; preserve the original deadline and pools."""
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import time
import urllib.request

HERE = Path(__file__).resolve().parent
OUT = Path('D:/AMD/output/rtl-grounded-minimal-fixed-20261018/capability-resume-driver')
SSH = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-i', 'C:/Users/qbr/.ssh/id_ed25519_amd',
       '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'ConnectTimeout=10', '-o', 'ServerAliveInterval=15', '-o', 'ServerAliveCountMax=3']
ENV = {k: v for k, v in os.environ.items() if not re.search('KEY|SECRET|TOKEN|PASSWORD|PROXY', k, re.I)}
REMOTE = '/workspace/codex-dual-20261017-35053/question-ssh-forwarding.py'
OWNER = 'rtl-grounded-minimal-coder-resume-20261018'


def save(name, value):
    with (OUT / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)


def remote(argv):
    return subprocess.run(SSH + ['-T', '-p', '35053', 'root@36.150.116.206', shlex.join(argv)],
        capture_output=True, text=True, timeout=40, creationflags=subprocess.CREATE_NO_WINDOW, env=ENV)


cleanup, tunnel, enabled, worker = {}, None, False, None
try:
    prior = json.loads((OUT.parent / 'cleanup.json').read_text())
    if not prior['ssh_original_hash_matches'] or not prior['tunnel']['reaped']:
        raise RuntimeError('PREVIOUS_TUNNEL_NOT_CLEAN')
    enabled = True
    digest = hashlib.sha256((HERE / 'ssh_forwarding.py').read_bytes()).hexdigest()
    code = ('import hashlib,pathlib,subprocess;p=pathlib.Path(' + repr(REMOTE) + ');assert hashlib.sha256(p.read_bytes()).hexdigest()==' + repr(digest) + ';subprocess.run(["python3",str(p),"enable",' + repr(OWNER) + '],check=True)')
    result = remote(['python3', '-c', code])
    save('ssh-enable.json', {'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    if result.returncode:
        raise RuntimeError('RESUME_SSH_ENABLE_FAILED')
    with (OUT / 'tunnel.log').open('xb') as log:
        tunnel = subprocess.Popen(SSH + ['-o', 'ExitOnForwardFailure=yes', '-L', '127.0.0.1:18080:127.0.0.1:18080',
            '-L', '127.0.0.1:18081:127.0.0.1:18081', '-N', '-T', '-p', '35053', 'root@36.150.116.206'],
            env=ENV, stdin=subprocess.DEVNULL, stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
        save('tunnel-start.json', {'pid': tunnel.pid, 'loopback_ports': [18080, 18081]})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for port in (18080, 18081):
            for attempt in range(15):
                try:
                    with opener.open(f'http://127.0.0.1:{port}/health', timeout=2) as response:
                        if json.load(response).get('status') == 'ok':
                            break
                except OSError:
                    if tunnel.poll() is not None:
                        raise RuntimeError('RESUME_TUNNEL_EXITED')
                    time.sleep(1)
            else:
                raise RuntimeError('RESUME_HEALTH_TIMEOUT')
        with (OUT / 'driver.log').open('xb') as log:
            start = time.monotonic()
            worker = subprocess.Popen(['C:/Program Files/nodejs/node.exe', str(HERE / 'resume-capability.mjs'), 'run'],
                cwd=HERE, env=ENV, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
            try:
                code = worker.wait(timeout=20*60)
            except subprocess.TimeoutExpired:
                subprocess.run(['taskkill.exe', '/PID', str(worker.pid), '/T', '/F'], capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
                worker.wait(timeout=30)
                raise
            finally:
                save('driver-process.json', {'pid': worker.pid, 'exit_code': worker.returncode, 'reaped': worker.poll() is not None, 'elapsed_s': time.monotonic()-start})
            if code:
                raise RuntimeError('RESUME_DRIVER_FAILED')
finally:
    if worker is not None and worker.poll() is None:
        subprocess.run(['taskkill.exe', '/PID', str(worker.pid), '/T', '/F'], capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
        worker.wait(timeout=30)
    if tunnel is not None:
        if tunnel.poll() is None:
            tunnel.terminate()
        tunnel.wait(timeout=15)
        cleanup['tunnel'] = {'pid': tunnel.pid, 'exit_code': tunnel.returncode, 'reaped': True}
    if enabled:
        result = remote(['python3', REMOTE, 'restore', OWNER])
        cleanup['ssh_restore'] = {'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
        if result.returncode == 0:
            receipt = json.loads(result.stdout)
            cleanup['ssh_original_hash_matches'] = receipt['current_sha256'] == receipt['original_sha256']
    save('cleanup.json', cleanup)
    print(json.dumps(cleanup))
    if enabled and not cleanup.get('ssh_original_hash_matches'):
        raise RuntimeError('RESUME_SSH_RESTORE_NOT_CONFIRMED')

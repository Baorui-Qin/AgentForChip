"""Report old blockers and all new observed attempts without assuming a successful model repair."""
import json
from pathlib import Path

OUT = Path('D:/AMD/output/rtl-grounded-minimal-fixed-20261018')
OLD = Path('D:/AMD/output/rtl-recovery-ablation-20261017')


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


old_case = OLD / 'campaign/arms/on/compare-Prob142_lemmings2/models/run-LQ1Xsi/token-19'
old_wire = load(old_case / 'input.json')
old_payload = json.loads(next(message['content'] for message in old_wire['messages'] if message['role'] == 'user'))
calls, errors, plans, usage = (load(OUT / name) for name in ('call-index.json', 'model-errors.json', 'planner-validation-index.json', 'skill-usage-audit.json'))
rows = {}
for task in ('Prob142_lemmings2', 'Prob096_review2015_fsmseq'):
    rows[task] = {}
    for arm in ('on', 'off'):
        coder = [row for row in usage['requests'] if row['task'] == task and row['arm'] == arm and row['provider'] == 'cloud-coder']
        planner = [row for row in plans if row['task'] == task and row['arm'] == arm]
        result = load(OUT / 'campaign/arms' / arm / ('compare-' + task) / 'result.json')
        rows[task][arm] = {'terminal': result['status'],
            'coder_dispatches': len(coder), 'native_input_counts_and_budgets': [{'tokens': row['input_tokens'], 'budget': row['input_budget'],
                'planning_text_omitted': 'planning:text:window' in row['omissions'], 'selected_skills': row['selected_skills'], 'request_file': row['request_file']} for row in coder],
            'planner_attempts': len(planner), 'planner_valid_attempts': sum(row['valid_compact_json'] for row in planner),
            'planner_truncated_attempts': sum(row['truncated'] for row in planner),
            'planner_output_tokens': [row['completion_tokens'] for row in planner],
            'context_preparation_errors': [row for row in errors if row['task'] == task and row['arm'] == arm and row['code'] == 'CONTEXT_UNSATISFIABLE']}
old_errors = load(OLD / 'model-errors.json')
report = {'old_Prob142_on': {'native_input_tokens': load(old_case / 'output.json')['input_tokens'], 'input_budget': 5120,
    'planning_text_chars': len(old_payload['planning']['text']), 'skills_already_removed': old_payload['guidance'] == [],
    'input_file': str(old_case / 'input.json'), 'count_file': str(old_case / 'output.json')},
    'old_Prob096_on': {'truncated_planner_attempts': len([row for row in old_errors if row['task'] == 'Prob096_review2015_fsmseq' and row['arm'] == 'on' and row['phase'] == 'plan' and row['code'] == 'truncated']),
        'planner_output_ceiling': 1024, 'terminal': 'PLANNER_OUTPUT_TRUNCATED'},
    'current': rows, 'original_budgets_unchanged': usage['same_per_task_budgets'], 'official_score': None}
with (OUT / 'blocker-comparison.json').open('x', encoding='utf-8') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
print(json.dumps({'old_input_tokens': report['old_Prob142_on']['native_input_tokens'], 'current': {task: {arm: {'terminal': value['terminal'], 'context_errors': len(value['context_preparation_errors']), 'planner_truncated': value['planner_truncated_attempts']} for arm, value in arms.items()} for task, arms in rows.items()}}))

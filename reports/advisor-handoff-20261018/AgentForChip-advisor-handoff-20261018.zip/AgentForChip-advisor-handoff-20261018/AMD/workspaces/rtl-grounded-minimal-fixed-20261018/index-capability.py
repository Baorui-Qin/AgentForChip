"""Audit all off-target model controls and their shared dispatch budget separately from question scores."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path

OUT = Path('D:/AMD/output/rtl-grounded-minimal-fixed-20261018')
ROOT = OUT / 'campaign'


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()


controls, links, models, counters = [], {}, [], []
for arm in ('on', 'off'):
    values = load(ROOT / 'capability' / arm / 'results.json')
    assert values['status'] == 'COMPLETED' and values['controls'] == 3
    for result in values['results']:
        controls.append({key: result[key] for key in ('task', 'arm', 'status', 'plan_citation_matched', 'plan_explanation_keyword_check',
            'patch_accepted', 'minimal_changed_spans', 'verification_requested', 'passed', 'oracle_not_in_request')})
    for file in (ROOT / 'capability' / arm).rglob('run.json'):
        directory = file.parent
        if not (directory / 'model.json').exists():
            continue
        task = next((p for p in directory.parts if p in ('ControlComma', 'ControlEnum', 'ControlScalar')), None)
        assert task
        dispatch = load(directory / 'dispatch.json') if (directory / 'dispatch.json').exists() else None
        row = {'arm': arm, 'task': task, 'phase': 'plan' if 'plans' in directory.parts else 'repair', 'directory': str(directory),
            'model_file': str(directory / 'model.json'), 'request_sha256': dispatch['request_sha256'] if dispatch else None,
            'raw_run_state': load(file).get('state')}
        models.append(row)
        if dispatch:
            links.setdefault(row['request_sha256'], []).append(row)
        for token_file in directory.glob('token-*/output.json'):
            counters.append({'arm': arm, 'task': task, 'path': str(token_file), 'input_tokens': load(token_file)['input_tokens']})
calls, usage = [], Counter()
for file in (ROOT / 'capability/http').glob('*/transport.json'):
    transport = load(file)
    wire = load(file.parent / 'request.json')
    sha = digest(wire)
    assert sha == transport['request_sha256'] and len(links.get(sha, [])) == 1
    model = links[sha][0]
    payload = json.loads(next(m['content'] for m in wire['messages'] if m['role'] == 'user'))
    assert payload['task']['id'] == model['task']
    assert 'CAPABILITY_CHECKS' not in json.dumps(wire) and 'causeWords' not in json.dumps(wire)
    if model['arm'] == 'off':
        assert not payload['guidance']
    for skill in payload['guidance']:
        assert set(skill) == {'id', 'version', 'scope', 'rule', 'limitations'}
    audit = load(Path(model['directory']) / 'context-audit.json')
    assert audit['tokens'] <= audit['budget']
    if model['phase'] == 'repair':
        context = load(Path(model['directory']) / 'context.json')
        assert payload['current']['source'] == context['current']['source']
        if context['pending_verification']:
            assert not payload['guidance']
    last_usage = None
    for line in (file.parent / 'sse.jsonl').read_text().splitlines():
        data = json.loads(line).get('data')
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except json.JSONDecodeError:
                continue
        if isinstance(data, dict) and data.get('usage'):
            last_usage = data['usage']
    if last_usage:
        usage.update({k: last_usage[k] for k in ('prompt_tokens', 'completion_tokens', 'total_tokens') if isinstance(last_usage.get(k), int)})
    calls.append({**model, 'provider': transport['provider'], 'http_status': transport['http_status'], 'stream_complete': transport['stream_complete'],
        'input_tokens': audit['tokens'], 'input_budget': audit['budget'], 'max_tokens': wire['max_tokens'], 'selected_skills': audit['selected_skills'],
        'request_file': str(file.parent / 'request.json'), 'sse_file': str(file.parent / 'sse.jsonl'), 'transport_file': str(file), 'usage': last_usage})
main_calls = load(OUT / 'call-index.json')
claims = {}
continuation = load(ROOT / 'campaign-freeze.json')['protocol']['continuation_budget']
for arm in ('on', 'off'):
    tickets = [load(p) for p in (ROOT / 'arms' / arm / 'dispatches').glob('*.json')]
    actual = [r for r in calls + main_calls if r['arm'] == arm]
    assert len(tickets) <= continuation['same_remaining_limit_both_arms'] == 56
    assert len(tickets) + continuation['previous_used'][arm] <= 100
    assert sorted(t['owner']['request_sha256'] for t in tickets) == sorted(r['request_sha256'] for r in actual)
    claims[arm] = {'reserved_dispatches': len(tickets), 'capability_calls': sum(r['arm'] == arm for r in calls),
        'question_calls': sum(r['arm'] == arm for r in main_calls), 'current_remaining_limit': 56,
        'previous_generation_calls': continuation['previous_used'][arm], 'total_used_across_generations': len(tickets) + continuation['previous_used'][arm],
        'unchanged_original_limit': 100, 'uncertain_unlinked_dispatches': 0}
summary = {'status': 'EVIDENCE_AUDIT_PASS', 'controls_completed': 6, 'controls': controls,
    'probe_completed_before_questions': True, 'bootstrap_directory_fix_active': True, 'mixed_noop_patch_fix_active': True,
    'previous_diagnostic_generation_preserved': continuation['previous_output'], 'original_deadline_not_reset': True,
    'quality_summary': {arm: {key: sum(bool(row[key]) for row in controls if row['arm'] == arm) for key in
        ('plan_citation_matched', 'plan_explanation_keyword_check', 'patch_accepted', 'minimal_changed_spans', 'verification_requested', 'passed')}
        for arm in ('on', 'off')}, 'calls': calls, 'model_records': models, 'native_counter_records': counters,
    'inference_calls': len(calls), 'usage': dict(usage), 'shared_arm_claim_audit': claims,
    'question_inference_calls': len(main_calls), 'combined_inference_calls': len(calls) + len(main_calls),
    'no_oracle_or_testbench_in_requests': True, 'official_score': None,
    'limitations': 'Literal citation and keyword checks are not a semantic proof; minimality is limited to predefined generic fixture spans.'}
with (OUT / 'capability-audit.json').open('x', encoding='utf-8') as stream:
    json.dump(summary, stream, ensure_ascii=False, indent=2)
with (OUT / 'capability-controls.csv').open('x', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(controls[0]))
    writer.writeheader()
    writer.writerows(controls)
print(json.dumps({k: summary[k] for k in ('quality_summary', 'inference_calls', 'combined_inference_calls', 'shared_arm_claim_audit')}))

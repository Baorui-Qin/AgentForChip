# Grounded Planning and Exact Model Edits

This corrected generation preserves the preceding diagnostic experiment. It fixes probe model-directory initialization and accepts a genuine exact patch that also contains unchanged disjoint context; an entirely unchanged result remains rejected. Both arms receive only 56 remaining dispatches, debited from the preceding 44 ON / 41 OFF calls, and keep the ORIGINAL campaign deadline. No new 100-call allowance or deadline is granted. Question budgets remain two edits and eight coder calls per independent run; both generations are reported, never merged by best result.

This independent copy keeps the preceding six-rule skill registry unchanged. ON uses C and OFF uses B; both planner and coder follow the existing diagnostic selector. No task-specific answers, reference implementations or hidden reasoning enter skills.

Exact mode adds the live diagnostic's existing source line and up to two lexical references, not inferred types or repairs. A compact planner cause must quote the supplied line when one is available. Citation validation checks literal location only; a plan can still be semantically wrong. All old field, output and recovery caps remain.

The coder submits one to three model-authored before/after replacements through edit_dut. Each before must match exactly once in the bound original DUT; spans cannot overlap. The host applies only these bytes, then uses unchanged interface, source-policy, duplicate, budget, EDA and rollback checks. It never supplies missing replacement text. Legacy full-source mode remains unchanged outside this frozen experiment.

After local tests and 26 existing EDA controls, six off-target real-model controls measure source citation, explanation keywords, changed-span locality and actual EDA behavior. Their oracle and testbench never enter requests. Each control gets one plan binding with the existing one recovery, at most two coder calls and one edit; failures are preserved, not patched by the host. These calls consume the SAME 100-dispatch pool per arm and the same 60-minute campaign deadline as the seven task pairs. Quality failures do not masquerade as a green capability result.

Then the same seven generated initials run in alternating ON/OFF order. Per question: two accepted RTL modifications, eight coder requests, four plan bindings, 240-second activity budget, 8192 contexts, 1024 margin, planner output 1024 and coder output 2048. Only dsh profiles launch applications. Run experiment.mjs prepare, main_run.py preflight, then main_run.py models. No handoff is updated; previous worktrees and all six historical output roots remain protected.

Development Vivado 2026.1 and the unchanged 2025.2 netlist-library pins do not establish official competition scoring or single-32GB compliance. Reports distinguish literal citation, semantic localization, minimal edits and final verification.

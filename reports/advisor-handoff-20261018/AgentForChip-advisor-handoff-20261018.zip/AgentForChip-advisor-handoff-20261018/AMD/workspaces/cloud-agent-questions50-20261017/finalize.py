"""Check log coverage and closed loopback ports, then index every native candidate attempt."""
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import socket

OUT = Path('D:/AMD/output/cloud-agent-questions50-20261017')
ROOT = OUT / 'campaign'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


ports = []
for port in (18080, 18081):
    with socket.socket() as connection:
        connection.settimeout(10)
        code = connection.connect_ex(('127.0.0.1', port))
        if code != 10061:
            raise RuntimeError(f'PORT_CLOSE_NOT_CONFIRMED:{port}:{code}')
        ports.append({'address': '127.0.0.1', 'port': port, 'socket_code': code, 'connection_refused': True})
cleanup = load(OUT / 'cleanup.json')
assert cleanup['ssh_original_hash_matches'] and cleanup['tunnel']['reaped']
attempts, stage_receipts = [], {}
for name in ('preflight', 'configure', 'validate', 'diagnostic'):
    stage_receipts[name] = load(OUT / (name + '-driver-process.json'))
    assert stage_receipts[name]['reaped'] and stage_receipts[name]['exit_code'] == 0 and not stage_receipts[name]['watchdog_timeout']
for task in load(ROOT / 'manifest-50.json')['task_ids']:
    result = load(ROOT / ('generate-' + task) / 'result.json')
    for number, attempt in enumerate(result.get('generation_attempts', []), 1):
        rejection = attempt.get('candidate_rejection') or {}
        attempts.append({'task': task, 'attempt': number, 'request_sha256': attempt.get('request_sha256'),
            'candidate_valid': attempt.get('candidate_valid'), 'response_complete': attempt.get('response_complete'),
            'rejection_stage': rejection.get('stage'), 'rejection_code': rejection.get('code'),
            'source_sha256': attempt.get('source_sha256'), 'model_run': attempt.get('model_run')})
with (OUT / 'tasks.csv').open(encoding='utf-8-sig', newline='') as stream:
    rows = list(csv.DictReader(stream))
notes = (OUT / 'FAILURE_ANALYSIS.zh.md').read_text(encoding='utf-8')
needed = {row['task'] for row in rows if row['generation'] != 'GENERATED_UNVERIFIED'
    or any(row['initial_' + stage] != 'PASS' for stage in ('compile', 'elaborate', 'simulation', 'synthesis'))}
needed.update(row['task'] for row in attempts if row['rejection_code'])
missing = [task for task in sorted(needed) if not re.search(r'^## ' + re.escape(task.split('_')[0]) + r'\b', notes, re.M)]
assert not missing, missing
with (OUT / 'generation-attempts.csv').open('x', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(attempts[0]))
    writer.writeheader()
    writer.writerows(attempts)
receipt = {'checked_at_utc': datetime.now(timezone.utc).isoformat(), 'loopback_ports': ports,
    'ssh_original_hash_matches': True, 'stages': stage_receipts,
    'native_candidate_attempts': len(attempts), 'candidate_rejections': sum(bool(row['rejection_code']) for row in attempts),
    'tasks_requiring_failure_notes': sorted(needed), 'failure_notes_missing': missing,
    'observed_http_model_attempts': load(OUT / 'summary.json')['http_model_attempts']}
with (OUT / 'post-run-checks.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
print(json.dumps({'candidate_attempts': len(attempts), 'tasks_with_failure_notes': len(needed), 'missing': missing, 'ports_closed': True}))

import { readFile, writeFile, mkdir, readdir, cp, copyFile, open, appendFile, access } from 'node:fs/promises'
import { join, resolve, dirname } from 'node:path'
import { createHash } from 'node:crypto'
import { spawn, execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { buildModelProfile, roles, validateBudgets } from './p10-profile.mjs'

const helper = dirname(fileURLToPath(import.meta.url))
const selectedCount = 50, expectedControls = 102
const repo = 'D:/AMD/workspaces/http-paired-20261016/harness', rtl = helper + '/rtl-tools', base = 'D:/AMD', prior = base + '/p156-20260927-v3', cal = base + '/p156-20260927-settled-cal'
const root = resolve(process.argv[2]), stage = process.argv[3]
const yaml = createRequire(repo + '/package.json')('js-yaml')
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const json = async path => JSON.parse(await readFile(path, 'utf8'))
const put = async (path, value) => writeFile(path, JSON.stringify(value, null, 2), { flag: 'wx' })
const unix = value => value.replaceAll('\\', '/')
const filesIn = async directory => {
  const files = []
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name)
    if (entry.isDirectory()) files.push(...await filesIn(path))
    else if (entry.isFile()) files.push(path)
  }
  return files
}
const sourceFiles = async () => [
  ...(await filesIn(rtl + '/src')).filter(p => p.endsWith('.ts')),
  ...(await filesIn(rtl + '/phase1/p10')).filter(p => /\.(mjs|ps1)$/.test(p)),
  repo + '/tsconfig.base.json', repo + '/rtl-tools/tsconfig.json',
  repo + '/packages/llm/llm-deepseek/src/serialize.ts', repo + '/packages/llm/llm-deepseek/src/sse.ts', repo + '/packages/llm/llm-deepseek/src/translate.ts',
  join(helper, 'experiment.mjs'), 'D:/AMD/cloud-dual-llama/models.json',
  join(helper, 'p10-profile.mjs'), join(helper, 'validate-profile.mjs'), join(helper, 'selection.mjs'), join(helper, 'selection.json')
]
const freeze = async (path, files, protocol) => put(path, { created_at: new Date().toISOString(), upstream_git_commit: execFileSync('git', ['-C', 'D:/deepseek-harness', 'rev-parse', 'HEAD']).toString().trim(), runtime_checkout: repo, independent_rtl_source: rtl,
  files: Object.fromEntries(await Promise.all(files.map(async p => [p, hash(await readFile(p))]))), protocol })
const validate = () => JSON.parse(execFileSync(process.execPath, ['--import', 'tsx/esm', join(helper, 'validate-profile.mjs'), root],
  { cwd: repo, encoding: 'utf8', windowsHide: true, timeout: 60000 }))

async function profile(name, rows) {
  const home = join(root, 'dsh-home/profiles', name)
  await mkdir(home, { recursive: true })
  await put(join(home, 'package.json'), { name, private: true, dependencies: {}, dsh: { profile: { bundles: [], patchReload: 'startup' } } })
  await put(join(home, 'cordis.yml'), [])
  await put(join(home, 'cordis.patch.yml'), [{ insert: rows }])
}
function common(workspace) {
  return [{ id: 'subprocess', name: repo + '/packages/subprocess/subprocess-local/src/index.ts' },
    { id: 'projections', name: repo + '/packages/session/session-projection/src/index.ts' },
    { id: 'policy', name: repo + '/packages/sandbox/sandbox-policy/src/index.ts', config: { mode: 'danger-full-access', workspaceRoot: unix(workspace) } }]
}
async function invoke(profileName, command, task) {
  await mkdir(join(root, 'runner-logs'), { recursive: true })
  const logPath = join(root, 'runner-logs', `${profileName}-${command}-${task ?? 'controls'}-${Date.now()}.log`)
  const log = await open(logPath, 'wx')
  let code
  try {
    const child = spawn(process.execPath, ['--import', 'tsx/esm', 'apps/cli/src/bin.ts', '--profile', profileName, command, ...(task ? [task] : [])],
      { cwd: repo, env: { ...Object.fromEntries(Object.entries(process.env).filter(([key]) => !/KEY|SECRET|TOKEN|PASSWORD|PROXY/i.test(key))),
        XILINXD_LICENSE_FILE: 'D:/AMDDesignTools/Xilinx.lic', DSH_HOME: join(root, 'dsh-home'), NODE_OPTIONS: '--max-old-space-size=4096' }, windowsHide: true, stdio: ['ignore', log.fd, log.fd] })
    code = await new Promise((res, rej) => { child.on('error', rej); child.on('exit', res) })
  } finally { await log.close() }
  console.log(`${command} ${task ?? 'controls'}: exit=${code}, log=${logPath}`)
  if (code !== 0) throw new Error('DSH_HOST_FAILED')
  if (task && command === 'probe') {
    const directory = (await readdir(root)).find(p => p.startsWith(`probe-${task}-`))
    if (!directory) throw new Error('PROBE_RESULT_MISSING')
    return json(join(root, directory, 'result.json'))
  }
  if (task && command !== 'probe') {
    const result = await json(join(root, `${command}-${task}/result.json`))
    console.log(`${task}: ${result.status}`)
    return result
  }
}

if (stage === 'prepare') {
  const budgets = validateBudgets(await json(process.argv[4] ?? base + '/cloud-dual-llama/p10-budgets.json'))
  await mkdir(dirname(root), { recursive: true })
  await mkdir(root, { recursive: true })
  if (await access(join(root, 'p10-budgets.json')).then(() => true, () => false)) throw new Error('PREPARATION_ALREADY_EXISTS')
  await put(join(root, 'p10-budgets.json'), budgets)
  await mkdir(join(root, 'preflight'))
  const manifestPath = join(helper, 'selection.json')
  const manifest = await json(manifestPath)
  if (manifest.task_ids.length !== selectedCount || new Set(manifest.task_ids).size !== selectedCount ||
    manifest.task_ids.some(id => manifest.excluded_previous_tasks.includes(id) || id === manifest.excluded_control)) throw new Error('SELECTION_INVALID')
  for (const [path, digest] of Object.entries(manifest.sources)) if (hash(await readFile(path)) !== digest) throw new Error('SELECTION_SOURCE_CHANGED')
  await copyFile(manifestPath, join(root, 'manifest-50.json'))
  for (const name of ['catalog.json', 'evaluator-policy.json']) await copyFile(join(cal, name), join(root, 'preflight', name))
  await cp(join(cal, 'derived'), join(root, 'preflight/derived'), { recursive: true, errorOnExist: true, force: false })
  await put(join(root, 'preflight/selection-order.json'), manifest.task_ids)
  const eda = yaml.load(await readFile(join(prior, 'eda-settings.yaml'), 'utf8'))
  eda.repositoryRoot = repo
  eda.expectedVivadoVersion = '2026.1'
  for (const name of ['vivado', 'xvlog', 'xelab', 'xsim']) eda.tools[name] = `D:/AMDDesignTools/2026.1/Vivado/bin/${name}.bat`
  eda.outputRoot = unix(join(root, 'eda'))
  await writeFile(join(root, 'eda-settings.yaml'), yaml.dump(eda), { flag: 'wx' })
  const limits = { compileMs: 60000, elaborateMs: 60000, simulationMs: 120000, totalMs: 900000, maxArtifactBytes: 268435456, artifactPollMs: 100, maxEventBytes: 1048576 }
  await profile('rtl-p10-cloud-preflight', [...common(join(root, 'preflight')), { id: 'preflight', name: rtl + '/src/phase1/p10-cloud-preflight.ts',
    config: { campaignRoot: unix(join(root, 'preflight')), datasetRoot: base + '/verilog-eval', settingsFile: unix(join(root, 'eda-settings.yaml')),
      freezeFile: unix(join(root, 'preflight/freeze.json')), selectedTaskCount: selectedCount, allowUnisolatedPreflight: true, ...limits } }])
  const selectedAssets = (await json(join(cal, 'catalog.json'))).filter(t => [...manifest.task_ids, 'Prob038_count15'].includes(t.task_id)).flatMap(t => Object.keys(t.assets).map(p => join(base, 'verilog-eval', p)))
  const assets = [...(await filesIn(join(root, 'preflight'))), ...selectedAssets, ...(await sourceFiles()), ...(await filesIn(join(root, 'dsh-home'))).filter(p => !p.endsWith('cordis.yml')), join(root, 'eda-settings.yaml'), join(root, 'p10-budgets.json')]
  await freeze(join(root, 'preflight/freeze.json'), assets, { rtl_evaluator: 'p10-settled-rtl-1', selected: manifest.task_ids, sentinel: 'Prob038_count15', model_calls: 0 })
  console.log('Prepared ' + root)
} else if (stage === 'preflight') {
  await invoke('rtl-p10-cloud-preflight', 'preflight')
} else if (stage === 'configure') {
  const frozen = await access(join(root, 'campaign-freeze.json')).then(() => true, error => { if (error.code !== 'ENOENT') throw error; return false })
  if (frozen) throw new Error('FROZEN_CAMPAIGN_IMMUTABLE')
  const budgets = validateBudgets(await json(join(root, 'p10-budgets.json')))
  const controls = await json(join(root, 'preflight/results.json'))
  if (controls.status !== 'PASS' || controls.controls !== expectedControls) throw new Error('PREFLIGHT_GATE_FAILED')
  const identity = {}, modelManifest = await json('D:/AMD/cloud-dual-llama/models.json')
  await mkdir(join(root, 'services'))
  for (const { role, baseURL, model: alias } of roles) {
    const props = await (await fetch(baseURL.replace(/\/v1$/, '') + '/props', { redirect: 'error', signal: AbortSignal.timeout(10000) })).json()
    const models = await (await fetch(baseURL + '/models', { redirect: 'error', signal: AbortSignal.timeout(10000) })).json()
    if (!models.data.some(m => m.id === alias) || props.default_generation_settings.n_ctx !== budgets[role].contextWindow || props.total_slots !== 1) throw new Error('SERVICE_IDENTITY_MISMATCH')
    await put(join(root, `services/${role}-props.json`), props)
    await put(join(root, `services/${role}-models.json`), models)
    identity[role] = { implementation: 'llama-native-chat-input-tokens', alias, props_sha256: hash(JSON.stringify(props)), template_sha256: hash(props.chat_template),
      model_manifest_sha256: hash(JSON.stringify(modelManifest)), context_window: String(budgets[role].contextWindow), build_info: props.build_info, model_path: props.model_path }
  }
  await put(join(root, 'cloud-identity.json'), identity)
  const predecessor = await json(join(root, 'predecessor.json')).catch(error => { if (error.code !== 'ENOENT') throw error; return null })
  const remaining = 500
  if (remaining <= 0) throw new Error('CAMPAIGN_BUDGET_EXHAUSTED')
  const auto = await json(join(prior, 'auto.json')); Object.assign(auto, { campaignRoot: unix(root), maxDispatches: remaining, campaignDispatchLimit: remaining, maxToolSteps: 12 })
  await put(join(root, 'auto.json'), auto)
  const deadline = new Date(Date.now() + 180 * 60 * 1000).toISOString()
  if (Date.now() >= Date.parse(deadline)) throw new Error('CAMPAIGN_TIME_BUDGET')
  const generated = buildModelProfile({ root, budgets, identity, deadline, remaining,
    config: yaml.load(await readFile(join(prior, 'model.patch.yml'), 'utf8')).find(r => r.id === 'p10-model').config,
    p09: await json(join(prior, 'p09.json')) })
  const { config, p09, llama } = generated
  Object.assign(config, { selectedTaskCount: selectedCount, generationMode: 'native-tool', maxRepairRounds: 2, maxAgentRequests: 8,
    activeMs: 240000, timeoutMs: 60000, maxTransportRetries: 0, transportBackoffMs: [], maxGenerationResumes: 0 })
  config.cloud.maxPlans = 4
  await put(join(root, 'p09.json'), p09)
  await profile('rtl-p10-model', [...common(root), { id: 'llm', name: repo + '/packages/llm/llm/src/index.ts' },
    { id: 'llama', name: rtl + '/src/phase1/p10-llama.ts', config: llama },
    { id: 'p10-model', name: rtl + '/src/phase1/p10-model.ts', config }])
  await put(join(root, 'offline-config-check.json'), validate())
  const frozenFiles = [...(await sourceFiles()), ...(await filesIn(join(root, 'dsh-home'))).filter(p => !p.endsWith('cordis.yml')), ...(await filesIn(join(root, 'preflight/derived'))),
    join(root, 'preflight/catalog.json'), join(root, 'preflight/selection-order.json'), join(root, 'preflight/evaluator-policy.json'), join(root, 'preflight/compat-positive-negative-results.json'),
    join(root, 'cloud-identity.json'), join(root, 'p09.json'), join(root, 'auto.json'), join(root, 'eda-settings.yaml'), join(root, 'manifest-50.json'),
    join(root, 'p10-budgets.json'), join(root, 'offline-config-check.json'), p09.skillsFile]
  const catalog = await json(join(root, 'preflight/catalog.json'))
  const tasks = (await json(join(root, 'manifest-50.json'))).task_ids
  for (const task of catalog.filter(t => [...tasks, 'Prob038_count15'].includes(t.task_id))) for (const [asset, digest] of Object.entries(task.assets)) {
    const path = join(base, 'verilog-eval', asset); if (hash(await readFile(path)) !== digest) throw new Error('DATASET_ASSET_CHANGED'); frozenFiles.push(path)
  }
  if (predecessor) frozenFiles.push(join(root, 'predecessor.json'))
  await freeze(join(root, 'campaign-freeze.json'), frozenFiles, { models: identity, selected: tasks, deadline, max_dispatches: remaining, previous_dispatches: predecessor?.dispatches_used ?? 0,
    kind: 'cloud-agent-new-50-development-2026.1', formal_scored_run: false,
    budgets, temperature: 0, top_p: 1, thinking: 'off', max_repairs: 2, max_coder_requests: 8, max_plans: 4,
    rtl_evaluator: 'p10-settled-rtl-1', acceptance_protocol: 'p10-netlist-1', full_os_isolation_verified: false,
    tool_version: '2026.1', netlist_library_gate_unchanged: true })
  console.log('Configured both model routes; deadline ' + deadline)
} else if (stage === 'validate') {
  console.log(JSON.stringify(validate(), null, 2))
} else if (stage === 'smoke') {
  const probe = await invoke('rtl-p10-model', 'probe', 'Prob005_notgate')
  const result = await invoke('rtl-p10-model', 'repair-control', 'Prob038_count15')
  const passed = probe.status === 'HEALTHY' && result.status === 'VERIFIED' && result.valid_repair_attempts > 0 && result.actions.some(a => a.tool === 'verify_rtl' && a.accepted)
  await put(join(root, 'smoke-result.json'), { passed, probe: probe.status, control: result, counted_in_ten: false })
  if (!passed) throw new Error('SMOKE_GATE_FAILED')
} else if (stage === 'diagnostic') {
  if ((await json(join(root, 'preflight/results.json'))).status !== 'PASS') throw new Error('PREFLIGHT_GATE_FAILED')
  validate()
  const tasks = (await json(join(root, 'manifest-50.json'))).task_ids
  await put(join(root, 'diagnostic-start.json'), { at: new Date().toISOString(), tasks, formal_score: false, separate_native_smoke: 'NOT_RUN' })
  for (const task of tasks) {
    let generated, compared
    try { generated = await invoke('rtl-p10-model', 'generate', task) }
    catch (error) { await appendFile(join(root, 'progress.jsonl'), JSON.stringify({ task, phase: 'generate', host_error: String(error), at: new Date().toISOString() }) + '\n'); break }
    if (generated.status === 'GENERATED_UNVERIFIED') {
      compared = await invoke('rtl-p10-model', 'compare', task)
    }
    await appendFile(join(root, 'progress.jsonl'), JSON.stringify({ task, at: new Date().toISOString(), generation: generated.status, comparison: compared?.status ?? 'NOT_RUN' }) + '\n')
    if (/CAMPAIGN_|TOKENIZER|IDENTITY|TRANSPORT|INFRA_PAUSED|HOST_FAILURE/.test(String(compared?.status ?? generated.status))) break
  }
  await put(join(root, 'diagnostic-ended.json'), { at: new Date().toISOString(), planned_tasks: tasks.length, formal_score: false })
} else throw new Error('Usage: experiment.mjs <fresh-root> prepare [budgets.json]|preflight|configure|validate|smoke|diagnostic')

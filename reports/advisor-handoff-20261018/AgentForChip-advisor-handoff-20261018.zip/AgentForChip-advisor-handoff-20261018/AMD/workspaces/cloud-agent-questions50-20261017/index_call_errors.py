"""Index model-level failures separately from HTTP success and host-side candidate rejection."""
from collections import Counter
import csv
import json
from pathlib import Path

OUT = Path('D:/AMD/output/cloud-agent-questions50-20261017')


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


errors, missing = [], []
for model in load(OUT / 'model-output-index.json'):
    directory = Path(model['directory'])
    native, generic, action = (directory / name for name in ('native-submission.json', 'model.json', 'result.json'))
    if native.exists():
        path, record = native, load(native)
        response = record['response']
        error = response.get('error')
        code = record.get('error_code')
        usage = response.get('usage', {})
    elif generic.exists():
        path, record = generic, load(generic)
        error = record.get('error')
        code = error.get('category') if error else None
        usage = record.get('usage', {})
    elif action.exists():
        path, record = action, load(action)
        code = record.get('error_code')
        error, usage = None, record
    else:
        missing.append(str(directory))
        continue
    if not code and not error:
        continue
    errors.append({'task': model['task'], 'phase': model['phase'], 'request_sha256': model['request_sha256'],
        'code': code, 'error': json.dumps(error, ensure_ascii=False) if error else None,
        'completion_tokens': usage.get('completion_tokens'), 'record': str(path),
        'planning_binding_completed': (directory.parent / 'plan.json').exists() if model['phase'] == 'plan' else None})
assert not missing, missing
with (OUT / 'model-errors.json').open('x', encoding='utf-8') as stream:
    json.dump(errors, stream, ensure_ascii=False, indent=2)
with (OUT / 'model-errors.csv').open('x', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(errors[0]))
    writer.writeheader()
    writer.writerows(errors)
print(json.dumps({'model_error_attempts': len(errors), 'by_phase': dict(Counter(row['phase'] for row in errors)),
    'planner_truncations_by_task': dict(Counter(row['task'] for row in errors if row['phase'] == 'plan')),
    'planner_truncations_with_completed_binding': sum(row['phase'] == 'plan' and row['planning_binding_completed'] for row in errors)}))

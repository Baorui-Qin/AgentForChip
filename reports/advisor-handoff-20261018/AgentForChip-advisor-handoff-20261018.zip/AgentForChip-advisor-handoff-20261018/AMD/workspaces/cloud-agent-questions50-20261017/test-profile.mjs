import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile, mkdir } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { DoctorConfig } from './rtl-tools/src/phase1/doctor.ts';
import { DoctorConfig as OriginalDoctorConfig } from '../http-paired-20261016/harness/rtl-tools/src/phase1/doctor.ts';
import { createDatasetSnapshot } from './rtl-tools/src/phase1/snapshots.ts';
import { calibratedLibraryFiles } from './rtl-tools/src/phase1/p10-netlist-profiles.ts';
import { calibratedLibraryFiles as OriginalLibraryFiles } from '../http-paired-20261016/harness/rtl-tools/src/phase1/p10-netlist-profiles.ts';
import { validateBudgets } from './p10-profile.mjs';
import { selectTasks, seed } from './selection.mjs';

const yaml = createRequire(import.meta.url)('js-yaml');
const out = 'D:/AMD/output/cloud-agent-questions50-20261017';
const config = yaml.load(await readFile(out + '/campaign/eda-settings.yaml', 'utf8'));

test('development settings accept the actual tool release but the untouched original pin refuses it', () => {
  assert.equal(DoctorConfig(config).expectedVivadoVersion, '2026.1');
  assert.throws(() => OriginalDoctorConfig(config));
  assert.throws(() => DoctorConfig({ ...config, expectedVivadoVersion: '2025.2' }));
});

test('snapshot provenance records the development release without spoofing a tool result', async () => {
  const parent = out + '/offline-checks';
  await mkdir(parent, { recursive: true });
  const snapshot = await createDatasetSnapshot(parent, {
    'rtl/solution.sv': 'module TopModule(input a,output y); assign y=a; endmodule\n',
    'trusted/tb.sv': 'module tb; endmodule\n',
  }, { top: 'TopModule', tbTop: 'tb', sources: ['rtl/solution.sv', 'trusted/tb.sv'],
    evaluatorId: 'keyless-unit-test', seed: 1, datasetRevision: 'synthetic-unit-test' });
  assert.equal(JSON.parse(snapshot.manifest).tool_version, '2026.1');
});

test('release-specific netlist library hashes remain unchanged and therefore fail closed on another build', () => {
  assert.deepEqual(calibratedLibraryFiles, OriginalLibraryFiles);
});

test('8K budgets are explicit and an output ceiling exhausting context is rejected', async () => {
  const budgets = JSON.parse(await readFile(new URL('./budgets.json', import.meta.url), 'utf8'));
  assert.equal(validateBudgets(budgets).coder.contextWindow, 8192);
  assert.throws(() => validateBudgets({ ...budgets, coder: { ...budgets.coder, maxTokens: 8192 } }));
});

test('fifty new tasks are deterministic, distinct and independent of catalog order', async () => {
  const catalog = JSON.parse(await readFile(out + '/campaign/preflight/catalog.json', 'utf8'));
  const derived = JSON.parse(await readFile(out + '/campaign/preflight/derived/settled-rtl-manifest.json', 'utf8'));
  const manifest = JSON.parse(await readFile(new URL('./selection.json', import.meta.url), 'utf8'));
  const selected = selectTasks(catalog, manifest.excluded_previous_tasks, derived.tasks).map(row => row.task_id);
  assert.equal(seed, '20261017');
  assert.equal(selected.length, 50);
  assert.equal(new Set(selected).size, 50);
  assert.deepEqual(selected, manifest.task_ids);
  assert.deepEqual(selectTasks([...catalog].reverse(), manifest.excluded_previous_tasks, derived.tasks).map(row => row.task_id), selected);
  assert.ok(selected.every(id => !manifest.excluded_previous_tasks.includes(id) && id !== 'Prob038_count15'));
  assert.throws(() => selectTasks(catalog.slice(0, 10), manifest.excluded_previous_tasks, derived.tasks));
});

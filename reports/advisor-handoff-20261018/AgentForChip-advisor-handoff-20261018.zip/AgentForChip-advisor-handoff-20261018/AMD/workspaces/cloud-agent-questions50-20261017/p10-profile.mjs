import { join } from 'node:path'
import { isDeepStrictEqual } from 'node:util'

export const roles = [
  { role: 'thinker', provider: 'cloud-thinker', model: 'qwen3-coder-30b', baseURL: 'http://127.0.0.1:18080/v1' },
  { role: 'coder', provider: 'cloud-coder', model: 'siliconmind-qwen3-8b', baseURL: 'http://127.0.0.1:18081/v1' },
]
const coderTokens = ['maxTokens', 'repairMaxTokens', 'forcedActionMaxTokens', 'generationRecoveryMaxTokens']
const coderBytes = ['maxResponseBytes', 'repairMaxResponseBytes', 'generationRecoveryMaxResponseBytes']
const unix = value => value.replaceAll('\\', '/')

/** Reject missing, mistyped or infeasible budgets before creating an experiment. */
export function validateBudgets(value) {
  const keys = (object, expected, label) => {
    if (!object || Array.isArray(object) || typeof object !== 'object'
      || Object.keys(object).sort().join(',') !== [...expected].sort().join(',')) throw new Error('BUDGET_FIELDS:' + label)
  }
  keys(value, ['margin', 'thinker', 'coder'], 'root')
  keys(value.thinker, ['contextWindow', 'maxTokens', 'maxResponseBytes'], 'thinker')
  keys(value.coder, ['contextWindow', ...coderTokens, ...coderBytes], 'coder')
  for (const [key, number] of [['margin', value.margin], ...Object.entries(value.thinker), ...Object.entries(value.coder)]) {
    if (!Number.isSafeInteger(number) || number <= 0) throw new Error('BUDGET_POSITIVE_INTEGER:' + key)
  }
  for (const role of ['thinker', 'coder']) {
    if (outputCeiling(value, role) + value.margin >= value[role].contextWindow) throw new Error('BUDGET_CONTEXT_EXHAUSTED:' + role)
  }
  return value
}

/** Each route must accommodate all of that role's bounded request modes. */
export function outputCeiling(budgets, role) {
  return role === 'thinker' ? budgets.thinker.maxTokens : Math.max(...coderTokens.map(key => budgets.coder[key]))
}

/** Build the model config, native routes and Coder context from one explicit budget file. */
export function buildModelProfile({ root, config: original, p09: previous, budgets, identity, deadline, remaining }) {
  validateBudgets(budgets)
  const config = { ...original, campaignRoot: unix(root), preflightRoot: unix(join(root, 'preflight')),
    settingsFile: unix(join(root, 'eda-settings.yaml')), p09File: unix(join(root, 'p09.json')),
    autoFile: unix(join(root, 'auto.json')), freezeFile: unix(join(root, 'campaign-freeze.json')),
    model: roles[1].model, provider: roles[1].provider,
    ...Object.fromEntries([...coderTokens, ...coderBytes].map(key => [key, budgets.coder[key]])),
    maxCandidateRecoveryAttempts: 1, selectedTaskCount: 50, maxGenerationResumes: 0, campaignMaxDispatches: remaining,
    cloud: { coderBaseURL: roles[1].baseURL, thinkerBaseURL: roles[0].baseURL, thinkerProvider: roles[0].provider,
      thinkerModel: roles[0].model, thinkerContextWindow: budgets.thinker.contextWindow,
      thinkerMaxTokens: budgets.thinker.maxTokens, thinkerMaxResponseBytes: budgets.thinker.maxResponseBytes,
      identityFile: unix(join(root, 'cloud-identity.json')), maxPlans: 16 } }
  const p09 = { ...previous, limits: { ...previous.limits, window: budgets.coder.contextWindow,
    output: budgets.coder.maxTokens, margin: budgets.margin } }
  const llama = { evidenceRoot: unix(join(root, 'http')), deadline, routes: roles.map(({ role, ...route }) => ({
    ...route, identity: identity[role], contextWindow: budgets[role].contextWindow, maxTokens: outputCeiling(budgets, role) })) }
  return { config, p09, llama }
}

/** Validate the persisted fields together; schema-valid but inconsistent routes still fail. */
export function assertProfileBudgets({ config, p09, llama, budgets, identity }) {
  validateBudgets(budgets)
  const same = (actual, expected, name) => {
    if (!isDeepStrictEqual(actual, expected)) throw new Error('PROFILE_BUDGET_MISMATCH:' + name)
  }
  for (const key of [...coderTokens, ...coderBytes]) same(config[key], budgets.coder[key], 'coder.' + key)
  same(config.provider, roles[1].provider, 'coder.provider')
  same(config.model, roles[1].model, 'coder.model')
  for (const [key, value] of Object.entries({ thinkerContextWindow: budgets.thinker.contextWindow,
    thinkerMaxTokens: budgets.thinker.maxTokens, thinkerMaxResponseBytes: budgets.thinker.maxResponseBytes,
    thinkerProvider: roles[0].provider, thinkerModel: roles[0].model, thinkerBaseURL: roles[0].baseURL, coderBaseURL: roles[1].baseURL })) {
    same(config.cloud?.[key], value, 'cloud.' + key)
  }
  for (const [key, value] of Object.entries({ window: budgets.coder.contextWindow, output: budgets.coder.maxTokens, margin: budgets.margin })) {
    same(p09.limits?.[key], value, 'p09.' + key)
  }
  same(llama.routes.length, 2, 'routes.length')
  for (const { role, ...expected } of roles) {
    const route = llama.routes.find(row => row.provider === expected.provider)
    for (const [key, value] of Object.entries(expected)) same(route?.[key], value, role + '.' + key)
    same(route.contextWindow, budgets[role].contextWindow, role + '.contextWindow')
    same(route.maxTokens, outputCeiling(budgets, role), role + '.ceiling')
    same(route.identity, identity[role], role + '.identity')
    same(route.identity.context_window, String(budgets[role].contextWindow), role + '.servedContext')
    same(route.identity.alias, expected.model, role + '.alias')
  }
}

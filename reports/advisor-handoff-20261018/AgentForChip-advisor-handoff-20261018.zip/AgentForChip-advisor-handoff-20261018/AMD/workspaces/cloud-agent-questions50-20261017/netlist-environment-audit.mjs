import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { calibratedLibraryFiles } from './rtl-tools/src/phase1/p10-netlist-profiles.ts';

const directory = 'D:/AMDDesignTools/2026.1/Vivado/data/xsim/verilog/unisims_ver';
const entries = [];
for (const [name, expected] of Object.entries(calibratedLibraryFiles)) {
  const bytes = await readFile(directory + '/' + name);
  const actual = createHash('sha256').update(bytes).digest('hex');
  entries.push({ name, expected_release: '2025.2', expected_sha256: expected, actual_release: '2026.1', actual_sha256: actual, matches: actual === expected });
}
const result = { scope: 'READ_ONLY_NETLIST_LIBRARY_GATE_DIAGNOSIS', directory, entries,
  all_match: entries.every(entry => entry.matches), library_files_modified: false, acceptance_guard_modified: false };
await writeFile('D:/AMD/output/cloud-agent-questions50-20261017/netlist-environment-audit.json', JSON.stringify(result, null, 2), { flag: 'wx' });
console.log(JSON.stringify(result));

"""Temporarily permit only the two loopback model destinations on this instance."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

CONFIG = Path('/tmp/amd-oneclick-sshd_config')
ROOT = Path('/workspace/codex-dual-20261017-35053/ssh-forwarding')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def listener():
    pid = int(Path('/tmp/amd-oneclick-sshd.pid').read_text().strip())
    command = Path(f'/proc/{pid}/cmdline').read_bytes()
    if b'/usr/sbin/sshd' not in command or str(CONFIG).encode() not in command:
        raise RuntimeError('SSH_LISTENER_IDENTITY_MISMATCH')
    return pid

def validate():
    subprocess.run(['/usr/sbin/sshd', '-t', '-f', str(CONFIG)], check=True)

def main():
    action, run_id = sys.argv[1:]
    if not run_id.replace('-', '').isalnum() or action not in ('enable', 'restore'):
        raise RuntimeError('INVALID_ARGUMENT')
    target = ROOT / run_id
    original = target / 'original.conf'
    changed = target / 'forwarding.conf'
    pid = listener()
    if action == 'enable':
        target.mkdir(parents=True, exist_ok=False)
        before = CONFIG.read_bytes()
        if b'Match ' in before or before.count(b'AllowTcpForwarding no') != 1:
            raise RuntimeError('SSH_CONFIGURATION_CHANGED')
        after = before.replace(b'AllowTcpForwarding no',
            b'AllowTcpForwarding local\nPermitOpen 127.0.0.1:18080 127.0.0.1:18081\nPermitListen none')
        original.write_bytes(before)
        changed.write_bytes(after)
        CONFIG.write_bytes(after)
        try:
            validate()
            os.kill(pid, signal.SIGHUP)
        except BaseException:
            CONFIG.write_bytes(before)
            validate()
            os.kill(pid, signal.SIGHUP)
            raise
    else:
        before = original.read_bytes()
        after = changed.read_bytes()
        if CONFIG.read_bytes() != after:
            raise RuntimeError('REFUSE_TO_OVERWRITE_LATER_SSH_CHANGES')
        CONFIG.write_bytes(before)
        validate()
        os.kill(pid, signal.SIGHUP)
    print(json.dumps({'action': action, 'run_id': run_id, 'original_sha256': sha(before),
        'forwarding_sha256': sha(after), 'current_sha256': sha(CONFIG.read_bytes()), 'listener_pid': pid}))

if __name__ == '__main__':
    main()

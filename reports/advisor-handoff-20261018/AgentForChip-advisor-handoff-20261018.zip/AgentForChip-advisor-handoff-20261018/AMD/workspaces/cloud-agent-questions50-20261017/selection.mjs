import { createHash } from 'node:crypto'
import { readFile, writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { resolve } from 'node:path'

export const seed = '20261017'
const hash = value => createHash('sha256').update(value).digest('hex')

/** Select an answer-independent, portable hash-ranked sample without repeating the prior questions. */
export function selectTasks(catalog, previous, derived) {
  const excluded = new Set([...previous, 'Prob038_count15'])
  const eligible = catalog.filter(task => task.interface && derived[task.task_id] && !excluded.has(task.task_id))
  if (new Set(eligible.map(task => task.task_id)).size !== eligible.length || eligible.length < 50) throw new Error('SELECTION_POOL_INVALID')
  return eligible.map(task => ({ task_id: task.task_id, rank: hash(seed + '\0' + task.task_id) }))
    .sort((a, b) => a.rank < b.rank ? -1 : a.rank > b.rank ? 1 : 0).slice(0, 50)
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const catalogPath = 'D:/AMD/p156-20260927-settled-cal/catalog.json'
  const derivedPath = 'D:/AMD/p156-20260927-settled-cal/derived/settled-rtl-manifest.json'
  const previousPath = 'D:/AMD/output/cloud-agent-questions-20261017/campaign/p10-manifest-10.json'
  const bytes = await Promise.all([catalogPath, derivedPath, previousPath].map(path => readFile(path)))
  const [catalog, derived, previous] = bytes.map(value => JSON.parse(value))
  const selected = selectTasks(catalog, previous.task_ids, derived.tasks)
  const value = { protocol: 'hash-ranked-new-50-v1', seed, count: 50,
    task_ids: selected.map(row => row.task_id), selected_ranks: selected,
    excluded_previous_tasks: previous.task_ids, excluded_control: 'Prob038_count15',
    sources: Object.fromEntries([catalogPath, derivedPath, previousPath].map((path, index) => [path, hash(bytes[index])])) }
  await writeFile(new URL('./selection.json', import.meta.url), JSON.stringify(value, null, 2), { flag: 'wx' })
  console.log(JSON.stringify({ selected: value.count, seed, duplicate_previous: value.task_ids.filter(id => previous.task_ids.includes(id)).length }))
}

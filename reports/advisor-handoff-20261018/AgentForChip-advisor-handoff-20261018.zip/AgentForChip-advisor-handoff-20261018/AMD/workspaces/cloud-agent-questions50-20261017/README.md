# Fifty New Cloud Harness Questions

This independent development run selects 50 new VerilogEval questions using SHA256 ranks with seed 20261017. It excludes all ten questions from the preceding run and the separate calibration sentinel Prob038_count15. The selection is frozen before observing any new model answer. It is not a test of the new 200-question bank.

Applications launch only through dsh profiles. The 30B planner and 8B Coder are routed automatically through the existing Harness. Installed framework code and dependencies are reused read-only from the earlier independent checkout. The original project, the previous ten-question output, old skills, question banks and sealed handoff are not overwritten.

All 50 selected questions plus the sentinel must pass model-free positive/negative calibration, 102 controls total, before inference. The copied RTL evaluator and release-specific netlist gate are unchanged from the preceding development run: actual Vivado 2026.1 is recorded, while the original 2025.2 library hashes remain enforced. A netlist environment block is not converted to a design failure or accepted score.

Per-question budgets remain two semantic repair rounds, eight Coder requests, twelve tool steps, 240 seconds active time per command and 8K model context. The expanded campaign has at most 500 physical inference dispatches and a 180-minute deadline after configuration. All failed, blocked and unrun questions remain in the summary. No result-driven reselection or hidden rerun is allowed.

The model manager temporarily enables local SSH forwarding only to the two existing loopback model ports, then closes and reaps its tunnel and restores the exact original sshd configuration. Cloud model services are not stopped. Raw requests, SSE events, model-visible plans and outputs, tool actions, revisions, EDA logs, calibration controls, terminal reasons and process receipts belong under D:/AMD/output/cloud-agent-questions50-20261017.

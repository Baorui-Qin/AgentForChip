import { readFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { Config as ModelConfig } from './rtl-tools/src/phase1/p10-model.ts'
import { Config as LlamaConfig } from './rtl-tools/src/phase1/p10-llama.ts'
import { assertProfileBudgets } from './p10-profile.mjs'

const json = async path => JSON.parse(await readFile(path, 'utf8'))

/** Use the actual Harness schemas without mounting plugins, networking or running EDA. */
export function validateProfile(value) {
  ModelConfig(value.config)
  LlamaConfig(value.llama)
  assertProfileBudgets(value)
  return { status: 'PASS', model_calls: 0, eda_runs: 0, budgets: value.budgets }
}

export async function validateProfileFiles(root) {
  const patch = await json(join(root, 'dsh-home/profiles/rtl-p10-model/cordis.patch.yml'))
  const rows = patch[0].insert
  return validateProfile({ config: rows.find(row => row.id === 'p10-model').config,
    llama: rows.find(row => row.id === 'llama').config, p09: await json(join(root, 'p09.json')),
    budgets: await json(join(root, 'p10-budgets.json')), identity: await json(join(root, 'cloud-identity.json')) })
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  console.log(JSON.stringify(await validateProfileFiles(resolve(process.argv[2])), null, 2))
}

"""Own the temporary tunnel, run only dsh-profile stages, then restore SSH exactly."""
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time
import urllib.request

HERE = Path(__file__).resolve().parent
OUT = Path('D:/AMD/output/rtl-rule-transfer-probes-20261018')
ROOT = OUT / 'campaign'
SSH = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-i', 'C:/Users/qbr/.ssh/id_ed25519_amd',
       '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', 'ConnectTimeout=10', '-o', 'ServerAliveInterval=15', '-o', 'ServerAliveCountMax=3']
env = {k: v for k, v in os.environ.items() if not re.search('KEY|SECRET|TOKEN|PASSWORD|PROXY', k, re.I)}
env['TSX_TSCONFIG_PATH'] = 'D:/AMD/workspaces/http-paired-20261016/harness/tsconfig.base.json'


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)


def stage(name, timeout):
    argv = ['C:/Program Files/nodejs/node.exe', '--import', 'tsx/esm', str(HERE / 'complete-configure.mjs')] if name == 'configure-complete' else ['C:/Program Files/nodejs/node.exe', '--import', 'tsx/esm', str(HERE / 'heldout-experiment.mjs'), name]
    with (OUT / (name + '-driver.log')).open('xb') as log:
        worker = subprocess.Popen(argv, cwd='D:/AMD/workspaces/http-paired-20261016/harness', env=env, stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
        start = time.monotonic()
        seen = 0
        timed_out = False
        try:
            while worker.poll() is None:
                if time.monotonic()-start > timeout:
                    timed_out = True
                    subprocess.run(['taskkill.exe', '/PID', str(worker.pid), '/T', '/F'],
                                   capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=30)
                    break
                progress = ROOT / 'progress.jsonl'
                lines = progress.read_text(encoding='utf-8').splitlines() if progress.exists() else []
                for line in lines[seen:]:
                    print(line, flush=True)
                seen = len(lines)
                time.sleep(3)
        finally:
            if worker.poll() is None:
                subprocess.run(['taskkill.exe', '/PID', str(worker.pid), '/T', '/F'],
                               capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=30)
            worker.wait(timeout=30)
            save(OUT / (name + '-driver-process.json'), {'pid': worker.pid, 'exit_code': worker.returncode,
                 'reaped': True, 'watchdog_timeout': timed_out, 'elapsed_s': time.monotonic()-start, 'argv': argv})
        print(json.dumps({'stage': name, 'exit_code': worker.returncode, 'watchdog_timeout': timed_out}), flush=True)
        if worker.returncode or timed_out:
            raise RuntimeError('STAGE_FAILED:' + name)


if sys.argv[1:] == ['preflight']:
    stage('preflight', 30*60)
    sys.exit(0)
if sys.argv[1:] != ['models']:
    raise SystemExit('Use main_run.py preflight|models')

cleanup = {}
tunnel = None
enable_attempted = False
remote_helper = '/workspace/codex-dual-20261017-35053/question-ssh-forwarding.py'
run_id = 'rtl-rule-transfer-probes-20261018-resume'
try:
    controls = json.loads((ROOT / 'preflight/results.json').read_text(encoding='utf-8'))
    if controls['status'] != 'PASS' or controls['controls'] != 24:
        raise RuntimeError('CALIBRATION_REQUIRED')
    enable_attempted = True
    digest = hashlib.sha256((HERE / 'ssh_forwarding.py').read_bytes()).hexdigest()
    checked_enable = ('import hashlib,pathlib,subprocess; p=pathlib.Path(' + repr(remote_helper) + '); '
        'assert hashlib.sha256(p.read_bytes()).hexdigest()==' + repr(digest) + '; '
        'subprocess.run(["python3",str(p),"enable",' + repr(run_id) + '],check=True)')
    enabled = subprocess.run(SSH + ['-T', '-p', '35053', 'root@36.150.116.206',
        shlex.join(['python3', '-c', checked_enable])],
        capture_output=True, text=True, timeout=40, creationflags=subprocess.CREATE_NO_WINDOW, env=env)
    save(OUT / 'ssh-enable-resume.json', {'exit_code': enabled.returncode, 'stdout': enabled.stdout, 'stderr': enabled.stderr})
    if enabled.returncode:
        raise RuntimeError('SSH_ENABLE_FAILED')
    with (OUT / 'tunnel-resume.log').open('xb') as log:
        tunnel = subprocess.Popen(SSH + ['-o', 'ExitOnForwardFailure=yes',
            '-L', '127.0.0.1:18080:127.0.0.1:18080', '-L', '127.0.0.1:18081:127.0.0.1:18081',
            '-N', '-T', '-p', '35053', 'root@36.150.116.206'], env=env, stdin=subprocess.DEVNULL,
            stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
        save(OUT / 'tunnel-start-resume.json', {'pid': tunnel.pid, 'loopback_ports': [18080, 18081]})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for port in (18080, 18081):
            for attempt in range(15):
                try:
                    with opener.open(f'http://127.0.0.1:{port}/health', timeout=2) as response:
                        if json.load(response).get('status') == 'ok':
                            break
                except OSError:
                    if tunnel.poll() is not None:
                        raise RuntimeError('TUNNEL_EXITED')
                    time.sleep(1)
            else:
                raise RuntimeError('LOOPBACK_HEALTH_TIMEOUT')
        stage('configure-complete', 120)
        stage('validate', 120)
        stage('diagnostic', 61*60)
finally:
    if tunnel is not None:
        if tunnel.poll() is None:
            tunnel.terminate()
        tunnel.wait(timeout=15)
        cleanup['tunnel'] = {'pid': tunnel.pid, 'exit_code': tunnel.returncode, 'reaped': True}
    if enable_attempted:
        result = subprocess.run(SSH + ['-T', '-p', '35053', 'root@36.150.116.206',
            shlex.join(['python3', remote_helper, 'restore', run_id])],
            capture_output=True, text=True, timeout=40, creationflags=subprocess.CREATE_NO_WINDOW, env=env)
        cleanup['ssh_restore'] = {'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
        if result.returncode == 0:
            receipt = json.loads(result.stdout)
            cleanup['ssh_original_hash_matches'] = receipt['current_sha256'] == receipt['original_sha256']
    else:
        cleanup['ssh_policy_change_attempted'] = False
    save(OUT / 'cleanup-resume.json', cleanup)
    print(json.dumps({'cleanup': cleanup}), flush=True)
    if enable_attempted and not cleanup.get('ssh_original_hash_matches'):
        raise RuntimeError('SSH_RESTORE_NOT_CONFIRMED')

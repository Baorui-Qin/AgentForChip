import assert from 'node:assert/strict'
import { readFile, readdir, writeFile } from 'node:fs/promises'
import { inventory, hash } from './selection.mjs'

const here='D:/AMD/workspaces/rtl-rule-transfer-probes-20261018', out='D:/AMD/output/rtl-rule-transfer-probes-20261018', root=out+'/campaign'
const json=async p=>JSON.parse(await readFile(p,'utf8'))
const freeze=await json(root+'/campaign-freeze.json')
for(const [path,digest] of Object.entries(freeze.files)) assert.equal(hash(await readFile(path)),digest,path)
assert.equal((await json(out+'/post-run-checks.json')).status,'POST_RUN_CHECKS_PASS')
assert.equal((await json(out+'/preservation-final.json')).status,'PASS')
assert.equal((await json(out+'/history-preservation-final.json')).status,'PASS')
const skills=await json(out+'/skill-usage-audit.json'), transfer=await json(out+'/rule-transfer-evidence.json')
assert.equal(skills.status,'PASS');assert.equal(skills.off_requests_with_guidance,0)
const calls=await json(out+'/call-index.json'), models=await json(out+'/model-output-index.json')
const claims={}
for(const arm of ['on','off']) {
  const dispatches=(await readdir(root+'/arms/'+arm+'/dispatches')).filter(n=>n.endsWith('.json'))
  assert.ok(dispatches.length<=100)
  assert.equal(dispatches.length,calls.filter(c=>c.arm===arm).length)
  claims[arm]=dispatches.length
}
assert.equal((await json(out+'/comparison-summary.json')).arm_runs,16)
assert.ok(calls.every(c=>c.http_status===200&&c.stream_complete))
assert.ok(skills.requests.every(r=>r.input_tokens<=r.input_budget))
for(const name of ['skills/rtl-diagnostic-reasoning/SKILL.md','skills/rtl-diagnostic-reasoning/references/rules.json','knowledge/constraint-graph.json','skill-registry/skills.validated.json'])
  assert.deepEqual(await readFile(here+'/'+name),await readFile('D:/AMD/workspaces/rtl-rule-explanations-offline-20261018/'+name))
const old=await inventory('D:/AMD/workspaces/rtl-rule-explanations-offline-20261018/rtl-tools/src'), current=await inventory(here+'/rtl-tools/src')
const relative=path=>path.slice(path.indexOf('/rtl-tools/src/')+15)
const a=Object.fromEntries(Object.entries(old).map(([p,h])=>[relative(p),h])),b=Object.fromEntries(Object.entries(current).map(([p,h])=>[relative(p),h]))
const changed=Object.keys(a).filter(p=>a[p]!==b[p]),added=Object.keys(b).filter(p=>!a[p])
assert.deepEqual(changed.sort(),['phase1/p10-compat.ts','phase1/p10-model.ts'])
assert.deepEqual(added,['phase1/p10-local-probes.ts'])
let links=0
for(const name of ['REPORT.results.zh.md','FAILURE_ANALYSIS.results.zh.md','LOG_INDEX.results.md'])for(const match of (await readFile(out+'/'+name,'utf8')).matchAll(/\]\(([^)]+)\)/g)) {
  if(match[1]!==out+'/delivery-verification.json')await readFile(match[1])
  links++
}
const value={status:'HELDOUT_EVIDENCE_AUDIT_PASS',not_a_claim_of_private_understanding:true,probe_tasks:8,arm_runs:16,
  comparison:await json(out+'/comparison-summary.json'),model_calls:calls.length,dispatch_claims:claims,model_outputs:models.length,
  recovered:transfer.recovery_summary,skill_v2_and_graph_unchanged:true,off_guidance:0,per_question_budgets_unchanged:true,
  original_deadline_preserved:freeze.protocol.deadline,original_and_history_preserved:true,handoff_updated:false,
  temporary_tunnels_reaped_and_ssh_restored:true,focused_tests_passed:115,typecheck_existing_diagnostics:70,added_type_diagnostics:0,
  frozen_files_checked:Object.keys(freeze.files).length,runtime_changes:changed,added_runtime:added,guard_and_planner_policy_unchanged:true,
  document_links_checked:links,official_score:null,statistical_significance_tested:false,
  prepared_report_and_failed_configuration_records_preserved:true}
await writeFile(out+'/delivery-verification.json',JSON.stringify(value,null,2),{flag:'wx'})
console.log(JSON.stringify(value))

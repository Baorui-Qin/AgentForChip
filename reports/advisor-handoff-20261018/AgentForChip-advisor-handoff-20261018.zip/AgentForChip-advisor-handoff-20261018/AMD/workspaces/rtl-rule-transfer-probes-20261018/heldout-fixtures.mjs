const seqTB = (declarations, wiring, drive, expected, observe) => `module tb;
reg clk=0; always #5 clk=~clk;
${declarations}
integer i, checks=0, mismatches=0, model=0;
TopModule dut(${wiring});
initial begin
for(i=0;i<72;i=i+1) begin
 @(negedge clk); ${drive}
 @(posedge clk); #1; ${expected}
 checks=checks+1; if(${observe}) mismatches=mismatches+1;
end
$display("Mismatches: %0d in %0d samples",mismatches,checks); $finish;
end
endmodule
`
const ports = list => ({ top: 'TopModule', ports: list.map(([name, direction, width = 1]) => ({ name, direction, width, signed: false })) })
const base = [['clk','input'],['rst','input'],['step','input']]
const ring = `module TopModule(input clk,input rst,input step,output [2:0] phase);
typedef enum logic [2:0] {Z0,Z1,Z2,Z3,Z4,Z5} phase_t;
phase_t phase_reg;
always @(posedge clk) if(rst) phase_reg<=Z0; else if(step) case(phase_reg)
Z0:phase_reg<=Z1; Z1:phase_reg<=Z2; Z2:phase_reg<=Z3;
Z3:phase_reg<=Z4; Z4:phase_reg<=Z5; default:phase_reg<=Z0;
endcase
assign phase=phase_reg;
endmodule
`
const sparse = `module TopModule(input clk,input rst,input step,output [1:0] phase);
typedef enum logic [1:0] {QUIET=2'd0,SCAN=2'd1,LATCH=2'd2,FLUSH=2'd3} stage_t;
stage_t cursor;
always @(posedge clk) if(rst) cursor<=QUIET; else if(step) case(cursor)
QUIET:cursor<=SCAN; SCAN:cursor<=LATCH; LATCH:cursor<=FLUSH; default:cursor<=QUIET;
endcase
assign phase=cursor;
endmodule
`
const typed = `module TopModule(input clk,input rst,input step,output flag);
typedef enum logic [2:0] {CALM=3'd1,ARMED=3'd6} command_t;
command_t alias_state;
command_t stored_state;
always @(posedge clk) if(rst) stored_state<=CALM; else if(step) stored_state<=(stored_state==CALM)?ARMED:CALM;
assign alias_state=stored_state;
assign flag=(alias_state==ARMED);
endmodule
`
const scalar = `module TopModule(input clk,input rst,input prefer,input serial,input alternate,output reg bit_out);
always @(posedge clk) if(rst) bit_out<=1'b0; else if(prefer) bit_out<=alternate; else bit_out<=bit_out^serial;
endmodule
`
const parity = `module TopModule(input clk,input rst,input capture,input [4:0] packet,output reg parity);
always @(posedge clk) if(rst) parity<=1'b0; else if(capture) parity<=^packet;
endmodule
`
const driver = `module TopModule(input clk,input rst,input freeze,input request,output pulse);
logic pulse_reg;
always_ff @(posedge clk) if(rst) pulse_reg<=1'b0; else if(!freeze) pulse_reg<=request;
assign pulse=pulse_reg;
endmodule
`
const validEnum = `module TopModule(input clk,input rst,input step,output marker);
typedef enum logic [1:0] {FIRST=2'd0,MIDDLE=2'd1,LAST=2'd2} orbit_t;
orbit_t orbit;
always @(posedge clk) if(rst) orbit<=FIRST; else if(step) case(orbit)
FIRST:orbit<=MIDDLE; MIDDLE:orbit<=LAST; default:orbit<=FIRST;
endcase
assign marker=(orbit==LAST);
endmodule
`
const phaseTB = (width, modulus) => seqTB(`reg rst=1,step=0; wire [${width-1}:0] phase;`, '.clk(clk),.rst(rst),.step(step),.phase(phase)',
  'rst=(i%19==0); step=(i%4!=1);', `if(rst) model=0; else if(step) model=(model+1)%${modulus};`, 'phase !== model['+(width-1)+':0]')

// Host-owned evaluator positives are never sent to a model; all faulty seeds freeze before dispatch.
export const heldoutFixtures = [
  { id:'Probe201_six_phase', family:'enum_capacity', rules:['R-ENUM-CAPACITY'], interface:ports([...base,['phase','output',3]]),
    spec:'A synchronous six-phase sequencer. rst has priority and sets phase=0. On step=1 advance 0,1,2,3,4,5,0; otherwise hold. phase is a fixed 3-bit output. Keep a named enum for the six internal phases and preserve the public numerical phase sequence.',
    seed:ring.replace('enum logic [2:0]','enum logic [1:0]'), positive:ring, tb:phaseTB(3,6), checks:72 },
  { id:'Probe202_unique_stage', family:'enum_uniqueness', rules:['R-ENUM-CAPACITY'], interface:ports([...base,['phase','output',2]]),
    spec:'A four-stage sequencer. Synchronous rst sets phase=0. Each enabled step advances 0->1->2->3->0; a disabled step holds. The internal enum labels are QUIET=0, SCAN=1, LATCH=2, FLUSH=3; keep these specified encodings and the fixed 2-bit output.',
    seed:sparse.replace('FLUSH=2\'d3','FLUSH=2\'d1'), positive:sparse, tb:phaseTB(2,4), checks:72 },
  { id:'Probe203_typed_toggle', family:'enum_type', rules:['R-ENUM-TYPE'], interface:ports([...base,['flag','output']]),
    spec:'A typed toggle state machine with synchronous reset. rst selects CALM (code 1); each step toggles CALM (code 1) and ARMED (code 6), otherwise hold. flag is high exactly for ARMED. Retain the command_t enum interpretation for alias_state and keep all public ports one bit.',
    seed:typed.replace('command_t stored_state;','logic [2:0] stored_state;'), positive:typed,
    tb:seqTB('reg rst=1,step=0; wire flag;', '.clk(clk),.rst(rst),.step(step),.flag(flag)',
      'rst=(i%13==0); step=(i%5!=2);','if(rst) model=0; else if(step) model=1-model;','flag !== model[0]'), checks:72 },
  { id:'Probe204_feedback_serial', family:'fixed_scalar', rules:['R-FIXED-PORT'],
    interface:ports([['clk','input'],['rst','input'],['prefer','input'],['serial','input'],['alternate','input'],['bit_out','output']]),
    spec:'A one-bit feedback cell. At the rising edge, synchronous rst clears bit_out. Otherwise prefer selects loading alternate; if not preferred, update bit_out to its previous value XOR serial. All ports are fixed scalars; this is not a stage that receives a parent vector.',
    seed:scalar.replace('bit_out^serial;','bit_out^serial[4];'), positive:scalar,
    tb:seqTB('reg rst=1,prefer=0,serial=0,alternate=0; wire bit_out;', '.clk(clk),.rst(rst),.prefer(prefer),.serial(serial),.alternate(alternate),.bit_out(bit_out)',
      'rst=(i%17==0); prefer=(i%4==0); serial=(i%3==0); alternate=(i%5<2);',
      'if(rst) model=0; else if(prefer) model=alternate; else model=model^serial;', 'bit_out !== model[0]'), checks:72 },
  { id:'Probe205_packet_parity', family:'procedural_target', rules:['R-PROCEDURAL-TARGET'],
    interface:ports([['clk','input'],['rst','input'],['capture','input'],['packet','input',5],['parity','output']]),
    spec:'Store the XOR reduction of all five packet bits when capture is high at a positive clock edge. Synchronous rst has priority and clears parity; otherwise hold when capture=0. Preserve the fixed five-bit packet input and one-bit parity output.',
    seed:parity.replace('output reg parity','output parity'), positive:parity,
    tb:seqTB('reg rst=1,capture=0; reg [4:0] packet=0; wire parity;', '.clk(clk),.rst(rst),.capture(capture),.packet(packet),.parity(parity)',
      'rst=(i%23==0); capture=(i%3!=1); packet=(i*7+3)%32;',
      'if(rst) model=0; else if(capture) model=^packet;', 'parity !== model[0]'), checks:72 },
  { id:'Probe206_owned_pulse', family:'multiple_drivers', rules:['R-MULTIPLE-DRIVERS'],
    interface:ports([['clk','input'],['rst','input'],['freeze','input'],['request','input'],['pulse','output']]),
    spec:'At each rising clock edge, synchronous rst clears pulse. Otherwise pulse holds if freeze=1 and samples request if freeze=0. The output is registered, not combinational. Preserve all one-bit public ports and the reset/hold timing.',
    seed:driver.replace('assign pulse=pulse_reg;',"always_comb pulse_reg=1'b0;\nassign pulse=pulse_reg;"), positive:driver,
    tb:seqTB('reg rst=1,freeze=0,request=0; wire pulse;', '.clk(clk),.rst(rst),.freeze(freeze),.request(request),.pulse(pulse)',
      'rst=(i%11==0); freeze=(i%4==1); request=(i%3==1);', 'if(rst) model=0; else if(!freeze) model=request;', 'pulse !== model[0]'), checks:72 },
  { id:'Probe207_valid_bitselect', family:'boundary_vector', rules:['R-FIXED-PORT'],
    interface:ports([['word','input',5],['folded','output']]),
    spec:'A combinational five-bit input word produces folded=word[2] XOR word[0]. The indexed input is deliberately a vector, not a scalar. Preserve its width and the one-bit output.',
    seed:'module TopModule(input [4:0] word,output folded); assign folded=word[3]^word[0]; endmodule\n',
    positive:'module TopModule(input [4:0] word,output folded); assign folded=word[2]^word[0]; endmodule\n',
    tb:'module tb; reg [4:0] word=0; wire folded; integer i,checks=0,mismatches=0; TopModule dut(word,folded); initial begin for(i=0;i<32;i=i+1) begin word=i; #2; checks=checks+1; if(folded !== (word[2]^word[0])) mismatches=mismatches+1; end $display("Mismatches: %0d in %0d samples",mismatches,checks); $finish; end endmodule\n', checks:32 },
  { id:'Probe208_valid_capacity', family:'boundary_enum', rules:['R-ENUM-CAPACITY'], interface:ports([...base,['marker','output']]),
    spec:'A three-state sequencer FIRST=0, MIDDLE=1, LAST=2. Synchronous rst selects FIRST; step cycles FIRST->MIDDLE->LAST->FIRST and otherwise holds. marker must be high exactly in LAST. Keep the legal 2-bit enum encoding unchanged; no public state port is needed.',
    seed:validEnum.replace('assign marker=(orbit==LAST);','assign marker=(orbit==MIDDLE);'), positive:validEnum,
    tb:seqTB('reg rst=1,step=0; wire marker;', '.clk(clk),.rst(rst),.step(step),.marker(marker)',
      'rst=(i%17==0); step=(i%4!=0);','if(rst) model=0; else if(step) model=(model+1)%3;', 'marker !== (model==2)'), checks:72 }
]

"""Index preserved Harness outputs and classify facts without converting blocked acceptance into success."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
from result_evidence import best_evidence

OUT = Path('D:/AMD/output/rtl-rule-transfer-probes-20261018')
ROOT = OUT / 'campaign'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()


def write_csv(path, rows):
    with path.open('x', encoding='utf-8-sig', newline='') as stream:
        if rows:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


def terminal_domain(status, stage_domains=(), generation=False):
    if status in ('TIMEOUT', 'CANCELLED'):
        return 'RUNTIME_TIMEOUT_OR_CANCEL'
    if status in ('TRANSPORT', 'INFRA_PAUSED'):
        return 'TRANSPORT'
    if 'OUTPUT_TRUNCATED' in status:
        return 'OUTPUT_LIMIT'
    if status in ('CONTEXT_UNSATISFIABLE', 'CONTEXT_LENGTH_EXCEEDED', 'CONTEXT_WINDOW_EXCEEDED'):
        return 'CONTEXT_BUDGET'
    if 'BUDGET' in status:
        return 'BUDGET'
    if status == 'NETLIST_NOT_CALIBRATED':
        return 'EVALUATOR_SCOPE'
    if status.startswith('NETLIST_'):
        return 'ENVIRONMENT'
    if status == 'POLICY_BLOCKED':
        return 'HARNESS_REPAIR_POLICY'
    if status in ('REPEATED_ACTION_REJECTED', 'INVALID_MODEL_ACTION', 'FINISHED_UNVERIFIED'):
        return 'AGENT_TOOL_PROTOCOL'
    if generation:
        return 'GENERATION_OR_PROTOCOL'
    if 'environment' in stage_domains:
        return 'ENVIRONMENT'
    if 'resource' in stage_domains:
        return 'RESOURCE'
    return 'DESIGN_OR_VERIFICATION' if set(stage_domains) == {'design'} else 'MODEL_OR_TOOL_PROTOCOL'


ids = load(ROOT / 'manifest.json')['task_ids']
controls = load(ROOT / 'preflight/results.json')
assert controls['status'] == 'PASS' and controls['controls'] == 24
assert load(OUT / 'cleanup.json')['ssh_original_hash_matches']
assert load(OUT / 'cleanup-resume.json')['ssh_original_hash_matches']
freeze = load(ROOT / 'campaign-freeze.json')
changed_inputs = [name for name, expected in freeze['files'].items()
                  if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected]
assert not changed_inputs, changed_inputs
links = {}
model_outputs = []
for parent in [path for arm in ('on', 'off') for path in [ROOT / 'arms' / arm / 'plans', *(ROOT / 'arms' / arm).glob('compare-*/models')]]:
    if not parent.exists():
        continue
    for record_file in parent.rglob('run.json'):
        directory = record_file.parent
        dispatch = directory / 'dispatch.json'
        prompt = directory / 'prompt-final.json'
        if not prompt.exists():
            prompt = directory / 'prompt-final.txt'
        digest = load(dispatch)['request_sha256'] if dispatch.exists() else None
        if digest and prompt.suffix == '.json':
            assert canonical_hash(load(prompt)) == digest
        model_record = load(directory / 'run.json') if (directory / 'run.json').exists() else {}
        matches = [qid for qid in ids if any(part in (qid, 'generate-' + qid, 'compare-' + qid) for part in directory.parts)]
        phase = 'plan' if 'plans' in directory.parts else 'generation' if any(p.startswith('generate-') for p in directory.parts) else 'repair'
        link = {'arm': directory.parts[directory.parts.index('arms') + 1], 'task': matches[0] if len(matches) == 1 else 'UNRESOLVED', 'phase': phase,
                'directory': str(directory), 'prompt': str(prompt) if prompt.exists() else None,
                'dispatch': str(dispatch) if dispatch.exists() else None, 'request_sha256': digest,
                'model_record_experiment_id': model_record.get('experiment_id'),
                'model_record_state': model_record.get('state'),
                'output_files': {name: str(directory / name) for name in
                    ('response.txt', 'output.txt', 'reasoning.txt', 'native-submission.json', 'model.json', 'result.json',
                     'transport.json', 'context.json', 'context-audit.json', 'plan-validation.json', 'events.jsonl', 'run.json')
                    if (directory / name).exists()}}
        if digest:
            links.setdefault(digest, []).append(link)
        model_outputs.append(link)
calls, tokens, unknown_usage = [], Counter(), 0
for transport_file in sorted((ROOT / 'http').glob('*/transport.json')):
    directory = transport_file.parent
    transport = load(transport_file)
    request = load(directory / 'request.json')
    digest = canonical_hash(request)
    assert digest == transport['request_sha256']
    associated = links.get(digest, [])
    tasks = sorted({row['task'] for row in associated})
    usage = None
    first_event_at = last_event_at = None
    for line in (directory / 'sse.jsonl').read_text(encoding='utf-8').splitlines():
        envelope = json.loads(line)
        if envelope.get('timestamp'):
            first_event_at = first_event_at or envelope['timestamp']
            last_event_at = envelope['timestamp']
        value = envelope.get('data')
        if isinstance(value, str):
            try:
                event = json.loads(value)
            except json.JSONDecodeError:
                continue
        elif isinstance(value, dict):
            event = value
        else:
            continue
        if isinstance(event, dict) and event.get('usage'):
            usage = event['usage']
    if usage:
        tokens.update({key: usage[key] for key in ('prompt_tokens', 'completion_tokens', 'total_tokens') if isinstance(usage.get(key), int)})
    else:
        unknown_usage += 1
    arms = sorted({row['arm'] for row in associated})
    assert len(arms) == 1 and len(tasks) == 1, (digest, associated)
    calls.append({'arm': arms[0], 'task': '|'.join(tasks) if tasks else 'UNLINKED', 'phase': '|'.join(sorted({r['phase'] for r in associated})),
                  'provider': transport['provider'], 'model': transport['model'],
                  'http_status': transport['http_status'], 'stream_complete': transport['stream_complete'],
                  'first_sse_at_utc': first_event_at, 'last_sse_at_utc': last_event_at,
                  'transport_elapsed_ms': transport.get('started_elapsed_ms'),
                  'associated_model_runs': '|'.join(row['directory'] for row in associated),
                  'request_sha256': digest, 'max_tokens': request.get('max_tokens'),
                  'prompt_tokens': usage.get('prompt_tokens') if usage else None,
                  'completion_tokens': usage.get('completion_tokens') if usage else None,
                  'request_file': str(directory / 'request.json'), 'sse_file': str(directory / 'sse.jsonl'),
                  'transport_file': str(transport_file),
                  'directory': str(directory)})
calls.sort(key=lambda call: (call['first_sse_at_utc'] or '', call['directory']))
save(OUT / 'model-output-index.json', model_outputs)
save(OUT / 'call-index.json', calls)
write_csv(OUT / 'calls.csv', calls)
rows, failures = [], []
checked_initial_sources = checked_repair_receipts = 0
for arm, qid in [(arm, task) for task in ids for arm in ('on', 'off')]:
    arm_root = ROOT / 'arms' / arm
    gp = arm_root / ('generate-' + qid) / 'result.json'
    cp = arm_root / ('compare-' + qid) / 'result.json'
    g = load(gp) if gp.exists() else {}
    c = load(cp) if cp.exists() else {}
    if g.get('status') == 'LOCAL_REPAIR_SEED':
        assert hashlib.sha256((gp.parent / 'initial.sv').read_bytes()).hexdigest() == g['source_sha256']
        checked_initial_sources += 1
    for attempt in c.get('repair_attempts', []):
        if attempt.get('valid') is True:
            verified = attempt['verification']
            result_file = Path(verified['verification_run']) / 'result.json'
            assert hashlib.sha256(result_file.read_bytes()).hexdigest() == verified['result_sha256']
            receipt = load(result_file)
            assert receipt['task_id'] == qid and receipt['final_source_sha256'] == attempt['edit']['source_sha256']
            checked_repair_receipts += 1
    final_run, stage_evidence_source = best_evidence(c, cp.parent)
    record_path = Path(final_run) / 'result.json' if final_run else None
    record = load(record_path) if record_path and record_path.exists() else {}
    stages = record.get('stages', {})
    tier = {name: stages.get(name, {}).get('status', 'NOT_RUN') for name in ('compile', 'elaborate', 'simulation', 'synthesis')}
    initial = load(Path(c['baseline_run']) / 'result.json') if c.get('baseline_run') else {}
    initial_stages = initial.get('stages', {})
    initial_tier = {'initial_' + name: initial_stages.get(name, {}).get('status', 'NOT_RUN') for name in tier}
    failed_domains = {stage.get('failure_domain') for stage in stages.values() if stage.get('status') in ('FAIL', 'INCONCLUSIVE')}
    repair_count_reported = c.get('valid_repair_attempts')
    repair_count = repair_count_reported if repair_count_reported is not None else sum(attempt.get('valid') is True for attempt in c.get('repair_attempts', []))
    result_status = c.get('status', g.get('status', 'NOT_RUN'))
    reasons = []
    if not g:
        domain, reason = 'NOT_RUN', 'No generation result; not counted as a model or design failure.'
        reasons.append(reason)
    elif g['status'] != 'LOCAL_REPAIR_SEED':
        status = str(g.get('terminal_reason', g['status']))
        domain = terminal_domain(status, generation=True)
        reasons.append(status)
        if g.get('candidate_rejection'):
            reasons.append(json.dumps(g['candidate_rejection'], ensure_ascii=False))
        for attempt in g.get('generation_attempts', []):
            if not attempt.get('candidate_valid'):
                reasons.append(json.dumps({key: value for key, value in attempt.items()
                    if key in ('candidate_rejection', 'rejection', 'recovery', 'candidate_extracted', 'candidate_valid', 'response_complete', 'error_code', 'model_run')}, ensure_ascii=False))
    elif c.get('status') == 'VERIFIED':
        domain = 'NONE'
    elif not c:
        domain = 'NOT_RUN'
        reasons.append('Generation succeeded, but no comparison result exists.')
    else:
        status = str(c.get('terminal_reason', c.get('status')))
        domain = terminal_domain(status, failed_domains)
        reasons.append(status)
        if c.get('terminal_policy_rule'):
            reasons.append(json.dumps({'policy_rule': c['terminal_policy_rule'],
                'decisions': c.get('repair_decisions', [])}, ensure_ascii=False))
        for acceptance in c.get('acceptance_results', []):
            ap = Path(acceptance['path'])
            if ap.exists():
                a = load(ap)
                reasons.append(json.dumps({'netlist_status': a['status'], 'error': a.get('error'), 'path': str(ap)}, ensure_ascii=False))
        for name, stage in stages.items():
            if stage.get('status') in ('FAIL', 'INCONCLUSIVE'):
                reasons.append(json.dumps({'stage': name, 'failure_domain': stage.get('failure_domain'),
                    'errors': stage.get('errors'), 'diagnostics_omitted': stage.get('diagnostics_omitted'),
                    'diagnostic_excerpt_truncated': stage.get('diagnostic_excerpt_truncated'),
                    'raw_log_path': str(Path(final_run) / stage['raw_log_path']) if stage.get('raw_log_path') else None}, ensure_ascii=False))
    task_calls = [call for call in calls if call['arm'] == arm and qid in call['task'].split('|')]
    row = {'arm': arm, 'task': qid, 'generation': g.get('status', 'NOT_RUN'), 'initial_generation_reused': False,
           'new_generation_requests': 0, 'terminal': result_status,
           **initial_tier, **tier, 'full_netlist_accepted': c.get('status') == 'VERIFIED',
           'final_binding_reported': bool(c.get('final_verification_run')), 'stage_evidence_source': stage_evidence_source,
           'stage_evidence_run': str(final_run),
           'model_calls': len(task_calls), 'planner_calls': sum(call['provider'] == 'cloud-thinker' for call in task_calls),
           'coder_calls': sum(call['provider'] == 'cloud-coder' for call in task_calls),
           'native_submissions': 0,
           'initial_simulation_checks': initial_stages.get('simulation', {}).get('evidence', {}).get('checks_executed'),
           'initial_simulation_mismatches': initial_stages.get('simulation', {}).get('evidence', {}).get('mismatch_count'),
           'final_simulation_checks': stages.get('simulation', {}).get('evidence', {}).get('checks_executed'),
           'final_simulation_mismatches': stages.get('simulation', {}).get('evidence', {}).get('mismatch_count'),
           'tool_actions': len(c.get('actions', [])), 'valid_repair_attempts': repair_count,
           'repair_count_source': 'reported' if repair_count_reported is not None else 'repair_attempts[].valid',
           'last_stage_failure_domains': '|'.join(sorted(value for value in failed_domains if value)),
           'failure_domain': domain, 'reason': '; '.join(dict.fromkeys(reasons)),
           'generation_result': str(gp) if gp.exists() else '', 'comparison_result': str(cp) if cp.exists() else ''}
    rows.append(row)
    if domain != 'NONE':
        failures.append({'arm': arm, 'task': qid, 'domain': domain, 'reasons': list(dict.fromkeys(reasons)),
                         'generation_result': row['generation_result'], 'comparison_result': row['comparison_result'],
                         'initial_verification_result': str(Path(c['baseline_run']) / 'result.json') if c.get('baseline_run') else None,
                         'initial_design_failures': [{'stage': name, 'errors': stage.get('errors'),
                             'evidence': stage.get('evidence'), 'diagnostics_omitted': stage.get('diagnostics_omitted'),
                             'raw_log_path': str(Path(c['baseline_run']) / stage['raw_log_path']) if stage.get('raw_log_path') else None}
                             for name, stage in initial_stages.items() if stage.get('status') in ('FAIL', 'INCONCLUSIVE')],
                         'valid_repair_attempts': row['valid_repair_attempts'],
                         'verification_result': str(record_path) if record else None})
write_csv(OUT / 'tasks.csv', rows)
save(OUT / 'failure-reasons.json', failures)
save(OUT / 'log-audit.json', {'frozen_inputs_checked': len(freeze['files']), 'changed_frozen_inputs': changed_inputs,
     'task_results': sum(row['generation'] != 'NOT_RUN' for row in rows),
     'comparison_results': sum(bool(row['comparison_result']) for row in rows),
     'model_output_directories': len(model_outputs), 'http_inference_attempts': len(calls),
     'model_runs_without_dispatch': sum(row['request_sha256'] is None for row in model_outputs),
     'repair_count_reconstructed_tasks': [row['task'] for row in rows if row['repair_count_source'] != 'reported' and row['valid_repair_attempts'] > 0],
     'stage_binding_reconstruction': [{'arm': row['arm'], 'task': row['task'], 'source': row['stage_evidence_source']} for row in rows if not row['final_binding_reported']],
     'host_seed_source_hashes_rechecked': checked_initial_sources,
     'valid_repair_result_hashes_and_source_bindings_rechecked': checked_repair_receipts,
     'raw_model_record_states': dict(Counter(row['model_record_state'] for row in model_outputs)),
     'terminal_authority': 'task result.json and HTTP transport.json; raw model run.json is preserved, not rewritten',
     'all_request_hashes_match': True, 'unlinked_calls': sum(call['task'] == 'UNLINKED' for call in calls),
     'incomplete_streams': sum(not call['stream_complete'] for call in calls),
     'non_200_responses': sum(call['http_status'] != 200 for call in calls)})
save(OUT / 'summary.json', {'scope': 'REAL_DSH_HARNESS_AUTOMATIC_DUAL_MODEL_DEVELOPMENT_DIAGNOSTIC',
     'selected_tasks': len(ids), 'arm_runs': len(rows), 'host_authored_local_seeds': sum(r['generation'] == 'LOCAL_REPAIR_SEED' for r in rows), 'new_generation_requests': 0,
     'initial_all_four_rtl_stages_pass': sum(all(r['initial_' + s] == 'PASS' for s in ('compile', 'elaborate', 'simulation', 'synthesis')) for r in rows),
     'all_four_rtl_stages_pass': sum(all(r[s] == 'PASS' for s in ('compile', 'elaborate', 'simulation', 'synthesis')) for r in rows),
     'repaired_to_four_stage_pass': sum(r['valid_repair_attempts'] > 0 and all(r[s] == 'PASS' for s in ('compile', 'elaborate', 'simulation', 'synthesis')) for r in rows),
     'full_netlist_accepted': sum(r['full_netlist_accepted'] for r in rows),
     'terminal_counts': dict(Counter(r['terminal'] for r in rows)),
     'failure_domain_counts': dict(Counter(r['failure_domain'] for r in rows)),
     'http_model_attempts': len(calls), 'calls_by_provider': dict(Counter(r['provider'] for r in calls)),
     'calls_unlinked': sum(r['task'] == 'UNLINKED' for r in calls), 'reported_usage': dict(tokens), 'calls_without_usage': unknown_usage,
     'native_submissions': sum(r['native_submissions'] for r in rows),
     'tool_actions': sum(r['tool_actions'] for r in rows), 'valid_repair_attempts': sum(r['valid_repair_attempts'] for r in rows),
     'calibration_controls': 24, 'actual_tool_version': '2026.1', 'official_competition_score': None,
     'formal_p10_campaign': False, 'new_200_question_bank_tested': False, 'original_baseline_run': False,
     'full_os_isolation_verified': False})
print(json.dumps({'tasks': len(rows), 'calls': len(calls), 'terminals': dict(Counter(r['terminal'] for r in rows))}))

"""Index saved native token-counter calls and rejected tools separately from inference."""
import csv
import hashlib
import json
from pathlib import Path

OUT = Path('D:/AMD/output/rtl-rule-transfer-probes-20261018')


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(name, rows):
    with (OUT / (name + '.json')).open('x', encoding='utf-8') as stream:
        json.dump(rows, stream, ensure_ascii=False, indent=2)
    if rows:
        with (OUT / (name + '.csv')).open('x', encoding='utf-8-sig', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


counters = []
for model in load(OUT / 'model-output-index.json'):
    directory = Path(model['directory'])
    for counter in sorted(directory.glob('token-*'), key=lambda p: int(p.name.split('-')[-1])):
        request_file, response_file = counter / 'input.json', counter / 'output.json'
        request, response = load(request_file), load(response_file)
        counters.append({'arm': model['arm'], 'task': model['task'], 'phase': model['phase'], 'model': request['model'],
            'kind': 'native_input_tokens_counter_not_inference', 'input_tokens': response['input_tokens'],
            'associated_inference_request_sha256': model['request_sha256'],
            'input_file_sha256': hashlib.sha256(request_file.read_bytes()).hexdigest(),
            'output_file_sha256': hashlib.sha256(response_file.read_bytes()).hexdigest(),
            'input_file': str(request_file), 'output_file': str(response_file),
            'identity_file': str(counter / 'identity.json')})
rejections = []
for arm, task in [(arm, task) for task in load(OUT / 'campaign/manifest.json')['task_ids'] for arm in ('on', 'off')]:
    path = OUT / 'campaign/arms' / arm / ('compare-' + task) / 'result.json'
    for number, action in enumerate(load(path)['actions'], 1):
        if action['accepted']:
            continue
        rejections.append({'arm': arm, 'task': task, 'action': number, 'tool': action['tool'],
            'error': action['observation'].get('error'), 'detail': action['observation'].get('detail'),
            'terminal_reason': action['observation'].get('terminal_reason'),
            'model_run': action['model_run'], 'action_file': str(path.parent / f'action-{number}.json'),
            'task_result': str(path)})
save('token-counter-index', counters)
save('tool-rejections', rejections)
print(json.dumps({'native_token_counter_records': len(counters), 'rejected_tool_actions': len(rejections)}))

import assert from 'node:assert/strict'
import { readFile, writeFile, mkdir, readdir, cp, copyFile, open, appendFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'
import { spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import { heldoutFixtures } from './heldout-fixtures.mjs'
import { buildModelProfile, roles, validateBudgets } from './p10-profile.mjs'

const here = dirname(fileURLToPath(import.meta.url)).replaceAll('\\','/'), root = here.replace('/workspaces/', '/output/'), campaign = root + '/campaign'
const repo = 'D:/AMD/workspaces/http-paired-20261016/harness', rtl = here + '/rtl-tools', prior = 'D:/AMD/p156-20260927-v3'
const yaml = createRequire(repo + '/package.json')('js-yaml'), stage = process.argv[2]
const hash = bytes => createHash('sha256').update(bytes).digest('hex'), unix = value => value.replaceAll('\\','/')
const json = async path => JSON.parse(await readFile(path, 'utf8'))
const put = async (path, value) => writeFile(path, JSON.stringify(value, null, 2), { flag:'wx' })
const filesIn = async directory => {
  const paths=[]
  for (const entry of await readdir(directory,{withFileTypes:true})) {
    const p=join(directory,entry.name)
    if(entry.isDirectory()) paths.push(...await filesIn(p)); else if(entry.isFile()) paths.push(p)
  }
  return paths
}
const sourceFiles = async () => [...await filesIn(rtl+'/src'), ...await filesIn(rtl+'/phase1/p10'),
  ...await filesIn(here+'/skills'), ...await filesIn(here+'/skill-registry'), ...await filesIn(here+'/knowledge'),
  ...['heldout-experiment.mjs','heldout-fixtures.mjs','heldout-preflight.ts','test-heldout.mjs','vitest.config.ts','rtl-tools/tests/p10-model.spec.ts',
    'main_run.py','p10-profile.mjs','validate-profile.mjs','budgets.json','campaign-budget.json','README.md','AGENT_NOTE.md'].map(n=>here+'/'+n),
  'D:/AMD/cloud-dual-llama/models.json', repo+'/tsconfig.base.json',
  ...['serialize.ts','sse.ts','translate.ts'].map(n=>repo+'/packages/llm/llm-deepseek/src/'+n)]
const freeze = async (name, files, protocol) => put(campaign+'/'+name, { files:Object.fromEntries(await Promise.all([...new Set(files)].map(async p=>[p,hash(await readFile(p))]))), protocol })
const common = workspace => [{id:'subprocess',name:repo+'/packages/subprocess/subprocess-local/src/index.ts'},
  {id:'projections',name:repo+'/packages/session/session-projection/src/index.ts'},
  {id:'policy',name:repo+'/packages/sandbox/sandbox-policy/src/index.ts',config:{mode:'danger-full-access',workspaceRoot:unix(workspace)}}]
const profile = async (name,rows) => {
  const home=campaign+'/dsh-home/profiles/'+name; await mkdir(home,{recursive:true})
  await put(home+'/package.json',{name,private:true,dependencies:{},dsh:{profile:{bundles:[],patchReload:'startup'}}})
  await put(home+'/cordis.yml',[]); await put(home+'/cordis.patch.yml',[{insert:rows}])
}
async function invoke(profileName, command, task, arm) {
  await mkdir(campaign+'/runner-logs',{recursive:true})
  const logPath=campaign+`/runner-logs/${profileName}-${command}-${task??'controls'}-${Date.now()}.log`, log=await open(logPath,'wx')
  let code
  try {
    const child=spawn(process.execPath,['--import','tsx/esm','apps/cli/src/bin.ts','--profile',profileName,command,...(task?[task]:[])],
      {cwd:repo,env:{...Object.fromEntries(Object.entries(process.env).filter(([k])=>!/KEY|SECRET|TOKEN|PASSWORD|PROXY/i.test(k))),
        XILINXD_LICENSE_FILE:'D:/AMDDesignTools/Xilinx.lic',DSH_HOME:campaign+'/dsh-home',NODE_OPTIONS:'--max-old-space-size=4096'},
        windowsHide:true,stdio:['ignore',log.fd,log.fd]})
    code=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',resolve)})
  } finally { await log.close() }
  console.log(JSON.stringify({profileName,command,task,code,logPath}))
  if(code!==0) throw new Error('DSH_HOST_FAILED')
  return task?json(campaign+`/arms/${arm}/${command}-${task}/result.json`):null
}
if(stage==='prepare') {
  await mkdir(campaign)
  const preflight=campaign+'/preflight', derived=preflight+'/derived'; await mkdir(derived,{recursive:true})
  const catalog=[], manifest={protocol:'local-rule-transfer-probes-v1',tasks:{}}, taskIds=heldoutFixtures.map(f=>f.id)
  assert.equal(heldoutFixtures.length,8); assert.equal(new Set(taskIds).size,8)
  const previousSkill='D:/AMD/workspaces/rtl-rule-explanations-offline-20261018'
  const oldEntries=await json(previousSkill+'/skill-registry/skills.validated.json'), newEntries=await json(here+'/skill-registry/skills.validated.json')
  assert.deepEqual(newEntries,oldEntries)
  const oldBundle=await json(here+'/skill-registry/bundle.json')
  oldBundle.settings={skillsFile:here+'/skill-registry/skills.validated.json',skillsSha256:hash(await readFile(here+'/skill-registry/skills.validated.json'))}
  await writeFile(here+'/skill-registry/bundle.json',JSON.stringify(oldBundle,null,2))
  const skillText=await readFile(previousSkill+'/skills/rtl-diagnostic-reasoning/SKILL.md','utf8')
  const oldControls=await import(new URL('../rtl-diagnostic-guards-20261018/capability-fixtures.ts',import.meta.url).href)
  const novelty=[]
  for(const fixture of heldoutFixtures) {
    assert.equal(skillText.includes(fixture.id),false)
    assert.ok(!oldControls.capabilityFixtures.some(f=>f.source===fixture.seed||f.spec===fixture.spec))
    const directory=derived+'/'+fixture.id; await mkdir(directory)
    const clock=fixture.interface.ports.some(p=>p.name==='clk')?{kind:'physical',port:'clk',period_ns:5}:{kind:'virtual',port:null,period_ns:5}
    const assets={}
    for(const [name,text] of Object.entries({'positive.sv':fixture.positive,'seed.sv':fixture.seed,'tb.sv':fixture.tb,
      'clock.xdc':clock.port?'create_clock -name probe_clock -period 5.000 [get_ports {clk}]\n':'create_clock -name probe_virtual -period 5.000\n'})) {
      await writeFile(directory+'/'+name,text,{flag:'wx'}); assets[fixture.id+'/'+name]=hash(text)
    }
    catalog.push({task_id:fixture.id,spec:fixture.spec,assets,interface:fixture.interface,interface_error:null,clock})
    manifest.tasks[fixture.id]={files:assets,spec_sha256:hash(fixture.spec),interface_sha256:hash(JSON.stringify(fixture.interface)),checks:fixture.checks}
    novelty.push({task:fixture.id,family:fixture.family,rules:fixture.rules,seed_sha256:hash(fixture.seed),spec_sha256:hash(fixture.spec),in_current_skill:false,matched_prior_controls:false})
    for(const arm of ['on','off']) {
      const generated=campaign+`/arms/${arm}/generate-${fixture.id}`; await mkdir(generated,{recursive:true})
      await writeFile(generated+'/initial.sv',fixture.seed,{flag:'wx'})
      await put(generated+'/result.json',{status:'LOCAL_REPAIR_SEED',origin:'host-authored-heldout-probe',source_sha256:hash(fixture.seed),initial_provider_dispatches:0,new_generation_requests:0})
    }
  }
  await put(derived+'/local-rule-probes.json',manifest)
  await put(preflight+'/catalog.json',catalog); await put(preflight+'/selection-order.json',taskIds)
  await put(preflight+'/evaluator-policy.json',{defaultTimescale:'1ps/1ps',official:false,source:'frozen-local-oracle',localProbeProtocol:'local-rule-transfer-probes-v1'})
  await put(campaign+'/manifest.json',{task_ids:taskIds,execution_order:taskIds.flatMap((task,i)=>(i%2?['off','on']:['on','off']).map(arm=>({task,arm}))),
    novelty,novelty_limit:'New local probes after skill freeze, compared to prior capability controls; not proof of absence from model pretraining.',official_score:null})
  const budgets=validateBudgets(await json(here+'/budgets.json')); await put(campaign+'/p10-budgets.json',budgets)
  const eda=yaml.load(await readFile(prior+'/eda-settings.yaml','utf8')); eda.repositoryRoot=repo; eda.expectedVivadoVersion='2026.1'; eda.outputRoot=campaign+'/eda'
  for(const n of ['vivado','xvlog','xelab','xsim']) eda.tools[n]=`D:/AMDDesignTools/2026.1/Vivado/bin/${n}.bat`
  await writeFile(campaign+'/eda-settings.yaml',yaml.dump(eda),{flag:'wx'})
  await profile('rtl-heldout-preflight',[...common(preflight),{id:'heldout-preflight',name:here+'/heldout-preflight.ts',config:{root:unix(campaign)}}])
  await freeze('preflight-freeze.json',[...await sourceFiles(),...await filesIn(preflight),campaign+'/manifest.json',campaign+'/p10-budgets.json',campaign+'/eda-settings.yaml'],
    {scope:'heldout-preflight-no-models',tasks:taskIds,model_calls:0})
  console.log(JSON.stringify({stage,tasks:taskIds.length,seed_origin:'host-authored-not-Baseline'}))
} else if(stage==='preflight') {
  await invoke('rtl-heldout-preflight','preflight')
} else if(stage==='configure') {
  const controls=await json(campaign+'/preflight/results.json'); assert.equal(controls.status,'PASS'); assert.equal(controls.controls,24)
  const identity={}, modelManifest=await json('D:/AMD/cloud-dual-llama/models.json'), budgets=await json(campaign+'/p10-budgets.json')
  await mkdir(campaign+'/services')
  for(const {role,baseURL,model:alias} of roles) {
    const props=await(await fetch(baseURL.replace(/\/v1$/,'')+'/props',{redirect:'error',signal:AbortSignal.timeout(10000)})).json()
    const models=await(await fetch(baseURL+'/models',{redirect:'error',signal:AbortSignal.timeout(10000)})).json()
    assert.ok(models.data.some(m=>m.id===alias)); assert.equal(props.default_generation_settings.n_ctx,8192); assert.equal(props.total_slots,1)
    const priorProps=await json('D:/AMD/output/rtl-diagnostic-guards-20261018/campaign/services/'+role+'-props.json')
    assert.equal(props.chat_template,priorProps.chat_template); assert.deepEqual(props.build_info,priorProps.build_info); assert.equal(props.model_path,priorProps.model_path)
    await put(campaign+'/services/'+role+'-props.json',props); await put(campaign+'/services/'+role+'-models.json',models)
    identity[role]={implementation:'llama-native-chat-input-tokens',alias,props_sha256:hash(JSON.stringify(props)),template_sha256:hash(props.chat_template),
      model_manifest_sha256:hash(JSON.stringify(modelManifest)),context_window:'8192',build_info:props.build_info,model_path:props.model_path}
  }
  await put(campaign+'/cloud-identity.json',identity)
  const campaignBudget=await json(here+'/campaign-budget.json')
  assert.equal(campaignBudget.max_dispatches_per_arm,100); assert.equal(campaignBudget.duration_ms,3600000)
  const deadline=new Date(Date.now()+campaignBudget.duration_ms).toISOString(), remaining=100, skillBundle=await json(here+'/skill-registry/bundle.json')
  for(const arm of ['on','off']) {
    const armRoot=campaign+'/arms/'+arm, auto=await json(prior+'/auto.json')
    Object.assign(auto,{campaignRoot:armRoot,maxDispatches:100,campaignDispatchLimit:100,maxToolSteps:12,editMode:'exact'}); await put(armRoot+'/auto.json',auto)
    const {config,p09,llama}=buildModelProfile({root:armRoot,budgets,identity,deadline,remaining,
      config:yaml.load(await readFile(prior+'/model.patch.yml','utf8')).find(r=>r.id==='p10-model').config,p09:await json(prior+'/p09.json')})
    Object.assign(p09,skillBundle.settings,{variant:arm==='on'?'C':'B'})
    Object.assign(config,{selectedTaskCount:8,datasetRoot:campaign+'/preflight/derived',preflightRoot:campaign+'/preflight',
      settingsFile:campaign+'/eda-settings.yaml',freezeFile:campaign+'/campaign-freeze.json',generationMode:'native-tool',maxRepairRounds:2,maxAgentRequests:8,
      activeMs:240000,timeoutMs:60000,maxTransportRetries:0,transportBackoffMs:[],maxGenerationResumes:0})
    config.cloud.maxPlans=4; config.cloud.identityFile=campaign+'/cloud-identity.json'; llama.evidenceRoot=campaign+'/http'
    await put(armRoot+'/p09.json',p09)
    await profile('rtl-p10-model-'+arm,[...common(armRoot),{id:'llm',name:repo+'/packages/llm/llm/src/index.ts'},
      {id:'llama',name:rtl+'/src/phase1/p10-llama.ts',config:llama},{id:'p10-model',name:rtl+'/src/phase1/p10-model.ts',config}])
  }
  const {validateProfileFiles}=await import('./validate-profile.mjs'); await put(campaign+'/profile-validation.json',await validateProfileFiles(campaign))
  await freeze('campaign-freeze.json',[...await sourceFiles(),...(await filesIn(campaign+'/dsh-home')).filter(p=>!p.endsWith('cordis.yml')),...await filesIn(campaign+'/preflight/derived'),
    ...await filesIn(campaign+'/services'),...['manifest.json','p10-budgets.json','eda-settings.yaml','cloud-identity.json','profile-validation.json'].map(n=>campaign+'/'+n),
    ...['catalog.json','selection-order.json','evaluator-policy.json','results.json','compat-positive-negative-results.json'].map(n=>campaign+'/preflight/'+n),
    ...await Promise.all(['on','off'].flatMap(arm=>['auto.json','p09.json',...heldoutFixtures.flatMap(f=>['initial.sv','result.json'].map(n=>`generate-${f.id}/${n}`))].map(n=>campaign+`/arms/${arm}/${n}`)))],
    {scope:'heldout-skill-transfer-not-official',deadline,arm_dispatch_limit:100,max_dispatches_total:200,models:identity,budgets,
      max_repairs:2,max_coder_requests:8,max_plans:4,active_ms:240000,skill_soft_tokens:768,planner_recovery_shared:1,
      new_generation_requests:0,seed_origin:'host-authored-heldout-probe',skill_entry_version:'2.0.0',skill_weights_unchanged:true,off_is_naked_baseline:false,
      forced_rejections:false,knowledge_integration:'frozen graph/catalog compiled into unchanged normally selected skill',netlist_profile:'unavailable-for-local-probes-not-official',official_score:null})
  console.log(JSON.stringify({stage,deadline,per_arm_dispatch_limit:100}))
} else if(stage==='validate') {
  const {validateProfileFiles}=await import('./validate-profile.mjs'); console.log(JSON.stringify(await validateProfileFiles(campaign)))
} else if(stage==='diagnostic') {
  const freezeData=await json(campaign+'/campaign-freeze.json'), manifest=await json(campaign+'/manifest.json')
  for(const [path,digest] of Object.entries(freezeData.files)) assert.equal(hash(await readFile(path)),digest)
  for(const {task,arm} of manifest.execution_order) {
    const result=await invoke('rtl-p10-model-'+arm,'compare',task,arm)
    await appendFile(campaign+'/progress.jsonl',JSON.stringify({task,arm,status:result.status,at:new Date().toISOString()})+'\n')
    if(/CAMPAIGN_|TOKENIZER|IDENTITY|TRANSPORT|INFRA_PAUSED|HOST_FAILURE/.test(result.status)) break
  }
  await put(campaign+'/ended.json',{at:new Date().toISOString(),planned_arm_runs:16,official_score:null})
} else throw new Error('Use prepare|preflight|configure|validate|diagnostic')

# Held-Out Rule Transfer Probes

This independent experiment uses eight newly authored public-spec repair probes, not the previous seven tasks. The user authorized the same existing cloud 30B planner and 8B coder. Skill/graph/catalog and all seven registry entries are byte-identical to offline v2. No answers are supplied by the Host after dispatch; no handoff or original project changes.

Freeze the public specs, faulty seeds, private evaluator positives/TBs, skills and protocol before model calls. A model-free preflight checks each positive, inverted-output negative and faulty seed (24 controls). Private positives and TBs never enter model requests. New means unseen in this local skill/probe history, not absent from model pretraining.

Both arms use the same full Harness, guards, public seed, EDA and models; only C/B differs. This is skill ablation, not naked Baseline. Graph explanations reach the Agent as normally selected compiled skill text; no dynamic graph server. The original 768-token skill budget and multiline format restriction remain unchanged.

Per question: two accepted edits, eight coder requests, four plan bindings, 240 seconds active time, 8192 contexts, margin 1024, planner output 1024 and coder output 2048. Format/constraint failures share the original single planner recovery. A NEW independent campaign has the same 100 dispatches per arm and 60-minute deadline, not an extension of a prior run. ON/OFF order alternates by probe. No forced rejection, synthetic error feedback, mid-run tuning or best-of rerun.

Run from this independent directory, through the existing dsh-profile launcher:

```powershell
node --import tsx/esm ./heldout-experiment.mjs prepare
python ./main_run.py preflight
python ./main_run.py models
```

The launcher owns a temporary SSH tunnel and restores SSH policy after joining all stages. It sends only these public probe specs, generated candidates, diagnostics and general skills to the user-designated instance. Keys and unrelated original files are never payloads. Outputs are in `D:/AMD/output/rtl-rule-transfer-probes-20261018`.

Only the asset loader and host-seed accounting support are added to runtime; guards, planning and repair policy stay unchanged. Local probes have no calibrated post-synthesis netlist profiles, so RTL four-stage results are not full acceptance or official competition scores. Report rejected/recovered actions, valid edits, EDA progress, regressions and no-op plans separately. Do not count mock tests as real repairs, or fewer calls due to gating as understanding. Inherited legacy campaign/analysis scripts still refer to prior experiments; do not run them.

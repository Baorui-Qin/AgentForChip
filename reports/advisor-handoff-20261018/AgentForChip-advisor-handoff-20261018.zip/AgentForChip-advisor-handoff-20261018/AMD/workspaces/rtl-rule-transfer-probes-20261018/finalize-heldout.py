"""Read-only process/port checks; preserve both setup attempts and original deadline."""
import json
from pathlib import Path
import socket
from datetime import datetime, timezone

OUT = Path('D:/AMD/output/rtl-rule-transfer-probes-20261018')
ROOT = OUT / 'campaign'
def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

stages = {name: load(OUT / (name + '-driver-process.json')) for name in ('preflight', 'configure', 'configure-complete', 'validate', 'diagnostic')}
for name, row in stages.items():
    assert row['reaped'] and not row['watchdog_timeout']
    assert row['exit_code'] == (1 if name == 'configure' else 0)
cleanups = {name: load(OUT / name) for name in ('cleanup.json', 'cleanup-resume.json')}
assert all(row['ssh_original_hash_matches'] and row['tunnel']['reaped'] for row in cleanups.values())
ports = []
for port in (18080, 18081):
    with socket.socket() as connection:
        connection.settimeout(5)
        code = connection.connect_ex(('127.0.0.1', port))
        assert code == 10061, (port, code)
        ports.append({'port': port, 'socket_code': code, 'connection_refused': True})
freeze = load(ROOT / 'campaign-freeze.json')
profiles = {}
for arm in ('on', 'off'):
    rows = load(ROOT / 'dsh-home/profiles' / ('rtl-p10-model-' + arm) / 'cordis.patch.yml')[0]['insert']
    profiles[arm] = next(row for row in rows if row['id'] == 'llama')['config']['deadline']
assert profiles['on'] == profiles['off'] == freeze['protocol']['configuration_recovery']['deadline_preserved'] == freeze['protocol']['deadline']
assert not freeze['protocol']['configuration_recovery']['budgets_reset']
for task in load(ROOT / 'manifest.json')['task_ids']:
    for arm in ('on', 'off'):
        assert (ROOT / 'arms' / arm / ('compare-' + task) / 'result.json').is_file()
value = {'status': 'POST_RUN_CHECKS_PASS', 'checked_at_utc': datetime.now(timezone.utc).isoformat(), 'stages': stages,
    'cleanup_receipts': cleanups, 'loopback_ports': ports, 'ssh_original_hash_matches': True,
    'initial_configure_failure_preserved': True, 'original_deadline_preserved': profiles['on'], 'budgets_reset': False,
    'task_results_present': 16, 'models_tested': True}
with (OUT / 'post-run-checks.json').open('x', encoding='utf-8') as stream:
    json.dump(value, stream, ensure_ascii=False, indent=2)
print(json.dumps({'status': value['status'], 'ports_closed': True, 'task_results': 16, 'budget_reset': False}))

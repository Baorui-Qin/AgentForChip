import { readFile, mkdir } from 'node:fs/promises'
import { join } from 'node:path'
import { randomUUID } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import { readDoctorConfig } from './rtl-tools/src/phase1/doctor.ts'
import { VerificationRunner } from './rtl-tools/src/phase1/verification.ts'
import { loadLocalProbeAssets } from './rtl-tools/src/phase1/p10-local-probes.ts'
import { publish } from './rtl-tools/src/phase1/candidates.ts'
import { sha256 } from './rtl-tools/src/phase1/snapshots.ts'
import type { P10Task } from './rtl-tools/src/phase1/p10-dataset.ts'
import type { PhaseId } from './rtl-tools/src/phase1/contracts.ts'

export const name = 'heldout-local-preflight'
export const inject = ['cmdlineArgs', 'appReady', 'subprocess', 'sandboxPolicy']
export function apply(ctx: Context, config: { root: string }): void {
  if (ctx.get('llm') || ctx.cmdlineArgs!.get().join(' ') !== 'preflight') throw new Error('MODEL_FREE_PREFLIGHT_REQUIRED')
  const controller = new AbortController(); let pending: Promise<void> | undefined
  ctx.effect(() => async () => { controller.abort(); await pending })
  ctx.effect(() => ctx.get('appReady')!.onReady(() => {
    pending = run(ctx, config.root, controller.signal).then(() => ctx.get('appExit')!(0)).catch(error => {
      process.stderr.write(String(error) + '\n'); ctx.get('appExit')!(1)
    })
  }))
}
async function run(ctx: Context, root: string, signal: AbortSignal) {
  if (ctx.sandboxPolicy.resolve({}).mode !== 'danger-full-access') throw new Error('EXPLICIT_PREFLIGHT_AUTHORITY_REQUIRED')
  const freeze = JSON.parse(await readFile(join(root, 'preflight-freeze.json'), 'utf8'))
  const check = async () => { for (const [path, digest] of Object.entries(freeze.files)) if (sha256(await readFile(path)) !== digest) throw new Error('PREFLIGHT_FREEZE_CHANGED') }
  await check()
  const preflight = join(root, 'preflight'), tasks: P10Task[] = JSON.parse(await readFile(join(preflight, 'catalog.json'), 'utf8'))
  const settings = (await readDoctorConfig(join(root, 'eda-settings.yaml'))).config
  await mkdir(join(preflight, 'eda'))
  const limits = { compileMs: 60000, elaborateMs: 60000, simulationMs: 120000, totalMs: 900000,
    maxArtifactBytes: 268435456, artifactPollMs: 100, maxEventBytes: 1048576 }
  const runner = new VerificationRunner(ctx.subprocess, { ...settings, outputRoot: join(preflight, 'eda') }, limits)
  const results = [], experiment = randomUUID() as PhaseId
  try {
    for (const task of tasks) {
      const controls = []
      for (const kind of ['positive', 'negative', 'seed'] as const) {
        await check()
        const { assets, evaluation } = await loadLocalProbeAssets(join(preflight, 'derived'), task)
        if (kind === 'seed') assets['rtl/solution.sv'] = await readFile(join(preflight, 'derived', task.task_id, 'seed.sv'), 'utf8')
        if (kind === 'negative') {
          const ports = task.interface!.ports, outputs = ports.filter(p => p.direction === 'output')
          assets['rtl/solution.sv'] = assets['rtl/solution.sv']!.replace(/\bTopModule\b/g, 'CalibrationReference') +
            `\nmodule TopModule(${ports.map(p => `${p.direction} wire ${p.width === 1 ? '' : `[${p.width-1}:0] `}${p.name}`).join(',')});\n` +
            outputs.map(p => `wire [${p.width-1}:0] inner_${p.name};`).join('\n') +
            '\nCalibrationReference reference(' + ports.map(p => `.${p.name}(${p.direction === 'output' ? 'inner_' : ''}${p.name})`).join(',') + ');\n' +
            outputs.map(p => `assign ${p.name}=~inner_${p.name};`).join('\n') + '\nendmodule\n'
        }
        const id = await runner.registerDataset(assets, evaluation, { experiment_id: experiment, task_id: task.task_id as PhaseId, sample_id: controls.length, mode: 'agent' })
        const result = await runner.preflightDataset(id, signal, argv => argv)
        const sim = result.stages.find(s => s.stage === 'simulation')!
        const row = { task_id: task.task_id, kind, status: result.status, run: result.artifacts, stages: result.stages, evidence: sim.evidence }
        await publish(preflight, `${task.task_id}-${kind}.json`, JSON.stringify(row, null, 2))
        controls.push(row); process.stdout.write(`${task.task_id} ${kind}: ${result.status}\n`)
      }
      const positive = controls[0]!, negative = controls[1]!, seed = controls[2]!
      const expected = evaluationChecks(task.task_id, JSON.parse(await readFile(join(preflight, 'derived/local-rule-probes.json'), 'utf8')))
      const evaluable = positive.status === 'EVALUATOR_READY' && positive.evidence.checks_executed === expected &&
        negative.stages.find(s => s.stage === 'simulation')?.status === 'FAIL' && (negative.evidence.mismatch_count ?? 0) > 0 &&
        seed.status === 'FAIL' && seed.stages.some(s => s.status === 'FAIL' && s.failure_domain !== 'environment')
      results.push({ task_id: task.task_id, positive, negative, seed, evaluable })
      if (!evaluable) throw new Error('LOCAL_PROBE_CONTROL_FAILED:' + task.task_id)
    }
    await check()
    await publish(preflight, 'compat-positive-negative-results.json', JSON.stringify(results, null, 2))
    await publish(preflight, 'results.json', JSON.stringify({ status: 'PASS', model_calls: 0, controls: results.length * 3, results }, null, 2))
  } finally { await runner.close() }
}
function evaluationChecks(id: string, manifest: { tasks: Record<string, { checks: number }> }) { return manifest.tasks[id]!.checks }

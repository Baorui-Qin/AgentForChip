import assert from 'node:assert/strict'
import { readFile, writeFile, access } from 'node:fs/promises'
import { hash } from './selection.mjs'
import { heldoutFixtures } from './heldout-fixtures.mjs'

const out='D:/AMD/output/rtl-rule-transfer-probes-20261018', root=out+'/campaign'
const here='D:/AMD/workspaces/rtl-rule-transfer-probes-20261018'
const json=async path=>JSON.parse(await readFile(path,'utf8'))
const freeze=await json(root+'/preflight-freeze.json')
for(const [path,digest] of Object.entries(freeze.files)) assert.equal(hash(await readFile(path)),digest,path)
const preflight=await json(root+'/preflight/results.json')
assert.equal(preflight.status,'PASS'); assert.equal(preflight.controls,24)
assert.ok(preflight.results.every(r=>r.evaluable))
assert.match(await readFile(out+'/harness-tests-pass.log','utf8'),/Tests\s+92 passed/)
assert.match(await readFile(out+'/guard-tests.log','utf8'),/pass 19\b/)
assert.match(await readFile(out+'/heldout-tests.log','utf8'),/pass 4\b/)
const current=await readFile(out+'/typecheck.log','utf8'), old=await readFile('D:/AMD/output/rtl-diagnostic-guards-20261018/typecheck-final.log','utf8')
assert.equal(current.replaceAll('../http-paired-20261016/harness/',''),old)
const graphPath='knowledge/constraint-graph.json', catalogPath='skills/rtl-diagnostic-reasoning/references/rules.json'
for(const name of [graphPath,catalogPath,'skills/rtl-diagnostic-reasoning/SKILL.md','skill-registry/skills.validated.json'])
  assert.deepEqual(await readFile(here+'/'+name),await readFile('D:/AMD/workspaces/rtl-rule-explanations-offline-20261018/'+name))
for(const f of heldoutFixtures) for(const arm of ['on','off']) assert.equal(hash(await readFile(root+`/arms/${arm}/generate-${f.id}/initial.sv`)),hash(f.seed))
const anyDispatch=await access(root+'/cloud-identity.json').then(()=>true,()=>false)
const value={status:'LOCAL_PREFLIGHT_READY_EXTERNAL_TRANSFER_AWAITING_AUTHORIZATION',preflight_controls:24,preflight_driver:await json(out+'/preflight-driver-process.json'),
  focused_tests_passed:115,full_typecheck_passed:false,existing_dependency_diagnostics:70,added_type_diagnostics:0,
  source_freeze_files_checked:Object.keys(freeze.files).length,skill_v2_and_graph_unchanged:true,identical_arm_seeds:8,
  question_model_calls_observed:0,cloud_configure_started:anyDispatch,source_files_sent_by_model_driver:false,
  private_oracles_in_planned_payload:false,authorization_block:'Auto-review requires explicit consent for this new eight-probe payload to 36.150.116.206:35053.',
  distinction:'No real-model results or recovery claims yet. Echo-only SSH connectivity check completed; the model driver was rejected before process creation.'}
assert.equal(anyDispatch,false)
await writeFile(out+'/local-readiness.json',JSON.stringify(value,null,2),{flag:'wx'})
console.log(JSON.stringify(value))

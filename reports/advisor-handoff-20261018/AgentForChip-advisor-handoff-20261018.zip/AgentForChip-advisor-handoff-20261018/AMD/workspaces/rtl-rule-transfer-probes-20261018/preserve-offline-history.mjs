import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { inventory } from './selection.mjs'

const out = 'D:/AMD/output/rtl-rule-transfer-probes-20261018'
const roots = ['D:/AMD/workspaces/rtl-diagnostic-guards-20261018', 'D:/AMD/output/rtl-diagnostic-guards-20261018',
  'D:/AMD/workspaces/rtl-rule-explanations-offline-20261018', 'D:/AMD/output/rtl-rule-explanations-offline-20261018']
const current = {}
for (const root of roots) Object.assign(current, await inventory(root))
if (process.argv[2] === 'before') {
  await writeFile(out + '/history-before.json', JSON.stringify(current), { flag: 'wx' })
  console.log(JSON.stringify({ roots, files: Object.keys(current).length }))
} else {
  assert.deepEqual(current, JSON.parse(await readFile(out + '/history-before.json', 'utf8')))
  await writeFile(out + '/history-preservation.json', JSON.stringify({ status: 'PASS', roots, files_checked: Object.keys(current).length, unchanged: true }, null, 2), { flag: 'wx' })
  console.log(JSON.stringify({ status: 'PASS', files: Object.keys(current).length }))
}

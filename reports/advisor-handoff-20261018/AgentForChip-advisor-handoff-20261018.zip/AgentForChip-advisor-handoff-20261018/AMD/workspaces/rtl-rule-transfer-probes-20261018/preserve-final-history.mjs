import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { inventory } from './selection.mjs'
const out='D:/AMD/output/rtl-rule-transfer-probes-20261018'
const roots=['D:/AMD/workspaces/rtl-diagnostic-guards-20261018','D:/AMD/output/rtl-diagnostic-guards-20261018',
  'D:/AMD/workspaces/rtl-rule-explanations-offline-20261018','D:/AMD/output/rtl-rule-explanations-offline-20261018']
const current={}
for(const root of roots)Object.assign(current,await inventory(root))
assert.deepEqual(current,JSON.parse(await readFile(out+'/history-before.json','utf8')))
const value={status:'PASS',roots,files_checked:Object.keys(current).length,unchanged:true,scope:'after actual model run, not just local preflight'}
await writeFile(out+'/history-preservation-final.json',JSON.stringify(value,null,2),{flag:'wx'})
console.log(JSON.stringify(value))

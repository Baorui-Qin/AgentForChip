import assert from 'node:assert/strict'
import test from 'node:test'
import { readFile, mkdir, mkdtemp, writeFile } from 'node:fs/promises'
import { heldoutFixtures } from './heldout-fixtures.mjs'
import { loadLocalProbeAssets } from './rtl-tools/src/phase1/p10-local-probes.ts'
import { hash } from './selection.mjs'
import { checkAutoSource } from './rtl-tools/src/phase1/p09-auto-policy.ts'
import { enumConstraints } from './rtl-tools/src/phase1/p10-repair-guards.ts'

const out='D:/AMD/output/rtl-rule-transfer-probes-20261018', here='D:/AMD/workspaces/rtl-rule-transfer-probes-20261018'
test('eight new public specs/seeds and independent Host testbenches are unique',()=>{
  assert.equal(heldoutFixtures.length,8)
  assert.equal(new Set(heldoutFixtures.map(f=>hash(f.seed))).size,8)
  for(const f of heldoutFixtures) {
    assert.notEqual(f.seed,f.positive); checkAutoSource(f.seed,f.interface); checkAutoSource(f.positive,f.interface)
    assert.match(f.tb,/Mismatches: %0d in %0d samples/)
    assert.doesNotMatch(f.spec,/reference|positive\.sv|seed\.sv|tb\.sv/)
  }
})
test('the skill, graph, catalog and seven registry entries are unchanged from offline v2',async()=>{
  const prior='D:/AMD/workspaces/rtl-rule-explanations-offline-20261018'
  for(const name of ['skills/rtl-diagnostic-reasoning/SKILL.md','skills/rtl-diagnostic-reasoning/references/rules.json','knowledge/constraint-graph.json','skill-registry/skills.validated.json'])
    assert.deepEqual(await readFile(here+'/'+name),await readFile(prior+'/'+name))
})
test('known enum capacity/duplicate defects differ from the legal-capacity boundary',()=>{
  assert.ok(enumConstraints(heldoutFixtures[0].seed).issues.some(i=>i.code==='ENUM_CAPACITY'))
  assert.ok(enumConstraints(heldoutFixtures[1].seed).issues.some(i=>i.code==='ENUM_DUPLICATE'))
  assert.equal(enumConstraints(heldoutFixtures[7].seed).issues.length,0)
})
test('local evaluator loader authenticates task contract and every loaded asset',async()=>{
  await mkdir(out+'/loader-tests',{recursive:true}); const root=await mkdtemp(out+'/loader-tests/case-')
  const f=heldoutFixtures[0], files={}; await mkdir(root+'/'+f.id)
  for(const [name,text] of Object.entries({'positive.sv':f.positive,'tb.sv':f.tb,'clock.xdc':'create_clock -period 5 [get_ports clk]\n'})) {
    await writeFile(root+'/'+f.id+'/'+name,text); files[f.id+'/'+name]=hash(text)
  }
  await writeFile(root+'/local-rule-probes.json',JSON.stringify({protocol:'local-rule-transfer-probes-v1',tasks:{[f.id]:{files,spec_sha256:hash(f.spec),interface_sha256:hash(JSON.stringify(f.interface)),checks:f.checks}}}))
  const task={task_id:f.id,spec:f.spec,interface:f.interface,assets:files}
  const assets=await loadLocalProbeAssets(root,task)
  assert.equal(assets.assets['rtl/solution.sv'],f.positive)
  assert.equal(assets.evaluation.compatibility.official,false)
  await assert.rejects(loadLocalProbeAssets(root,{...task,spec:f.spec+' modified'}),/LOCAL_PROBE_BINDING_CHANGED/)
  await writeFile(root+'/'+f.id+'/tb.sv',f.tb+' ')
  await assert.rejects(loadLocalProbeAssets(root,task),/LOCAL_PROBE_ASSET_CHANGED/)
})

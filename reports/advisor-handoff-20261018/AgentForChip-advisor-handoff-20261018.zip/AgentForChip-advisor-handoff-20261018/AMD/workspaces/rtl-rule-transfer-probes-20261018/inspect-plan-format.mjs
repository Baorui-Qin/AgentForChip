import { readFile, writeFile } from 'node:fs/promises'
const output='D:/AMD/output/rtl-rule-transfer-probes-20261018'
const json=async p=>JSON.parse(await readFile(p,'utf8'))
const attempts=(await json(output+'/guarded-output-audit.json')).plans
const rows=attempts.map(p=>{
  let value=null,parse=false
  try {value=JSON.parse(p.output);parse=true} catch { /* Original malformed response stays unchanged. */ }
  const limits=[]
  if(p.output.length>1200)limits.push({field:'total',actual:p.output.length,limit:1200})
  if(typeof value?.cause==='string'&&value.cause.length>160)limits.push({field:'cause',actual:value.cause.length,limit:160})
  for(const [i,c] of (Array.isArray(value?.changes)?value.changes:[]).entries()) for(const key of ['before','after']) {
    if(typeof c?.[key]==='string') {
      if(c[key].length>200)limits.push({field:`changes[${i}].${key}`,actual:c[key].length,limit:200})
      if(/[\r\n`]/.test(c[key]))limits.push({field:`changes[${i}].${key}`,issue:'newline_or_backtick_disallowed_in_frozen_format'})
    }
  }
  for(const [i,c] of (Array.isArray(value?.checks)?value.checks:[]).entries()) if(typeof c==='string'&&c.length>160)limits.push({field:`checks[${i}]`,actual:c.length,limit:160})
  return {task:p.task,arm:p.arm,scope:p.scope??'question',directory:p.directory,valid:p.valid,json_parsed:parse,format_limit_violations:limits,
    constraint_issues:p.issues,diagnosis:value?.cause??null,model_changes:value?.changes??null,
    limitation:'A format refusal alone does not show that the diagnosis or proposed edit is wrong. No response was clipped or repaired by this audit.'}
})
await writeFile(output+'/plan-format-review.json',JSON.stringify(rows,null,2),{flag:'wx'})
console.log(JSON.stringify({attempts:rows.length,invalid:rows.filter(r=>!r.valid).length,overlong_cause:rows.filter(r=>r.format_limit_violations.some(v=>v.field==='cause')).length}))

# Frozen Held-Out Validation

Explain constraints offline rather than equating every refusal with lack of understanding. Separate language legality, fixed task contract, Host action protocol, current Host format and environment. Describe a violated relation and a falsifiable check; do not request hidden chain-of-thought or treat copied diagnostics as a coherent repair.

The user authorized a new real 30B/8B skill ON/OFF experiment on newly authored local repair probes. Keep v2 skill/catalog/graph and all registry entries unchanged. The full graph remains an offline source for compiled guidance, not a graph database. Do not change model weights, budgets or refusal policies.

Validate C/AB isolation, compressed rejection facts, evidence hashes, bounded known-form examples and preserved source. Estimated token counts are test doubles, not production tokenizer receipts. Mocked model/EDA outputs must never be counted as genuine repairs or improvements.

Preserve original uncommitted changes, previous source/results and sealed handoff. Only use the user-designated existing model instance via temporary SSH; never send credentials, private keys, private evaluator positives/TBs or unrelated files. Freeze before dispatch, retain every failure, no answer edits or mid-run tuning. Do not run inherited campaign scripts targeting older experiments. No official score or proof of private understanding.

import assert from 'node:assert/strict'
import { readFile, readdir, writeFile, access } from 'node:fs/promises'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
import { validateProfileFiles } from './validate-profile.mjs'

const here='D:/AMD/workspaces/rtl-rule-transfer-probes-20261018', out='D:/AMD/output/rtl-rule-transfer-probes-20261018', root=out+'/campaign'
const json=async p=>JSON.parse(await readFile(p,'utf8'))
const hash=b=>createHash('sha256').update(b).digest('hex')
const frozen=await json(root+'/preflight-freeze.json')
for(const [path,digest] of Object.entries(frozen.files)) assert.equal(hash(await readFile(path)),digest)
assert.equal(await access(root+'/http').then(()=>true,()=>false),false)
assert.equal(await access(root+'/campaign-freeze.json').then(()=>true,()=>false),false)
const filesIn=async directory=>{
  const files=[]
  for(const entry of await readdir(directory,{withFileTypes:true})) {
    const path=join(directory,entry.name)
    if(entry.isDirectory())files.push(...await filesIn(path));else if(entry.isFile())files.push(path)
  }
  return files
}
const on=(await json(root+'/dsh-home/profiles/rtl-p10-model-on/cordis.patch.yml'))[0].insert
const off=(await json(root+'/dsh-home/profiles/rtl-p10-model-off/cordis.patch.yml'))[0].insert
const deadline=on.find(r=>r.id==='llama').config.deadline
assert.equal(off.find(r=>r.id==='llama').config.deadline,deadline)
assert.ok(Date.parse(deadline)>Date.now())
for(const rows of [on,off]) {
  const model=rows.find(r=>r.id==='p10-model').config
  assert.equal(model.campaignMaxDispatches,100);assert.equal(model.maxRepairRounds,2)
  assert.equal(model.maxAgentRequests,8);assert.equal(model.activeMs,240000);assert.equal(model.cloud.maxPlans,4)
}
const validated=await validateProfileFiles(root)
await writeFile(root+'/profile-validation.json',JSON.stringify(validated,null,2),{flag:'wx'})
const files=[...Object.keys(frozen.files),root+'/preflight-freeze.json',root+'/profile-validation.json',root+'/cloud-identity.json',
  ...await filesIn(root+'/services'),...(await filesIn(root+'/dsh-home')).filter(p=>!p.endsWith('cordis.yml')),
  ...await filesIn(root+'/arms'),root+'/preflight/results.json',root+'/preflight/compat-positive-negative-results.json',
  here+'/complete-configure.mjs',here+'/resume_models.py']
const identity=await json(root+'/cloud-identity.json'), budgets=await json(root+'/p10-budgets.json')
const protocol={scope:'heldout-skill-transfer-not-official',deadline,arm_dispatch_limit:100,max_dispatches_total:200,models:identity,budgets,
  max_repairs:2,max_coder_requests:8,max_plans:4,active_ms:240000,skill_soft_tokens:768,planner_recovery_shared:1,new_generation_requests:0,
  seed_origin:'host-authored-heldout-probe',skill_entry_version:'2.0.0',skill_weights_unchanged:true,off_is_naked_baseline:false,
  forced_rejections:false,knowledge_integration:'frozen graph/catalog compiled into unchanged normally selected skill',
  netlist_profile:'unavailable-for-local-probes-not-official',official_score:null,
  configuration_recovery:{reason:'tsconfig resolution from launcher working directory',model_calls_before_recovery:0,
    deadline_preserved:deadline,budgets_reset:false,frozen_preflight_files_changed:0,policy_and_skill_changed:false}}
await writeFile(root+'/campaign-freeze.json',JSON.stringify({files:Object.fromEntries(await Promise.all([...new Set(files)].map(async p=>[p,hash(await readFile(p))]))),protocol},null,2),{flag:'wx'})
console.log(JSON.stringify({status:'CONFIGURATION_COMPLETED',deadline_preserved:deadline,budgets_reset:false,model_calls:0}))

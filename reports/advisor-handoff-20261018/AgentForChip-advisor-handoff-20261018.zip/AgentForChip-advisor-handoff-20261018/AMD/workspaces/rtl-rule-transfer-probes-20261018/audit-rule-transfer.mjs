import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { enumConstraints, repairCodeHash } from './rtl-tools/src/phase1/p10-repair-guards.ts'
import { exactEdit } from './rtl-tools/src/phase1/p10-exact-edit.ts'
import { hash } from './selection.mjs'
import { heldoutFixtures } from './heldout-fixtures.mjs'
import { projectedFeedback } from '../rtl-plan-effectiveness-audit-20261018/projection.mjs'

const out='D:/AMD/output/rtl-rule-transfer-probes-20261018', root=out+'/campaign'
const json=async path=>JSON.parse(await readFile(path,'utf8'))
const put=async(name,value)=>writeFile(out+'/'+name,JSON.stringify(value,null,2),{flag:'wx'})
const models=await json(out+'/model-output-index.json'), calls=await json(out+'/call-index.json')
const checks=await json(out+'/verification-index.json'), guarded=await json(out+'/guarded-output-audit.json')
const callFor=directory=>calls.find(c=>c.associated_model_runs.split('|').some(p=>resolve(p)===resolve(directory)))
const rows=[], refused=[], reviews=[], plannerRecoveries=[], alignment=[]
for(const fixture of heldoutFixtures)for(const arm of ['on','off']) {
  const resultPath=root+`/arms/${arm}/compare-${fixture.id}/result.json`, result=await json(resultPath)
  assert.equal(result.shared_seed_origin,'host-authored-heldout-probe')
  assert.equal(result.initial_generation_logical_requests,0);assert.equal(result.counted_in_model_score,false)
  const verification=checks.filter(c=>c.task===fixture.id&&c.arm===arm)
  const final=verification.find(c=>result.final_verification_run&&resolve(c.result_file)===resolve(result.final_verification_run,'result.json'))??
    verification.find(c=>c.source_sha256===result.best_source_sha256)??verification[0]
  const revision=result.revisions.find(r=>r.sha256===final.source_sha256)
  const source=await readFile(revision.directory+'/solution.sv','utf8'), enums=enumConstraints(source)
  const initialEnum=/typedef\s+enum[\s\S]*?}\s*\w+\s*;/.exec(fixture.seed)?.[0]??null
  const sensitivity=[...source.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g,' ').matchAll(/\balways(?:_ff)?\s*@\s*\(([^)]*)\)/g)].map(m=>m[1])
  const stages=Object.fromEntries(Object.entries(final.stages).map(([name,value])=>[name,value.status]))
  const taskCalls=calls.filter(c=>c.task===fixture.id&&c.arm===arm)
  rows.push({task:fixture.id,arm,family:fixture.family,rules:fixture.rules,result:resultPath,terminal:result.status,
    result_source:revision.directory+'/solution.sv',source_sha256:final.source_sha256,
    code_changed:repairCodeHash(source)!==repairCodeHash(fixture.seed),stages,rtl_four_stage_pass:Object.values(stages).every(s=>s==='PASS'),
    model_calls:taskCalls.length,planner_calls:taskCalls.filter(c=>c.provider==='cloud-thinker').length,coder_calls:taskCalls.filter(c=>c.provider==='cloud-coder').length,
    host_policy_blocked_before_models:result.status==='POLICY_BLOCKED'&&taskCalls.length===0,policy_rule:result.terminal_policy_rule??null,
    enum_facts:enums,legal_enum_declaration_preserved:fixture.id==='Probe208_valid_capacity'&&initialEnum?source.includes(initialEnum):null,
    synchronous_contract_review:{sensitivity,reset_in_sensitivity:sensitivity.some(s=>/\b(?:posedge|negedge)\s+rst\b/.test(s)),
      limitation:'Lexical review for these small fixtures, not a full timing proof; testbench checks sampled edge behavior.'},
    verification_result:final.result_file})
  for(const [i,prior] of result.actions.entries()) if(!prior.accepted) {
    const next=result.actions[i+1], call=next?callFor(next.model_run):null
    const request=call?await json(call.request_file):null
    const materialized=next?guarded.patches.find(p=>p.model_run===next.model_run):null
    const progress=next?.accepted&&next.tool==='edit_dut'?verification.find(v=>v.source_sha256===next.observation.source_sha256):null
    refused.push({task:fixture.id,arm,prior_index:i+1,prior_error:prior.observation.error,prior_model_run:prior.model_run,
      terminal_without_followup:!next,next_tool:next?.tool??null,next_accepted:next?.accepted??false,next_model_run:next?.model_run??null,
      next_request:call?.request_file??null,feedback:request?projectedFeedback(request,prior):null,
      substantive_next_edit:!!(next?.accepted&&next.tool==='edit_dut'&&materialized?.code_sha256),
      next_candidate_rtl_pass:!!progress&&Object.values(progress.stages).every(s=>s.status==='PASS')})
  }
  for(const decision of result.revision_decisions??[]) if(decision.rolled_back) reviews.push({task:fixture.id,arm,...decision})
}
for(const plan of guarded.plans) {
  const validation=await json(plan.directory+'/plan-validation.json')
  if(!validation.recovery)continue
  const earlier=guarded.plans.find(p=>p.directory!==plan.directory&&dirname(p.directory)===dirname(plan.directory))
  const input=JSON.parse((await json(plan.request_file)).messages.filter(m=>m.role==='user').at(-1).content)
  plannerRecoveries.push({task:plan.task,arm:plan.arm,prior:earlier?.directory??null,recovery:plan.directory,
    prior_issues:earlier?.issues??[],prior_valid:earlier?.valid??null,recovery_valid:plan.valid,
    output_changed:earlier?earlier.output!==plan.output:null,recovery_issues:plan.issues,
    supplied_skill_ids:input.guidance?.map(g=>g.id)??[],
    system_feedback:(await json(plan.request_file)).messages.find(m=>m.role==='system')?.content??null,
    limitation:'Output change alone is not correction; require constraint acceptance, encoder action and EDA evidence.'})
}
for(const patch of guarded.patches) {
  const context=await json(patch.model_run+'/context.json')
  const plan=context.planning?JSON.parse(context.planning.text):null
  if(!plan)continue
  let desired=null,actual=null,error=null
  try {
    desired=exactEdit(JSON.stringify({expected_revision_id:context.current.revision_id,replacements:plan.changes}),context.current.source,context.current.revision_id).source
    actual=exactEdit(JSON.stringify(patch.arguments),context.current.source,context.current.revision_id).source
  } catch(e) { error=e.message }
  alignment.push({task:patch.task,arm:patch.arm,model_run:patch.model_run,accepted:patch.accepted,materialization_error:error,
    plan_candidate_sha256:desired?hash(desired):null,encoder_candidate_sha256:actual?hash(actual):null,
    identical_to_plan:desired!==null&&actual!==null?desired===actual:null,
    same_code_tokens_as_plan:desired!==null&&actual!==null?repairCodeHash(desired)===repairCodeHash(actual):null,
    replacements:patch.arguments?.replacements??null,limitation:'Different valid edits can implement the same diagnosis; mismatch is not automatically a defect.'})
}
for(const call of calls) {
  const request=await json(call.request_file)
  for(const fixture of heldoutFixtures) assert.equal(JSON.stringify(request).includes(JSON.stringify(fixture.tb).slice(1,-1)),false,'PRIVATE_TB_SENT')
  const model=models.filter(m=>m.request_sha256===call.request_sha256)
  assert.equal(model.length,1,'Ambiguous raw model/request mapping requires separate review')
}
const recoverySummary={tool_rejections:refused.length,followups:refused.filter(r=>!r.terminal_without_followup).length,
  feedback_delivered:refused.filter(r=>r.feedback?.delivered).length,substantive_next_edits:refused.filter(r=>r.substantive_next_edit).length,
  next_candidate_rtl_pass:refused.filter(r=>r.next_candidate_rtl_pass).length,eda_rollbacks:reviews.length,
  planner_recovery_attempts:plannerRecoveries.length,planner_recoveries_accepted:plannerRecoveries.filter(r=>r.recovery_valid).length}
await put('rule-transfer-evidence.json',{scope:'Local held-out behavioral evidence, not private understanding or generalization proof',rows,
  recovery_summary:recoverySummary,tool_rejections:refused,eda_rollbacks:reviews,planner_recoveries:plannerRecoveries,planner_encoder_alignment:alignment,
  private_tb_in_requests:false,private_positive_policy:'Initials are bound faulty seeds. Later current.source is checked against model-authored revisions; matching a private positive after an edit is not evidence of oracle injection.',
  limitations:['No forced refusals; absence of refusal is not recovery evidence.','Edge-sampled internal TBs do not prove every possible timing behavior.',
    'Enum facts cover bounded forms only; changed legal enum declarations need manual encoding review.','All fixed interface constraints remain enforced by the normal source guard.']})
console.log(JSON.stringify({rows:rows.length,rtl_pass:rows.filter(r=>r.rtl_four_stage_pass).length,blocked_before_models:rows.filter(r=>r.host_policy_blocked_before_models).length,...recoverySummary}))

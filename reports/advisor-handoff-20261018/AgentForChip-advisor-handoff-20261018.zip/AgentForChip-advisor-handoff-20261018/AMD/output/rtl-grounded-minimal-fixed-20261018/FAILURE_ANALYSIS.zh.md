# 逐题规划、编码和验证原因

仅解释已经发生的模型输出、工具调用和 EDA 结果，不把本报告当作答案注入 Agent。本轮 ON/OFF 两组均从相同初稿开始，未直接修改题目答案。完整逐请求对应关系见 [planner-coder-evidence.json](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/planner-coder-evidence.json)，逐次验证见 [verification-index.json](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/verification-index.json)。

## Prob096

当前首要错误是 VRFC 10-3279：S4 与其他 enum 成员重码。初稿定义了五个枚举成员，枚举宽度只有两位，已有 S0..S3 用完四种编码。仅在两位范围内把 S4 改成另一个已有值，不可能消除所有冲突。

ON 的规划引用 L16 正确，却提出 S4 改为与 S1 相同的值，checks 又声称应保证唯一，规划内部不一致。编码器实际又选择与 S3 相同的值，还改了输出置位条件并添加注释，既没有严格落实规划，也不是最小修改。其中 `next_state = S4;` 在绑定源码中出现两次，整单被 PATCH_ANCHOR_NOT_UNIQUE 原子拒绝。重试原样提交同一组替换，再次拒绝；0 个接受的候选，以 REPEATED_ACTION_REJECTED 停止。

OFF 的两份规划分别建议与 S3、S1 冲突的编码。编码器接受的两个候选都保留了与 S3 相同的值，第二次还只把注释改成“unique value”。两次真实 EDA 均仍报相同重码，回滚后耗尽两次修改预算。主机正确应用了模型文本，但模型文本本身错误。

本轮没有逗号语法错误诊断，不等于题目已修好：两组都没有进入仿真。故障定位应区分“找到了 enum 报错行”“识别编码容量约束”“正确实现状态行为”三件事。

原始终态：[ON](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/on/compare-Prob096_review2015_fsmseq/result.json)、[OFF](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/off/compare-Prob096_review2015_fsmseq/result.json)。前后计划、diff 与错误码见 [semantic-repair-evidence.json](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/semantic-repair-evidence.json)。

## Prob142

当前 VRFC 10-2649 出现在 L25 的普通位向量向 enum 赋值。两组 cause 都准确引用该行，也重复了 EDA 类型错误，但 changes 三项全部为原文变成相同原文。这是无效规划，不是“规划正确但编码器不配合”。

两组 8B 都没有提交 edit_dut，而是两次 verify_rtl 当前已经验证失败、且没有待验证修改的 revision。原有工具状态检查拒绝为 VERIFICATION_REQUEST_REJECTED，并以 REPEATED_ACTION_REJECTED 终止。这里不能说“新 enum 修法在 EDA 中失败”：根本没有新的候选提交，仍保留初稿编译错误。

本次首代诊断实验曾由模型提交 cast/同 enum 类型修改，消除了 10-2649 后暴露多驱动；那是独立历史结果，不能挪到当前组宣称当前完成了同样修复。当前退步发生在规划输出和动作选择，非上下文超限或输出截断。

原始终态：[ON](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/on/compare-Prob142_lemmings2/result.json)、[OFF](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/off/compare-Prob142_lemmings2/result.json)。

## Prob104

当前 VRFC 10-3186 指向对标量 q_in 的索引。题目固定接口明确 q_in 为一位，规划器两组都把“应扩大输入宽度”当成修复方向；OFF 还建议调整内部寄存器和部分表达式。该方向与可信题目接口冲突。

ON 两次编码器提交相同扩宽输入/寄存器的替换，均被既有源码/接口检查以 INVALID_OUTPUT 拒绝，0 个接受的修改。OFF 共四次提交：三次同类接口无效候选、一次引用了未被接受候选中的表达式，因此当前源码没有该锚点，报 PATCH_ANCHOR_NOT_UNIQUE。最终亦为 REPEATED_ACTION_REJECTED。

主机没有偷偷扩大端口，也没有把修复预算用在直接编辑正确答案上。这里的主要缺口是规划语义和拒绝后的状态适应，不是技能未送达。两组均未修复本轮退步。

原始终态：[ON](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/on/compare-Prob104_mt2015_muxdff/result.json)、[OFF](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/off/compare-Prob104_mt2015_muxdff/result.json)。

## Prob039

初稿 out_always 是 net，但在过程块中赋值，报 VRFC 10-1280。ON 编码器先把 reg 声明插进 ANSI 端口列表，之后又给端口声明加了多余分号，三次均被 UNSUPPORTED_INTERFACE 拒绝；没有接受的修改，停于 REPEATED_ACTION_REJECTED。不能把这是精确替换“无串扰”的事实当成修复成功。

OFF 在端口声明处将输出改成变量，同时把两个过程赋值改为非阻塞赋值，RTL 四阶段通过，226 checks、0 mismatch。后两项不证明必要，因此不是全局最小修复证明。完整网表仍被环境校准门限阻塞。

原始终态：[ON](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/on/compare-Prob039_always_if/result.json)、[OFF](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/off/compare-Prob039_always_if/result.json)。

## Prob060

初稿复位语句包含畸形数值字面量。两组均由编码器精确替换这一处为合法零值，未改其余代码；随后正常 verify_rtl。两组编译、展开、仿真、综合通过，593 checks、0 mismatch。这是本轮局部修改落实成功的实际正例。

两组终态均为 NETLIST_ENVIRONMENT_NOT_CALIBRATED，这是 2025.2 固定库与本地 2026.1 环境不匹配，不应标记成 RTL 功能失败，也不能计为完整验收成功。

原始终态：[ON](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/on/compare-Prob060_m2014_q4k/result.json)、[OFF](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/off/compare-Prob060_m2014_q4k/result.json)。

## Prob119

初稿在过程块内写 net 类型 out，报 VRFC 10-1280。ON 唯一接受的修改只是把 always @* 换成 always_comb，没有改变输出类型，真实 EDA 仍报同一错误并回滚。随后两次重复验证回滚后的已验证版本，被拒绝并终止。

OFF 正常改写 ANSI 输出声明为变量，另加了一条非必要注释，随后 RTL 四阶段通过，459 checks、0 mismatch。当前 ON 相对前一轮 semantic 实验退步，OFF 相对那一轮没有退步。两个当前组不能用首代实验的 ON 成功结果替换。

原始终态：[ON](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/on/compare-Prob119_fsm3/result.json)、[OFF](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/off/compare-Prob119_fsm3/result.json)。

## Prob058

初稿两个输出都是 net 却由过程块赋值，报 VRFC 10-1280。ON 第一次提交完全不变，被 REPEATED_CANDIDATE 拒绝；第二次添加重复的时序块，仍未解决变量声明，实际 EDA 继续失败。其后在重复验证、原样候选及先前已拒绝候选之间循环，耗尽 8 次编码请求，终态 MODEL_REQUEST_BUDGET_EXHAUSTED。

三次原样拒绝后的压缩恢复请求均保留了当前源码与真实诊断，没有重放被拒绝方案或缓存规划；但模型仍重复无效策略。恢复提示正确送达与模型执行正确是两回事。

OFF 首次在模块体中重声明 ANSI 输出为 reg，候选 EDA 报 VRFC 10-9336 重声明错误，随后回滚。后三次提交带末尾逗号的 `output out_always_ff,` 锚点，但初稿该末端端口没有逗号，无法匹配。终态 REPEATED_ACTION_REJECTED。两组均没有修好，ON 相对前一轮 semantic 实验退步。

原始终态：[ON](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/on/compare-Prob058_alwaysblock2/result.json)、[OFF](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/arms/off/compare-Prob058_alwaysblock2/result.json)。

## 非题目因素

本次保留的首代预检 ENOENT 是主机目录初始化问题；混合真实修改/不变项被整单拒绝是校验器缺陷。两项均在独立修正版中修复并回归，原失败不删除。当前 6 个通用预检全部实际仿真通过，但不能外推为三道复杂题通过。

当前七题 62 次模型 HTTP/SSE 正常，0 模型传输错误、0 上下文错误、0 输出截断。26 个工具拒绝为：UNSUPPORTED_INTERFACE 3、VERIFICATION_REQUEST_REJECTED 7、PATCH_ANCHOR_NOT_UNIQUE 6、INVALID_OUTPUT 5、REPEATED_CANDIDATE 3、REJECTED_REVISION 2。PATCH_ANCHOR_NOT_UNIQUE 同时用于缺失/重复锚点；新关联索引已按真实源码出现次数区分，不臆测原因。

4 个 RTL 四阶段通过的组均未获完整网表验收，原因是固定 2025.2 网表库的三个哈希与本地 2026.1 不一致，不是云模型或网络故障。没有改写哈希绕过检查。原始模型 run.json 的 RUNNING 字段也原样保留；任务 result、HTTP 完整流和进程退出回执是本次终态依据。

证据：[工具拒绝](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/tool-rejections.json)、[模型错误](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/model-errors.json)、[网表环境](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/netlist-environment-audit.json)、[原始日志核验](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/log-audit.json)。

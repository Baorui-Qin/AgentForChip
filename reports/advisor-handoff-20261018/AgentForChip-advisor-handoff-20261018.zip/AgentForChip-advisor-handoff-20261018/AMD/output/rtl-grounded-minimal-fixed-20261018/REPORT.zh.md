# 规划定位与精确修复验证报告

日期：2026-10-18。范围：Prob096、Prob142、Prob104 的规划/编码衔接验证，以及相同七题的同期 skill 开关对照。本报告记录开发实测，不是比赛成绩。

## 结论

本轮实验及日志核验已完成，但三个重点题没有修好，不建议将本版精确替换流程推广为默认方案。修正后的通用能力预检为 6/6 通过，七题实测却只有 skill ON 1/7、OFF 3/7 通过本地 RTL 四阶段。18/18 份规划能正确引用当前报错行，不代表 18/18 份规划的根因判断或修法正确。

具体失败已分离到规划、编码、工具协议和 EDA 层：Prob096 提出了仍冲突的状态编码，ON 编码还使用了歧义锚点；Prob142 的规划只有原样替换，编码器随后重复验证未修改的版本；Prob104 仍违反题目固定输入宽度。不存在“已经解决三题”的证据。

数据入口：[七题对照](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/comparison.csv)、[逐题原因](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/FAILURE_ANALYSIS.zh.md)、[规划与编码关联](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/planner-coder-evidence.json)、[最终核验](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/delivery-verification.json)。

## 本轮变更

独立源码在 `D:/AMD/workspaces/rtl-grounded-minimal-fixed-20261018`，没有覆盖 `D:/deepseek-harness`，没有直接编辑任何题目答案。

1. 规划输入增加当前首个阻塞性 DUT 错误的真实代码行，以及最多两条词法引用。规划必须在原有紧凑 JSON 限制内引用该行；校验只证明位置对应，不充当 SystemVerilog 类型求解器。
2. 编码器通过正常 `edit_dut` 工具提交一至三个明确的 `before/after` 替换。主机要求当前 revision 一致、每个锚点唯一、区间不重叠，然后仅应用模型给出的文本。未选中的代码保持不变，不猜补缺失内容。
3. 候选继续经过原有端口、源码策略、重复提交、两次修改预算、`verify_rtl` 和回滚流程。没有绕过 EDA，也没有自动生成正确修法。
4. 两组使用同一套上述机制，六条已有 skill 内容保持不变。ON 按原有诊断选择器正常装载；OFF 不加载 skill。本轮不是再次修改 skill 文本的实验。

源码说明与测试入口：[README](D:/AMD/workspaces/rtl-grounded-minimal-fixed-20261018/README.md)、[变更记录](D:/AMD/workspaces/rtl-grounded-minimal-fixed-20261018/AGENT_NOTE.md)、[精确替换实现](D:/AMD/workspaces/rtl-grounded-minimal-fixed-20261018/rtl-tools/src/phase1/p10-exact-edit.ts)、[定位实现](D:/AMD/workspaces/rtl-grounded-minimal-fixed-20261018/rtl-tools/src/phase1/p10-grounding.ts)。

## 先验证通用能力

七题开始前，使用非目标题的逗号语法、enum 类型、标量索引三个控制样例，分别运行 ON/OFF。仍由 30B 规划、8B 编码；本地 Vivado 实际编译、展开和仿真，每例执行 8 次检查、0 mismatch。验证 oracle 和测试台未进入模型请求。

| 控制样例 | ON 规划引用 | ON 局部修改/仿真 | OFF 规划引用 | OFF 局部修改/仿真 |
| --- | --- | --- | --- | --- |
| ControlComma | 匹配 | 通过/通过 | 匹配 | 通过/通过 |
| ControlEnum | 匹配 | 通过/通过 | 匹配 | 未通过局部范围检查/通过 |
| ControlScalar | 匹配 | 通过/通过 | 匹配 | 通过/通过 |

这里的“局部范围检查”是控制样例的预设改动范围检查，不是全局最小修复证明。OFF 的 enum 方案虽然仿真通过，但还删除连续赋值并改写寄存器写入对象，超出了所需范围。关键词检查同样只是一项弱检查，不能替代 EDA 或语义分析。

证据：[能力检查汇总及请求索引](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/capability-audit.json)、[六例结果](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/capability-controls.csv)。

## 七题同期结果

七题均从历史 50 题实验中导入同一份生成初稿，两组初稿逐字节相同，本轮没有重新生成初稿。按题交替 ON/OFF 顺序，随后执行新的规划、模型修复和本地 EDA。

“RTL 通过”指开发环境编译、展开、仿真、综合全部通过，不含完整网表验收。表中调用数包含规划和编码，不包含原生 token 计数调用。

| 题目 | ON RTL | OFF RTL | ON/OFF 推理调用 | 本轮主要观察 |
| --- | --- | --- | --- | --- |
| Prob039 | 未通过 | 通过 | 4 / 3 | ON 修坏 ANSI 端口声明；OFF 修复后 226 checks、0 mismatch |
| Prob060 | 通过 | 通过 | 3 / 3 | 两组都仅修复畸形复位字面量；593 checks、0 mismatch |
| Prob119 | 未通过 | 通过 | 6 / 3 | ON 只改 always 形式，未修 net 类型；OFF 459 checks、0 mismatch |
| Prob096 | 未通过 | 未通过 | 3 / 6 | 定位 enum 重码，但修法仍冲突；ON 另有歧义锚点 |
| Prob104 | 未通过 | 未通过 | 3 / 5 | 两组均试图扩大固定输入宽度，工具拒绝 |
| Prob142 | 未通过 | 未通过 | 3 / 3 | 两组规划均无有效修改，重复验证已知失败版本 |
| Prob058 | 未通过 | 未通过 | 10 / 7 | ON 重复无效/已拒绝修改耗尽 8 次编码请求；OFF 有 ANSI 重声明错误 |
| 合计 | 1 / 7 | 3 / 7 | 32 / 30 | 三个重点题均未完成修复 |

Prob058 ON 的 10 次是 2 次规划加 8 次编码，不是把编码上限提高到 10 次。所有 14 个任务均有终态和最终验证绑定。

## 三题验证判断

| 题目 | 规划能否准确定位 | 编码器是否落实有效的最小修复 |
| --- | --- | --- |
| Prob096 | 找到 S4 重码位置，但提出的值与其他状态仍冲突；没有解决五个枚举状态与两位容量的矛盾 | ON 加了不必要的行为/注释修改，锚点出现两次而被原子拒绝；OFF 的两个候选均仍被 VRFC 10-3279 拒绝 |
| Prob142 | 找到 enum 赋值错误位置，但 changes 的三项全部为原文替换原文，不是有效修法 | 两组都没有提交 edit_dut，重复 verify_rtl 被拒绝；没有进入新的候选 EDA |
| Prob104 | 找到标量索引位置，但把错误归结为应扩大题目输入，违背固定接口 | 扩宽输入的候选被原有接口检查拒绝；OFF 还使用了不在当前源码中的锚点 |

本轮未再出现 Prob096 的逗号语法诊断，但不能因此宣布它已解决：ON 没有产生可接受的新候选，OFF 停在枚举展开错误，均未到功能仿真。

证据：[前后规划、候选 diff 和 EDA](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/semantic-repair-evidence.json)、[每次编码器实际输入及工具参数](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/planner-coder-evidence.json)、[精确应用审计](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/exact-edit-grounding-audit.json)。

## 历史与本轮分开保留

本次工作中先产生了一代诊断实验，其通用预检存在两个主机问题：没有预先创建 models 目录，导致编码请求前出现 ENOENT；精确替换校验器会把“真实修改加不变上下文项”整单拒绝。这些不是模型失败。补做未派出的编码步骤时保留了原规划，没有额外重跑规划，但补做发生在七题之后，因此那代不能作为“先通过预检再跑题”的证据。

随后创建当前修正版副本，修复目录初始化及混合替换的判断，并增加正负回归测试。完全不变的候选仍拒绝，文件系统异常按基础设施错误停止。当前六例预检在七题之前完成，之后没有根据预检结果再调参。

| 独立实验 | ON RTL | OFF RTL | 说明 |
| --- | --- | --- | --- |
| 前一轮 semantic skill 实验 | 4/7 | 3/7 | 历史参考，不是本轮同期控制 |
| 本次保留的首代诊断实验 | 3/7 | 2/7 | 含预检主机缺陷，完整失败结果保留 |
| 当前修正版同期实验 | 1/7 | 3/7 | 当前唯一成对结果，不挑选跨代最佳答案 |

相对前一轮 semantic 实验，当前 ON 退步题为 Prob039、Prob119、Prob058；OFF 通过题集合不变。不能从单次七题实验断言 skill 在统计意义上有害，但已经足以否决直接推广本版。

证据：[三代逐题同源对比](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/three-generation-comparison.json)、[历史对比](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/previous-vs-current.csv)、[首代原始结果](D:/AMD/output/rtl-grounded-minimal-ablation-20261018/comparison-summary.json)、[首代状态说明](D:/AMD/output/rtl-grounded-minimal-ablation-20261018/EXPERIMENT_STATUS.json)。

## 预算、请求与技能

模型保持 Qwen3-Coder-30B-A3B-Instruct-Q4_K_M 负责规划、SiliconMind-V1-Qwen3-8B-Q4_K_M 负责编码，模型属性、模板及服务 build 与前轮一致。两组上下文均为 8192；规划输出 1024、编码输出 2048、预留 1024。每题仍为最多 2 次接受的 RTL 修改、8 次编码请求、4 个规划绑定及原有 240 秒活动预算。

首代已经使用 ON 44、OFF 41 次推理调用。当前两组都只获 56 张剩余票额，且继续使用原始截止时间 2026-10-18 03:39:48.472（北京时间），没有重置为新的 100 次或重新计时。当前实际使用 ON 41、OFF 39；合并首代后分别为 85/100、80/100。不同独立实验的题目结果没有拼成一次更长的修复轨迹。

当前推理调用共 80 次：通用能力检查 18 次，七题 62 次（30B 18 次、8B 44 次）。七题 token 为输入 174930、输出 6927；预检输入 29882、输出 1609。另保留七题的 415 条原生计数记录，计数请求不计作推理调用。

七题 62 次及预检 18 次 HTTP 均为 200、SSE 完整，模型错误为 0，没有上下文超限或输出截断。七题最大规划输入 3331/6144、最大编码输入 4233/5120。18 份规划均满足紧凑格式与字面位置检查，但上述三题证明格式合格并不保证有效修法。

ON 的 9/9 次规划、20/23 次编码请求携带选中的 skill；剩余 3 次为待验证候选请求，不加载修复技能。10 次压缩后的 ON 请求仍带 skill。OFF 的 30 次请求均不带 skill。没有将“已加载”当作“已遵循”或“已提升正确率”。

证据：[冻结模型与预算](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/campaign-freeze.json)、[技能请求审计](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/skill-usage-audit.json)、[能力及跨代调用票额](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/capability-audit.json)、[调用日志](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/LOG_INDEX.md)。

## 验证与保留

本地通过 165 项针对性测试（85 项 Harness 行为测试、69 项技能/定位/预算测试、11 项配置与规划快照），并通过 10 个语法/类型/宽度 EDA 控制与 16 个既有任务 EDA 控制。完整类型检查没有通过：当前与前版均有完全相同的 70 条已有依赖诊断，没有新增诊断，不能写成 typecheck 全绿。

当前 381 个冻结输入未变；9 个接受的精确候选已逐一从模型参数重算并对照实际文件，主机没有补写答案。原工程 12690 个条目、题库 2155 个文件、旧 skill/知识库、封存交接目录及 zip 均与执行前一致；七个历史输出目录逐文件复核无改动。未更新交接包。

六个执行阶段均正常退出并回收；临时 SSH 隧道已关闭，SSH 原始配置哈希恢复一致。回环端口关闭复核及所有证据链接见最终核验回执。

证据：[原工程保留](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/preservation.json)、[历史输出保留](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/grounded-round-preservation.json)、[退出及端口复核](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/post-run-checks.json)。

## 解释边界与后续判断

本地 Vivado 为 2026.1，比赛截图要求 2025.2；固定网表库的三个哈希仍指向 2025.2，与本机 2026.1 不匹配，完整网表验收为 0/14。没有修改库哈希或放宽验收规则。skill OFF 是相同 Harness 的无技能消融，不是原始裸 Baseline；本轮不证明比赛 pass@1/pass@5、留出题泛化、单张 32GB 合规或统计显著性。

下一步优先在离线控制样例中验证“规划包含实质变化、满足固定接口和枚举容量约束、编码锚点唯一、拒绝后改变策略”，而不是继续叠加技能文字。精确替换可保留为审计工具，但本版不能据此替代上一版默认流程。任何新的模型对照应另行冻结实验和预算，不能补跑并覆盖当前负结果。

证据：[网表环境诊断](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/netlist-environment-audit.json)、[推广决定](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/PROMOTION_DECISION.json)。

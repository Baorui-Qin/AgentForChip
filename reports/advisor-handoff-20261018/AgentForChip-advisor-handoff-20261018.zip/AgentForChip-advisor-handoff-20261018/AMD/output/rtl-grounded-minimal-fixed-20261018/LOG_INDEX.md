# 本轮日志索引

所有文件保留在独立输出目录。本轮没有覆盖原始工程、历史结果或交接包；没有把模型摘要替代原始请求和响应。

## 先读这些

- [报告](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/REPORT.zh.md)：结论、三代结果、预算和限制。
- [逐题原因](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/FAILURE_ANALYSIS.zh.md)：七题规划/编码/EDA 分层说明。
- [七题配对表](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/comparison.csv)：同源初稿、两组结果、修改。
- [逐任务阶段表](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/tasks.csv)：14 组终态、四阶段、调用数。
- [最终核验回执](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/delivery-verification.json)：证据审计，不是全部题目修复通过。

## 模型输出与调用

- [模型目录索引](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/model-output-index.json)：七题 62 次规划/编码目录。每目录保留 prompt-final、dispatch、response/output、model、context、events 等实际存在的文件。
- [调用 CSV](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/calls.csv)、[调用 JSON](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/call-index.json)：角色、题目、组别、请求 SHA、token、HTTP、SSE 与模型目录。
- [七题原始 HTTP/SSE](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/http)：每次 request.json、sse.jsonl、transport.json。
- [规划与编码关联](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/planner-coder-evidence.json)：44 次编码的实际上下文、规划 SHA、工具原参数、锚点出现次数、接受/拒绝观察和 HTTP 路径。
- [规划格式记录](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/planner-validation-index.json)：18 份规划的紧凑格式检查。
- [位置与精确替换审计](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/exact-edit-grounding-audit.json)：18 次位置检查及 9 个接受候选的逐文件重算。
- [技能请求审计](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/skill-usage-audit.json)：ON 选择/压缩/恢复请求、OFF 零装载、预算及内容哈希。
- [原生计数](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/token-counter-index.csv)：415 条七题计数记录，非推理请求。

原始 run.json 中 62 个 RUNNING 字段未改写。真实终态读取任务 result.json，并与完整 HTTP/SSE、进程退出和验证 receipt 对照。待验证候选的原始 context.json 可以保留编辑前 planning 元数据，不等同于投影后真正发送的 HTTP 请求；检查模型可见内容应以 request.json 为准。

## 通用能力预检

- [六例能力汇总](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/capability-audit.json)：18 次调用、源码/请求绑定、输入预算、ON/OFF 无 oracle 注入及跨代票额。
- [控制结果 CSV](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/capability-controls.csv)：引用、关键词、修改范围、EDA，分别列示，不能相互替代。
- [预检原始日志](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/capability)：三例乘两组，含 plan、model 输出、实际候选 EDA 及独立 HTTP/SSE 子目录。

## EDA 与失败

- [验证索引](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/verification-index.json)、[阶段 CSV](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/verification-stages.csv)：七题 23 次验证、92 行阶段证据，包括初稿和失败后回滚前候选。
- [错误原因原记录](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/failure-reasons.json)：终态、失败域、原始 EDA 路径。
- [三题前后语义证据](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/semantic-repair-evidence.json)：前一轮与当前三题的计划、候选 diff、错误码及回滚记录。
- [工具拒绝 CSV](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/tool-rejections.csv)：26 次拒绝，不与 0 次模型传输错误混记。
- [模型错误 CSV](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/model-errors.csv)：本轮为空结果。
- [网表环境只读核验](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/netlist-environment-audit.json)：2025.2 固定哈希与 2026.1 实际库不匹配，未修改库或验收门限。

## 历史、预算和保留

- [三代对比](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/three-generation-comparison.json)：历史 semantic、保留诊断、当前修正版，不选取跨代最佳答案。
- [历史对比 CSV](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/previous-vs-current.csv)：与前一轮 semantic 的每题变化。
- [原始冻结清单](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/campaign-freeze.json)：模型、模板、上下文、每题预算、381 个输入哈希及原始 deadline。
- [同源初稿导入](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/imported-initials.json)：14 份导入件与旧生成日志位置，当前新增初稿调用为 0。
- [原工程保留](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/preservation.json)：原工程/题库/旧技能/旧知识/封存交接目录和 zip。
- [历史 50 题保留](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/previous-round-preservation.json)、[诊断路由轮保留](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/control-round-preservation.json)、[旧技能轮保留](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/skills-round-preservation.json)、[恢复轮保留](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/recovery-round-preservation.json)、[预算轮保留](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/budgetfit-round-preservation.json)、[semantic 轮保留](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/semantic-round-preservation.json)、[本次首代诊断轮保留](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/grounded-round-preservation.json)。
- [首代原始能力审计](D:/AMD/output/rtl-grounded-minimal-ablation-20261018/capability-audit.json)：保留原 ENOENT 和补做轨迹，不能当作本轮预先通过。

## 测试与回收

- [85 项 Harness 行为测试](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/unit-loop-host.log)、[69 项技能/定位/预算测试](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/unit-skills-grounding.log)、[11 项配置/规划快照](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/unit-profile-planner.log)。最初沙箱缓存重命名受限的失败日志 unit-loop.log 亦保留，不伪装成行为测试失败。
- [当前类型诊断](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/typecheck-current.log)、[前版类型诊断](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/typecheck-previous.log)：逐字节相同的 70 条既有诊断，完整 typecheck 未通过。
- [10 个 EDA 控制](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/semantic-controls/results.json)、[16 个既有任务控制](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/preflight/results.json)。
- [14 组顺序与终态](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/campaign/progress.jsonl)、[运行退出](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/diagnostic-driver-process.json)、[隧道及 SSH 恢复](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/cleanup.json)、[端口与阶段回收](D:/AMD/output/rtl-grounded-minimal-fixed-20261018/post-run-checks.json)。隧道由管理器主动终止，其退出码 1 不表示模型推理崩溃。

本轮 80 次推理加首代 85 次合计 165 次，按 ON/OFF 分别累计 85/100、80/100；原始截止时间未延长。该调用数恰好也等于本轮 165 项单元测试数量，两者是不同指标。

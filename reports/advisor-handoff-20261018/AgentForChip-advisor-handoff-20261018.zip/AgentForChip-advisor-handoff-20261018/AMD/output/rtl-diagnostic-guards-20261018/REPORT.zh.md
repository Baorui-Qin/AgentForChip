# RTL 诊断技能与修复约束独立验证报告

日期：2026-10-18。范围：同一套 30B 规划器、8B 编码器，七题同期 skill 开关对照；不直接修改答案，不更新交接包。

## 结论

发现了模型未有效运用报错和拒绝反馈的可观测证据，但不能据此读取或断言其内部是否“理解”。最明确的例子是 Prob096：收到“2 位、5 个枚举成员、仍有重复值”的具体反馈后，规划器继续提交同一冲突编码，并声称 4 个取值足够容纳 5 个成员。另一方面，Prob104 和 Prob142 的部分规划已经指出正确错误类型，却被本轮冻结的格式限制拒绝，不能把这些拒绝都归为诊断理解失败。

已将诊断经验整理为通用 skill，通过 Harness 正常选择器加载；加入规划预检、具体拒绝定位、忽略普通注释和空白的候选指纹，并做了离线测试及真实模型验证。当前结果：skill ON 与 OFF 均为 **4/7 通过本地 RTL 四阶段**，没有 ON 独有成功题。因此，本轮支持“工程防护可用、部分拒绝后恢复可观察”，**不支持“新 skill 已带来额外通过率收益”**。Prob096、Prob104、Prob142 仍未全部修好。

## 本轮结果

四阶段为编译、展开、RTL 仿真、综合。表内不是正式比赛分数，也不是网表验收通过。

| 题目 | skill ON | skill OFF | 观察 |
| --- | --- | --- | --- |
| Prob039_always_if | 四阶段通过 | 四阶段通过 | 修复过程赋值目标声明；ON 曾提前验证，被拒绝后转为编辑 |
| Prob060_m2014_q4k | 四阶段通过 | 四阶段通过 | 修复非法二进制字面量语法 |
| Prob119_fsm3 | 四阶段通过 | 四阶段通过 | 修复过程赋值目标声明；ON 拒绝后改变动作 |
| Prob096_review2015_fsmseq | 规划约束拒绝 | 规划约束拒绝 | 重复枚举值及容量仍不合法，两侧均未调用编码器 |
| Prob104_mt2015_muxdff | 规划格式拒绝 | 规划约束拒绝 | ON 多行代码被格式拦截；OFF 恢复规划扩宽固定输入被拦截 |
| Prob142_lemmings2 | 规划格式拒绝 | 编译改善，展开仍失败 | OFF 先修 enum 类型，再暴露多驱动，后续无实质修改规划被拒绝 |
| Prob058_alwaysblock2 | 四阶段通过 | 四阶段通过 | 修复两个过程赋值目标声明；ON 拒绝后改变动作 |

即时前一轮为 ON 1/7、OFF 3/7，本轮为 4/7、4/7；未见题目级退步。不过，更早的 semantic 轮已达到 ON 4/7、OFF 3/7，本轮 ON 是恢复此前水平，不是新的最高能力证明。历史比较同时改变了规划格式、约束与提示，不能单独归因于 skill 或某项防护。详见 [同期对照](D:/AMD/output/rtl-diagnostic-guards-20261018/comparison-summary.json)、[前轮比较](D:/AMD/output/rtl-diagnostic-guards-20261018/previous-vs-current.json)。

## 已实现的约束

1. **规划必须包含可检验的实质修改。** 修复模式的 `changes` 为 1 至 3 个精确 `before/after` 对；Host 仅在内存预览模型提交的修改，不写入 DUT，不替模型构造答案。无代码变化、锚点缺失或不唯一、固定接口违规、可确定的枚举容量和值冲突会被拒绝。旧单次生成规划路径不变。
2. **拒绝要指出具体位置。** 精确替换拒绝提供第几个替换、缺失或多义、匹配次数、至多三处行号；接口拒绝提供端口及预期/实际属性；枚举拒绝提供类型、宽度、成员或重复成员。反馈经正常工具观察和规划恢复请求返回，不只写本地日志。
3. **剔除表面变化的重复候选。** token 指纹忽略普通注释和空白，保留字符串及综合控制注释；会话内记录已拒绝候选，拦截只改注释、原样提交和被拒代码的表面重放。它是 token 等价检查，不是语义等价证明，也不是完整 HDL 解析器。
4. **整理并正常调用通用 skill。** 新增 `rtl.00_diagnostic_reasoning`，覆盖 VRFC 过程赋值、enum 类型/重复、标量索引、语法及工具拒绝恢复；不含题号、目标答案或隐藏思维链。保持旧六项技能不变，沿用正常 C 选择器，最多选两项。OFF 的 B 模式不加载技能，但仍保留 Agent 和共享防护，因此不是原始裸 Baseline。

实现入口：[修复约束](D:/AMD/workspaces/rtl-diagnostic-guards-20261018/rtl-tools/src/phase1/p10-repair-guards.ts)、[精确替换诊断](D:/AMD/workspaces/rtl-diagnostic-guards-20261018/rtl-tools/src/phase1/p10-exact-edit.ts)、[规划器](D:/AMD/workspaces/rtl-diagnostic-guards-20261018/rtl-tools/src/phase1/p10-planner.ts)、[修复循环](D:/AMD/workspaces/rtl-diagnostic-guards-20261018/rtl-tools/src/phase1/p10-model.ts)、[新技能](D:/AMD/workspaces/rtl-diagnostic-guards-20261018/skills/rtl-diagnostic-reasoning/SKILL.md)。

## 单独验证

离线及模拟 Harness 聚焦测试共 **109 项通过**：原有 85 项加本次新增 24 项。覆盖无实质修改、注释重放、固定接口、枚举约束、锚点具体定位、拒绝反馈传递、拒绝后更换策略、EDA 失败回退以及不追加恢复额度。日志为 [Harness 90 项](D:/AMD/output/rtl-diagnostic-guards-20261018/unit-loop-pass.log) 和 [约束 19 项](D:/AMD/output/rtl-diagnostic-guards-20261018/unit-guards-complete.log)。

真实模型先做三种非目标题型的能力探针，各有 ON/OFF：逗号语法 ON/OFF 通过；enum ON 格式失败、OFF 通过；标量索引 ON 通过、OFF 格式失败，合计 **4/6 通过**。四个成功均检查修改局部性并跑真实编译、展开、仿真。未把 oracle 或测试平台发给模型，失败未隐藏重试，也未据此在本轮中途调参。见 [能力探针审计](D:/AMD/output/rtl-diagnostic-guards-20261018/capability-audit.json)。

七题中的三次真实工具拒绝全部是 ON 提前调用 `verify_rtl`，当时 `pending_verification=false`。三次具体反馈均送达，下一次均变为有效 `edit_dut`，最终四阶段通过。这证明这三次流程恢复成立，不证明所有拒绝都能恢复。本批没有实际发生编码器锚点拒绝或注释重放拒绝，其恢复路径仅由离线/模拟测试覆盖。详见 [拒绝恢复审计](D:/AMD/output/rtl-diagnostic-guards-20261018/recovery-effectiveness.json)。

当前题目共有 21 次规划，9 次通过、12 次拒绝，含 6 次恢复；12 次中格式拒绝 6 次、约束拒绝 6 次。编码器 9 个编辑均由其自己提交，审计按原参数重新计算并确认来源和最终文件绑定；其中 8 个达到 RTL 四阶段通过，1 个是 OFF Prob142 的编译阶段改善。三个重点题的六个 arm-run 中，五个在编码器前停止，一个有上述部分改善。减少无效编码调用有一部分是 Host 提前拦截的结果，不能称为模型学会了修复。

## 不能忽略的限制

- 结构化规划沿用了旧文本字段的 CR/LF 禁令，导致多行 `before/after` 即使长度合规也被拒绝。Prob104 ON 两次均受此影响；Prob142 ON 另有 cause 超长。应区分“定位方向合理但协议不合规”和“修改本身违反约束”。本轮冻结后没有修改格式或重跑挑选结果。
- 格式恢复目前只返回通用格式约束，没有逐字段实际长度；事后 [规划格式复核](D:/AMD/output/rtl-diagnostic-guards-20261018/plan-format-review.json) 已列出超限字段，但不是当时模型已收到的反馈。不能宣称所有拒绝类型都完成了同等精度定位。
- enum 检查仅覆盖有限字面量 packed 声明；未知表达式、其他形式显式标记未知，仍交给 EDA。固定接口依赖项目已有解析器与策略，不是完整 SystemVerilog 类型检查。
- 题目和规模均小，未做未见题留出集或统计显著性检验；ON 与 OFF 的相同通过率不能证明 skill 无效，也不能证明其有效。
- 四阶段通过的八个 arm-run 均停在 `NETLIST_ENVIRONMENT_NOT_CALIBRATED`。本地 Vivado 2026.1 与固定 2025.2 unisim 库的三个哈希不一致，未放松该门槛，完整网表验收为 **0/14**。这不应算作 RTL 修改失败，也不应计为正式比赛通过。见 [环境审计](D:/AMD/output/rtl-diagnostic-guards-20261018/netlist-environment-audit.json)。
- 全量类型检查仍有 70 个既存依赖诊断，本轮与前版日志逐字节相同、无新增诊断；不能写成全量 typecheck 通过。技能 Python 校验器因缺 PyYAML 不可用，使用已有 js-yaml 验证 frontmatter、旧技能一致性及正常路由，未联网安装。

## 预算、日志与保全

使用既有 `qwen3-coder-30b` 规划器和 `siliconmind-qwen3-8b` 编码器，8192 上下文、thinking 关闭、temperature=0、top_p=1。两侧相同初始 RTL，交替 ON/OFF 顺序，保护措施完全相同，只有技能选择模式不同。没有重新生成七题初始答案，没有更换模型或直接修 DUT。

本轮是新请求下独立冻结的实验，不是续跑或重置前一轮已过期预算。每侧最多 100 次推理派发、总期限 60 分钟，包含探针；实际 ON 30、OFF 29，共 **59 次模型推理**，其中题目 42 次、探针 17 次。每题仍为两次有效修改、八次编码请求、四个规划绑定、240 秒活动预算；规划格式与约束拒绝共用原来的一次恢复。规划输出 1024、编码输出 2048，未放宽。

42 次题目推理均 HTTP 200、SSE 完整，无超时、截断、上下文超限或未关联调用。题目 token 为输入 104996、输出 5033；探针输入 28023、输出 1748。另有 238 条题目原生 token 计数记录，不能混算为模型推理。新 skill 出现在 17 个题目请求中，OFF 技能泄漏为 0，待验证动作请求不加载技能。详见 [技能与请求审计](D:/AMD/output/rtl-diagnostic-guards-20261018/skill-usage-audit.json) 与 [日志索引](D:/AMD/output/rtl-diagnostic-guards-20261018/LOG_INDEX.md)。

原始模型 `run.json` 中的 42 条 `RUNNING` 标记原样保留，未伪改为完成；终态由任务 `result.json`、HTTP/SSE 传输及驱动退出回执共同判断。六阶段驱动均已回收且 exit=0，临时 SSH 隧道已终止并回收，SSH 配置已恢复原哈希。端口关闭与最终文件核验见 [收尾检查](D:/AMD/output/rtl-diagnostic-guards-20261018/post-run-checks.json) 和 [交付证据核验](D:/AMD/output/rtl-diagnostic-guards-20261018/delivery-verification.json)。

独立源码位于 `D:/AMD/workspaces/rtl-diagnostic-guards-20261018`，输出位于本报告目录。原工程、题库、旧技能/知识库、历史实验及封存交接包均做前后清单/哈希检查，没有覆盖原工程未提交改动，没有更新交接包。[原工程与交接包保全](D:/AMD/output/rtl-diagnostic-guards-20261018/preservation.json)、[补充历史保全](D:/AMD/output/rtl-diagnostic-guards-20261018/additional-history-preservation.json)。

## 后续判断

本轮保留为开发验证证据，不把新技能升级为“已证明提高通过率”的结论。优先单独修正规划中代码字段的多行兼容和逐字段格式拒绝定位，保留原长度与 token 预算，再重新冻结同期对照；不能把本轮被格式挡住的方案事后算作成功。之后再针对 enum 容量推理、固定标量语义和多驱动修改做非目标题留出验证。以上为建议，未在本轮追加执行或消耗模型预算。

"""Check evidence bindings, transport history and artifact integrity without trusting summaries."""
import argparse
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import load, sha


def validate(root):
    checks = []
    def check(name, condition):
        checks.append({'check': name, 'pass': bool(condition)})
    plan = load(root / 'plan.json')
    usage = load(root / 'api-usage.json')
    graph = load(root / 'knowledge/graph.json')
    ids = [n['id'] for n in graph['nodes']]
    check('graph_unique_nodes', len(set(ids)) == len(ids))
    check('graph_no_dangling_edges', all(e['source'] in ids and e['target'] in ids for e in graph['edges']))
    connected = {endpoint for edge in graph['edges'] for endpoint in (edge['source'], edge['target'])}
    check('graph_no_isolated_nodes', set(ids) == connected)
    check('graph_evidence_hashes', all(sha(Path(n['artifact']['path'])) == n['artifact']['sha256']
          for n in graph['nodes'] if 'artifact' in n))
    ET.parse(root / 'knowledge/graph.graphml')
    ET.parse(root / 'knowledge/agent-overview.drawio')
    check('xml_artifacts_parse', True)
    check('bounded_api_requests', usage['chat_requests'] <= plan['max_requests'])
    check('bounded_reported_tokens', usage['total_tokens'] <= plan['max_reported_tokens'])
    check('no_unknown_api_usage', not usage['unknown_usage_attempts'])
    for qid in plan['execution_order']:
        task = root / 'tasks' / qid
        previous = []
        calls = []
        for path in sorted((task / 'api').glob('*/request.json')):
            payload = load(path)
            posthoc = (path.parent / 'purpose.json').exists()
            check(qid + ':' + path.parent.name + ':disabled_thinking_and_fixed_route',
                  payload['model'] == 'deepseek-v4-pro' and payload['thinking'] == {'type': 'disabled'})
            messages = payload['messages']
            if not posthoc:
                check(qid + ':' + path.parent.name + ':history_prefix_preserved', messages[:len(previous)] == previous)
            response = load(path.parent / 'response.json')
            raw = json.dumps(response)
            check(qid + ':' + path.parent.name + ':no_hidden_reasoning_persisted',
                  'reasoning_content' not in raw and '"type": "reasoning"' not in raw)
            if not posthoc:
                check(qid + ':' + path.parent.name + ':native_tool_schemas',
                      {t['function']['name'] for t in payload['tools']} ==
                      {'read_file', 'write_file', 'list_files', 'show_diff', 'evaluate_rtl', 'run_diagnostic', 'finish_task'})
            message = response['choices'][0]['message']
            previous = messages + [{key: message.get(key) for key in ('role', 'content') if key in message} |
                                   ({'tool_calls': message['tool_calls']} if message.get('tool_calls') else {})]
            # Transport removes provider-only per-tool index fields and normalizes empty text to null.
            if previous[-1].get('content') == '':
                previous[-1]['content'] = None
            for call in previous[-1].get('tool_calls', []):
                call.pop('index', None)
            calls += message.get('tool_calls', [])
        operations = list((task / 'operations').glob('*/call.json'))
        check(qid + ':all_executed_tools_requested_by_teacher', len(operations) <= len(calls))
        for path in operations:
            call = load(path)
            check(qid + ':' + path.parent.name + ':tool_call_origin',
                  any(c['function']['name'] == call['name'] and json.loads(c['function']['arguments']) == call['arguments'] for c in calls))
        result_path = task / 'agent-result.json'
        if not result_path.exists():
            check(qid + ':task_completion', False)
            continue
        result = load(result_path)
        check(qid + ':native_agent_complete', result['status'] == 'completed' and not result.get('keyless_preflight_only'))
        session = task / 'session-events.jsonl'
        check(qid + ':native_session_saved', session.is_file() and session.stat().st_size > 0)
        if load(task / 'question.json')['task_type'] != 'harness_scenario':
            current = sha(task / 'work/dut.sv')
            evidence = [load(p) for p in (task / 'operations').glob('*/result.json')]
            for kind in ('frozen_bank_evaluation', 'teacher_authored_public_diagnostic'):
                matches = [e for e in evidence if e.get('kind') == kind and e.get('source_sha256') == current]
                check(qid + ':final_source_bound_to_' + kind, bool(matches))
                for record in matches:
                    raw = load(task / 'operations' / record['evidence_id'] / 'evaluation/results.json')
                    check(qid + ':' + record['evidence_id'] + ':real_tool_source_hashes',
                          all(c['source_sha256'] == current for c in raw['cases']))
                    check(qid + ':' + record['evidence_id'] + ':real_tool_completed', bool(raw.get('finished_at')))
        else:
            check(qid + ':scenario_no_eda_executed', all(load(p)['name'] not in ('evaluate_rtl', 'run_diagnostic') for p in operations))
    completion_suffixes = (':task_completion', ':native_agent_complete', ':final_source_bound_to_frozen_bank_evaluation',
                           ':final_source_bound_to_teacher_authored_public_diagnostic')
    integrity = [c for c in checks if not c['check'].endswith(completion_suffixes)]
    incomplete = [c['check'] for c in checks if not c['pass'] and c['check'].endswith(completion_suffixes)]
    status = 'FAIL' if not all(c['pass'] for c in integrity) else 'PASS_WITH_INCOMPLETE_TASKS' if incomplete else 'PASS'
    save(root / 'run-validation.json', {'status': status, 'checks': checks,
         'scope': 'PROVENANCE_AND_AUTHORITY_CHECKS_NOT_GENERAL_RTL_CORRECTNESS'})
    print(json.dumps({'status': status, 'checks': len(checks), 'failed': [c['check'] for c in checks if not c['pass']]}))
    return status != 'FAIL'


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    raise SystemExit(0 if validate(parser.parse_args().out) else 1)

"""Single no-retry official request, called by a real Harness LLM adapter."""
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import Client, save
from pilot import load


def check_budget(root, directory, payload):
    plan = load(root / 'plan.json')
    budget_roots = plan.get('budget_roots', [str(root)])
    calls = [path for base in budget_roots for path in (Path(base) / 'tasks').glob('*/api/*/reservation.json')]
    total = 0
    task_total = 0
    task_calls = 0
    for reservation in calls:
        receipt = reservation.parent / 'receipt.json'
        response = reservation.parent / 'response.json'
        if not receipt.exists() or not response.exists():
            raise ValueError('Prior API outcome unknown; explicit reconciliation required, no automatic retry')
        usage = load(response).get('usage', {})
        if not isinstance(usage.get('total_tokens'), int):
            raise ValueError('Prior usage unavailable; stop rather than assume zero')
        total += usage['total_tokens']
        if reservation.parent.parent.parent == directory.parent.parent:
            task_calls += 1
            task_total += usage['total_tokens']
    if len(calls) >= plan['max_requests']:
        raise ValueError('Approved request budget exhausted')
    # UTF-8 bytes provide a deliberately conservative reservation, not a tokenizer estimate.
    reservation = len(json.dumps(payload, ensure_ascii=False).encode('utf-8')) + payload['max_tokens']
    limit = plan['max_reported_tokens']
    policy = root / 'budget-policy.json'
    if payload.get('tools') and policy.exists():
        limit -= load(policy)['reserve_for_failure_reflection']
    if total + reservation > limit:
        raise ValueError('Approved token budget has insufficient conservative reservation for the next call')
    task_limit = plan.get('task_limits', {}).get(directory.parent.parent.name)
    if task_limit and (task_calls >= task_limit['requests'] or task_total + reservation > task_limit['tokens']):
        raise ValueError('Per-task approved budget has insufficient conservative reservation; other allocations cannot be borrowed')
    return {'previous_actual_tokens': total, 'reserved_upper_bound': reservation,
            'call_number': len(calls) + 1, 'previous_task_tokens': task_total, 'task_call_number': task_calls + 1}


def run(root, directory, payload):
    save(directory / 'reservation.json', check_budget(root, directory, payload))
    save(directory / 'request.json', payload)
    client = Client(direct=True)
    client.opener.addheaders = list(load(directory / 'attribution-headers.json').items())
    try:
        value, receipt = client.request('/chat/completions', payload)
        filtered = {key: value.get(key) for key in ('id', 'model', 'created', 'usage')}
        filtered['choices'] = []
        for choice in value.get('choices', []):
            message = choice.get('message', {})
            filtered['choices'].append({'index': choice.get('index'), 'finish_reason': choice.get('finish_reason'),
                'message': {key: message[key] for key in ('role', 'content', 'tool_calls') if key in message}})
        receipt['persisted_response_is_filtered'] = True
        receipt['thinking_requested'] = 'disabled'
        save(directory / 'response.json', filtered)
        save(directory / 'receipt.json', receipt)
        print(json.dumps(filtered, ensure_ascii=False))
    except Exception as error:
        save(directory / 'failure.json', {'error': client.clean(error), 'automatic_retry': False,
                                        'charged_status': 'unknown_unless_provider_confirms'})
        raise


if __name__ == '__main__':
    root, directory, payload = map(Path, sys.argv[1:])
    run(root, directory, load(payload))

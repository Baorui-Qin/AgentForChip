"""Local developer TB regressions, not API repairs and never inherited by fresh tasks."""
import argparse
from pathlib import Path
import shutil
from task_tools import execute, save, put, load, sha

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=False)
base = Path('D:/AMD/output/rtl-api-distillation-20261017')
checks = []
for qid in ('Q114', 'Q193'):
    for source in ('original', 'previous_model_candidate'):
        task = args.out / source / qid
        work = task / 'work'
        work.mkdir(parents=True)
        q = load(base / 'pilot-01/questions' / (qid + '.json'))
        save(task / 'question.json', q)
        if source == 'original':
            put(work / 'dut.sv', q['starter_code'])
        else:
            shutil.copyfile(base / 'agent-knowledge-02/tasks' / qid / 'work/dut.sv', work / 'dut.sv')
        shutil.copyfile(Path(__file__).parent / 'fixtures' / (qid.lower() + '_protocol_tb.sv'), work / 'diag_tb.sv')
        result = execute(task, 1, 'run_diagnostic', {})
        expected = 'simulate_failed' if source == 'original' else 'simulation_pass'
        checks.append({'task': qid, 'source': source, 'expected': expected, 'result': result,
                       'tb_sha256': sha(work / 'diag_tb.sv'), 'passed': result['cases'][0]['status'] == expected})
        print(qid, source, result['cases'][0]['status'], flush=True)
save(args.out / 'validation.json', {'api_requests': 0, 'developer_regression_only': True, 'checks': checks})
assert all(c['passed'] for c in checks)

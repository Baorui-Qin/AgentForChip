"""Real Vivado regression of diagnostic failure propagation; no model/API calls."""
import argparse
from pathlib import Path
import shutil

from task_tools import execute, save, put


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    root = args.out
    root.mkdir(parents=True, exist_ok=False)
    results = []
    for name, fail in [('positive', False), ('printed_failure', True), ('prior_false_pass', True)]:
        task = root / name / ('Q083' if name == 'prior_false_pass' else 'Q010')
        work = task / 'work'
        work.mkdir(parents=True)
        save(task / 'question.json', {'task_type': 'rtl_generation'})
        if name == 'prior_false_pass':
            old = Path('D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-01/tasks/Q083/work')
            for file in ('dut.sv', 'diag_tb.sv'):
                shutil.copyfile(old / file, work / file)
        else:
            put(work / 'dut.sv', 'module top_module(input a, output y); assign y=a; endmodule\n')
            body = '$display("FAIL: deliberately failing host regression");' if fail else 'if(y !== 1) $fatal(1,"incorrect output");'
            put(work / 'diag_tb.sv', 'module tb(output reg done); reg a=0; wire y; top_module dut(a,y);\n'
                'initial begin done=0; #2; a=1; #2; ' + body + ' done=1; end endmodule\n')
        result = execute(task, 1, 'run_diagnostic', {})
        case = result['cases'][0]
        expected = 'simulate_failed' if fail else 'simulation_pass'
        assert case['status'] == expected, result
        if fail:
            assert case['raw_evaluator_status'] == 'simulation_pass', result
            assert case['failure_line_count'] > 0 and any('FAIL' in s for s in case['diagnostics']), result
        results.append({'name': name, 'expected': expected, 'actual': result, 'passed': True})
    save(root / 'validation.json', {'real_eda': True, 'api_requests': 0, 'checks': results,
        'scope': 'Host failure propagation, not testbench completeness or model correctness'})
    print('Three real Vivado regressions passed, including replay of the preserved false-pass diagnostic.')


if __name__ == '__main__':
    main()

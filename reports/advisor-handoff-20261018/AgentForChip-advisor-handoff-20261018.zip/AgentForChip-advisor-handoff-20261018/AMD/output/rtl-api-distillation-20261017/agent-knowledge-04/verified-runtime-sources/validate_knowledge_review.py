"""Validate the independent review against recorded evidence; no API calls."""

import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, required=True)
    args = parser.parse_args()
    root = args.run.resolve()
    evidence = read(root / "knowledge-use-audit/evidence.json")
    review = read(root / "knowledge-use-review.json")
    graph = read(root / "knowledge-use-audit/graph.json")
    checks = []

    def check(name, passed):
        checks.append({"check": name, "passed": bool(passed)})

    tasks = evidence["tasks"]
    contexts = [c for t in tasks for c in t["contexts"]]
    delivered = [c for c in contexts if c["actual_requests"]]
    lookups = [q for t in tasks for q in t["lookups"]]
    cases = [c for t in tasks if t["final_bank"] for c in t["final_bank"]["cases"]]
    counts = {
        "tasks": len(tasks),
        "completed": sum(t["agent_status"] == "completed" for t in tasks),
        "manual_lookups": sum(t["manual_lookups"] for t in tasks),
        "automatic_lookups": sum(t["automatic_lookups"] for t in tasks),
        "hit_events_including_duplicates_and_irrelevant": sum(bool(q["matched"]) for q in lookups),
        "no_match_events": sum(not q["matched"] for q in lookups),
        "prepared_contexts": len(contexts),
        "delivered_contexts": len(delivered),
        "delivered_rule_ids": len({r for c in delivered for r in c["rules"]}),
        "tasks_with_delivered_context": sum(any(c["actual_requests"] for c in t["contexts"]) for t in tasks),
        "operations": sum(len(t["operations"]) for t in tasks),
        "eda_operations": sum(o["name"] in ("evaluate_rtl", "run_diagnostic") for t in tasks for o in t["operations"]),
        "frozen_configurations_tested": len(cases),
        "frozen_configurations_passed": sum(c["status"] == "synthesis_pass" for c in cases),
        "dut_changes": sum(t["source_changed_from_seed"] for t in tasks if not t["scenario_text_only"]),
    }
    expected = [12, 7, 49, 1, 19, 31, 10, 9, 13, 7, 48, 14, 13, 12, 0]
    for (name, value), target in zip(counts.items(), expected, strict=True):
        check(name, value == target)
    check("api_usage", evidence["usage"] == {"requests": 88, "prompt_tokens": 566361, "completion_tokens": 7820, "total_tokens": 574181})
    check("prior_integrity_audit", evidence["integrity_passed"] and len(evidence["checks"]) == 604)
    check("review_task_coverage", sorted(t["id"] for t in tasks) == sorted(t["id"] for t in review["tasks"]))
    check("review_no_gain_claim", review["causal_skill_gain_established"] is False and review["new_verified_dut_repairs"] == 0)
    for task in review["tasks"]:
        for rel in task["evidence"]:
            check(f"review_link:{rel}", (root / rel).is_file())
    ids = {n["id"] for n in graph["nodes"]}
    check("graph_counts", len(ids) == len(graph["nodes"]) == 645 and len(graph["edges"]) == 852)
    for i, edge in enumerate(graph["edges"]):
        check(f"edge:{i}", edge["source"] in ids and edge["target"] in ids)
    for node in graph["nodes"]:
        artifact = node.get("artifact")
        if artifact:
            path = Path(artifact["path"])
            check(f"graph_artifact:{node['id']}", path.is_file() and digest(path) == artifact["sha256"])
    ns = {"g": "http://graphml.graphdrawing.org/xmlns"}
    xml = ET.parse(root / "knowledge-use-audit/graph.graphml")
    check("graphml_counts", len(xml.findall(".//g:node", ns)) == 645 and len(xml.findall(".//g:edge", ns)) == 852)
    report = root / "RUN_REPORT.md"
    for path in re.findall(r"\]\((D:/[^)]+)\)", report.read_text(encoding="utf-8")):
        check(f"report_link:{path}", Path(path).exists())
    files = [report, root / "knowledge-use-review.json", root / "review-protocol.json",
             root / "knowledge-use-audit/evidence.json", root / "knowledge-use-audit/graph.json",
             root / "knowledge-use-audit/graph.graphml", root / "preservation.json", Path(__file__).resolve()]
    result = {"scope": "REPORT_AND_PROVENANCE_VALIDATION_NOT_BEHAVIORAL_SUCCESS",
              "passed": all(c["passed"] for c in checks), "counts": counts,
              "usage": evidence["usage"], "checks": checks,
              "artifacts": [{"path": str(p), "sha256": digest(p)} for p in files]}
    output = root / "review-validation.json"
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    print(json.dumps({"passed": result["passed"], "checks": len(checks), "counts": counts,
                      "failed": [c for c in checks if not c["passed"]]}, ensure_ascii=False))
    raise SystemExit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()

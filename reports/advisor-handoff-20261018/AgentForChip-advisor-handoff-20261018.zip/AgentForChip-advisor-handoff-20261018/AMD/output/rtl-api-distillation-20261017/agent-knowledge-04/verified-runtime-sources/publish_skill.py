"""Publish only explicitly reviewed teacher rules; keep case provenance outside model context."""
import argparse
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import load, put, sha
from build_report import graphml


ENTRY = '''---
name: rtl-agent-correction
description: Diagnose and repair RTL through a tool-using edit-test loop, investigate DUT versus testbench failures, and retain source-bound verification evidence. Use for RTL debugging and verification, not for altering private evaluators or treating simulation as CDC sign-off.
---

# RTL Agent Correction

Use the available task tools to perform the correction, not merely propose one. Respect the granted file and command scope.

## Diagnose Before Editing

- Distinguish compiler errors, functional mismatches, testbench races, evaluator/specification conflicts, infrastructure failures and output truncation. A tool failure is not automatically a DUT failure.
- Reproduce a concrete failure before changing the relevant logic. If a candidate already passes, inspect and test it without gratuitous rewriting.
- For an independent testbench, respect valid/ready input stability and sample the specified pre-edge or post-NBA values. Check its driver and scoreboard scheduling before attributing a mismatch to the DUT.
- Read only the relevant conditional rules in [references/rules.json](references/rules.json). Their evidence strength and caveats are part of the rule, not optional footnotes.

## Execute And Verify

- Record each actual tool call and returned diagnostic. Preserve the before/after diff and source hash for each edit. Equal hashes mean no repair occurred; do not count repeated identical writes as progress.
- Run the necessary compile, elaboration, functional simulation and synthesis stages on the final source. Bind results to source, test/configuration and tool version. An earlier revision's pass does not transfer to a later revision.
- Keep independently written diagnostics separate from frozen evaluation. Preserve evaluator conflicts and failures rather than editing the oracle or overfitting excluded behavior.
- On repeated no-progress actions, unavailable tools or incomplete provider output, stop or request a bounded continuation. Do not silently repeat a possibly charged request or claim a truncated action executed.

## Summarize The Actual Correction

State the observed symptom, edits actually made, verification performed and remaining limits. Separate model-authored explanations from developer review and confirmed tool results.

Digital simulation and synthesis do not prove metastability safety, physical CDC closure, mathematical correctness or skill gains on new tasks. A self-authored test is finite supporting evidence, not an independent reference solution.

Keep reusable rules conditional and solution-free. Case IDs, previous answers, private vectors and full provenance graphs belong outside the next solver's skill context.
'''


def publish(root, destination):
    proposals = load(root / 'teacher-rule-proposals.json')['rules']
    review = load(root / 'developer-review.json')
    accepted = {item['id']: item for item in review['rules'] if item['disposition'] == 'accept_with_limits'}
    rules = []
    for rule in proposals:
        if rule['id'] not in accepted:
            continue
        selected = {key: value for key, value in rule.items() if key != 'status'}
        selected.update(accepted[rule['id']].get('revised_fields', {}))
        selected['review_note'] = accepted[rule['id']]['note']
        rules.append(selected)
    if not rules:
        raise ValueError('No teacher rule has been explicitly reviewed for publication')
    if re.search(r'\bQ\d{3}\b|module\s+top_module|D:[/\\]', __import__('json').dumps(rules)):
        raise ValueError('Case-specific data in model-visible catalog')
    destination.mkdir(parents=True, exist_ok=False)
    put(destination / 'SKILL.md', ENTRY)
    save(destination / 'references/rules.json', {'scope': 'REVIEWED_CONDITIONAL_TEACHER_RULES_NOT_GENERAL_PROOFS', 'rules': rules})
    manifest = {'skill': str(destination), 'entry_sha256': sha(destination / 'SKILL.md'),
         'rules_sha256': sha(destination / 'references/rules.json'), 'published_rules': len(rules),
         'entry_author': 'Codex, based on observed workflow failures and guard corrections',
         'rule_author': 'DeepSeek visible finish_task reports and separately labeled failure reflection; reviewed and where recorded generalized by Codex',
         'global_installation': False, 'student_gain_tested': False}
    save(root / 'skill-manifest.json', manifest)
    graph_path = root / 'knowledge/graph.json'
    original = load(graph_path)
    nodes, edges = original['nodes'], original['edges']
    nodes.append({'id': 'developer-review', 'kind': 'DeveloperRuleReview',
                  'artifact': {'path': str(root / 'developer-review.json'), 'sha256': sha(root / 'developer-review.json')}})
    nodes.append({'id': 'published-skill', 'kind': 'PublishedSkill',
                  'artifact': {'path': str(destination / 'SKILL.md'), 'sha256': manifest['entry_sha256']}})
    edges.append({'source': 'proposals', 'target': 'developer-review', 'relationship': 'reviewed_before_publication'})
    for item in review['rules']:
        edges.append({'source': item['id'], 'target': 'developer-review',
                      'relationship': 'accepted_with_limits' if item['disposition'] == 'accept_with_limits' else 'excluded_from_skill'})
    audit = root / 'teacher-claim-audit.json'
    if audit.exists():
        nodes.append({'id': 'teacher-claim-audit', 'kind': 'DeveloperAuditOfTeacherClaims',
                      'artifact': {'path': str(audit), 'sha256': sha(audit)}})
        edges.append({'source': 'Q123:summary', 'target': 'teacher-claim-audit', 'relationship': 'contains_rejected_unverified_claims'})
        edges.append({'source': 'teacher-claim-audit', 'target': 'developer-review', 'relationship': 'constrains_rule_publication'})
    for rule in rules:
        edges.append({'source': rule['id'], 'target': 'published-skill', 'relationship': 'conditionally_included'})
    edges.append({'source': 'developer-review', 'target': 'published-skill', 'relationship': 'authorizes_selected_rules'})
    save(root / 'knowledge/published-graph.json', {**original, 'nodes': nodes, 'edges': edges})
    graphml(root / 'knowledge/published-graph.graphml', nodes, edges)
    print(manifest)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--skill', type=Path, required=True)
    args = parser.parse_args()
    publish(args.out, args.skill)

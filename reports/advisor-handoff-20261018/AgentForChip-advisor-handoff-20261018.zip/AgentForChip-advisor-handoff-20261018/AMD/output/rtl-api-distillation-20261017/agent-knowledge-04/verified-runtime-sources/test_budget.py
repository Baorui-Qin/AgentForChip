import json
from pathlib import Path
import tempfile
import unittest
from api_worker import check_budget
from task_tools import execute


class BudgetTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.directory = self.root / 'tasks/Q123/api/002'
        self.directory.mkdir(parents=True)
        self.plan = {'max_requests': 80, 'max_reported_tokens': 900000,
                     'task_limits': {'Q123': {'requests': 22, 'tokens': 260000, 'eda': 7}},
                     'reserved_closing_calls': 3}
        self.payload = {'max_tokens': 6000, 'messages': []}
        self.save_plan()

    def tearDown(self):
        self.temp.cleanup()

    def save_plan(self):
        (self.root / 'plan.json').write_text(json.dumps(self.plan))

    def receipt(self, qid, number, tokens, complete=True):
        directory = self.root / 'tasks' / qid / 'api' / f'{number:03d}'
        directory.mkdir(parents=True, exist_ok=True)
        (directory / 'reservation.json').write_text('{}')
        if complete:
            (directory / 'receipt.json').write_text('{}')
            (directory / 'response.json').write_text(json.dumps({'usage': {'total_tokens': tokens}}))

    def test_task_and_global_usage_are_separate(self):
        self.receipt('Q123', 1, 9000)
        self.receipt('Q155', 1, 10000)
        value = check_budget(self.root, self.directory, self.payload)
        self.assertEqual((value['previous_actual_tokens'], value['previous_task_tokens']), (19000, 9000))
        self.assertEqual((value['call_number'], value['task_call_number']), (3, 2))

    def test_task_cannot_borrow_unused_other_budget(self):
        self.receipt('Q123', 1, 255000)
        with self.assertRaisesRegex(ValueError, 'Per-task approved budget'):
            check_budget(self.root, self.directory, self.payload)

    def test_unknown_prior_outcome_stops_all_tasks(self):
        self.receipt('Q155', 1, 0, False)
        with self.assertRaisesRegex(ValueError, 'outcome unknown'):
            check_budget(self.root, self.directory, self.payload)

    def test_task_request_cap(self):
        self.plan['task_limits']['Q123']['requests'] = 1
        self.save_plan()
        self.receipt('Q123', 1, 1000)
        with self.assertRaisesRegex(ValueError, 'Per-task approved budget'):
            check_budget(self.root, self.directory, self.payload)

    def test_global_request_and_token_caps(self):
        self.receipt('Q155', 1, 1000)
        for key, value in [('max_requests', 1), ('max_reported_tokens', 1001)]:
            old = self.plan[key]
            self.plan[key] = value
            self.save_plan()
            with self.assertRaises(ValueError):
                check_budget(self.root, self.directory, self.payload)
            self.plan[key] = old

    def test_closing_phase_rejects_and_records_edit(self):
        task = self.root / 'tasks/Q123'
        (task / 'work').mkdir()
        (task / 'question.json').write_text('{"task_type":"rtl_generation"}')
        self.plan['task_limits']['Q123']['requests'] = 4
        self.save_plan()
        self.receipt('Q123', 1, 1)
        self.receipt('Q123', 2, 1)
        result = execute(task, 1, 'write_file', {'path': 'dut.sv', 'content': 'module top_module; endmodule'})
        self.assertTrue(result['operation_rejected'])
        self.assertFalse((task / 'work/dut.sv').exists())
        self.assertTrue((task / 'operations/001/result.json').exists())

    def test_approved_allocations(self):
        limits = json.loads((Path(__file__).parent / 'round4-limits.json').read_text())
        self.assertEqual(sum(v['requests'] for v in limits.values()), 80)
        self.assertEqual(sum(v['tokens'] for v in limits.values()), 900000)
        self.assertEqual(sum(v['eda'] for v in limits.values()) + 7, 34)


if __name__ == '__main__':
    unittest.main()

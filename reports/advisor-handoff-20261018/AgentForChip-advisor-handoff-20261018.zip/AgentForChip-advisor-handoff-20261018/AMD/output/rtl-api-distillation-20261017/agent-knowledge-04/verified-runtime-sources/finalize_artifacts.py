"""Finalize derived metadata only; never changes model requests, responses, sessions or EDA evidence."""
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from build_report import graphml
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import load, sha

root = Path(sys.argv[1])
catalog = root / 'teacher-rule-proposals.json'
value = load(catalog)
value['authorship'] = 'DeepSeek visible finish_task reports and separately labeled posthoc failure reflection'
catalog.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
checks = []
for name in ('graph', 'published-graph'):
    path = root / 'knowledge' / (name + '.json')
    graph = load(path)
    for node in graph['nodes']:
        if 'artifact' in node:
            node['artifact']['sha256'] = sha(Path(node['artifact']['path']))
    path.write_text(json.dumps(graph, ensure_ascii=False, indent=2), encoding='utf-8')
    graphml(path.with_suffix('.graphml'), graph['nodes'], graph['edges'], overwrite=True)
    ids = [node['id'] for node in graph['nodes']]
    assert len(ids) == len(set(ids))
    assert all(edge['source'] in ids and edge['target'] in ids for edge in graph['edges'])
    assert {endpoint for edge in graph['edges'] for endpoint in (edge['source'], edge['target'])} == set(ids)
    assert all(sha(Path(node['artifact']['path'])) == node['artifact']['sha256'] for node in graph['nodes'] if 'artifact' in node)
    ET.parse(path.with_suffix('.graphml'))
    checks.append({'graph': name, 'nodes': len(ids), 'edges': len(graph['edges']), 'all_evidence_hashes_match': True,
                   'unique_nodes': True, 'no_dangling_edges': True, 'no_isolated_nodes': True, 'graphml_parsed': True})
source = Path(__file__).resolve().parent
save(root / 'final-source-manifest.json', {p.name: sha(p) for p in source.iterdir() if p.is_file()})
save(root / 'final-artifact-validation.json', {'status': 'PASS', 'graphs': checks,
     'native_run_validation': load(root / 'run-validation.json')['status'],
     'official_skill_validator': 'NOT_RUN_SUCCESSFULLY: ModuleNotFoundError yaml',
     'alternative_skill_validation': load(root / 'skill-validation.json'),
     'raw_evidence_modified': False,
     'limitations': ['Incomplete native tasks remain incomplete', 'No behavioral student-gain test',
                     'Drawio XML structurally validated but not visually rendered',
                     'Historical controller revisions have hashes, not full source snapshots']})
print(json.dumps(checks))

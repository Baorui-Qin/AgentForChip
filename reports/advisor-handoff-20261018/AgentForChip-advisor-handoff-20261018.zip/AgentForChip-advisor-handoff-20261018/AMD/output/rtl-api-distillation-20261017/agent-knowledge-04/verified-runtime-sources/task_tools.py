"""Allowlisted task files and real EDA operations; private evaluator assets never leave here."""
import difflib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import BANK, IDS, LICENSE, VIVADO, extract, load, put, sha

FILES = {'prompt.md', 'previous-answer.md', 'initial-evidence.json', 'dut.sv', 'diag_tb.sv', 'answer.md'}
WRITABLE = {'dut.sv', 'diag_tb.sv', 'answer.md'}
ALLOWED_TASKS = {'display', 'write', 'fatal', 'finish', 'error', 'signed', 'unsigned', 'clog2', 'bits',
                 'size', 'left', 'right', 'low', 'high', 'countones', 'onehot', 'onehot0', 'isunknown',
                 'random', 'urandom', 'urandom_range', 'time', 'realtime'}


FAILURE_LINE = re.compile(r'^\s*(?:FAIL(?:ED|URE)?\b|FATAL\b|ERROR\b|ASSERT(?:ION)?[_ -]*(?:FAIL|ERROR))', re.I)


def clean_log(text, public_diagnostic=False):
    lines = [line for line in text.splitlines() if re.match(r'ERROR:|WARNING:|Fatal:|Error:', line)
             or (public_diagnostic and FAILURE_LINE.search(line))]
    return [re.sub(r'[A-Za-z]:[/\\][^\]\n]*?(?=:\d+\]|"|$)', '<local-file>', line)[:600]
            for line in lines[:12]]


def prepare(root, initial, ids=IDS, original=False):
    root.mkdir(parents=True, exist_ok=False)
    for qid in ids:
        task = root / 'tasks' / qid
        work = task / 'work'
        work.mkdir(parents=True)
        q = load(initial / 'questions' / (qid + '.json'))
        save(task / 'question.json', q)
        put(work / 'prompt.md', q['prompt'])
        if original:
            if q['task_type'] == 'harness_scenario':
                source = (initial / 'answers' / qid / 'initial/answer.txt').read_text(encoding='utf-8')
                put(work / 'answer.md', source)
                origin, baseline = 'first_api_scenario_answer', False
            elif q['task_type'] == 'rtl_repair':
                source = q['starter_code']
                put(work / 'dut.sv', source)
                origin, baseline = 'public_original_buggy_starter', True
            elif qid in ('Q123', 'Q163'):
                source = (initial / 'candidates-initial' / qid / 'dut.sv').read_text(encoding='utf-8')
                put(work / 'dut.sv', source)
                origin, baseline = 'first_api_candidate_never_repaired', True
            else:
                source = ''
                put(work / 'dut.sv', source)
                origin, baseline = 'empty_generation_candidate', False
            put(work / 'previous-answer.md', source)
            save(work / 'initial-evidence.json', {'kind': 'original_input_not_current_validation', 'origin': origin,
                 'baseline_evaluation_required_before_edit': baseline,
                 'notice': 'No previous repair, testbench or evaluation has been inherited. Diagnose and validate with tools in this run.'})
            save(task / 'start-state.json', {'origin': origin, 'baseline_required': baseline})
            shutil.copytree(work, task / 'seed')
            save(task / 'seed-manifest.json', {p.name: sha(p) for p in work.iterdir()})
            continue
        shutil.copyfile(initial / 'answers' / qid / 'initial/answer.txt', work / 'previous-answer.md')
        if q['task_type'] == 'harness_scenario':
            review = next(item for item in load(initial / 'scenario-review.json')['questions'] if item['id'] == qid)
            save(work / 'initial-evidence.json', {'kind': 'developer_text_review_not_execution', 'review': review})
        else:
            shutil.copyfile(initial / 'candidates-initial' / qid / 'dut.sv', work / 'dut.sv')
            cases = [c for c in load(initial / 'evaluation-initial-host/results.json')['cases'] if c['id'] == qid]
            evidence = {'kind': 'prior_real_vivado_evaluation', 'cases': [
                {key: case.get(key) for key in ('variant', 'parameters', 'status', 'source_sha256')} for case in cases]}
            if qid == 'Q123':
                log = initial / 'evaluation-initial-host/Q123/default/compile.log'
                evidence['compiler_diagnostics'] = clean_log(log.read_text())
            if qid == 'Q163':
                evidence['developer_contract_audit'] = (
                    'Prior failure concerns a combinational ready comparison while reset is asserted. '
                    'The common public convention excludes unspecified reset-time ready. '
                    'This is a suspected evaluator/specification conflict, not permission to change the evaluator. '
                    'Independently inspect the public specification and test it. Frozen failure must remain a failure.')
            save(work / 'initial-evidence.json', evidence)
        save(task / 'seed-manifest.json', {p.name: sha(p) for p in work.iterdir()})


def validate_tb(text):
    code = re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S)
    if re.search(r'`(include|define)|\b(import|export|force|release|bind)\b', code):
        raise ValueError('Testbench external dependencies and foreign access are forbidden')
    if set(re.findall(r'\$([A-Za-z_][A-Za-z0-9_]*)', code)) - ALLOWED_TASKS:
        raise ValueError('Testbench contains a non-allowlisted system function/task')
    if len(re.findall(r'\bmodule\s+tb\b', code)) != 1 or re.search(r'\bmodule\s+top_module\b', code):
        raise ValueError('Diagnostic must define tb(output done), and must not redefine the DUT')


def environment():
    return {key: value for key, value in os.environ.items()
            if not re.search(r'KEY|SECRET|TOKEN|PASSWORD|PROXY', key, flags=re.I)}


def evaluate(task, directory, diagnostic):
    work = task / 'work'
    extract((work / 'dut.sv').read_text(encoding='utf-8'), 'stop')
    candidates = directory / 'candidates' / task.name
    candidates.mkdir(parents=True)
    shutil.copyfile(work / 'dut.sv', candidates / 'dut.sv')
    evaluator = BANK / 'tools/evaluate.mjs'
    tb_sha = None
    if diagnostic:
        tb = (work / 'diag_tb.sv').read_text(encoding='utf-8')
        validate_tb(tb)
        bank = directory / 'diagnostic-bank'
        (bank / 'tools').mkdir(parents=True)
        shutil.copyfile(evaluator, bank / 'tools/evaluate.mjs')
        (bank / 'cases').mkdir()
        shutil.copyfile(work / 'diag_tb.sv', bank / 'cases/tb.sv')
        tb_sha = sha(work / 'diag_tb.sv')
        save(bank / 'metadata/full_cases.json', {'part': 'xczu3eg-sbva484-1-e', 'cases': [
            {'id': task.name, 'variant': 'teacher_public_diagnostic', 'directory': 'cases', 'parameters': {}, 'clocks': []}]})
        evaluator = bank / 'tools/evaluate.mjs'
    argv = [shutil.which('node'), str(evaluator), '--vivado-bin', str(VIVADO), '--license-file', str(LICENSE),
            '--candidate-dir', str(candidates.parent), '--ids', task.name, '--work-dir', str(directory / 'evaluation'),
            '--stage-seconds', '120', '--synth-jobs', '2']
    if diagnostic:
        argv.append('--no-synth')
    start = time.monotonic()
    with (directory / 'process.log').open('xb') as log:
        process = subprocess.run(argv, cwd=directory, env=environment(), stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    save(directory / 'process.json', {'argv': argv, 'exit_code': process.returncode, 'reaped': True,
                                     'seconds': time.monotonic() - start})
    result_file = directory / 'evaluation/results.json'
    if not result_file.exists():
        return {'kind': 'infrastructure_failure', 'exit_code': process.returncode,
                'diagnostics': clean_log((directory / 'process.log').read_text(errors='replace')),
                'evidence_id': directory.name}
    raw = load(result_file)
    cases = []
    for case in raw['cases']:
        item = {key: case.get(key) for key in ('variant', 'parameters', 'status', 'source_sha256', 'testbench_sha256')}
        item['diagnostics'] = []
        printed_failures = []
        for stage in case.get('stages', []):
            # Private simulation logs may contain hidden input/output vectors. Never send them.
            if diagnostic or stage['tool'] in ('xvlog', 'xelab'):
                log_text = (directory / 'evaluation' / stage['log']).read_text(errors='replace')
                item['diagnostics'] += clean_log(log_text, diagnostic)
                if diagnostic:
                    printed_failures.extend(line for line in log_text.splitlines() if FAILURE_LINE.search(line))
        if diagnostic:
            item['raw_evaluator_status'] = item['status']
            item['failure_line_count'] = len(printed_failures)
            if printed_failures and item['status'] in ('simulation_pass', 'synthesis_pass', 'simulate_pass'):
                item['status'] = 'simulate_failed'
                item['status_override_reason'] = 'Public diagnostic printed failure; completion marker cannot override failure.'
        cases.append(item)
    return {'kind': 'teacher_authored_public_diagnostic' if diagnostic else 'frozen_bank_evaluation',
            'source_sha256': sha(work / 'dut.sv'), 'testbench_sha256': tb_sha,
            'cases': cases, 'tool_version': raw['version'], 'evidence_id': directory.name,
            'private_test_contents_disclosed': False,
            'note': 'Finite diagnostic only; not bank acceptance or CDC sign-off.' if diagnostic else
                    'Frozen tests unchanged; functional mismatch values withheld. No official competition claim.'}


def evidence_summary(task, report):
    """Generate change/verification claims from the operation ledger, not model prose."""
    required = {'diagnosis', 'remaining', 'rules', 'change_operations', 'verification_operations'}
    if set(report) != required or not all(isinstance(report[k], str) for k in ('diagnosis', 'remaining')):
        raise ValueError('Report requires diagnosis/remaining/rules/change_operations/verification_operations; correction and verification prose are host-generated')
    if not isinstance(report['rules'], list) or not 1 <= len(report['rules']) <= 4:
        raise ValueError('Provide 1-4 conditional rules')
    for rule in report['rules']:
        if set(rule) != {'trigger', 'action', 'check', 'caveat'} or not all(isinstance(v, str) for v in rule.values()):
            raise ValueError('Each rule needs trigger/action/check/caveat strings')
        if re.search(r'\bQ\d{3}\b|module\s+top_module|[A-Z]:[/\\]', json.dumps(rule)):
            raise ValueError('Reusable rules must not contain task IDs, solutions or local paths')
    rows = [(p.parent.name, load(p)) for p in sorted((task / 'operations').glob('*/result.json'))]
    changes = {op: value for op, value in rows if value.get('path') in WRITABLE
               and 'previous_sha256' in value and not value.get('no_change')}
    for field in ('change_operations', 'verification_operations'):
        ids = report[field]
        if not isinstance(ids, list) or not all(isinstance(v, str) for v in ids) or len(ids) != len(set(ids)):
            raise ValueError(field + ' must contain unique operation ID strings')
    if set(report['change_operations']) != set(changes):
        raise ValueError('Change claims do not match actual non-identical writes: ' + ','.join(changes))
    scenario = load(task / 'question.json')['task_type'] == 'harness_scenario'
    primary = 'answer.md' if scenario else 'dut.sv'
    final_sha = sha(task / 'work' / primary)
    seed = load(task / 'seed-manifest.json').get(primary)
    final_tests = {}
    if not scenario:
        tb_sha = sha(task / 'work/diag_tb.sv')
        for op, value in rows:
            kind = value.get('kind')
            if kind in ('frozen_bank_evaluation', 'teacher_authored_public_diagnostic') and value.get('source_sha256') == final_sha:
                if kind == 'teacher_authored_public_diagnostic' and value.get('testbench_sha256') != tb_sha:
                    continue
                if value.get('cases'):
                    final_tests[kind] = {'operation': op, **value}
        if len(final_tests) != 2:
            raise ValueError('Run both frozen evaluation and diagnostic on final DUT and current TB before finishing')
    if set(report['verification_operations']) != {v['operation'] for v in final_tests.values()}:
        raise ValueError('Verification IDs must be the latest final-source/current-TB results: ' +
                         ','.join(v['operation'] for v in final_tests.values()))
    baselines = [v for _, v in rows if v.get('kind') == 'frozen_bank_evaluation' and v.get('source_sha256') == seed]
    baseline_failed = any(c['status'] in ('compile_failed', 'elaborate_failed', 'simulate_failed', 'synthesis_failed')
                          for v in baselines for c in v.get('cases', []))
    final_pass = bool(final_tests) and all(c['status'] in ('synthesis_pass', 'simulation_pass', 'simulate_pass')
                                        for v in final_tests.values() for c in v['cases'])
    audit = {'primary_file': primary, 'seed_sha256': seed, 'final_sha256': final_sha,
             'net_source_change': seed != final_sha, 'changes': changes, 'final_tests': final_tests,
             'baseline_failure_observed': baseline_failed,
             'new_repair_chain_verified': not scenario and baseline_failed and seed != final_sha and final_pass,
             'final_tests_passed': final_pass, 'knowledge_adoption': 'REQUIRES_INDEPENDENT_TRAJECTORY_REVIEW'}
    summary = {'diagnosis': report['diagnosis'],
               'correction': json.dumps({'host_verified_writes': changes, 'net_source_change': seed != final_sha}, ensure_ascii=False),
               'verification': json.dumps(final_tests, ensure_ascii=False), 'remaining': report['remaining'], 'rules': report['rules'],
               'narrative_status': 'Model diagnosis/remaining/rules are proposals; change and test facts are generated by host.'}
    return summary, audit


def execute(task, number, name, args):
    directory = task / 'operations' / f'{number:03d}'
    directory.mkdir(parents=True, exist_ok=False)
    save(directory / 'call.json', {'name': name, 'arguments': args})
    q = load(task / 'question.json')
    scenario = q['task_type'] == 'harness_scenario'
    try:
        if (task / 'teacher-summary.json').exists():
            raise ValueError('Task already finalized; no queued operation may change accepted evidence')
        if name == 'list_files':
            result = {'files': sorted(p.name for p in (task / 'work').iterdir() if p.name in FILES)}
        elif name == 'read_file':
            if set(args) != {'path'} or args['path'] not in FILES:
                raise ValueError('Only named task files are readable')
            file = task / 'work' / args['path']
            result = {'path': file.name, 'sha256': sha(file), 'content': file.read_text(encoding='utf-8')}
        elif name == 'write_file':
            plan_file = task.parent.parent / 'plan.json'
            if plan_file.exists():
                plan = load(plan_file)
                limits = plan.get('task_limits', {}).get(task.name)
                if limits and len(list((task / 'api').glob('*/reservation.json'))) > limits['requests'] - plan.get('reserved_closing_calls', 0):
                    raise ValueError('Reserved verification/closing phase: no new edits')
            if set(args) != {'path', 'content'} or args['path'] not in WRITABLE or not isinstance(args['content'], str):
                raise ValueError('Only dut.sv, diag_tb.sv and answer.md are writable')
            if len(args['content'].encode('utf-8')) > 60000:
                raise ValueError('File size limit exceeded')
            if scenario and args['path'] != 'answer.md':
                raise ValueError('Scenario review permits answer.md only, no external actions')
            if args['path'] == 'dut.sv':
                extract(args['content'], 'stop')
                start = task / 'start-state.json'
                if start.exists() and load(start)['baseline_required']:
                    seed = load(task / 'seed-manifest.json')['dut.sv']
                    prior = [load(p) for p in (task / 'operations').glob('*/result.json')]
                    if not any(v.get('kind') == 'frozen_bank_evaluation' and v.get('source_sha256') == seed and v.get('cases') for v in prior):
                        raise ValueError('Evaluate the original candidate before the first DUT edit; no historical result substitutes for this run')
            if args['path'] == 'diag_tb.sv':
                validate_tb(args['content'])
            path = task / 'work' / args['path']
            before = path.read_text(encoding='utf-8') if path.exists() else ''
            put(directory / 'before.txt', before)
            put(directory / 'after.txt', args['content'])
            put(directory / 'change.diff', ''.join(difflib.unified_diff(before.splitlines(True),
                args['content'].splitlines(True), fromfile='before/' + path.name, tofile='after/' + path.name)))
            path.write_text(args['content'], encoding='utf-8', newline='\n')
            result = {'path': path.name, 'sha256': sha(path), 'previous_sha256': sha(directory / 'before.txt'),
                      'evidence_id': directory.name, 'no_change': before == args['content']}
            if result['no_change']:
                result['warning'] = 'Identical content: NO repair occurred. Do not repeat this write; investigate the failing evidence or report the unresolved limit.'
        elif name == 'show_diff':
            if args or scenario:
                raise ValueError('show_diff takes no arguments and requires an RTL task')
            initial = task / 'seed/dut.sv'
            if not initial.exists():
                initial = task / 'work/previous-answer.md'
            current = task / 'work/dut.sv'
            original = initial.read_text(encoding='utf-8')
            result = {'diff': ''.join(difflib.unified_diff((extract(original, 'stop') if original.strip() else '').splitlines(True),
                      current.read_text(encoding='utf-8').splitlines(True), fromfile='initial/dut.sv', tofile='current/dut.sv'))}
        elif name in ('evaluate_rtl', 'run_diagnostic'):
            if scenario or args:
                raise ValueError('No arguments expected; scenarios must not execute EDA')
            plan_file = task.parent.parent / 'plan.json'
            plan = load(plan_file) if plan_file.exists() else {}
            limit = plan.get('task_limits', {}).get(task.name, {}).get('eda', plan.get('max_eda_runs_per_task', 5))
            # Count attempted launches, including infrastructure failures without evaluation output.
            if len(list((task / 'operations').glob('*/process.json'))) >= limit:
                raise ValueError('Per-task EDA budget exhausted')
            result = evaluate(task, directory, name == 'run_diagnostic')
        elif name == 'finish_task':
            if set(args) != {'report'}:
                raise ValueError('finish_task requires report JSON string')
            report = json.loads(args['report'])
            summary, audit = evidence_summary(task, report)
            save(task / 'completion-audit.json', audit)
            save(task / 'teacher-summary.json', summary)
            result = {'accepted': True, 'new_repair_chain_verified': audit['new_repair_chain_verified'],
                      'final_tests_passed': audit['final_tests_passed'],
                      'note': 'Change/test facts are host-bound. Narrative and rule proposals still require independent review.'}
        else:
            raise ValueError('Unknown tool')
    except (ValueError, KeyError, FileNotFoundError, json.JSONDecodeError) as error:
        result = {'error': str(error), 'operation_rejected': True}
    save(directory / 'result.json', result)
    return result


if __name__ == '__main__':
    task, number, name, argfile = sys.argv[1:]
    print(json.dumps(execute(Path(task), int(number), name, load(Path(argfile))), ensure_ascii=False))

# 五条失败路径：真实 API / Harness 重跑与独立补验

日期：2026-10-17。范围：教师模型开发，有引导的知识检索与纠错。不是原始 Baseline、正式比赛成绩、小模型 skill 增益或随机全库评估。

## 结论

不能把本轮写成五题全部完成。**严格 API Agent 修复与验证闭环为 Q155 一题；Q193、Q114、Q083 的最终 RTL 经模型运行及开发者独立补验通过，但 Agent 自主闭环各有缺口；Q123 仍有已复现的容量错误。**

| 题目 | 本轮起点 | API Agent 实际结果 | 独立补验及最终判定 |
|---|---|---|---|
| Q123 | 首轮未修候选，先复现重复声明编译错误 | 只删除重复声明；冻结测试通过，但两次自写诊断 watchdog 失败；三次原样写回后停止 | 同一最终 DUT 在容量检查中第三笔写入就阻塞，未达题面容量 4。仍未修复 |
| Q155 | 公开原始错误代码，先复现仿真失败 | 真正修改舍入与饱和逻辑；修复测试台保留字编译错误；诊断和最终冻结验证通过 | 独立穷举全部 65,536 个 16 位输入通过。API 修复闭环完成，原总结中的错误历史描述另行纠正 |
| Q193 | 公开原始错误代码，先复现仿真失败 | 改为分支独立 pending；自写测试台仍失败；三次原样写回后停止，无模型最终冻结验证或总结 | 合规开发者测试台及本轮最终源码的冻结编译、展开、仿真、综合通过。RTL 修复经补验确认，Agent 闭环未完成 |
| Q114 | 公开原始错误代码，先复现仿真失败 | DUT 修复、诊断及冻结验证通过；错误总结字段被拒绝后重交 | 模型测试台静态审查仍违反源端阻塞保持协议。独立修正测试台通过，不计严格 Agent 闭环成功 |
| Q083 | 空白 DUT，属于生成题 | 新生成 DUT；自写诊断的 ready 采样断言失败；当前源码 DEPTH=3、1、9 冻结验证通过 | 合规开发者诊断通过，最终验证已补齐；模型第 8 次请求在外发前因单题保守 token 预留不足被阻止，无模型总结，不计自主纠错完成 |

冻结通过表示该源码、工具环境和所测配置通过编译、展开、仿真、综合，不表示全行为证明、时序收敛或物理 CDC 签核。Q123 正是“冻结通过仍不能覆盖结构问题和独立反证”的实例。

## 授权、预算与真实调用

本轮使用独立追加授权，不与旧轮额度混算：[人工授权](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/human-authorization.json)、[执行计划](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/plan.json)。

| 题目 | 实际请求 / 分题上限 | 实际 reported tokens / 分题上限 |
|---|---:|---:|
| Q123 | 11 / 22 | 135,410 / 260,000 |
| Q155 | 9 / 20 | 59,324 / 230,000 |
| Q193 | 11 / 20 | 100,447 / 230,000 |
| Q114 | 8 / 10 | 42,250 / 110,000 |
| Q083 | 7 / 8 | 39,052 / 70,000 |
| 合计 | **46 / 80** | **376,483 / 900,000** |

输入 357,304、输出 19,179 tokens。实际模型为 `deepseek-v4-pro`，`temperature=0`、`thinking=disabled`；没有自动重试、未知接收结果、账户账单查询或货币费用推算。详见 [用量账本](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/api-usage.json)。

Q083 的 `api/008` 只有本地 payload，没有 reservation、已发送 request 或 response；不能算第八次真实调用。总预算尚有余额，但没有借用其他题额度。只预留最后三次请求不能保证不断增长的上下文仍满足保守 token 预留，这是本轮保留的控制限制。

本地真实 EDA 共 **29 / 34 次**：付费运行前回归 7 次、模型实际请求 16 次、开发者补验 6 次。所有受跟踪进程均已结束。无密钥测试仅用于控制回归，没有替代真实 API 答题。

认证只在本地客户端读取，未进入工件；直连官方 HTTPS 接口并保持证书验证，不改全局代理。外发限于授权的公开题面、原始错误/首轮未修候选、本轮模型文件与可见操作、过滤诊断和通用知识。未发送私有测试台、参考答案、私有向量、密钥或原工程源码。保存的是过滤响应及原响应体 SHA-256，不是逐字节原始 HTTP 体；未请求或保存隐藏思维链。

## 运行前控制修复

- 分题请求、token、EDA 配额与外发前守卫统一读取计划，互不挪用。未知接收或用量不按零处理。
- 原样写回计数不再被普通读文件或评测操作清零；三次原样写回会阻止下一模型步骤。新内容 hash 本身仍不证明有效进展。
- 总结接收后拒绝同批排队操作，避免已绑定证据被随后写入改变。
- 保留公开诊断失败打印、显式失败与 watchdog，不能用 done/PASS 覆盖失败；修改与最终验证事实由操作 ID、hash 和真实结果生成。
- 真实测试台预检：修正 Q114/Q193 的源端保持、沿前握手、沿后状态采样和计数；相同合规测试能拒绝原始错误并检查旧候选。这些只算开发者回归，不算本轮模型修复。

运行前 23 项 Python 工具/预算单测、14 项检索测试、10 项原生 Harness 控制测试通过；7 次真实 EDA 回归包括协议正负候选和诊断假通过负例。预检没有向后续模型提供修好的 DUT 或测试台。

## 关键纠错证据

### Q123：仍未修复，新增明确的容量反证

模型在修改前收到了 R-CDC、T-001、T-002，但只做了删除重复声明的语法修复，二进制指针仍缺回绕位，Gray 也不是完整指针的转换。模型测试台还串行写入超过容量的数据而不启动读取，这类 watchdog 不足以单独归因于 DUT。

开发者另用无读端流量、允许同步稳定、沿前稳定驱动及有界等待的容量检查，在**同一最终 DUT** 上观察到第三笔写入无法接受。该反证与模型 watchdog 分开记录：[容量诊断](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/independent-diagnostics/Q123/operations/001/result.json)。不能用冻结通过覆盖它。

### Q155：真实修复成功，但总结仍须纠正

实际修改使用 signed 商、非负余数、数值 0/+1 的增量，并在舍入后饱和。首次测试台因 `expect` 保留字编译失败，模型真实改写后重跑通过。模型自写诊断覆盖 23 个定向输入；开发者另使用绝对值/商余数算法做全输入穷举，未复制 DUT 的位切片参考逻辑：[独立穷举结果](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/independent-diagnostics/Q155/operations/001/result.json)。

原总结错误地声称旧代码“饱和发生在截断后”，并把半值行为概括为全部远离零。旧代码根本没有饱和逻辑，正偏置也不等于该带符号半值规则。原总结不覆盖，审查单独纠正。这说明操作绑定解决不了自由诊断叙述的全部失真。

### Q193 / Q114：RTL 与测试台责任分开

Q193 的本轮 DUT 实际改为各分支独立 pending，但模型测试仍在活动沿驱动/检查，并在 valid 持续为高时漏计额外接受机会。只把监视器赋值改为 NBA 并未修复整个时序和事务序列。最终冻结验证及合规测试由开发者补做，不能伪装成 API 工具调用。

Q114 新测试虽把复位释放移到下降沿，却在 A 接受后仍保持 valid 经过额外阻塞沿，形成新的 A 请求，随后将其改成 B。静态审查确认违反公共输入保持约定；“诊断通过”不能证明测试台合规。

已完成独立修正并实际运行的测试台：[Q114 合规测试台](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/independent-protocol-review/Q114/work/diag_tb.sv)、[Q193 合规测试台](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/independent-protocol-review/Q193/work/diag_tb.sv)、[补验结果与来源标签](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/independent-protocol-review/validation.json)。模型原测试和失败记录均未修改。

### Q083：最终验证补齐，不能回填成模型自主完成

模型在第三次入队后的已满状态检查 `s_ready==1`，混淆了接受沿前条件和沿后状态。宿主保留了 FAIL/FAILED/Fatal；之后提议写回的内容逐字相同，并未提出有效修正。该请求被收尾阶段写入守卫拒绝。

本轮最终源码已由模型请求完成三参数冻结验证，不借用上一轮结果。开发者独立测试改为沿前判定传输、沿后检查队列，同时覆盖满槽替换、连续回绕、阻塞保持、排空和复位：[模型冻结结果](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/tasks/Q083/operations/007/result.json)、[独立合规测试台](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/independent-fifo-review/Q083/work/diag_tb.sv)、[独立诊断结果](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/independent-fifo-review/validation.json)。没有伪造第八次请求或模型总结。

## Skill 与知识图谱

本轮 **5/5 题都检索到相关规则，且相关上下文实际进入 API 请求**。但送达不是遵循：Q123 收到 CDC 规则仍未执行完整修复；Q193、Q114、Q083 的 DUT 有对应规则的实际改动/实现，但模型诊断闭环不足。只有 Q155 满足本轮严格的新修复与最终验证闭环。这不是有/无 skill 配对实验，不能据此声称因果增益。

另有 Q083 在最终评测后准备的 H09/R-CONTRACT 上下文进入本地会话，却未进入新的实际请求；图中分别记录准备、会话准入和发送，不把它算成已送达。

发布包保留三份 skill，共 **46 条条件化规则**，运行时图 **95 个节点、92 条关系**：

- [RTL 合约与修复](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/published-knowledge/skills/rtl-contract-and-repair/SKILL.md)：强化 declared-capacity 检查及连续 valid 的事务含义。
- [Agent 纠错流程](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/published-knowledge/skills/rtl-agent-correction/SKILL.md)：新增 T-021 通用时钟握手诊断；异步专用 T-002 额外说明容量与并发驱动限制。
- [Harness 运行审查](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/published-knowledge/skills/rtl-harness-run-triage/SKILL.md)：记录预算预留、自由总结失真及开发者补验不能冒充模型闭环的限制。
- [运行时知识图谱](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/published-knowledge/runtime-graph.json)：只包含通用症状、规则、skill 路由，不含题号、解答或私有测试内容。
- [完整审查溯源图 JSON](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/reviewed-knowledge/graph.json) / [GraphML](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/reviewed-knowledge/graph.graphml)：**541 节点、722 关系**，包含请求、接收、检索交付、工具操作、diff、评测、独立审查及后续规则关联。完整溯源图不得直接注入下一求解模型。

后续默认加载仍由这个独立 Harness profile 的 registry、隔离 skill provider、lookup 工具和事件路由完成，没有改全局 Codex 配置或原 Baseline。新发布规则在本轮 API 停止后更新，**只通过 15 项本地检索回归，未追加付费重测，不能声称模型已经使用新增 T-021**。

## 全部记录与验证

- [逐题实际轨迹与证据索引](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/knowledge-use-audit)：五份 `Qxxx-TRAJECTORY.md` 关联原生会话、每次 API 和工具记录。
- [独立审查及规则取舍](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/reviewed-lessons.json)：保留失败、模型原叙述和审查修正。
- [原始输入审计](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/original-input-audit.json)：86 项通过；四题原始错误先评测再改写，Q083 从空白开始，无继承测试台。
- [轨迹完整性](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/knowledge-use-audit/evidence.json)：367 项通过；完整性不等于行为正确。
- [图谱发布校验](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/publication-validation.json)：423 项通过，包括规则交付先于实际修改、证据 hash 和图结构。
- [最终校验](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/final-validation.json)：独立额度、源码快照、测试、文档链接及工件关联。
- [原工程保护结果](D:/AMD/output/rtl-api-distillation-20261017/knowledge-round4-preservation/preservation.json)：原工程 12,690 个条目、题库 2,155 个文件、旧 skill、旧知识、交接目录及 ZIP 前后相同。

官方 `quick_validate.py` 仍因缺少 PyYAML 无法执行，未联网安装。使用原工程已有的只读 yaml 解析器完成元数据和规则检查，不声称官方脚本通过。GraphML 结构已校验，未做图形渲染排版验收。

首次最终工件校验因报告链接指向尚未生成的校验结果自身而失败；修正该输出顺序检查后重跑，首次结果保存在 `validation-attempt-01`，不覆盖失败记录。这不是 API 或 EDA 失败。

独立补验复用了工具结果结构中历史命名的 `teacher_authored_public_diagnostic` kind；实际作者、调度来源以各补验 `validation.json` 的 developer/not_model_requested 标记和单独目录为准，绝不据该 kind 将开发者测试归为模型动作。

## 未完成项

1. Q123 的 CDC RTL 仍未修复；容量不足已被真实工具复现，不能通过只删声明结案。
2. Q193 没有模型自主完成的诊断修正、最终冻结验证和总结；开发者补验不改变原状态。
3. Q114 模型自己的测试台仍不合规；已交付合规开发者版本，但不伪造模型采用。
4. Q083 模型自己的诊断仍失败，无模型总结；本轮当前源码的最终冻结和独立诊断证据已齐全，但收尾 token 预留问题仍需后续策略验证。
5. 新增通用测试规则与路由没有再用付费 API 验证，未证明可靠自动采用、跨题泛化、小模型收益、正式赛事兼容性或物理 CDC 安全。

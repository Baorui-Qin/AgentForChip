"""Keyless tests for file authority, evidence freshness and teacher test safety."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from task_tools import execute, validate_tb, clean_log, evidence_summary, FAILURE_LINE, sha


class AgentToolTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.task = Path(self.temp.name) / 'Q123'
        (self.task / 'work').mkdir(parents=True)
        (self.task / 'question.json').write_text(json.dumps({'task_type': 'rtl_generation'}))
        (self.task / 'work/dut.sv').write_text('module top_module; endmodule\n')

    def tearDown(self):
        self.temp.cleanup()

    def test_path_traversal_read_rejected(self):
        result = execute(self.task, 1, 'read_file', {'path': '../question.json'})
        self.assertTrue(result['operation_rejected'])

    def test_private_write_rejected(self):
        result = execute(self.task, 1, 'write_file', {'path': 'results.json', 'content': '{}'})
        self.assertTrue(result['operation_rejected'])

    def test_source_update_has_diff_and_hash(self):
        result = execute(self.task, 1, 'write_file', {'path': 'dut.sv', 'content': 'module top_module; wire a; endmodule\n'})
        self.assertIn('sha256', result)
        self.assertIn('+module', (self.task / 'operations/001/change.diff').read_text())

    def test_dut_file_access_rejected(self):
        result = execute(self.task, 1, 'write_file', {'path': 'dut.sv', 'content': 'module top_module; initial $system("cmd"); endmodule'})
        self.assertTrue(result['operation_rejected'])

    def test_diagnostic_foreign_access_rejected(self):
        for source in ('module tb; initial $fopen("x"); endmodule', '`include "secret"\nmodule tb; endmodule'):
            with self.assertRaises(ValueError):
                validate_tb(source)

    def test_benign_diagnostic_allowed(self):
        validate_tb('module tb(output reg done); initial begin done=0; #10; $display("checked"); done=1; end endmodule')

    def test_finish_rejects_stale_or_absent_evidence(self):
        report = {'diagnosis': '', 'correction': '', 'verification': '', 'remaining': '',
                  'rules': [{'trigger': 'x', 'action': 'y', 'check': 'z', 'caveat': 'finite tests'}]}
        result = execute(self.task, 1, 'finish_task', {'report': json.dumps(report)})
        self.assertTrue(result['operation_rejected'])
        self.assertFalse((self.task / 'teacher-summary.json').exists())

    def test_scenario_cannot_execute_eda(self):
        (self.task / 'question.json').write_text(json.dumps({'task_type': 'harness_scenario'}))
        with patch('task_tools.evaluate') as evaluate:
            result = execute(self.task, 1, 'evaluate_rtl', {})
        evaluate.assert_not_called()
        self.assertTrue(result['operation_rejected'])

    def test_diagnostic_filter_omits_other_lines(self):
        self.assertEqual(clean_log('PRIVATE VECTOR 123\nERROR: compiler issue\nExpected: 0x123'), ['ERROR: compiler issue'])

    def test_public_failure_is_not_filtered_out(self):
        log = 'FAIL: wrong item\nFAIL: 5 errors\nEVAL_PASS_task\n'
        self.assertEqual(len(clean_log(log, True)), 2)
        self.assertTrue(FAILURE_LINE.search('  Fatal: assertion failed'))
        self.assertFalse(FAILURE_LINE.search('PASS: failures=0'))
        self.assertEqual(clean_log(log), [])

    def finish_fixture(self):
        (self.task / 'work/diag_tb.sv').write_text('module tb(output reg done); endmodule')
        source = sha(self.task / 'work/dut.sv')
        (self.task / 'seed-manifest.json').write_text(json.dumps({'dut.sv': source}))
        for op, kind in [('001', 'frozen_bank_evaluation'), ('002', 'teacher_authored_public_diagnostic')]:
            directory = self.task / 'operations' / op
            directory.mkdir(parents=True)
            (directory / 'result.json').write_text(json.dumps({'kind': kind, 'source_sha256': source,
                'testbench_sha256': sha(self.task / 'work/diag_tb.sv'),
                'cases': [{'status': 'synthesis_pass' if op == '001' else 'simulate_failed'}]}))
        return {'diagnosis': 'Inspected current artifacts', 'remaining': 'Diagnostic failed',
                'change_operations': [], 'verification_operations': ['001', '002'],
                'rules': [{'trigger': 'a failed test', 'action': 'inspect the failure', 'check': 'rerun', 'caveat': 'finite evidence'}]}

    def test_summary_cannot_invent_a_write(self):
        report = self.finish_fixture()
        report['change_operations'] = ['003']
        with self.assertRaisesRegex(ValueError, 'actual non-identical writes'):
            evidence_summary(self.task, report)

    def test_summary_cannot_supply_false_correction_or_pass_prose(self):
        report = self.finish_fixture()
        report['correction'] = 'I repaired the DUT and every test passed'
        with self.assertRaisesRegex(ValueError, 'host-generated'):
            evidence_summary(self.task, report)

    def test_summary_preserves_failed_status_and_unchanged_source(self):
        report = self.finish_fixture()
        summary, audit = evidence_summary(self.task, report)
        self.assertFalse(audit['new_repair_chain_verified'])
        self.assertFalse(audit['net_source_change'])
        self.assertFalse(audit['final_tests_passed'])
        self.assertIn('simulate_failed', summary['verification'])

    def test_summary_requires_current_testbench(self):
        report = self.finish_fixture()
        (self.task / 'work/diag_tb.sv').write_text('module tb(output reg done); wire new_check; endmodule')
        with self.assertRaisesRegex(ValueError, 'current TB'):
            evidence_summary(self.task, report)

    def test_baseline_required_before_original_dut_edit(self):
        self.finish_fixture()
        (self.task / 'start-state.json').write_text(json.dumps({'baseline_required': True}))
        (self.task / 'seed-manifest.json').write_text(json.dumps({'dut.sv': '0' * 64}))
        result = execute(self.task, 3, 'write_file', {'path': 'dut.sv', 'content': 'module top_module; wire b; endmodule'})
        self.assertTrue(result['operation_rejected'])
        self.assertIn('original candidate', result['error'])

    def test_accepted_summary_prevents_queued_writes(self):
        (self.task / 'teacher-summary.json').write_text('{}')
        result = execute(self.task, 1, 'write_file', {'path': 'dut.sv', 'content': 'module top_module; wire b; endmodule'})
        self.assertTrue(result['operation_rejected'])
        self.assertNotIn('wire b', (self.task / 'work/dut.sv').read_text())


if __name__ == '__main__':
    unittest.main()

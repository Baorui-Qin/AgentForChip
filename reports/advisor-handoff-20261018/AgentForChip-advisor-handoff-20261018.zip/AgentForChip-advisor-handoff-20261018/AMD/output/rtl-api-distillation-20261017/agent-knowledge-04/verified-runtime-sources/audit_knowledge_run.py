"""Audit a real knowledge-assisted run without treating receipt or citation as rule adoption."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import load, sha


def lines(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()] if path.exists() else []


def artifact(path):
    return {'path': str(path.resolve()), 'sha256': sha(path)}


def audit(root):
    out = root / 'knowledge-use-audit'
    out.mkdir(exist_ok=False)
    plan = load(root / 'plan.json')
    ledger_path = root / 'knowledge-runtime/retrieval/retrieval.jsonl'
    ledger = lines(ledger_path)
    runtime = load(root / 'knowledge-runtime/runtime-graph.json')
    checks, tasks, nodes, edges = [], [], [], []
    totals = Counter()
    unknown = []
    def check(name, passed):
        checks.append({'name': name, 'passed': bool(passed)})
    def node(ident, kind, path=None, **extra):
        nodes.append({'id': ident, 'kind': kind, **({'artifact': artifact(path)} if path and path.exists() else {}), **extra})
    def edge(source, target, relationship):
        edges.append({'source': source, 'target': target, 'relationship': relationship})
    node('run', 'RealKnowledgeAssistedReplay', root / 'plan.json', directed=True, gain_test=False)
    node('bundle', 'FrozenRuntimeKnowledge', root / 'knowledge-runtime/manifest.json')
    edge('run', 'bundle', 'mounts')
    for item in runtime['nodes']:
        node('knowledge:' + item['id'], item['type'], content=item)
    for item in runtime['edges']:
        edge('knowledge:' + item['from'], 'knowledge:' + item['to'], item['type'])
    for item in runtime['nodes']:
        if item['type'] == 'skill':
            edge('bundle', 'knowledge:' + item['id'], 'freezes')
    for qid in plan['execution_order']:
        task = root / 'tasks' / qid
        sid_path = task / 'session-identity.json'
        sid = load(sid_path)['session_id'] if sid_path.exists() else None
        events = lines(task / 'session-events.jsonl')
        live = lines(task / 'session-live.jsonl')
        node(qid, 'NativeSession', task / 'session-events.jsonl', session_id=sid)
        edge('run', qid, 'runs')
        check(qid + ':live_log_matches_final_snapshot', live == events and bool(events))
        trace = ['# ' + qid + ' 实际轨迹', '', '以下来自真实 API、原生会话和本轮工具记录，不含隐藏思维链。', '']
        call_map, requests, row_ops, evals, diagnostic_log_reviews = {}, [], [], [], []
        for directory in sorted((task / 'api').glob('*')):
            payload = directory / 'request.json'
            if not payload.exists():
                continue
            reqid = qid + ':api:' + directory.name
            request = load(payload)
            requests.append((reqid, request))
            node(reqid, 'ApiRequest', payload)
            edge(qid, reqid, 'dispatches')
            totals['requests'] += 1
            response_path, receipt_path = directory / 'response.json', directory / 'receipt.json'
            check(reqid + ':knowledge_tool_exposed', any(t['function']['name'] == 'lookup_knowledge' for t in request.get('tools', [])))
            check(reqid + ':fixed_visible_only_route', request.get('model') == 'deepseek-v4-pro' and request.get('thinking') == {'type': 'disabled'})
            if not response_path.exists() or not receipt_path.exists():
                unknown.append(reqid)
                continue
            response, receipt = load(response_path), load(receipt_path)
            check(reqid + ':http_receipt', receipt['status'] == 200 and bool(re.fullmatch('[a-f0-9]{64}', receipt['response_sha256'])))
            check(reqid + ':no_hidden_reasoning_stored', 'reasoning_content' not in json.dumps(response))
            usage = response.get('usage', {})
            for key in ('prompt_tokens', 'completion_tokens', 'total_tokens'):
                totals[key] += usage.get(key, 0)
            check(reqid + ':usage_available', all(isinstance(usage.get(key), int) for key in ('prompt_tokens', 'completion_tokens', 'total_tokens')))
            node(reqid + ':response', 'VisibleApiResponse', response_path)
            node(reqid + ':receipt', 'HttpReceiptWithOriginalBodyHash', receipt_path)
            edge(reqid, reqid + ':response', 'receives_filtered_response')
            edge(reqid, reqid + ':receipt', 'has_receipt')
            message = response['choices'][0]['message']
            trace += ['## API ' + directory.name, '', f"结束原因：`{response['choices'][0]['finish_reason']}`；用量：{usage.get('total_tokens')} tokens。", '']
            if message.get('content'):
                trace += ['模型可见说明：', '', message['content'], '']
            for call in message.get('tool_calls', []):
                call_map[call['id']] = {'request': reqid, 'name': call['function']['name'], 'arguments': call['function']['arguments']}
                node(call['id'], 'ModelRequestedTool', response_path, name=call['function']['name'], arguments=call['function']['arguments'])
                edge(reqid + ':response', call['id'], 'requests')
                trace += [f"- `{call['id']}` → `{call['function']['name']}`；完整参数见 [response.json]({response_path.as_posix()})。"]
        own = [item for item in ledger if item.get('session_id') == sid]
        lookups = [item for item in own if item['event'] == 'lookup']
        contexts = [item for item in own if item['event'] == 'context_prepared']
        delivered = []
        for number, item in enumerate(lookups):
            ident = qid + ':lookup:' + str(number + 1)
            node(ident, 'ActualKnowledgeRetrieval', ledger_path, record=item)
            edge(qid, ident, 'retrieves')
            cause = item.get('tool_call_id')
            check(ident + ':model_origin', cause in call_map)
            if cause in call_map:
                edge(cause, ident, 'triggers')
            for rule in item['matched']:
                edge(ident, 'knowledge:' + rule, 'matches')
            trace += ['', f"检索 `{item['query']}`：命中 {', '.join(item['matched']) or '无'}；本次新加载 {', '.join(item['selected']) or '无'}。"]
        for item in contexts:
            textpath = root / 'knowledge-runtime/retrieval' / item['message_file']
            text = textpath.read_text(encoding='utf-8')
            check(qid + ':context:' + item['record_id'] + ':hash', sha(textpath) == item['message_sha256'])
            in_session = any(e['type'] == 'user/message' and any(b.get('text') == text for b in e['data'].get('content', [])) for e in events)
            seen = [reqid for reqid, request in requests if any(m['role'] == 'user' and m.get('content') == text for m in request['messages'])]
            check(qid + ':context:' + item['record_id'] + ':native_admission', in_session)
            delivered.append({'record_id': item['record_id'], 'rules': item['rules'], 'actual_requests': seen, 'native_admitted': in_session})
            ident = 'context:' + item['record_id']
            node(ident, 'ExactSkillContext', textpath, rules=item['rules'])
            edge(qid, ident, 'admits_context')
            for rule in item['rules']:
                edge('knowledge:' + rule, ident, 'included_in')
            for reqid in seen:
                edge(ident, reqid, 'sent_in')
        for directory in sorted((task / 'operations').glob('*')):
            callfile, resultfile = directory / 'call.json', directory / 'result.json'
            if not callfile.exists():
                continue
            call = load(callfile)
            result = load(resultfile) if resultfile.exists() else {'missing': True}
            dispatchfile = task / ('tool-dispatch-' + directory.name + '.json')
            dispatch = load(dispatchfile) if dispatchfile.exists() else {}
            cause = call_map.get(dispatch.get('tool_call_id'))
            check(qid + ':op:' + directory.name + ':teacher_requested', cause and cause['name'] == call['name'] and json.loads(cause['arguments']) == call['arguments'])
            ident = qid + ':op:' + directory.name
            node(ident, 'ExecutedTool', callfile, name=call['name'], result=result)
            edge(qid, ident, 'executes')
            if cause:
                edge(dispatch['tool_call_id'], ident, 'dispatches')
            if resultfile.exists():
                node(ident + ':result', 'ToolResult', resultfile)
                edge(ident, ident + ':result', 'returns')
            if (directory / 'change.diff').exists():
                node(ident + ':diff', 'ActualFileDiff', directory / 'change.diff', changed=result.get('no_change') is False)
                edge(ident, ident + ':diff', 'writes')
                check(ident + ':before_after_hashes', sha(directory / 'before.txt') == result.get('previous_sha256') and sha(directory / 'after.txt') == result.get('sha256'))
            if (directory / 'evaluation/results.json').exists():
                raw = load(directory / 'evaluation/results.json')
                node(ident + ':eda', 'RealVivadoExecution', directory / 'evaluation/results.json')
                edge(ident, ident + ':eda', 'produces')
                check(ident + ':evaluation_source_binding', all(c['source_sha256'] == result['source_sha256'] for c in raw['cases']))
                check(ident + ':real_tool_finished', bool(raw.get('finished_at')))
                if result.get('kind') == 'teacher_authored_public_diagnostic':
                    for case in raw['cases']:
                        for stage in case.get('stages', []):
                            if stage['tool'] != 'xsim':
                                continue
                            log_path = directory / 'evaluation' / stage['log']
                            printed_failures = [line for line in log_path.read_text(encoding='utf-8', errors='replace').splitlines()
                                                if re.match(r'^FAIL\b', line, re.I)]
                            diagnostic_log_reviews.append({'operation': directory.name, 'log': artifact(log_path),
                                'reported_status': case['status'], 'printed_failures': printed_failures,
                                'nominal_pass_with_failure_prints': case['status'] == 'simulation_pass' and bool(printed_failures)})
                evals.append(result)
            row_ops.append({'operation': directory.name, 'tool_call_id': dispatch.get('tool_call_id'), 'name': call['name'], 'result': result})
            trace += ['', f"操作 {directory.name} `{call['name']}`：`{result.get('kind', result.get('error', 'accepted' if result.get('accepted') else 'recorded'))}`。",
                      f"完整记录：[call]({callfile.as_posix()}) / [result]({resultfile.as_posix()})。"]
        q = load(task / 'question.json')
        scenario = q['task_type'] == 'harness_scenario'
        final = task / ('work/answer.md' if scenario else 'work/dut.sv')
        final_sha = sha(final) if final.exists() else None
        latest = {}
        for record in evals:
            if record.get('source_sha256') == final_sha:
                latest[record['kind']] = record
        diagnostic = latest.get('teacher_authored_public_diagnostic')
        tb_current = sha(task / 'work/diag_tb.sv') if (task / 'work/diag_tb.sv').exists() else None
        summary = load(task / 'teacher-summary.json') if (task / 'teacher-summary.json').exists() else None
        status = load(task / 'agent-result.json') if (task / 'agent-result.json').exists() else {'status': 'not_finished'}
        seeds = load(task / 'seed-manifest.json')
        if summary:
            node(qid + ':summary', 'TeacherSummaryNotIndependentProof', task / 'teacher-summary.json')
            edge(qid, qid + ':summary', 'submits')
            trace += ['', '## 教师总结', '', '```json', json.dumps(summary, ensure_ascii=False, indent=2), '```']
        tasks.append({'id': qid, 'session_id': sid, 'agent_status': status['status'], 'summary_accepted': summary is not None,
                      'model_requests': len(requests), 'manual_lookups': sum(x['trigger'] == 'model_tool' for x in lookups),
                      'automatic_lookups': sum(x['trigger'] != 'model_tool' for x in lookups), 'lookups': lookups,
                      'contexts': delivered, 'operations': row_ops, 'final_source_sha256': final_sha,
                      'final_bank': latest.get('frozen_bank_evaluation'), 'final_diagnostic': diagnostic,
                      'diagnostic_matches_final_tb': bool(diagnostic and diagnostic.get('testbench_sha256') == tb_current),
                      'diagnostic_log_reviews': diagnostic_log_reviews,
                      'source_changed_from_seed': bool(final_sha and seeds.get(final.name) != final_sha),
                      'testbench_changed_from_seed': bool(tb_current and seeds.get('diag_tb.sv') != tb_current),
                      'scenario_text_only': scenario, 'teacher_summary': summary,
                      'behavioral_adoption': 'REQUIRES_INDEPENDENT_ACTION_REVIEW_NOT_INFERRED_FROM_DELIVERY'})
        (out / (qid + '-TRAJECTORY.md')).write_text('\n'.join(trace) + '\n', encoding='utf-8')
    check('budget_request_limit', totals['requests'] <= plan['max_requests'])
    check('budget_token_limit', totals['total_tokens'] <= plan['max_reported_tokens'])
    check('known_receipts_and_usage', not unknown)
    check('graph_no_dangling_edges', all(e['source'] in {n['id'] for n in nodes} and e['target'] in {n['id'] for n in nodes} for e in edges))
    save(out / 'evidence.json', {'scope': 'REAL_DIRECTED_KNOWLEDGE_USE_NOT_PAIRED_GAIN_TEST', 'usage': dict(totals), 'unknown': unknown,
                               'tasks': tasks, 'checks': checks, 'integrity_passed': all(c['passed'] for c in checks)})
    save(out / 'graph.json', {'scope': 'ACTUAL_RETRIEVAL_DELIVERY_AND_ACTION_PROVENANCE_NOT_CAUSAL_PROOF', 'nodes': nodes, 'edges': edges})
    doc = ET.Element('graphml', xmlns='http://graphml.graphdrawing.org/xmlns')
    ET.SubElement(doc, 'key', id='record', attrib={'for': 'all', 'attr.name': 'record', 'attr.type': 'string'})
    graph = ET.SubElement(doc, 'graph', id='knowledge-use', edgedefault='directed')
    for item in nodes:
        element = ET.SubElement(graph, 'node', id=item['id'])
        ET.SubElement(element, 'data', key='record').text = json.dumps(item, ensure_ascii=False)
    for index, item in enumerate(edges):
        element = ET.SubElement(graph, 'edge', id='e' + str(index), source=item['source'], target=item['target'])
        ET.SubElement(element, 'data', key='record').text = item['relationship']
    with (out / 'graph.graphml').open('xb') as stream:
        stream.write(ET.tostring(doc, encoding='utf-8', xml_declaration=True))
    print(json.dumps({'requests': totals['requests'], 'tokens': totals['total_tokens'], 'checks': len(checks),
                      'failed_checks': [c['name'] for c in checks if not c['passed']], 'tasks': len(tasks),
                      'nodes': len(nodes), 'edges': len(edges)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    audit(parser.parse_args().out)

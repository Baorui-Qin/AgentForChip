"""Package actual teacher trajectories, not reconstructed or invented model operations."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import load, put, sha

HERE = Path(__file__).resolve().parent


def artifact(path):
    return {'path': str(path.resolve()), 'sha256': sha(path)}


def graphml(path, nodes, edges, overwrite=False):
    root = ET.Element('graphml', xmlns='http://graphml.graphdrawing.org/xmlns')
    for kind in ('node', 'edge'):
        ET.SubElement(root, 'key', id=kind, attrib={'for': kind, 'attr.name': 'record', 'attr.type': 'string'})
    graph = ET.SubElement(root, 'graph', id='teacher-agent', edgedefault='directed')
    for node in nodes:
        entry = ET.SubElement(graph, 'node', id=node['id'])
        ET.SubElement(entry, 'data', key='node').text = json.dumps(node, ensure_ascii=False)
    for number, edge in enumerate(edges):
        entry = ET.SubElement(graph, 'edge', id='e' + str(number), source=edge['source'], target=edge['target'])
        ET.SubElement(entry, 'data', key='edge').text = json.dumps(edge, ensure_ascii=False)
    with path.open('wb' if overwrite else 'xb') as stream:
        stream.write(ET.tostring(root, encoding='utf-8', xml_declaration=True))


def overview(path):
    doc = ET.Element('mxfile', host='local')
    diagram = ET.SubElement(doc, 'diagram', name='Native Teacher Agent', id='teacher')
    model = ET.SubElement(diagram, 'mxGraphModel', page='1', pageWidth='1250', pageHeight='800')
    root = ET.SubElement(model, 'root')
    ET.SubElement(root, 'mxCell', id='0')
    ET.SubElement(root, 'mxCell', id='1', parent='0')
    boxes = [
        ('seed', 'Visible prompt + previous answer', 40, 80, '#dae8fc'),
        ('agent', 'Native Harness Agent/session', 440, 80, '#dae8fc'),
        ('tools', 'Read / edit / diff / real EDA', 840, 80, '#d5e8d4'),
        ('evidence', 'Versioned source + tool evidence', 840, 340, '#d5e8d4'),
        ('summary', 'Teacher correction summary', 440, 340, '#fff2cc'),
        ('review', 'Developer review + limits', 40, 340, '#fff2cc'),
        ('skill', 'Reusable skill (no task answers)', 40, 600, '#e1d5e7'),
        ('graph', 'Traceable knowledge graph', 440, 600, '#e1d5e7')]
    for ident, label, x, y, color in boxes:
        cell = ET.SubElement(root, 'mxCell', id=ident, value=label, vertex='1', parent='1',
            style=f'rounded=0;whiteSpace=wrap;html=1;fillColor={color};strokeColor=#555555;fontSize=15;')
        ET.SubElement(cell, 'mxGeometry', x=str(x), y=str(y), width='270', height='100', attrib={'as': 'geometry'})
    links = [('seed', 'agent'), ('agent', 'tools'), ('tools', 'evidence'), ('evidence', 'summary'),
             ('summary', 'review'), ('review', 'skill'), ('summary', 'graph')]
    for number, (source, target) in enumerate(links):
        cell = ET.SubElement(root, 'mxCell', id='edge' + str(number), edge='1', parent='1', source=source, target=target,
            style='edgeStyle=orthogonalEdgeStyle;endArrow=block;html=1;')
        ET.SubElement(cell, 'mxGeometry', relative='1', attrib={'as': 'geometry'})
    with path.open('xb') as stream:
        stream.write(ET.tostring(doc, encoding='utf-8', xml_declaration=True))


def build(root):
    output = root / 'knowledge'
    output.mkdir(exist_ok=False)
    nodes, edges, rules, curation, results = [], [], [], [], []
    def node(ident, kind, path=None, **data):
        nodes.append({'id': ident, 'kind': kind, **({'artifact': artifact(path)} if path else {}), **data})
    def edge(source, target, relationship):
        edges.append({'source': source, 'target': target, 'relationship': relationship})
    node('run', 'NativeHarnessDevelopmentRun', root / 'plan.json', official=False, gain_test=False)
    previous_run = load(root / 'plan.json').get('continues_native_run')
    if previous_run and (Path(previous_run) / 'knowledge/graph.json').exists():
        previous = load(Path(previous_run) / 'knowledge/graph.json')
        for old in previous['nodes']:
            nodes.append({**old, 'id': 'previous::' + old['id']})
        for old in previous['edges']:
            edges.append({**old, 'source': 'previous::' + old['source'], 'target': 'previous::' + old['target']})
        edge('previous::run', 'run', 'explicitly_approved_continuation_preserves_prior_failure')
    requests, tokens_in, tokens_out, unknown_usage = 0, 0, 0, []
    for qid in load(root / 'plan.json')['execution_order']:
        task = root / 'tasks' / qid
        seed = qid + ':seed'
        node(seed, 'VisibleSeed', task / 'seed-manifest.json')
        edge('run', seed, 'continues_previous_visible_answer')
        session = qid + ':session'
        session_path = task / 'session-events.jsonl'
        if session_path.exists():
            node(session, 'ActualNativeSession', session_path)
            edge(seed, session, 'starts_fresh_native_session')
        else:
            node(session, 'NotStartedTask')
            edge(seed, session, 'pending')
        proposed_calls = []
        for directory in sorted((task / 'api').glob('*')):
            if not directory.is_dir():
                continue
            request = directory / 'request.json'
            if not request.exists():
                continue
            requests += 1
            attempt = qid + ':api:' + directory.name
            posthoc = (directory / 'purpose.json').exists()
            node(attempt, 'PosthocTeacherReflectionRequest' if posthoc else 'OfficialApiRequest', request)
            edge(session, attempt, 'reviewed_after_incomplete_turn' if posthoc else 'requests_model_action')
            receipt = directory / 'receipt.json'
            if receipt.exists():
                node(attempt + ':receipt', 'HttpReceiptWithOriginalBodyHash', receipt)
                edge(attempt, attempt + ':receipt', 'has_receipt')
            response = directory / 'response.json'
            if response.exists():
                value = load(response)
                usage = value.get('usage') or {}
                if isinstance(usage.get('prompt_tokens'), int) and isinstance(usage.get('completion_tokens'), int):
                    tokens_in += usage['prompt_tokens']; tokens_out += usage['completion_tokens']
                else:
                    unknown_usage.append(attempt)
                node(attempt + ':answer', 'VisibleAssistantResponse', response)
                edge(attempt, attempt + ':answer', 'receives_filtered_response')
                for call in value['choices'][0]['message'].get('tool_calls', []):
                    proposed_calls.append({'response': attempt + ':answer', 'id': call['id'],
                        'name': call['function']['name'], 'arguments': json.loads(call['function']['arguments'])})
            else:
                unknown_usage.append(attempt)
        operation_rows, evaluations = [], []
        for directory in sorted((task / 'operations').glob('*')):
            callfile, resultfile = directory / 'call.json', directory / 'result.json'
            if not callfile.exists():
                continue
            call = load(callfile)
            result = load(resultfile) if resultfile.exists() else {'kind': 'missing_result'}
            ident = qid + ':tool:' + directory.name
            node(ident, 'ActualToolOperation', callfile, tool=call['name'])
            edge(session, ident, 'executes_tool')
            match = next((c for c in proposed_calls if not c.get('matched') and c['name'] == call['name'] and c['arguments'] == call['arguments']), None)
            if match:
                match['matched'] = True
                edge(match['response'], ident, 'requests_this_operation')
            if resultfile.exists():
                node(ident + ':result', 'ToolFeedback', resultfile, status=result.get('kind', result.get('error', 'recorded')))
                edge(ident, ident + ':result', 'produces_feedback')
            diff = directory / 'change.diff'
            if diff.exists():
                node(ident + ':diff', 'ModelAuthoredChange', diff)
                edge(ident, ident + ':diff', 'writes_versioned_change')
            raw = directory / 'evaluation/results.json'
            if raw.exists():
                node(ident + ':eval', 'RealVivadoEvidence', raw,
                     evidence_kind=result.get('kind'), source_sha256=result.get('source_sha256'))
                edge(ident + ':result', ident + ':eval', 'redacts_private_test_contents_from')
                evaluations.append(result)
            operation_rows.append({'number': directory.name, 'name': call['name'], 'result': result})
        final_file = task / ('work/answer.md' if load(task / 'question.json')['task_type'] == 'harness_scenario' else 'work/dut.sv')
        final_hash = sha(final_file) if final_file.exists() else None
        last_bank = next((e for e in reversed(evaluations) if e['kind'] == 'frozen_bank_evaluation' and e['source_sha256'] == final_hash), None)
        last_diag = next((e for e in reversed(evaluations) if e['kind'] == 'teacher_authored_public_diagnostic' and e['source_sha256'] == final_hash), None)
        statusfile = task / 'agent-result.json'
        agent_result = load(statusfile) if statusfile.exists() else {'status': 'not_started'}
        results.append({'id': qid, 'agent_status': agent_result['status'], 'final_sha256': final_hash,
                        'bank': last_bank, 'diagnostic': last_diag, 'operations': len(operation_rows)})
        summaryfile = task / 'teacher-summary.json'
        posthoc_summary = False
        if not summaryfile.exists() and (task / 'teacher-reflection.json').exists():
            summaryfile = task / 'teacher-reflection.json'
            posthoc_summary = True
        text = [f'# {qid} Teacher Agent Trajectory', '', 'Source: actual native session and tool records. No hidden reasoning.', '']
        for row in operation_rows:
            result = row['result']
            status = result.get('error') or result.get('kind') or ('accepted' if result.get('accepted') else 'recorded')
            text.append(f"- {row['number']} `{row['name']}`: {status}")
        if summaryfile.exists():
            summary = load(summaryfile)
            if posthoc_summary:
                summary = summary['report']
            summary_id = qid + ':summary'
            node(summary_id, 'PosthocReflectionOfIncompleteTask' if posthoc_summary else 'TeacherAuthoredCorrectionSummary', summaryfile, independently_proven=False)
            edge(session, summary_id, 'reflects_incomplete_work_not_a_success' if posthoc_summary else 'summarizes_visible_work')
            for e in (last_bank, last_diag):
                if e:
                    edge(qid + ':tool:' + e['evidence_id'] + ':eval', summary_id, 'bounds_claims_with')
            for field in ('diagnosis', 'correction', 'verification', 'remaining'):
                text.extend(['', '## ' + field.title(), '', str(summary[field])])
            for proposed in summary['rules']:
                ident = 'T-' + str(len(rules) + 1).zfill(3)
                evidence_kind = 'text_review_only' if last_bank is None else (
                    'finite_bank_and_teacher_test_passed' if all(c['status'] == 'synthesis_pass' for c in last_bank['cases'])
                    and last_diag and all(c['status'] == 'simulation_pass' for c in last_diag['cases']) else
                    'bank_pass_diagnostic_failed_unresolved' if all(c['status'] == 'synthesis_pass' for c in last_bank['cases']) else
                    'frozen_failure_public_diagnostic_only')
                rule = {'id': ident, **proposed, 'support': evidence_kind,
                        'status': 'teacher_proposal_developer_review_required'}
                rules.append(rule)
                curation.append({'id': ident, 'source_task': qid, 'teacher_summary': artifact(summaryfile),
                                 'evidence_kind': evidence_kind, 'developer_disposition': 'pending_review'})
                node(ident, 'TeacherProposedRule', summaryfile, content=proposed, support=evidence_kind)
                edge(summary_id, ident, 'proposes_conditional_rule')
        put(task / 'TRAJECTORY.md', '\n'.join(text) + '\n')
    current_requests = requests
    for base in load(root / 'plan.json').get('budget_roots', []):
        if Path(base).resolve() == root.resolve():
            continue
        for path in (Path(base) / 'tasks').glob('*/api/*/request.json'):
            requests += 1
            response = path.parent / 'response.json'
            if response.exists():
                usage = load(response).get('usage') or {}
                tokens_in += usage.get('prompt_tokens', 0); tokens_out += usage.get('completion_tokens', 0)
            else:
                unknown_usage.append(str(path))
    save(root / 'api-usage.json', {'chat_requests': requests, 'current_run_requests': current_requests,
         'input_tokens': tokens_in, 'output_tokens': tokens_out,
         'total_tokens': tokens_in + tokens_out, 'unknown_usage_attempts': unknown_usage,
         'cost': None, 'cost_reason': 'Account billing and pricing not queried', 'automatic_retries': 0})
    save(root / 'agent-results.json', {'tasks': results, 'agent_status_counts': dict(Counter(r['agent_status'] for r in results))})
    save(root / 'teacher-rule-proposals.json', {'authorship': 'DeepSeek visible finish_task calls and separately labeled posthoc failure reflection', 'rules': rules})
    save(root / 'curation.json', {'rules': curation})
    node('proposals', 'TeacherRuleProposalCatalog', root / 'teacher-rule-proposals.json')
    edge('run', 'proposals', 'produces')
    for rule in rules:
        edge(rule['id'], 'proposals', 'catalogued_in')
    save(output / 'graph.json', {'schema_version': 2, 'scope': 'VISIBLE_NATIVE_AGENT_OPERATIONS_NOT_CHAIN_OF_THOUGHT',
         'nodes': nodes, 'edges': edges})
    graphml(output / 'graph.graphml', nodes, edges)
    overview(output / 'agent-overview.drawio')
    print(json.dumps({'requests': requests, 'tokens': tokens_in + tokens_out, 'rules_proposed': len(rules),
                      'nodes': len(nodes), 'edges': len(edges), 'tasks': Counter(r['agent_status'] for r in results)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    build(parser.parse_args().out)

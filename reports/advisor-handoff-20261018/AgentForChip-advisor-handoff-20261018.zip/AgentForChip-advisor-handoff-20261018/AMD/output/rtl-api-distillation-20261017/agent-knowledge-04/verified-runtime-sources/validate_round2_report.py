"""Final local checks and source snapshots. No network or API dispatch."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

from task_tools import load, save, sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, required=True)
    args = parser.parse_args()
    root = args.run
    review = load(root / 'reviewed-lessons.json')
    checks = []
    def check(name, passed):
        checks.append({'name': name, 'passed': bool(passed)})
    report = root / 'RUN_REPORT.md'
    for link in re.findall(r'\]\((D:/[^)]+)\)', report.read_text(encoding='utf-8')):
        check('report_link:' + link, Path(link).exists())
    graph = load(root / 'reviewed-knowledge/graph.json')
    xml = ET.parse(root / 'reviewed-knowledge/graph.graphml')
    ns = {'g': 'http://graphml.graphdrawing.org/xmlns'}
    check('graphml_nodes', len(xml.findall('.//g:node', ns)) == len(graph['nodes']) == 898)
    check('graphml_edges', len(xml.findall('.//g:edge', ns)) == len(graph['edges']) == 1173)
    fields = {
        'rtl-contract-and-repair': ('rules.json', 'rules', ['condition', 'action', 'check']),
        'rtl-agent-correction': ('rules.json', 'rules', ['trigger', 'action', 'check', 'caveat']),
        'rtl-harness-run-triage': ('patterns.json', 'patterns', ['symptom', 'agent_action', 'harness_requirement', 'verify', 'limit']),
    }
    for name, (file, key, required) in fields.items():
        rules = load(root / 'published-knowledge/skills' / name / 'references' / file)[key]
        for rule in rules:
            check('rule_schema:' + rule['id'], all(isinstance(rule.get(f), str) and rule[f].strip() for f in required))
    for label, directory in review['runs'].items():
        run = Path(directory)
        process = load(run / 'harness-process.json')
        check(label + ':process_reaped', process['reaped'] and process['exit_code'] == 0)
        manifest = load(run / 'knowledge-runtime/manifest.json')
        for name, expected in manifest['files'].items():
            check(label + ':frozen:' + name, sha(run / 'knowledge-runtime' / name) == expected)
        # Preserve executable contents that still match the pre-run manifest, without inventing old source bytes.
        source_manifest = load(run / 'runtime-source-manifest.json')
        snapshots = run / 'verified-runtime-sources'
        snapshots.mkdir()
        for name in ('agent.ts', 'api_worker.py', 'task_tools.py'):
            source = Path(__file__).parent / name
            matched = sha(source) == source_manifest[name]
            check(label + ':runtime_source:' + name, matched)
            if matched:
                shutil.copyfile(source, snapshots / name)
        check(label + ':original_input_audit', load(run / 'original-input-audit.json')['passed'])
    third = Path(review['runs']['r03'])
    check('shared_budget_roots', [Path(p).resolve() for p in load(third / 'plan.json')['budget_roots']] ==
          [Path(p).resolve() for p in review['runs'].values()])
    usage = load(root / 'publication-validation.json')['usage']
    check('total_usage', usage['requests'] == 84 and usage['total_tokens'] == 574854)
    env = os.environ.copy()
    env.update(TEMP='D:/AMD/tmp/knowledge-live-tests', TMP='D:/AMD/tmp/knowledge-live-tests')
    unit = subprocess.run([sys.executable, '-B', '-m', 'unittest', 'test_agent', '-v'],
                          cwd=Path(__file__).parent, env=env, capture_output=True, text=True)
    save(root / 'python-test-validation.json', {'exit_code': unit.returncode, 'stdout': unit.stdout,
        'stderr': unit.stderr, 'api_requests': 0, 'fixture_only': True})
    check('python_tool_tests', unit.returncode == 0 and 'Ran 15 tests' in unit.stderr)
    check('original_materials_unchanged', load(root / 'preservation.json')['status'] == 'PASS')
    files = [report, root / 'reviewed-lessons.json', root / 'publication-validation.json',
             root / 'preservation.json', root / 'python-test-validation.json', Path(__file__).resolve()]
    result = {'scope': 'LOCAL_INTEGRITY_SCHEMA_AND_REGRESSION_NOT_MODEL_SUCCESS',
              'passed': all(c['passed'] for c in checks), 'checks': checks,
              'artifacts': [{'path': str(p), 'sha256': sha(p)} for p in files]}
    save(root / 'final-validation.json', result)
    print(json.dumps({'passed': result['passed'], 'checks': len(checks),
                      'failed': [c for c in checks if not c['passed']]}, ensure_ascii=False))
    raise SystemExit(0 if result['passed'] else 1)


if __name__ == '__main__':
    main()

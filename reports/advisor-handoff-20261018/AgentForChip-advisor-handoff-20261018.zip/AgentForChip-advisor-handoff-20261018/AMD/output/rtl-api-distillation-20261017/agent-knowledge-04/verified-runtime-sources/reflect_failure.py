"""One explicit post-run teacher reflection of a failed native trajectory, never a solver retry."""
import argparse
import contextlib
import io
import json
import re
from pathlib import Path
import sys

from api_worker import run
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import load, sha


def reflect(root, qid):
    task = root / 'tasks' / qid
    events = []
    for base in load(root / 'plan.json')['budget_roots']:
        old = Path(base) / 'tasks' / qid
        for directory in sorted((old / 'operations').glob('*')):
            if not (directory / 'call.json').exists() or not (directory / 'result.json').exists():
                continue
            call, result = load(directory / 'call.json'), load(directory / 'result.json')
            compact = {key: result[key] for key in ('kind', 'sha256', 'previous_sha256', 'source_sha256', 'no_change', 'error') if key in result}
            if 'cases' in result:
                compact['cases'] = [{'status': c['status'], 'diagnostics': c.get('diagnostics', [])} for c in result['cases']]
            events.append({'run': Path(base).name, 'evidence_id': directory.name, 'tool': call['name'], 'result': compact})
    def uncomment(path):
        text = re.sub(r'/\*.*?\*/|//[^\n]*', '', path.read_text(encoding='utf-8'), flags=re.S)
        return '\n'.join(line.strip() for line in text.splitlines() if line.strip())
    facts = {'purpose': 'POSTHOC_REFLECTION_OF_ACTUAL_INCOMPLETE_AGENT_NOT_A_REPAIR_OR_SUCCESS_CLAIM',
             'visible_specification': load(task / 'question.json')['specification'],
             'actual_operations_all_runs': events,
             'final_source_comments_omitted': uncomment(task / 'work/dut.sv'),
             'final_testbench_comments_omitted': uncomment(task / 'work/diag_tb.sv'),
             'initial_source_comments_omitted': uncomment(Path(load(root / 'plan.json')['initial']) / 'candidates-initial' / qid / 'dut.sv'),
             'developer_static_review_not_simulation_proof': (
                 'The original 2-bit pointer maps binary 2 to Gray 110; with synchronized read Gray 000, '
                 'the original full expression becomes true after only two accepted writes, not four. '
                 'A watchdog alone does not prove the teacher narrative of four writes wrapping and then a read hang. '
                 'The corrected pointer candidate passed the bank but its race-prone teacher test still failed. '
                 'Neither the functional cause nor physical CDC safety is signed off.'),
             'native_result': load(task / 'agent-result.json')}
    payload = {'model': 'deepseek-v4-pro', 'temperature': 0, 'max_tokens': 2200, 'stream': False,
               'thinking': {'type': 'disabled'}, 'response_format': {'type': 'json_object'}, 'messages': [
        {'role': 'system', 'content': 'Summarize only visible engineering actions and evidence, not hidden reasoning. '
         'This is a report of an INCOMPLETE native agent task, not a new attempt to repair it. Do not supply replacement code. '
         'Return concise JSON with exactly diagnosis/correction/verification/remaining/rules. The first four fields are strings; '
         'rules is a list of 1-3 objects each with trigger/action/check/caveat strings, no case IDs, local paths or solution snippets. '
         'Separate actual changes, identical-hash no-op writes, frozen test passes, failed teacher-authored tests, '
         'testbench race risks, and output/call-budget stops. Do not turn a hypothesis or a pass into a general proof.'},
        {'role': 'user', 'content': json.dumps(facts, ensure_ascii=False)}]}
    numbers = [int(p.name) for p in (task / 'api').iterdir() if p.is_dir() and p.name.isdigit()]
    directory = task / 'api' / f'{max(numbers, default=0) + 1:03d}'
    directory.mkdir()
    save(directory / 'purpose.json', {'kind': 'POSTHOC_TEACHER_REFLECTION_NOT_NATIVE_AGENT_ACTION'})
    save(directory / 'attribution-headers.json', {'user-agent': 'rtl-teacher-development-report/2'})
    with contextlib.redirect_stdout(io.StringIO()):
        run(root, directory, payload)
    response = load(directory / 'response.json')
    if response['choices'][0]['finish_reason'] != 'stop':
        raise ValueError('Incomplete reflection; no implicit retry')
    report = json.loads(response['choices'][0]['message']['content'])
    save(task / 'teacher-reflection.json', {'origin': 'POSTHOC_TEACHER_REFLECTION_NOT_NATIVE_FINISH',
         'request': str(directory / 'request.json'), 'request_sha256': sha(directory / 'request.json'), 'report': report})
    print('Teacher failure reflection recorded, native task remains incomplete: ' + qid)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--id', choices=('Q123',), default='Q123')
    args = parser.parse_args()
    reflect(args.out, args.id)

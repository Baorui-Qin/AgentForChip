import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const YAML = require('D:/deepseek-harness/node_modules/.pnpm/yaml@2.9.0/node_modules/yaml');
const [skill, output] = process.argv.slice(2);
const text = fs.readFileSync(path.join(skill, 'SKILL.md'), 'utf8');
const front = text.match(/^---\r?\n([\s\S]*?)\r?\n---/);
if (!front) throw new Error('Missing frontmatter');
const metadata = YAML.parse(front[1]);
if (!/^[a-z0-9-]{1,64}$/.test(metadata.name) || typeof metadata.description !== 'string') throw new Error('Invalid discovery metadata');
const catalog = fs.readFileSync(path.join(skill, 'references/rules.json'), 'utf8');
const rules = JSON.parse(catalog).rules;
if (!rules.length || new Set(rules.map(r => r.id)).size !== rules.length) throw new Error('Invalid catalog IDs');
for (const rule of rules) {
  for (const field of ['trigger', 'action', 'check', 'caveat', 'support', 'review_note']) {
    if (typeof rule[field] !== 'string' || !rule[field].trim()) throw new Error('Missing conditional rule field: ' + field);
  }
}
if (/\bQ\d{3}\b|module\s+top_module|D:[/\\]|\[TODO:/i.test(text + catalog)) throw new Error('Case leakage or unfinished scaffold');
const result = { status: 'PASS', rules: rules.length, parser: 'existing local yaml 2.9.0',
  scope: 'FRONTMATTER_RULE_SCHEMA_AND_CASE_LEAKAGE_ONLY_NOT_BEHAVIORAL_GAIN' };
fs.writeFileSync(output, JSON.stringify(result, null, 2), { flag: 'wx' });
console.log(JSON.stringify(result));

"""Freeze a separate full-agent continuation; launch only through the existing dsh profile."""
import argparse
import json
from pathlib import Path
import os
import shutil
import subprocess
import sys

from task_tools import prepare, environment
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import IDS, load, sha
from api_worker import budget_state
from completion_gate import handoff_from_review

HERE = Path(__file__).resolve().parent
HARNESS = Path('D:/AMD/workspaces/http-paired-20261016/harness')
INITIAL = Path('D:/AMD/output/rtl-api-distillation-20261017/pilot-01')
FAILURE_PATHS = ['Q123', 'Q073', 'Q114', 'Q083', 'Q118', 'Q197', 'Q163', 'Q155', 'Q193', 'Q010']


def authorized_caps(parent, usage, limits, approval=None):
    caps = {'requests': parent['max_requests'], 'tokens': parent['max_reported_tokens'],
            'eda': parent.get('max_eda_cumulative')}
    if approval:
        if approval.get('status') != 'EXPLICITLY_APPROVED_BY_USER' or approval.get('task_limits') != limits:
            raise ValueError('Budget amendment is not approved or does not match task allocations')
        if approval['previous_used']['requests'] != usage['calls'] or approval['previous_used']['tokens'] != usage['total']:
            raise ValueError('Budget approval does not match the actual prior ledger')
        if approval['previous_caps'] != caps:
            raise ValueError('Budget amendment does not match prior cumulative caps')
        caps = approval['cumulative_caps']
        if set(caps) != {'requests', 'tokens', 'eda'} or any(type(v) is not int or v <= 0 for v in caps.values()):
            raise ValueError('Invalid approved cumulative caps')
    if (usage['calls'] + sum(v['requests'] for v in limits.values()) > caps['requests'] or
            usage['total'] + sum(v['tokens'] for v in limits.values()) > caps['tokens']):
        raise ValueError('Continuation allocations exceed explicit cumulative authorization')
    return caps


def profile(root, driver=HERE / 'agent.ts', knowledge=True):
    home = root / 'home'
    directory = home / 'profiles/rtl-teacher-agent-v2'
    directory.mkdir(parents=True)
    services = {'llm': 'llm/llm', 'session': 'core/session', 'projections': 'session/session-projection',
                'prompt': 'core/system-prompt', 'tools': 'core/tools', 'agents': 'core/agent', 'loop': 'core/agent-loop'}
    plugins = []
    for name, path in services.items():
        item = {'id': name, 'name': str(HARNESS / 'packages' / path / 'src/index.ts')}
        if name == 'prompt':
            item['config'] = {'personaPrefix': '', 'includeHarnessIdentity': False, 'includeRuntimeContext': False}
        if name == 'loop':
            item['config'] = {'agents': [], 'maxParallelToolCalls': 1}
        plugins.append(item)
    if knowledge:
        prepared = subprocess.run([shutil.which('node'), str(HERE.parent / 'knowledge-runtime/prepare.mjs'),
                                   str(root / 'knowledge-runtime')], check=True, capture_output=True, text=True,
                                  creationflags=subprocess.CREATE_NO_WINDOW)
        plugins.extend(json.loads(prepared.stdout))
    plugins.append({'id': 'teacher-agent-v2', 'name': str(driver)})
    save(directory / 'package.json', {'name': 'rtl-teacher-agent-v2-profile', 'private': True, 'dependencies': {},
         'dsh': {'profile': {'bundles': [], 'patchReload': 'startup'}}})
    save(directory / 'cordis.yml', [])
    save(directory / 'cordis.patch.yml', [{'insert': plugins}])


def initialize(root, continuation=None, maximum_tokens=300000, replay_from=None, original_failures=False,
               selected_ids=None, shared_budget_from=None, task_limits=None, handoff_review=None, authorization=None,
               stepwise_review=False):
    order = FAILURE_PATHS if original_failures else ['Q123', 'Q163', 'Q118', 'Q197'] + [qid for qid in IDS if qid not in ('Q123', 'Q163', 'Q118', 'Q197')]
    if selected_ids:
        if not (original_failures or continuation) or len(set(selected_ids)) != len(selected_ids) or not set(selected_ids) <= set(FAILURE_PATHS):
            raise ValueError('Task selection is limited to unique original failure-path IDs')
        order = selected_ids
    if shared_budget_from and not original_failures:
        raise ValueError('Separate shared-budget replay must use original inputs')
    limits = load(task_limits) if task_limits else {}
    if limits and (set(limits) != set(order) or not (original_failures or continuation) or shared_budget_from or replay_from):
        raise ValueError('Per-task budget requires original inputs or an explicit continuation and exact selected IDs')
    for value in limits.values():
        if set(value) != {'requests', 'tokens', 'eda'} or any(type(v) is not int or v <= 0 for v in value.values()):
            raise ValueError('Invalid per-task budget')
    if limits and sum(v['tokens'] for v in limits.values()) != maximum_tokens:
        raise ValueError('Task token allocations must equal the approved run limit')
    bounded_continuation = bool(continuation and limits)
    parent_plan, parent_usage = (None, None)
    handoffs = {}
    approval = load(authorization) if authorization else None
    caps = None
    if bounded_continuation:
        if not handoff_review:
            raise ValueError('Explicit counterevidence handoff review is required for continuation')
        review = load(handoff_review)
        if set(review['tasks']) != set(order):
            raise ValueError('Handoff review must cover every selected task exactly')
        parent_plan, parent_usage = budget_state(continuation, continuation / 'tasks/_budget/api/000')
        caps = authorized_caps(parent_plan, parent_usage, limits, approval)
        if not load(continuation / 'harness-process.json')['reaped']:
            raise ValueError('Prior Harness must be stopped')
        for qid in order:
            if not (continuation / 'tasks' / qid / 'agent-result.json').exists():
                raise ValueError('Cannot continue an unfinished task process')
            handoffs[qid] = handoff_from_review(continuation / 'tasks' / qid, review['tasks'][qid])
    prepare(root, INITIAL, order, original=original_failures)
    if authorization:
        shutil.copyfile(authorization, root / 'human-authorization.json')
    source_run = continuation or replay_from
    if source_run:
        for qid in order:
            old = source_run / 'tasks' / qid
            current = root / 'tasks' / qid
            for name in ('dut.sv', 'diag_tb.sv', 'answer.md'):
                if (old / 'work' / name).exists():
                    shutil.copyfile(old / 'work' / name, current / 'work' / name)
            history = []
            for directory in sorted((old / 'operations').glob('*')):
                if (directory / 'call.json').exists() and (directory / 'result.json').exists():
                    call = load(directory / 'call.json')
                    history.append({'evidence_id': directory.name, 'tool': call['name'],
                                    'result': load(directory / 'result.json')})
            if history:
                path = current / 'work/initial-evidence.json'
                value = {} if bounded_continuation else load(path)
                last_evidence = {}
                for item in history:
                    kind = item['result'].get('kind')
                    if kind:
                        result = item['result']
                        last_evidence[kind] = {'evidence_id': item['evidence_id'], 'tool': item['tool'],
                            'result': {key: result[key] for key in ('kind', 'source_sha256', 'testbench_sha256', 'cases') if key in result}}
                value['prior_actual_operations'] = {'count': len(history), 'latest_evidence_by_kind': last_evidence,
                    'same_hash_writes': sum(1 for item in history if item['tool'] == 'write_file' and
                        item['result'].get('sha256') == item['result'].get('previous_sha256'))}
                value['continuation_notice'] = (
                    'This is a new knowledge-assisted replay of the last persisted files and recorded evidence. '
                    'Historical evaluations are not this run\'s validation. Inspect the current source and rerun. '
                    'Do not repeat long prose or claim diagnosis alone proves correctness.') if replay_from else (
                    'Continue from the last persisted files and actual recorded operations. '
                    'Historical evidence is not a new execution or a successful completion.')
                previous_result = old / 'agent-result.json'
                if previous_result.exists():
                    outcome = load(previous_result)
                    value['previous_native_outcome'] = {key: outcome.get(key) for key in ('status', 'calls', 'operations')}
                if qid == 'Q123' and not replay_from and not bounded_continuation:
                    value['developer_test_review_not_a_repair'] = (
                        'The teacher diagnostic drives and deasserts handshake signals at posedge and advances its expected queue '
                        'in the active region, before DUT NBA updates. An off-by-one diagnostic mismatch does not isolate the DUT '
                        'from a testbench sampling/driver race. Inspect and correct test scheduling before assigning that cause. '
                        'Prior writes with identical source hashes did not fix anything. No replacement RTL or TB is supplied.')
                if bounded_continuation:
                    value.update(kind='prior_api_model_artifacts_not_new_validation',
                        baseline_evaluation_required_before_edit=False,
                        continuation_notice='Continue the API model\'s own DUT and diagnostic. Inspect both for defects; '
                        'repair necessary files, run both final tests yourself, then summarize actual new operations. '
                        'Prior bank/diagnostic passes are not new validation and do not establish testbench correctness. '
                        'No developer-corrected artifact or developer supplemental test has been supplied. '
                        'The original-error trajectory remains linked in the local provenance ledger.')
                path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
            if bounded_continuation:
                # Only the prior model work directory supplies the continuation seed.
                shutil.copyfile(current / 'work/dut.sv', current / 'work/previous-answer.md')
                handoff, refs = handoffs[qid]
                save(current / 'work/handoff.json', handoff)
                save(current / 'completion-contract.json', handoff['completion_contract'])
                save(current / 'handoff-provenance.json', {'review_path': str(handoff_review),
                     'review_sha256': sha(handoff_review), 'evidence': refs})
                save(current / 'start-state.json', {'origin': 'prior_api_model_artifacts', 'baseline_required': False,
                     'required_changed_files': handoff['completion_contract']['required_changed_files']})
                shutil.copytree(current / 'work', current / 'seed')
                files = {}
                for name in ('dut.sv', 'diag_tb.sv'):
                    prior = old / 'work' / name
                    matching = [item['evidence_id'] for item in history if item['tool'] == 'write_file' and
                                item['result'].get('path') == name and item['result'].get('sha256') == sha(prior)]
                    inherited = None
                    if not matching and (old / 'continuation-provenance.json').exists():
                        previous = load(old / 'continuation-provenance.json')['files'][name]
                        if previous['sha256'] == sha(prior) == load(old / 'seed-manifest.json')[name]:
                            inherited = {'path': str(old / 'continuation-provenance.json'), 'sha256': sha(old / 'continuation-provenance.json')}
                    if not matching and not inherited:
                        raise ValueError('Continuation file not bound to a prior API model write: ' + str(prior))
                    files[name] = {'prior_path': str(prior), 'sha256': sha(prior), 'model_write_operations': matching,
                                   'unchanged_inherited_model_file': inherited}
                input_audit = source_run / ('continuation-input-audit.json' if (source_run / 'continuation-input-audit.json').exists() else 'original-input-audit.json')
                save(current / 'continuation-provenance.json', {'parent_task': str(old), 'files': files,
                     'original_seed_manifest': {'path': str(old / 'seed-manifest.json'), 'sha256': sha(old / 'seed-manifest.json')},
                     'parent_input_audit': {'path': str(input_audit), 'sha256': sha(input_audit)},
                     'prior_operations': [{'id': item['evidence_id'],
                        'result_sha256': sha(old / 'operations' / item['evidence_id'] / 'result.json')} for item in history]})
            (current / 'seed-manifest.json').write_text(json.dumps(
                {p.name: sha(p) for p in (current / 'work').iterdir()}, indent=2), encoding='utf-8')
    budget_parent = shared_budget_from or continuation
    budget_roots = load(budget_parent / 'plan.json')['budget_roots'] if budget_parent else []
    if budget_parent and not bounded_continuation and maximum_tokens != load(budget_parent / 'plan.json')['max_reported_tokens']:
        raise ValueError('Shared-budget replay cannot change the authorized total token limit')
    continuation_budget = {}
    if bounded_continuation:
        prior_audit = load(continuation / 'final-validation.json')
        if not prior_audit['passed']:
            raise ValueError('Prior budget evidence is not validated')
        previous_eda = (prior_audit['cumulative']['eda'] if 'cumulative' in prior_audit else
                        sum(prior_audit[k] for k in ('agent_eda_runs', 'preflight_eda_runs', 'independent_review_eda_runs')))
        new_eda = sum(v['eda'] for v in limits.values())
        if approval and approval['previous_used']['eda'] != previous_eda:
            raise ValueError('Approved EDA amendment does not match prior evidence')
        eda_cap = caps['eda'] if caps['eda'] is not None else previous_eda + new_eda
        if previous_eda + new_eda > eda_cap:
            raise ValueError('Continuation exceeds the authorized cumulative EDA cap')
        continuation_budget = {'max_requests_this_run': sum(v['requests'] for v in limits.values()),
            'max_tokens_this_run': maximum_tokens, 'max_eda_this_run': new_eda,
            'prior_eda_runs': previous_eda, 'max_eda_cumulative': eda_cap,
            'prior_usage': parent_usage, 'prior_budget_evidence_sha256': sha(continuation / 'final-validation.json'),
            'closing_policy': 'token_aware_correction_allowed', 'developer_supplemental_eda_allowed': False,
            'context_policy': {'kind': 'artifact_checkpoint_v2', 'max_request_bytes': 65536},
            'completion_policy': 'required_changes_final_tests_and_read_only_review'}
    save(root / 'plan.json', {'scope': 'TEACHER_FULL_AGENT_DEVELOPMENT_CONTINUATION_NOT_BASELINE_OR_GAIN_TEST',
         'initial': str(INITIAL), 'execution_order': order, 'model': 'deepseek-v4-pro', 'thinking': 'disabled',
         'max_requests': caps['requests'] if bounded_continuation else sum(v['requests'] for v in limits.values()) if limits else 120,
         'max_reported_tokens': caps['tokens'] if bounded_continuation else maximum_tokens, 'max_requests_per_task': 12,
         'max_eda_runs_per_task': 5, 'automatic_retry': False,
         'task_limits': limits, 'reserved_closing_calls': 3 if limits else 0,
         'native_harness': str(HARNESS), 'native_agent_loop': True,
         'knowledge_runtime_required': True,
         'knowledge_use_directed': True,
         'stepwise_review': stepwise_review,
         'original_failure_paths': original_failures,
         'summary_schema': 'host_bound_operation_claims_v2',
         'os_read_isolation': False, 'model_tools_allowlisted': True, 'arbitrary_shell': False,
         'allowed_outbound': ['selected visible prompts', 'previous visible answers', 'model-authored files',
                              'sanitized diagnostics', 'visible tool operations',
                              'frozen generalized skills and selected runtime knowledge subgraphs'],
         'excluded_outbound': ['private TB', 'reference solutions', 'private vectors', 'credentials', 'original project source'],
         'budget_roots': budget_roots + [str(root)],
         'shares_budget_with': str(shared_budget_from) if shared_budget_from else None,
         'continues_native_run': str(continuation) if continuation else None,
         'replays_native_run': str(replay_from) if replay_from else None,
         'source_files': {p.name: sha(p) for p in HERE.iterdir() if p.is_file()}, **continuation_budget})
    profile(root)


def run(root, keyless=False):
    if not keyless and not (root / 'external-scope-approved.json').exists():
        raise ValueError('Explicit human approval of outbound data scope is required')
    env = environment()
    home = root / 'home'
    env.update(HOME=str(home), USERPROFILE=str(home), DSH_HOME=str(home), DSH_TELEMETRY_DISABLED='1',
               NO_COLOR='1', TSX_TSCONFIG_PATH=str(HARNESS / 'tsconfig.json'), TSX_DISABLE_CACHE='1')
    if keyless:
        env['RTL_AGENT_KEYLESS_PREFLIGHT'] = '1'
    argv = [shutil.which('node'), '--import', (HARNESS / 'node_modules/tsx/dist/esm/index.mjs').as_uri(),
            str(HARNESS / 'apps/cli/src/bin.ts'), '--profile', 'rtl-teacher-agent-v2', str(root), sys.executable]
    print('Starting real Harness teacher agent; evidence: ' + str(root), flush=True)
    logs = root
    if (root / 'harness-process.json').exists():
        number = len(list((root / 'launches').glob('*'))) + 1
        logs = root / 'launches' / f'{number:03d}'
        logs.mkdir(parents=True)
        save(logs / 'runtime-source-manifest.json', {p.name: sha(p) for p in HERE.iterdir() if p.is_file()})
    with (logs / 'harness-stdout.log').open('xb') as stdout, (logs / 'harness-stderr.log').open('xb') as stderr:
        process = subprocess.run(argv, cwd=HARNESS, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
    save(logs / 'harness-process.json', {'argv': argv, 'exit_code': process.returncode, 'reaped': True})
    print('Harness exit: ' + str(process.returncode), flush=True)
    if process.returncode:
        print((logs / 'harness-stderr.log').read_text(encoding='utf-8', errors='replace')[-10000:])
    return process.returncode


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('prepare', 'run', 'preflight', 'approved-run'))
    parser.add_argument('--out', type=Path, required=True)
    source = parser.add_mutually_exclusive_group()
    source.add_argument('--continuation-from', type=Path)
    source.add_argument('--replay-from', type=Path)
    source.add_argument('--original-failures', action='store_true')
    parser.add_argument('--max-tokens-budget', type=int, default=300000)
    parser.add_argument('--ids', nargs='+')
    parser.add_argument('--shared-budget-from', type=Path)
    parser.add_argument('--task-limits', type=Path)
    parser.add_argument('--handoff-review', type=Path)
    parser.add_argument('--authorization', type=Path)
    parser.add_argument('--stepwise-review', action='store_true')
    args = parser.parse_args()
    if args.command == 'prepare':
        initialize(args.out, args.continuation_from, args.max_tokens_budget, args.replay_from, args.original_failures,
                   args.ids, args.shared_budget_from, args.task_limits, args.handoff_review, args.authorization, args.stepwise_review)
    elif args.command == 'preflight':
        initialize(args.out)
        raise SystemExit(run(args.out, keyless=True))
    else:
        if args.command == 'approved-run':
            save(args.out / 'external-scope-approved.json', {
                'basis': 'Explicit host command approval with outbound scope and caps in the approval question',
                'destination': 'https://api.deepseek.com/chat/completions',
                'scope': load(args.out / 'plan.json')['allowed_outbound'],
                'excluded': load(args.out / 'plan.json')['excluded_outbound'],
                'max_requests': load(args.out / 'plan.json')['max_requests'],
                'max_reported_tokens': load(args.out / 'plan.json')['max_reported_tokens']})
            save(args.out / 'runtime-source-manifest.json', {p.name: sha(p) for p in HERE.iterdir() if p.is_file()})
        raise SystemExit(run(args.out))

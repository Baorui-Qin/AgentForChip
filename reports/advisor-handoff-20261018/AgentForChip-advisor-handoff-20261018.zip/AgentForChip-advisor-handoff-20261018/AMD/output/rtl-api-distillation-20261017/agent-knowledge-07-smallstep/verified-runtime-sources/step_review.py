"""Human-visible per-call gate for bounded real API probes. No source edits or EDA."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import save
from pilot import load, sha
from completion_gate import source_tokens


def observation(task, number):
    api = task / 'api' / f'{number:03d}'
    response, receipt = load(api / 'response.json'), load(api / 'receipt.json')
    if receipt['status'] != 200:
        raise ValueError('Step has no confirmed successful API receipt')
    calls = {c['id']: c for c in response['choices'][0]['message'].get('tool_calls', [])}
    operations = []
    for path in sorted((task / 'operations').glob('*/result.json')):
        directory = path.parent
        dispatch = load(task / ('tool-dispatch-' + directory.name + '.json'))
        if dispatch['tool_call_id'] not in calls:
            continue
        result, call = load(path), load(directory / 'call.json')
        item = {'operation': directory.name, 'tool': call['name'], 'result_sha256': sha(path), 'result': result}
        if call['name'] == 'write_file' and not result.get('operation_rejected'):
            item['non_comment_change'] = source_tokens((directory / 'before.txt').read_text(encoding='utf-8')) != source_tokens(
                (directory / 'after.txt').read_text(encoding='utf-8'))
        operations.append(item)
    retrieval = task.parent.parent / 'knowledge-runtime/retrieval/retrieval.jsonl'
    lookups = []
    if retrieval.exists():
        for line in retrieval.read_text(encoding='utf-8').splitlines():
            value = json.loads(line)
            if value.get('tool_call_id') in calls and value['event'] in ('lookup', 'retrieval_guard_stopped'):
                lookups.append(value)
    return {'call': number, 'response_sha256': sha(api / 'response.json'), 'receipt_sha256': sha(api / 'receipt.json'),
            'reported_tokens': response['usage']['total_tokens'],
            'tools': [{'id': ident, 'name': value['function']['name'], 'arguments': value['function']['arguments']}
                      for ident, value in calls.items()],
            'operations': operations, 'lookups': lookups,
            'work_sha256': {name: sha(task / 'work' / name) for name in ('dut.sv', 'diag_tb.sv')}}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()


def await_review(task, number, timeout=600):
    current = observation(task, number)
    pending = task / f'step-review-pending-{number:03d}.json'
    if not pending.exists():
        save(pending, {'scope': 'AFTER_REAL_CALL_BEFORE_ANY_NEXT_REQUEST', 'observation': current,
             'observation_sha256': digest(current), 'awaiting_host_read_only_review': True})
    decision = task / 'step-decisions' / f'after-{number:03d}.json'
    deadline = time.monotonic() + timeout
    while not decision.exists():
        if time.monotonic() >= deadline:
            raise ValueError('Step review timeout; stop before any next API request')
        time.sleep(0.25)
    value = load(decision)
    if value['observation_sha256'] != digest(observation(task, number)):
        raise ValueError('Step decision is stale; stop before dispatch')
    if value['action'] not in ('continue', 'stop_task', 'stop_run') or not value.get('reason'):
        raise ValueError('Invalid step decision')
    return value


def decide(task, number, action, reason):
    if action not in ('continue', 'stop_task', 'stop_run') or not isinstance(reason, str) or not reason.strip():
        raise ValueError('A concrete action and review reason are required')
    pending = load(task / f'step-review-pending-{number:03d}.json')
    value = observation(task, number)
    if pending['observation_sha256'] != digest(value):
        raise ValueError('Observed artifacts changed during review')
    result = {'action': action, 'reason': reason, 'observation_sha256': digest(value),
              'review_kind': 'host_read_only_action_check_no_source_edits_no_eda'}
    if action == 'stop_run':
        save(task.parent.parent / 'step-stop-run.json', {'task': task.name, 'call': number, 'reason': reason})
    save(task / 'step-decisions' / f'after-{number:03d}.json', result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('await', 'inspect', 'decide'))
    parser.add_argument('task', type=Path)
    parser.add_argument('number', type=int)
    parser.add_argument('--action', choices=('continue', 'stop_task', 'stop_run'))
    parser.add_argument('--reason')
    args = parser.parse_args()
    if args.mode == 'await':
        value = await_review(args.task, args.number)
    elif args.mode == 'inspect':
        value = observation(args.task, args.number)
    else:
        value = decide(args.task, args.number, args.action, args.reason)
    print(json.dumps(value, ensure_ascii=False))

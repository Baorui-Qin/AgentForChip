"""Single no-retry official request, called by a real Harness LLM adapter."""
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api_client import Client, save
from pilot import load
from context_window import bound_context, encoded_size


def budget_state(root, directory):
    plan = load(root / 'plan.json')
    budget_roots = plan.get('budget_roots', [str(root)])
    if len(set(map(str, map(Path, budget_roots)))) != len(budget_roots):
        raise ValueError('Duplicate budget roots')
    calls = [path for base in budget_roots for path in (Path(base) / 'tasks').glob('*/api/*/reservation.json')]
    total = 0
    task_total = 0
    task_calls = 0
    run_total = 0
    run_calls = 0
    for reservation in calls:
        receipt = reservation.parent / 'receipt.json'
        response = reservation.parent / 'response.json'
        if not receipt.exists() or not response.exists():
            raise ValueError('Prior API outcome unknown; explicit reconciliation required, no automatic retry')
        usage = load(response).get('usage', {})
        if not isinstance(usage.get('total_tokens'), int):
            raise ValueError('Prior usage unavailable; stop rather than assume zero')
        total += usage['total_tokens']
        if reservation.parent.parent.parent.parent.parent == root:
            run_calls += 1
            run_total += usage['total_tokens']
        if reservation.parent.parent.parent == directory.parent.parent:
            task_calls += 1
            task_total += usage['total_tokens']
    return plan, {'total': total, 'calls': len(calls), 'task_total': task_total, 'task_calls': task_calls,
                  'run_total': run_total, 'run_calls': run_calls}


def check_budget(root, directory, payload):
    plan, state = budget_state(root, directory)
    total, task_total, task_calls = state['total'], state['task_total'], state['task_calls']
    if state['calls'] >= plan['max_requests']:
        raise ValueError('Approved request budget exhausted')
    # UTF-8 bytes provide a deliberately conservative reservation, not a tokenizer estimate.
    reservation = len(json.dumps(payload, ensure_ascii=False).encode('utf-8')) + payload['max_tokens']
    limit = plan['max_reported_tokens']
    policy = root / 'budget-policy.json'
    if payload.get('tools') and policy.exists():
        limit -= load(policy)['reserve_for_failure_reflection']
    if total + reservation > limit:
        raise ValueError('Approved token budget has insufficient conservative reservation for the next call')
    if (state['run_calls'] >= plan.get('max_requests_this_run', plan['max_requests']) or
            state['run_total'] + reservation > plan.get('max_tokens_this_run', limit)):
        raise ValueError('This-run approved budget has insufficient conservative reservation')
    task_limit = plan.get('task_limits', {}).get(directory.parent.parent.name)
    if task_limit and (task_calls >= task_limit['requests'] or task_total + reservation > task_limit['tokens']):
        raise ValueError('Per-task approved budget has insufficient conservative reservation; other allocations cannot be borrowed')
    return {'previous_actual_tokens': total, 'reserved_upper_bound': reservation,
            'call_number': state['calls'] + 1, 'previous_task_tokens': task_total, 'task_call_number': task_calls + 1,
            'previous_run_tokens': state['run_total'], 'run_call_number': state['run_calls'] + 1}


def prepare_payload(root, directory, payload):
    plan, state = budget_state(root, directory)
    if plan.get('closing_policy') != 'token_aware_correction_allowed':
        return payload, {'policy': 'legacy'}
    limits = plan['task_limits'][directory.parent.parent.name]
    remaining_tokens = min(plan['max_reported_tokens'] - state['total'],
                           plan['max_tokens_this_run'] - state['run_total'], limits['tokens'] - state['task_total'])
    remaining_calls = min(plan['max_requests'] - state['calls'],
                          plan['max_requests_this_run'] - state['run_calls'], limits['requests'] - state['task_calls'])
    payload = dict(payload)
    bound = len(json.dumps(payload, ensure_ascii=False).encode('utf-8')) + payload['max_tokens']
    closing = remaining_calls <= 2 or remaining_tokens < 3 * bound
    message = (f'Budget: {remaining_calls} requests including this one, {remaining_tokens} reported tokens remain '
               'within all cumulative/run/task caps. Each full request must fit a conservative UTF-8-byte plus output reservation. '
               + ('Closing priority: ' if closing else 'Execution priority: ')
               + 'necessary corrective writes are allowed. Batch independent writes or final tests; after their results, '
               'submit the operation-bound summary. Do not waste requests rereading preloaded files or rewriting identical content. '
               'If a check fails, make a concrete correction within remaining budgets or preserve the failure. '
               'No historical/developer test substitutes for this run. Budget does not guarantee completion.')
    payload['messages'] = [{'role': 'system', 'content': message}, *payload['messages']]
    original_max = payload['max_tokens']
    for _ in range(3):
        size = len(json.dumps(payload, ensure_ascii=False).encode('utf-8'))
        payload['max_tokens'] = min(original_max, remaining_tokens - size)
    if payload['max_tokens'] < 1024:
        raise ValueError('Full input plus minimum output reservation cannot fit; stop before dispatch')
    if plan.get('context_policy') and encoded_size(payload) > plan['context_policy']['max_request_bytes']:
        raise ValueError('Checkpoint plus budget instructions exceeds active request byte cap')
    check_budget(root, directory, payload)
    return payload, {'policy': plan['closing_policy'], 'remaining_calls': remaining_calls,
                     'remaining_tokens': remaining_tokens, 'closing_priority': closing,
                     'original_max_tokens': original_max, 'effective_max_tokens': payload['max_tokens'],
                     'state': state, 'conservative_bytes_are_not_reported_tokens': True}


def run(root, directory, payload):
    plan, _ = budget_state(root, directory)
    payload, checkpoint = bound_context(root, directory, payload, plan)
    save(directory / 'context-checkpoint.json', checkpoint)
    if plan.get('context_policy'):
        save(directory / 'checkpoint-payload.json', payload)
    payload, decision = prepare_payload(root, directory, payload)
    save(directory / 'budget-decision.json', decision)
    save(directory / 'reservation.json', check_budget(root, directory, payload))
    save(directory / 'request.json', payload)
    client = Client(direct=True)
    client.opener.addheaders = list(load(directory / 'attribution-headers.json').items())
    try:
        value, receipt = client.request('/chat/completions', payload)
        filtered = {key: value.get(key) for key in ('id', 'model', 'created', 'usage')}
        filtered['choices'] = []
        for choice in value.get('choices', []):
            message = choice.get('message', {})
            filtered['choices'].append({'index': choice.get('index'), 'finish_reason': choice.get('finish_reason'),
                'message': {key: message[key] for key in ('role', 'content', 'tool_calls') if key in message}})
        receipt['persisted_response_is_filtered'] = True
        receipt['thinking_requested'] = 'disabled'
        save(directory / 'response.json', filtered)
        save(directory / 'receipt.json', receipt)
        print(json.dumps(filtered, ensure_ascii=False))
    except Exception as error:
        save(directory / 'failure.json', {'error': client.clean(error), 'automatic_retry': False,
                                        'charged_status': 'unknown_unless_provider_confirms'})
        raise


if __name__ == '__main__':
    if sys.argv[1] == '--checkpoint-only':
        root, directory, payload_file = map(Path, sys.argv[2:])
        payload, record = bound_context(root, directory, load(payload_file), load(root / 'plan.json'))
        save(directory / 'checkpoint-preview.json', payload)
        save(directory / 'checkpoint-audit.json', {**record, 'offline_only': True, 'api_requests': 0, 'eda_runs': 0})
        print(json.dumps({'offline_only': True, 'checkpoint_bytes': encoded_size(payload), 'api_requests': 0, 'eda_runs': 0}))
        raise SystemExit(0)
    root, directory, payload = map(Path, sys.argv[1:])
    run(root, directory, load(payload))

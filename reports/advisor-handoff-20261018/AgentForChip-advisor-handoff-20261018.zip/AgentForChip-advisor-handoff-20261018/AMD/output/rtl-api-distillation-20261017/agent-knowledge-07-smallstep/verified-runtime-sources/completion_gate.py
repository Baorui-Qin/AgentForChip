"""Fail-closed continuation handoff and completion facts; no EDA or source repair."""
import re
import json
from pathlib import Path

from pilot import load, sha


def source_tokens(text):
    parts = re.findall(r'"(?:\\.|[^"\\])*"|//[^\n]*|/\*[\s\S]*?\*/|[A-Za-z_$][\w$]*|\d[\w\x27.]*|[^\s]', text)
    return [p for p in parts if not p.startswith(('//', '/*'))]


def handoff_from_review(old, review):
    if not review.get('findings') or not review.get('required_changed_files'):
        raise ValueError('Continuation requires explicit unresolved findings and required file changes')
    if set(review['file_sha256']) != {'dut.sv', 'diag_tb.sv'}:
        raise ValueError('Review must bind both model work files')
    for name, expected in review['file_sha256'].items():
        if sha(old / 'work' / name) != expected:
            raise ValueError('Stale handoff review: ' + name)
    ids = [v['id'] for v in review['findings']]
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate unresolved finding')
    if not set(review['required_changed_files']) <= {'dut.sv', 'diag_tb.sv'}:
        raise ValueError('Invalid required change file')
    findings, provenance = [], []
    for value in review['findings']:
        if (value['file'] not in review['required_changed_files'] or not value.get('observation') or
                not value.get('resolution_condition') or not value.get('evidence')):
            raise ValueError('Incomplete handoff finding')
        refs = []
        for relative in value['evidence']:
            path = old / relative
            if not path.resolve().is_relative_to(old.resolve()) or not relative.startswith(('work/', 'operations/')):
                raise ValueError('Handoff evidence outside prior model artifacts')
            refs.append({'id': relative, 'sha256': sha(path)})
            provenance.append({'path': str(path), 'sha256': sha(path)})
        findings.append({k: value[k] for k in ('id', 'file', 'observation', 'resolution_condition')})
        findings[-1].update(status='unresolved', evidence=refs)
    contract = {'schema': 'continuation-completion-v1', 'required_changed_files': review['required_changed_files'],
                'required_resolutions': ids, 'read_only_semantic_review_required': True}
    return {'kind': 'READ_ONLY_REVIEW_COUNTEREVIDENCE_NOT_REPLACEMENT_CODE',
            'notice': 'Prior passes do not resolve these findings. Repair your own files, run final diagnostic and frozen '
                      'evaluation yourself, then summarize. The host will not supply corrected RTL/TB or supplemental EDA.',
            'seed_work_sha256': review['file_sha256'], 'unresolved_findings': findings,
            'completion_contract': contract}, provenance


def correction_checks(task, final_pass):
    path = task / 'completion-contract.json'
    if not path.exists():
        return None
    contract = load(path)
    handoff = load(task / 'work/handoff.json')
    if handoff['completion_contract'] != contract or sha(task / 'work/handoff.json') != load(task / 'seed-manifest.json')['handoff.json']:
        raise ValueError('Immutable continuation contract mismatch')
    checks, authored = {}, {}
    for name in contract['required_changed_files']:
        before = (task / 'seed' / name).read_text(encoding='utf-8')
        after = (task / 'work' / name).read_text(encoding='utf-8')
        checks[name] = source_tokens(before) != source_tokens(after)
        authored[name] = any(v.get('path') == name and v.get('no_change') is False and v.get('sha256') == sha(task / 'work' / name)
                             and model_requested(task, p.parent.name)
                             for p in (task / 'operations').glob('*/result.json') for v in [load(p)])
    missing = [name + ':required_non_comment_change_missing' for name, changed in checks.items() if not changed]
    missing += [name + ':final_model_write_missing' for name, valid in authored.items() if not valid]
    if not final_pass:
        missing.append('final_current_source_and_testbench_tests_not_passed')
    return {'non_comment_changes': checks, 'model_authored_required_changes': authored, 'missing': missing,
            'automated_prerequisites_passed': not missing,
            'semantic_correctness_established': False,
            'required_resolutions': contract['required_resolutions']}


def model_requested(task, operation):
    dispatch = task / ('tool-dispatch-' + operation + '.json')
    if not dispatch.exists():
        return False
    ident = load(dispatch)['tool_call_id']
    recorded = load(task / 'operations' / operation / 'call.json')
    matches = []
    for path in (task / 'api').glob('*/response.json'):
        for choice in load(path).get('choices', []):
            matches += [v for v in choice['message'].get('tool_calls', []) if v['id'] == ident]
    return (len(matches) == 1 and matches[0]['function']['name'] == recorded['name'] and
            json.loads(matches[0]['function']['arguments']) == recorded['arguments'])


def reviewed_status(task, audit, report_sha256):
    if not audit.get('automated_prerequisites_passed'):
        return 'incomplete'
    path = task / 'read-only-completion-review.json'
    if not path.exists():
        return 'pending_review'
    value = load(path)
    expected = {name: sha(task / 'work' / name) for name in ('dut.sv', 'diag_tb.sv')}
    tests = {v['operation']: sha(task / 'operations' / v['operation'] / 'result.json')
             for v in audit['final_tests'].values()}
    findings = value.get('findings', [])
    if (value.get('kind') != 'read_only_semantic_review_no_source_edits_or_eda' or
            value.get('file_sha256') != expected or value.get('submitted_report_sha256') != report_sha256 or
            value.get('test_result_sha256') != tests or
            len(findings) != len(audit['required_resolutions']) or
            {f.get('id') for f in findings} != set(audit['required_resolutions']) or
            not all(f.get('resolved') is True and f.get('source_evidence') and f.get('explanation') for f in findings)):
        return 'incomplete'
    return 'completed'

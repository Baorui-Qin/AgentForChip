# v2 两题小步验证：重复后停止

日期：2026-10-18。本轮使用现有剩余额度，没有追加预算。

## 结论

实际仅执行 **Q123 两次真实 API 请求，18,164 reported tokens**；模型写入 0 次、EDA 0 次、模型总结 0 份。Q123 第 2 次仍只读取已预载且 hash 未变的 DUT/TB，没有进入实质修改或验证。

按启动前明确记录的“发现重复则整轮停止”条件，没有启动 Q114；其两次额度完整保留。Q114 未测，不能记为模型失败，也不能外推它的 v2 表现。

确认 v2 数据通路已生效：第 2 份真实外发请求逐字保留了第一轮实际 assistant/tool 调用与回传，并携带检索到的规则。**数据通路修复不等于模型工作流恢复：本次两调用窗口未观察到从检索进入修改和验证。** 不声称 v2 已获行为收益，也不能据此断言更长运行永远不会编辑。

## 逐次动作与检查

| 调用 | tokens | 模型实际动作 | 检查后的宿主决定 |
| --- | ---: | --- | --- |
| Q123-001 | 7,297 | 两个不同检索，分别匹配 R-CDC/T-001/T-002 和 T-021；无文件操作 | 本会话首次相关检索，没有重复操作，明确放行一次后续调用 |
| Q123-002 | 10,867 | 读取 dut.sv、diag_tb.sv；内容与该请求中已预载文件完全一致 | 未产生新证据、修改或验证，重现此前检索后读取的模式；停止整轮 |
| Q114 | 0 | 未建立模型会话，未发送请求 | 受 Q123 的 stop_run 条件约束，保留额度 |

每次调用完成后，真实 Harness 都在下一次模型请求前等待宿主检查记录。决定绑定实际 API 响应、接收记录、操作结果及文件 hash。第 1 次决定只允许下一次；第 2 次 stop_run 阻止了第三次 Q123 及全部 Q114 请求。没有绕过守卫或自动续跑。

这不是禁止任何初次读取的普遍规则，而是本次明确的小步停止条件：模型已经拿到完整文件、反证及检索反馈，第二次却仅请求相同内容；在两次额度内尚未达到试验要观察的实质动作，因此不继续花费。

证据：

- [第 1 次完整观察](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/tasks/Q123/step-review-pending-001.json) / [放行记录](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/tasks/Q123/step-decisions/after-001.json)
- [第 2 次完整观察](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/tasks/Q123/step-review-pending-002.json) / [停止记录](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/tasks/Q123/step-decisions/after-002.json)
- [第 2 次真实外发请求](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/tasks/Q123/api/002/request.json) / [v2 最近轮次保留 hash](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/tasks/Q123/api/002/context-checkpoint.json)
- [整轮停止标记](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/step-stop-run.json)

## 预算与起点

累计上限保持 **100 次请求、1,150,000 tokens、54 次 EDA**。本轮累计实际用量变为 **98 次请求、922,099 tokens、36 次 EDA**，剩余 **2 次请求、227,901 tokens、18 次 EDA**。剩余请求均属于 Q114；Q123、Q193、Q083 的请求余量为 0。剩余 token 和 EDA 不构成跨题借用请求或扩大外发的许可。

两题都是从上一轮模型自己的文件续接，保留原始错误及全部历史证据链，没有继承开发者修正版。Q123 与 Q114 的 DUT/TB 最终 hash 均与本轮 seed 一致。没有开发者修改模型文件、补跑 EDA 或替模型提交总结。

已有 skill 与通用知识图谱实际挂载，相关检索文本在第 2 次请求中实际送达；没有新模型修复证据，也没有新的教师规则总结。此次保留负面观察，不据此制造新 RTL 技能或成功率。

证据：[授权](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/human-authorization.json)、[冻结计划](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/plan.json)、[实际用量](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/api-usage.json)、[限定结论](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/probe-conclusion.json)。

## 完整记录与验证

- [Q123 实际轨迹](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/knowledge-use-audit/Q123-TRAJECTORY.md)
- [Q114 未启动记录](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/knowledge-use-audit/Q114-TRAJECTORY.md)
- [实际证据图谱 JSON](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/knowledge-use-audit/graph.json) / [GraphML](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/knowledge-use-audit/graph.graphml)：119 节点、132 条关系，明确区分计划未启动、真实检索、实际读取和宿主只读检查。
- [最终完整性验证](D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/final-validation.json)：46 项通过，验证预算、逐次审查、真实消息保留、原文件未改和停止条件，不表示修复成功。

启动前 59 项本地控制测试通过；真实轨迹审计 25 项通过。它们不计入实际 API/EDA 次数，也不是模型行为或 RTL 正确性的替代验证。

原工程、冻结题库、旧 skill/知识及交接包前后快照一致，上一轮记录未改变。模型和工具进程已结束回收，无未知收费结果，无自动重试，没有再次调用 API。

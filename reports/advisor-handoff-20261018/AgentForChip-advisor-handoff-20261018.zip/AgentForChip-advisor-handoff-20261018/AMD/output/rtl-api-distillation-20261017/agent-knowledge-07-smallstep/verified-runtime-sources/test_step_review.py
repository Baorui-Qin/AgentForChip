"""Offline per-call gate fixtures; never call a model or EDA."""
import json
from pathlib import Path
import tempfile
import unittest

from step_review import observation, await_review, decide, digest
from api_client import save


class StepReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.task = Path(self.temp.name) / 'tasks/Q123'
        work = self.task / 'work'
        work.mkdir(parents=True)
        (work / 'dut.sv').write_text('module top_module; endmodule')
        (work / 'diag_tb.sv').write_text('module tb(output reg done); endmodule')
        save(self.task / 'api/001/response.json', {'usage': {'total_tokens': 1}, 'choices': [{'message': {'tool_calls': [
             {'id': 'OFFLINE', 'function': {'name': 'read_file', 'arguments': '{"path":"dut.sv"}'}}]}}]})
        save(self.task / 'api/001/receipt.json', {'status': 200, 'offline_fixture': True})
        save(self.task / 'operations/001/call.json', {'name': 'read_file', 'arguments': {'path': 'dut.sv'}})
        save(self.task / 'operations/001/result.json', {'path': 'dut.sv', 'content': 'fixture'})
        save(self.task / 'tool-dispatch-001.json', {'tool_call_id': 'OFFLINE'})

    def tearDown(self):
        self.temp.cleanup()

    def pending(self):
        with self.assertRaisesRegex(ValueError, 'timeout'):
            await_review(self.task, 1, timeout=0)

    def test_no_next_request_without_explicit_review(self):
        self.pending()
        value = json.loads((self.task / 'step-review-pending-001.json').read_text())
        self.assertTrue(value['awaiting_host_read_only_review'])
        self.assertEqual(value['observation']['operations'][0]['tool'], 'read_file')
        self.assertFalse((self.task / 'api/002').exists())

    def test_stop_run_is_explicit_and_does_not_edit_work(self):
        self.pending()
        before = observation(self.task, 1)['work_sha256']
        decide(self.task, 1, 'stop_run', 'Repeated preloaded-file read')
        self.assertEqual(await_review(self.task, 1)['action'], 'stop_run')
        self.assertTrue((self.task.parent.parent / 'step-stop-run.json').exists())
        self.assertEqual(before, observation(self.task, 1)['work_sha256'])

    def test_changed_work_invalidates_allowance(self):
        self.pending()
        decide(self.task, 1, 'continue', 'First relevant retrieval may proceed once')
        (self.task / 'work/dut.sv').write_text('module top_module; wire changed; endmodule')
        with self.assertRaisesRegex(ValueError, 'stale'):
            await_review(self.task, 1)

    def test_continue_is_bound_to_actual_response_and_results(self):
        self.pending()
        value = decide(self.task, 1, 'continue', 'Observed non-repeated relevant step')
        self.assertEqual(value['observation_sha256'], digest(observation(self.task, 1)))
        self.assertEqual(await_review(self.task, 1)['action'], 'continue')
        self.assertFalse((self.task / 'api/002').exists())


if __name__ == '__main__':
    unittest.main()

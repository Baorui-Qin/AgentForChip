# 新例子 Skill 开关验证：本地准备与授权状态

日期：2026-10-18。独立副本：`D:/AMD/workspaces/rtl-rule-transfer-probes-20261018`。

**当前状态：本地预检完成，真实 30B/8B 对照尚未执行。** 云端模型驱动在创建进程之前被安全审核拒绝，要求用户单独明确授权将这批新建的八个探针载荷发送到 `36.150.116.206:35053`。没有绕过拒绝，没有创建隧道或修改 SSH 配置，模型调用为 0。因此本报告没有新通过率、规则应用或拒绝恢复的实测结论。

## 冻结的八个例子

| 探针 | 验证重点 | 本地预检 |
| --- | --- | --- |
| Probe201_six_phase | 六阶段枚举的容量与输出数值序列 | 正例通过，反例及种子失败 |
| Probe202_unique_stage | 容量足够但编码重复，指定状态码保持 | 正例通过，反例及种子失败 |
| Probe203_typed_toggle | 三位枚举的类型身份与时钟状态 | 正例通过，反例及种子失败 |
| Probe204_feedback_serial | 固定标量输入，带反馈与装载选择的修复 | 正例通过，反例及种子失败 |
| Probe205_packet_parity | 五位数据归约的过程赋值目标声明 | 正例通过，反例及种子失败 |
| Probe206_owned_pulse | 组合/时钟过程的多驱动与保持时序 | 正例通过，反例及种子失败 |
| Probe207_valid_bitselect | 合法向量位选的边界，不应当成标量错误 | 正例通过，反例及种子失败 |
| Probe208_valid_capacity | 合法两位三成员枚举，不应盲目扩宽/换码 | 正例通过，反例及种子失败 |

这八例是在 v2 skill 冻结后新建，规格和种子不同于前轮能力控制。“新”只表示本地技能/探针历史中的新例子，不证明不存在于模型预训练数据，也不代表官方隐藏题。初始错误由 Host 构造，不冒充模型生成或裸 Baseline 成绩。

每例使用相同规格和种子做 ON/OFF，交替顺序。正确对照、反例和测试台是 Host 私有评测资产，不计划发送给模型。后续由模型通过正常 `edit_dut` 修改候选，Host 不替换答案，不伪造诊断，不强制拒绝正确修改；没有实际拒绝时不计为已验证恢复能力。

## 协议与预算

新例子的 [清单](D:/AMD/output/rtl-rule-transfer-probes-20261018/campaign/manifest.json)、[冻结哈希](D:/AMD/output/rtl-rule-transfer-probes-20261018/campaign/preflight-freeze.json) 已保存。skill、知识图谱、规则目录及全部七条技能注册记录与离线 v2 逐字节相同。知识仍通过现有技能路径以精简解释送入上下文，没有新增图谱服务。

两侧共用原 Harness 防护和规划/修复流程，只有 C/B 技能选择不同；OFF 不是裸 Baseline。为接入新例子，仅增加认证的本地评测资产加载和真实的 Host 种子记账，不更改规划规则、重复候选检查或拒绝策略。

预算保持原值：每题两次有效修改、八次编码请求、四个规划绑定、240 秒活动时限；8192 上下文、1024 安全余量；规划输出 1024、编码输出 2048；技能软预算 768。规划格式与约束拒绝共用原一次恢复。新批次每侧仍最多 100 次派发、60 分钟，不延长历史批次。本轮模型阶段尚未开始，所以其期限尚未启动。

已有多行规划格式限制未修复、未放宽。局部探针没有校准的综合后网表验收 profile，后续本地 RTL 四阶段通过也不会计为完整比赛验收或官方分数。

## 已完成的验证

- 真实本地 Vivado 2026.1 完成 24 项预检：8 个正确对照仿真成功，8 个输出取反的反例均检出，8 个错误种子均实际失败。正/反例没有被当作模型修复。
- 新例子/资产加载测试 4 项通过；Harness 回归 92 项通过；原约束测试 19 项通过，合计 115 项。回归中的模型/EDA 为 mock，不能计作真实模型收益。
- 类型检查仍有 70 条既存依赖诊断，归一化运行路径后与前轮相同，没有新增诊断；不称全量类型检查通过。
- 194 个预检冻结文件哈希核验通过，ON/OFF 的八个种子分别相同，v2 技能和图谱没有变化。

证据：[预检结果](D:/AMD/output/rtl-rule-transfer-probes-20261018/campaign/preflight/results.json)、[本地就绪检查](D:/AMD/output/rtl-rule-transfer-probes-20261018/local-readiness.json)、[新增测试](D:/AMD/output/rtl-rule-transfer-probes-20261018/heldout-tests.log)、[Harness 回归](D:/AMD/output/rtl-rule-transfer-probes-20261018/harness-tests-pass.log)、[约束回归](D:/AMD/output/rtl-rule-transfer-probes-20261018/guard-tests.log)。

准备中遇到的 Windows 动态 import 路径错误、以及新增测试夹具缺少 assets 字段的问题，均在真实模型调用前修复，失败回执和日志保留：[准备失败记录](D:/AMD/output/rtl-rule-transfer-probes-20261018/preparation-attempt-01.json)、[首次回归日志](D:/AMD/output/rtl-rule-transfer-probes-20261018/harness-tests.log)。没有对模型失败结果调参重跑或删除失败样本。

## 当前阻塞与保全

安全审核认为前次明确的数据发送授权仅覆盖七道公开题，要求为新八例明确目的地和载荷范围。已向用户请求：允许发送公共规格、错误种子/模型候选、EDA 诊断及通用技能；不发送正确对照、私有测试台、密钥、私钥或原工程文件。记录见 [发送授权阻塞](D:/AMD/output/rtl-rule-transfer-probes-20261018/external-transfer-block.json)。此前只进行了回显式 SSH 连通检查，连接已结束；被拒模型驱动没有执行任何云端推理。

原工程未提交改动、题库、原技能/知识库和封存交接包均保持不变；另复核前两轮独立源码/输出 14956 个文件不变。[原工程保全](D:/AMD/output/rtl-rule-transfer-probes-20261018/preservation.json)、[历史保全](D:/AMD/output/rtl-rule-transfer-probes-20261018/history-preservation.json)。没有更新交接包，也没有产生或声称新的模型通过率。

获得这批载荷的明确发送授权后，才可启动已准备的同期对照。模型输出、HTTP/SSE 调用、候选修改、具体拒绝及后续动作、EDA 各阶段日志都应保留，分别报告规则应用、有效修改、阶段进展和拒绝恢复，而非把少调用工具当作模型理解。

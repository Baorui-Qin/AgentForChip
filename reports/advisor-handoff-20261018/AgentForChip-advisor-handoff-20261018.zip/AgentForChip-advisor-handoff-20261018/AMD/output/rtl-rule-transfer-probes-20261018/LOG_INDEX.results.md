# 真实模型对照的日志入口

本目录为 `D:/AMD/output/rtl-rule-transfer-probes-20261018`。旧 `REPORT.zh.md`、`local-readiness.json` 和 `external-transfer-block.json` 是授权前历史记录，原样保留；当前结果以下列文件为准。

## 结果与源码

- [最终中文报告](D:/AMD/output/rtl-rule-transfer-probes-20261018/REPORT.results.zh.md)、[逐例原因与关键模型原文](D:/AMD/output/rtl-rule-transfer-probes-20261018/FAILURE_ANALYSIS.results.zh.md)。
- [八例同期汇总](D:/AMD/output/rtl-rule-transfer-probes-20261018/comparison-summary.json)、[比较 CSV](D:/AMD/output/rtl-rule-transfer-probes-20261018/comparison.csv)、[含修改 diff 的逐题比较](D:/AMD/output/rtl-rule-transfer-probes-20261018/comparison.json)。
- [全部阶段与调用计数](D:/AMD/output/rtl-rule-transfer-probes-20261018/tasks.csv)、[原始错误及失败分类](D:/AMD/output/rtl-rule-transfer-probes-20261018/failure-reasons.json)。
- [规则应用、边界和拒绝恢复](D:/AMD/output/rtl-rule-transfer-probes-20261018/rule-transfer-evidence.json)、[不升级为技能增益证明的决定](D:/AMD/output/rtl-rule-transfer-probes-20261018/PROMOTION_DECISION.results.json)。

## 模型输出和调用

- [42 个模型输出目录索引](D:/AMD/output/rtl-rule-transfer-probes-20261018/model-output-index.json)：定位 output.txt、model.json、reasoning.txt、transcript、原始 stream、context 和 transport 文件。
- [42 次真实 HTTP/SSE 索引](D:/AMD/output/rtl-rule-transfer-probes-20261018/call-index.json)、[调用 CSV](D:/AMD/output/rtl-rule-transfer-probes-20261018/calls.csv)：关联题目、arm、模型、请求哈希、响应状态、用量与全部文件路径。
- [模型错误索引](D:/AMD/output/rtl-rule-transfer-probes-20261018/model-errors.json)：本轮为 0，不能据此推断规划内容正确。
- [215 条原生 token 计数记录](D:/AMD/output/rtl-rule-transfer-probes-20261018/token-counter-index.json)：与推理调用分开统计。

`campaign/http/<id>/` 保存请求、SSE 和传输记录。`campaign/arms/<arm>/plans/<task>/.../run-*/` 保存规划原文、实际请求、验证及恢复记录。`compare-<task>/models/run-*/` 保存编码器模型输出和上下文。reasoning.txt 仅为服务提供的可见输出，不伪称完整隐藏思维链。

## 规划、工具与 EDA

- [20 份规划验证](D:/AMD/output/rtl-rule-transfer-probes-20261018/planner-validation-index.json)、[字段长度/换行复核](D:/AMD/output/rtl-rule-transfer-probes-20261018/plan-format-review.json)。后者为事后审计，不表示模型当时收到逐字段格式定位。
- [技能可达性与原预算核对](D:/AMD/output/rtl-rule-transfer-probes-20261018/skill-usage-audit.json)：16 次 v2 指导可达、OFF 技能为 0。
- [10 个模型编辑按原参数重算](D:/AMD/output/rtl-rule-transfer-probes-20261018/guarded-output-audit.json)、[规划/编码/工具关联](D:/AMD/output/rtl-rule-transfer-probes-20261018/planner-coder-evidence.json)。
- [两次真实工具拒绝](D:/AMD/output/rtl-rule-transfer-probes-20261018/tool-rejections.json)、[26 次实际验证与源码绑定](D:/AMD/output/rtl-rule-transfer-probes-20261018/verification-index.json)、[104 个阶段行](D:/AMD/output/rtl-rule-transfer-probes-20261018/verification-stages.csv)。

每题 `compare-<task>/result.json` 是任务终态；`revisions/<id>/solution.sv` 是对应模型候选；`eda/run-*/` 包含快照、真实四阶段日志、结果与综合产物；`acceptance-*/` 记录局部探针未校准的网表接受状态。不要用 `best_source_sha256` 单独代替终态绑定：完整网表门槛未过时它可能保留初始版本，应按报告指明的 final_verification_run 对应实际 RTL 阶段。

## 冻结与历史

- [新例子与交替顺序](D:/AMD/output/rtl-rule-transfer-probes-20261018/campaign/manifest.json)、[最终冻结 247 个文件](D:/AMD/output/rtl-rule-transfer-probes-20261018/campaign/campaign-freeze.json)。私有 TB/正确对照只由本地 Host 使用。
- [明确的用户发送授权](D:/AMD/output/rtl-rule-transfer-probes-20261018/authorization-granted.json)。
- [最初配置失败日志](D:/AMD/output/rtl-rule-transfer-probes-20261018/configure-driver.log)、[补齐配置且不重置期限](D:/AMD/output/rtl-rule-transfer-probes-20261018/configure-complete-driver.log)、[模型驱动日志](D:/AMD/output/rtl-rule-transfer-probes-20261018/diagnostic-driver.log)。
- [退出/端口/SSH 核验](D:/AMD/output/rtl-rule-transfer-probes-20261018/post-run-checks.json)、[日志绑定审计](D:/AMD/output/rtl-rule-transfer-probes-20261018/log-audit.json)：原始 RUNNING 字段未修改，终态由任务结果、HTTP/SSE 和退出回执共同确认。
- [原工程及封存包最终保全](D:/AMD/output/rtl-rule-transfer-probes-20261018/preservation-final.json)、[14956 个前轮文件最终保全](D:/AMD/output/rtl-rule-transfer-probes-20261018/history-preservation-final.json)、[交付证据核验](D:/AMD/output/rtl-rule-transfer-probes-20261018/delivery-verification.json)。

原有准备失败、首次回归失败和发送被拦记录未删除；技能、图谱和所有历史结果未覆盖，交接包未更新。模型服务本身保留给用户继续使用，仅关闭本轮临时隧道。

# 离线规则解释、知识图谱与 Skill 更新

日期：2026-10-18。工作副本：`D:/AMD/workspaces/rtl-rule-explanations-offline-20261018`。本轮没有联网、调用 API/云端模型或运行真实 EDA，没有改模型权重、题目答案或原工程，没有更新交接包。

## 判断与目标

规则检查失败说明“当前规划或候选没有满足该规则”，不能直接推出“模型不懂规则”。已有日志同时包含约束推理矛盾、违反题目接口、无实质修改以及 Host 格式拒绝，必须分开记录。

本次将规则从简短命令扩展为可解释知识：**何时适用、规则含义、为何必要、错误反例、检查步骤、证据和适用边界**。目标是让后续模型请求能获得明确依据，而非只看错误编号或重复报错。离线知识注入不是训练，接入成功不等于模型已理解。

## 已整理的九类规则

| 规则 | 核心解释 | 要避免的误解 |
| --- | --- | --- |
| 枚举容量、唯一性与范围 | w 位仅有 2^w 种编码；成员数、唯一性和表示范围都须检查 | 换到另一个已占用值就是修复 |
| 枚举类型身份 | 位宽相同不代表命名类型相同，应检查赋值两侧实际声明 | 扩宽普通向量就能解决 enum 类型错误 |
| 固定接口与标量索引 | 公共端口是契约，错误索引需要按题意改内部实现 | 扩宽公共输入，只要能编译就可以 |
| 过程赋值目标 | 目标声明要允许该赋值方式，还要检查驱动关系 | 只改 always 关键词，或再加一个同名声明 |
| 多过程驱动 | 检查所有赋值位置、写入所有权和时序 | 重写相同声明、改注释就消除多驱动 |
| 精确修改锚点 | before 必须来自当前版本并唯一匹配，拒绝未应用 | 用失败草稿作当前源码，或用重复变量名作锚点 |
| 实质修改与候选重放 | 必须改变导致错误的代码关系 | before=after、普通注释变化就是新策略 |
| 验证状态与版本绑定 | 新编辑成功后验证新 revision；记录的 FAIL 不会被规划 checks 覆盖 | 没有新候选也反复验证，或把计划写成已通过 |
| 规划格式与 Host 边界 | 格式、字段长度和截断与 HDL 合法性分开判断 | 格式拒绝就证明电路错误，或未跑 EDA 就算修复 |

例如：一位只能表达 0、1 两种模式。三个成员编码为 0、1、0 时重复；把第三个改成 1 后变成 0、1、1，仍然重复。这个例子说明既要检查容量，也要检查所有值。它不是任何目标题的答案；涉及指定状态编码时仍必须保留契约及状态转移含义，不能盲目换码。

规则全文和反例见 [规则目录](D:/AMD/workspaces/rtl-rule-explanations-offline-20261018/skills/rtl-diagnostic-reasoning/references/rules.json)。来源为既有本地源码和冻结日志，不把经验说明冒充语言标准条款，也不声称覆盖完整 SystemVerilog 类型系统。

## 知识图谱与 Agent 接入

本轮生成 [知识图谱](D:/AMD/workspaces/rtl-rule-explanations-offline-20261018/knowledge/constraint-graph.json)，共 **9 条规则、51 个节点、58 条关系**。包含 symptom、rule、cause、counterexample、check、evidence、skill 节点，关系区分“路由到规则”“解释原因”“检查方法”“反例”“证据来源”“对应技能”。

采用最小接入方式：规则目录为单一来源，离线构建器同时生成图谱和[精简 skill](D:/AMD/workspaces/rtl-rule-explanations-offline-20261018/skills/rtl-diagnostic-reasoning/SKILL.md)，再编入本副本的 [技能注册表配置](D:/AMD/workspaces/rtl-rule-explanations-offline-20261018/skill-registry/bundle.json)。仅更新 `rtl.00_diagnostic_reasoning` 至 `2.0.0`，另外六项技能保持不变。

Agent 使用现有 C 选择器、`buildContext` 和可选 `retrieve_skill` 收到精简规则。**没有新增图数据库、图谱服务或运行时图查询工具；模型不会自动读取整张图和 references。** 图谱当前是可审计的离线知识来源，实际发送的是编译后的英文摘要，包含关键原因和反例。详细中文解释留在本地供复核。

运行时源码和所有原预算/拒绝策略未改。精简规则正文 2132 字符，仍受原 768-token 技能软预算与整体上下文限制。使用本地估算计数器的固定样例中，新技能保留，第二项 `rtl.assignment_integrity` 因软预算被裁掉；更紧预算时所有技能仍可被移除。不能宣称所有真实模型请求都一定容纳这些说明。

## 离线验证结果

新增 **15 项测试通过**，原有约束测试 **19 项通过**，Harness 回归 **90 项通过**，共 **124 项**。Harness 模型、EDA 和计数器为 mock，结果不计入真实题目通过率。

- 图谱与 skill 从同一目录确定性构建，所有关系端点、证据和引用有效。
- C 正常路径收到完整的精简解释，A/B 不读取技能文件、不泄漏技能；ON/OFF 的可信源码及诊断核心一致。
- 压缩上下文后保留枚举容量、锚点匹配次数/行号、验证 pending 状态等具体拒绝事实和技能解释。
- 通用 enum 正反例、固定端口反例、只改注释/原样规划，均与原有有限检查器行为一致。
- 图谱证据文件被篡改时拒绝加载，不静默注入变化内容。
- 技能预算继续强制执行；没有为了可达性放宽上下文或恢复预算。

测试日志：[新增离线测试](D:/AMD/output/rtl-rule-explanations-offline-20261018/offline-tests.log)、[原约束回归](D:/AMD/output/rtl-rule-explanations-offline-20261018/guard-regressions.log)、[Harness 回归](D:/AMD/output/rtl-rule-explanations-offline-20261018/harness-tests-host.log)。

可检查实际本地请求投影：[开启技能](D:/AMD/output/rtl-rule-explanations-offline-20261018/request-on.json)、[关闭技能 B](D:/AMD/output/rtl-rule-explanations-offline-20261018/request-b.json)、[压缩拒绝投影](D:/AMD/output/rtl-rule-explanations-offline-20261018/compressed-rejections.json)。这些是合成测试输入和请求构建结果，不是新模型输出或真实 EDA 回执。

## 限制与保全

本轮模型/API 调用为 0。测试中的 token 数为明确标记的本地估算值，不是实际 30B/8B tokenizer 测量。未验证小模型是否能迁移应用规则、拒绝后是否真的改变策略，也未产生新通过率。已有规划的多行字符串限制仅得到解释和边界测试，**没有修复**；不能把原有未完成问题写成已解决。

Python skill 校验器仍缺 PyYAML，未联网安装；已使用现有 js-yaml 验证 frontmatter 和引用。首次沙箱 Harness 测试因 Vite 临时缓存 rename 权限失败而未执行测试，日志 [保留](D:/AMD/output/rtl-rule-explanations-offline-20261018/harness-tests.log)；主机侧离线重跑后 90 项通过，未删除失败记录。

原工程未提交改动、题库、原技能/知识库、封存交接包做前后快照检查；前轮独立源码和输出另检查 12310 个文件。保全与核验见 [原工程及封存包](D:/AMD/output/rtl-rule-explanations-offline-20261018/preservation.json)、[前轮历史](D:/AMD/output/rtl-rule-explanations-offline-20261018/history-preservation.json)、[最终核验](D:/AMD/output/rtl-rule-explanations-offline-20261018/delivery-verification.json)。

## 后续怎样验证“理解”

不能只让模型复述规则。下一次有本地模型可用时，应用未在技能中出现的新变量、新常量和新题型，检验它能否：给出简短规则依据；识别相似但不满足条件的反例；提出保持接口/状态语义的实质修改；收到具体拒绝后改变失败策略；最终通过独立 EDA。保持 skill 开关同期对照、相同预算和全部失败日志。

这组行为测试才能逐步支持“规则应用改善”，仍不直接读取模型内部理解。本轮未执行该真实模型实验，也未继续消耗云端算力。

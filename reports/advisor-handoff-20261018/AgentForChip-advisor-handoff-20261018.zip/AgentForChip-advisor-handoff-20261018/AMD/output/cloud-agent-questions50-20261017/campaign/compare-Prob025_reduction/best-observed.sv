module TopModule(
    input  [7:0] in,
    output       parity
);
    // Compute even parity as reduction XOR of the 8 data bits
    assign parity = ^in; // ^ is reduction XOR
endmodule
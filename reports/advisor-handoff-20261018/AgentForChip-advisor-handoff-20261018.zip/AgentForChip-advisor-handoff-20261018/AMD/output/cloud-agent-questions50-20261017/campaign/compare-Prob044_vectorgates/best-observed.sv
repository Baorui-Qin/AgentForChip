module TopModule(
    input  [2:0] a,
    input  [2:0] b,
    output [2:0] out_or_bitwise,
    output       out_or_logical,
    output [5:0] out_not
);

    // Bitwise OR of the two 3-bit vectors
    assign out_or_bitwise = a | b;

    // Logical OR: true if either vector has any 1 bits
    assign out_or_logical = (|a) || (|b);

    // Inverse of a and b placed in out_not
    // Upper half [5:3] = ~b, lower half [2:0] = ~a
    assign out_not = {~b, ~a};

endmodule
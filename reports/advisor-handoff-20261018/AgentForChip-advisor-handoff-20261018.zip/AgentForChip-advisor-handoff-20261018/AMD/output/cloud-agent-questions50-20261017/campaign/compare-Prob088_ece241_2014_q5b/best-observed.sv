module TopModule(
    input  clk,
    input  areset,
    input  x,
    output z
);
    // One-hot state encoding
    reg state_A;
    reg state_B;

    // Output logic (Mealy)
    assign z = (state_A & x) | (state_B & ~x);

    // State register with asynchronous active-high reset
    always @(posedge clk or posedge areset) begin
        if (areset) begin
            state_A <= 1'b1;
            state_B <= 1'b0;
        end else begin
            // Next-state logic
            if (state_A) begin
                if (x) begin
                    state_A <= 1'b0;
                    state_B <= 1'b1;
                end else begin
                    state_A <= 1'b1;
                    state_B <= 1'b0;
                end
            end else begin // state_B is active
                if (x) begin
                    state_A <= 1'b0;
                    state_B <= 1'b1; // stay in B (one-hot: B=1)
                end else begin
                    state_A <= 1'b0;
                    state_B <= 1'b1; // stay in B
                end
            end
        end
    end
endmodule
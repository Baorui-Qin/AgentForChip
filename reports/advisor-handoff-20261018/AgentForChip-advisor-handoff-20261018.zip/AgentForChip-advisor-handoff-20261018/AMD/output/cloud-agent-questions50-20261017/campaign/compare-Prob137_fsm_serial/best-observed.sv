module TopModule(
    input  wire clk,
    input  wire reset,
    input  wire in,
    output wire done
);
    // State encoding
    typedef enum logic [1:0] {
        IDLE         = 2'b00,
        RECEIVE_DATA = 2'b01,
        CHECK_STOP   = 2'b10,
        WAIT_STOP    = 2'b11
    } state_t;

    // Registers
    state_t   state, next_state;
    logic [2:0] bit_cnt;
    logic [7:0] data_reg;
    logic       done_reg;

    // Sequential logic
    always @(posedge clk) begin
        if (reset) begin
            state      <= IDLE;
            bit_cnt    <= 3'd0;
            data_reg   <= 8'd0;
            done_reg   <= 1'b0;
        end else begin
            state      <= next_state;
            // Reset internal registers when entering IDLE or WAIT_STOP
            if (next_state == IDLE) begin
                bit_cnt <= 3'd0;
                data_reg <= 8'd0;
                done_reg <= 1'b0;
            end else if (next_state == WAIT_STOP) begin
                bit_cnt <= 3'd0;
                data_reg <= 8'd0;
                done_reg <= 1'b0;
            end else if (state == RECEIVE_DATA) begin
                // Capture incoming bit
                data_reg[bit_cnt] <= in;
                // Increment counter
                bit_cnt <= (bit_cnt == 3'd7) ? 3'd7 : bit_cnt + 1'b1;
            end else if (state == CHECK_STOP) begin
                if (in) begin
                    // Valid stop bit
                    done_reg <= 1'b1;
                    // Transition to IDLE after asserting done
                    // bit_cnt and data_reg already cleared above
                end else begin
                    // Invalid stop bit, go to WAIT_STOP and clear done
                    done_reg <= 1'b0;
                    // next_state already set to WAIT_STOP by combinational logic
                end
            end
        end
    end

    // Combinational next state logic
    always @* begin
        // Default hold
        next_state = state;
        // done_reg is sequential, not combinational
        case (state)
            IDLE: begin
                if (in == 1'b0) begin
                    next_state = RECEIVE_DATA;
                    bit_cnt    = 3'd0;
                end
            end
            RECEIVE_DATA: begin
                if (bit_cnt == 3'd7) begin
                    next_state = CHECK_STOP;
                end
            end
            CHECK_STOP: begin
                if (in == 1'b1) begin
                    next_state = IDLE;
                end else begin
                    next_state = WAIT_STOP;
                end
            end
            WAIT_STOP: begin
                if (in == 1'b1) begin
                    next_state = IDLE;
                end
            end
            default: begin
                next_state = IDLE;
            end
        endcase
    end

    assign done = done_reg;
endmodule
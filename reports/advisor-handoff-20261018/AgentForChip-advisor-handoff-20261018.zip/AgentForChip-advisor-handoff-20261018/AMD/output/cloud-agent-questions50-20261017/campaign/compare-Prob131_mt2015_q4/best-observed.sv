module TopModule(
    input  wire x,
    input  wire y,
    output wire z
);
    // combinational implementation of A: z = (x ^ y) & x
    wire Ax1 = (x ^ y) & x;
    wire Ax2 = (x ^ y) & x; // same for both A submodules
    // combinational implementation of B per waveform
    // B1: 1 when (x==0 && y==0) || (x==1 && y==1); 0 otherwise
    wire Bx1 = (~x & ~y) | (x & y);
    // B2: 1 only when (x==1 && y==1); 0 otherwise
    wire Bx2 = (x & y);
    // OR of A1 and B1
    wire or_out = Ax1 | Bx1;
    // AND of A2 and B2
    wire and_out = Ax2 & Bx2;
    // XOR to produce final output
    assign z = or_out ^ and_out;
endmodule
module TopModule(
    input  wire clk,
    input  wire reset,
    input  wire in,
    output wire out
);
    // State encoding
    typedef enum logic [1:0] {
        A = 2'b00,
        B = 2'b01,
        C = 2'b10,
        D = 2'b11
    } state_t;

    // State register
    state_t current_state;
    // Next state combinational logic
    state_t next_state;

    // Output combinational logic (Moore)
    assign out = (current_state == D);

    // Sequential block with synchronous active-high reset
    always_ff @(posedge clk) begin
        if (reset) begin
            current_state <= A;
        end else begin
            current_state <= next_state;
        end
    end

    // Combinational next-state logic
    always_comb begin
        case (current_state)
            A: next_state = in ? B : A;
            B: next_state = in ? B : C;
            C: next_state = in ? D : A;
            D: next_state = in ? B : C;
            default: next_state = A;
        endcase
    end

endmodule
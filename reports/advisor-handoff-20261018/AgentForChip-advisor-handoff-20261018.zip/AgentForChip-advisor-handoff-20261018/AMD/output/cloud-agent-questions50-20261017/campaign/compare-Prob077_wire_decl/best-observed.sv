module TopModule(
    input  a,
    input  b,
    input  c,
    input  d,
    output out,
    output out_n
);
    // Internal wires to connect the two AND gates to the OR gate
    wire wire1;
    wire wire2;

    // First AND gate: a & b
    assign wire1 = a & b;
    // Second AND gate: c & d
    assign wire2 = c & d;
    // OR gate combines the two AND results
    assign out = wire1 | wire2;
    // NOT gate provides the inverted output
    assign out_n = ~out;
endmodule
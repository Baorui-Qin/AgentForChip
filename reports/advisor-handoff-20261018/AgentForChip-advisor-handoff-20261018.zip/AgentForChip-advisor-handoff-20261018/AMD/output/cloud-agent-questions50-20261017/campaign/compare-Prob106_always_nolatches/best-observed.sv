module TopModule(
    input  wire [15:0] scancode,
    output wire       left,
    output wire       down,
    output wire       right,
    output wire       up
);
    // Combinational logic: map scancode to arrow output
    // No latches inferred because all outputs are assigned in every path.
    assign {left, down, right, up} = (
        scancode == 16'hE06B ? 4'b1000 : 
        scancode == 16'hE072 ? 4'b0100 : 
        scancode == 16'hE074 ? 4'b0010 : 
        scancode == 16'hE075 ? 4'b0001 : 
        4'b0000
    );
endmodule
module TopModule(
    input  wire clk,
    input  wire resetn,
    input  wire [1:0] byteena,
    input  wire [15:0] d,
    output reg  [15:0] q
);
    // Sequential logic for 16-bit register with byte enable
    always @(posedge clk) begin
        if (!resetn) begin
            q <= 16'b0;
        end else begin
            // Upper byte write enable
            if (byteena[1]) begin
                q[15:8] <= d[15:8];
            end
            // Lower byte write enable
            if (byteena[0]) begin
                q[7:0] <= d[7:0];
            end
        end
    end
endmodule
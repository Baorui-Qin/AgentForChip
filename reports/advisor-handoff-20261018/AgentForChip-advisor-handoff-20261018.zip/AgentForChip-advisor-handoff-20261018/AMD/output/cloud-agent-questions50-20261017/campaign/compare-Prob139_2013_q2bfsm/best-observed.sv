module TopModule(
    input  clk,
    input  resetn,
    input  x,
    input  y,
    output f,
    output g
);
    // State encoding
    typedef enum logic [2:0] {
        A = 3'b000, // reset state, wait for reset deassertion
        B = 3'b001, // f=1 for one cycle after reset
        C = 3'b010, // detect x=1,0,1 sequence
        D = 3'b011, // monitor y for up to 2 cycles after sequence detection
        E = 3'b100, // permanent g=1
        F = 3'b101  // permanent g=0
    } state_t;

    // State registers
    state_t state, next_state;
    // Shift register for x sequence detection
    logic [2:0] x_shift;
    // Counter for y timeout
    logic [1:0] y_cnt; // 0,1,2
    // Output registers
    logic f_reg, g_reg;

    // Sequential logic
    always @(posedge clk) begin
        if (!resetn) begin
            state   <= A;
            f_reg  <= 1'b0;
            g_reg  <= 1'b0;
            x_shift <= 3'b000;
            y_cnt  <= 2'b00;
        end else begin
            state   <= next_state;
            // f output: asserted only in state B
            f_reg  <= (next_state == B) ? 1'b1 : 1'b0;
            // g output: asserted in D, E; cleared in F
            g_reg  <= (next_state == D) ? 1'b1 :
                      (next_state == E) ? 1'b1 :
                      (next_state == F) ? 1'b0 : g_reg;
            // Shift x input
            x_shift <= {x_shift[1:0], x}; // shift left, insert new x
            // y counter: reset when entering D, increment while staying in D
            if (next_state == D) begin
                y_cnt <= 2'b00;
            end else if (state == D) begin
                y_cnt <= y_cnt + 1'b1;
            end else begin
                y_cnt <= 2'b00;
            end
        end
    end

    // Next-state combinational logic
    always @* begin
        // default: stay in current state
        next_state = state;
        case (state)
            A: begin // reset state, wait for reset deassertion
                // stay in A while reset is asserted
                if (!resetn)
                    next_state = A;
                else
                    next_state = B; // after reset deassert, go to B
            end
            B: begin // f=1 for one cycle, then move to monitor x
                next_state = C;
            end
            C: begin // detect x=1,0,1 sequence
                if (x_shift == 3'b101) begin
                    next_state = D; // sequence detected, monitor y
                end else begin
                    next_state = C;
                end
            end
            D: begin // wait for y=1 within 2 cycles after sequence detection
                if (y == 1'b1) begin
                    // y asserted, keep g=1 permanently (state E)
                    next_state = E;
                end else if (y_cnt == 2'b10) begin
                    // timeout after 2 cycles without y=1, set g=0 permanently (state F)
                    next_state = F;
                end else begin
                    next_state = D;
                end
            end
            E, F: begin // permanent states, stay until reset
                // on reset deassert, go to B? Actually we want to stay until reset.
                // So we stay in same state until reset.
                next_state = state;
            end
            default: next_state = A;
        endcase
    end

    // Output assignments
    assign f = f_reg;
    assign g = g_reg;

endmodule
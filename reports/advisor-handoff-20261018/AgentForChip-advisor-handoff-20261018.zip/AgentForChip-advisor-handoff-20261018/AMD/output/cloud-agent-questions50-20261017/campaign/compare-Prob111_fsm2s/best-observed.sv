module TopModule(
    input  clk,
    input  reset,
    input  j,
    input  k,
    output out
);
    // State encoding: 0 = OFF, 1 = ON
    logic q; // current state
    // Next-state combinational logic
    logic q_next;
    assign q_next = (q == 1'b0) ? j : ~k;
    // Output is Moore: out follows current state
    assign out = q;
    // Sequential state register with synchronous active-high reset
    always @(posedge clk) begin
        if (reset)
            q <= 1'b0;
        else
            q <= q_next;
    end
endmodule
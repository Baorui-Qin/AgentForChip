module TopModule(
    input  wire clk,
    input  wire reset,
    input  wire [7:0] in,
    output reg  [23:0] out_bytes,
    output reg        done
);
    // State encoding
    typedef enum logic [1:0] {
        IDLE = 2'b00,
        BYTE1 = 2'b01,
        BYTE2 = 2'b10
    } state_t;

    state_t state;
    // Register to hold third byte
    logic [7:0] byte2;
    // Register to hold second byte
    logic [7:0] byte1;
    // Register to hold first byte (message start)
    logic [7:0] byte0;

    // Sequential logic
    always @(posedge clk) begin
        if (reset) begin
            state   <= IDLE;
            out_bytes <= 24'b0;
            done    <= 1'b0;
            byte0   <= 8'b0;
            byte1   <= 8'b0;
            byte2   <= 8'b0;
        end else begin
            // default output values (don't-care)
            done <= 1'b0;
            case (state)
                IDLE: begin
                    if (in[3]) begin
                        // first byte of message
                        byte0 <= in;
                        state <= BYTE1;
                    end
                end
                BYTE1: begin
                    // second byte
                    byte1 <= in;
                    state <= BYTE2;
                end
                BYTE2: begin
                    // third byte
                    byte2 <= in;
                    out_bytes <= {byte0, byte1, in}; // assemble message
                    state <= IDLE;
                    done <= 1'b1;
                end
                default: begin
                    state <= IDLE;
                end
            endcase
        end
    end
endmodule
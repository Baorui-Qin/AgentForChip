module TopModule(
    input  wire clk,
    input  wire reset,
    output wire [3:0] q
);
    // 4-bit counter for 0-9
    reg [3:0] cnt;
    assign q = cnt;
    always @(posedge clk) begin
        if (reset) begin
            cnt <= 4'd0;
        end else if (cnt == 4'd9) begin
            cnt <= 4'd0;
        end else begin
            cnt <= cnt + 4'd1;
        end
    end
endmodule
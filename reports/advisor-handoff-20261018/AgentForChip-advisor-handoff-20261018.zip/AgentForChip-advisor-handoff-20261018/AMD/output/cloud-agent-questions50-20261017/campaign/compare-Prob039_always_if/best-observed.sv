module TopModule(
    input  a,
    input  b,
    input  sel_b1,
    input  sel_b2,
    output out_assign,
    output out_always
);

    // Continuous assignment version
    assign out_assign = (sel_b1 && sel_b2) ? b : a;

    // Procedural if version
    always @(*) begin
        if (sel_b1 && sel_b2)
            out_always = b;
        else
            out_always = a;
    end

endmodule
module TopModule(
    input  wire in1,
    input  wire in2,
    input  wire in3,
    output wire out
);
    // XNOR of in1 and in2
    wire xnor_out = (in1 == in2);
    // XOR of xnor_out and in3
    assign out = xnor_out ^ in3;
endmodule
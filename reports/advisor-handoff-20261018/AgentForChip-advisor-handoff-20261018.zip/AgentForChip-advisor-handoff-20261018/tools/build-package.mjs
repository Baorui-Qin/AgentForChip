import { readFile, writeFile, mkdir, readdir, stat } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { dirname, join, resolve, relative, extname, basename } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const root = 'D:/AMD/output/handoff/AgentForChip-advisor-handoff-20261018'
const unix = value => value.replaceAll('\\', '/')
const hash = data => createHash('sha256').update(data).digest('hex')
const get = async path => JSON.parse(await readFile(path, 'utf8'))
const exists = async path => { try { await stat(path); return true } catch (error) { if (error.code === 'ENOENT') return false; throw error } }
if (await exists(root)) throw new Error('New package directory required; refusing overwrite')
await mkdir(root, { recursive: true })
const records = [], exclusions = [], sources = [], copied = new Set()
const textExtensions = new Set('.md .txt .json .jsonl .csv .ts .mjs .js .py .ps1 .sh .sv .v .vh .svh .tcl .xdc .log .rpt .jou .yaml .yml .xml .graphml .drawio .diff .patch .mem .dat .ini'.split(' '))
const excludedDirectories = new Set(['.git', '.ssh', 'node_modules', '.pnpm-store', '__pycache__', '.venv', '.Xil', 'xsim.dir', 'XilinxTclStore', 'dsh-home', 'loader-tests', 'unit-loop', 'offline-checks', 'final-preservation', 'snapshot', 'snapshots'])
const credentialPatterns = [
  ['private-key', /-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----/],
  ['github-token', /\b(?:github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9]{20,})\b/],
  ['api-token', /\bsk-[A-Za-z0-9_-]{20,}\b/],
  ['aws-access-key', /\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/],
  ['bearer-token', /Bearer\s+[A-Za-z0-9_.-]{20,}/],
  ['url-credentials', /https?:\/\/[^\s/:'"]+:[^\s/@'"]+@/],
  ['assigned-secret', /["']?(?:api_key|apiKey|access_token|client_secret|password)["']?\s*[:=]\s*["'](?!redacted|placeholder|example|test|dummy|\$|process\.env)[A-Za-z0-9_+/=-]{24,}["']/i],
]
const secretHits = []
const check = (path, data) => {
  if (data.includes(0)) throw new Error(`Unexpected binary in text export: ${path}`)
  const text = data.toString('utf8')
  for (const [code, pattern] of credentialPatterns) if (pattern.test(text)) secretHits.push({ path, code })
}
const outputPath = path => {
  const target = resolve(root, path)
  if (!target.toLowerCase().startsWith(resolve(root).toLowerCase() + '\\')) throw new Error('Output escapes package')
  return target
}
async function put(path, data, source = null, transformation = null) {
  if (copied.has(path)) return
  copied.add(path)
  const bytes = Buffer.isBuffer(data) ? data : Buffer.from(data)
  check(path, bytes)
  const target = outputPath(path)
  await mkdir(dirname(target), { recursive: true })
  await writeFile(target, bytes, { flag: 'wx' })
  records.push({ path, bytes: bytes.length, sha256: hash(bytes), source, transformation })
}
function mapped(path) {
  const normalized = unix(path)
  if (/^D:\/AMD\//i.test(normalized)) return normalized.slice(3)
  if (/^D:\/deepseek-harness\//i.test(normalized)) return normalized.slice(3)
  throw new Error(`Unmapped source: ${path}`)
}
async function copy(path, destination = mapped(path)) {
  const data = await readFile(path)
  sources.push({ source: unix(path), bytes: data.length, sha256: hash(data), exported_path: destination })
  await put(destination, data, unix(path))
}
function omit(path) {
  const name = basename(path), ext = extname(name).toLowerCase()
  if (/^\.env(?:\.|$)|credentials|\.lic$|^id_(?:rsa|ed25519)$/i.test(name)) return 'credentials_or_license'
  if (/^(?:preservation-before|history-before|parent-preservation-before|before|after|history-manifest)\.json$/i.test(name)) return 'unrelated_workspace_inventory'
  if (/^(?:human-authorization|authorization-granted|external-scope-approved|external-transfer-block|ssh-|tunnel-)/i.test(name)) return 'authorization_or_ssh_metadata'
  if (!textExtensions.has(ext) && !/^(?:LICENSE|COPYING|NOTICE|THIRD_PARTY_NOTICES)$/i.test(name)) return 'binary_cache_or_nonselected_format'
  return null
}
async function walk(directory) {
  const entries = await readdir(directory, { withFileTypes: true })
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const path = join(directory, entry.name)
    if (entry.isSymbolicLink()) { exclusions.push({ source: unix(path), reason: 'symlink_not_followed' }); continue }
    if (entry.isDirectory()) {
      if (excludedDirectories.has(entry.name)) exclusions.push({ source: unix(path), reason: 'directory_out_of_scope' })
      else await walk(path)
    } else if (entry.isFile()) {
      const reason = omit(path)
      if (reason) exclusions.push({ source: unix(path), reason })
      else await copy(path)
    }
  }
}
const directories = [
  'D:/AMD/output/cloud-agent-questions50-20261017',
  'D:/AMD/output/rtl-rule-transfer-probes-20261018',
  'D:/AMD/output/rtl-rule-transfer-review-20261018',
  'D:/AMD/output/rtl-plan-effectiveness-audit-20261018',
  'D:/AMD/output/rtl-grounded-minimal-fixed-20261018',
  'D:/AMD/output/rtl-diagnostic-guards-20261018',
  'D:/AMD/output/rtl-rule-explanations-offline-20261018',
  'D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-04',
  'D:/AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep',
  'D:/AMD/p156-20260928-final-report',
  'D:/AMD/workspaces/cloud-agent-questions50-20261017',
  'D:/AMD/workspaces/rtl-rule-transfer-probes-20261018',
  'D:/AMD/workspaces/rtl-diagnostic-guards-20261018',
  'D:/AMD/workspaces/rtl-grounded-minimal-fixed-20261018',
  'D:/AMD/workspaces/rtl-rule-explanations-offline-20261018',
  'D:/AMD/workspaces/rtl-api-distillation-20261017/knowledge-runtime',
  'D:/AMD/workspaces/rtl-api-distillation-20261017/skill',
  'D:/AMD/workspaces/rtl-api-distillation-20261017/agent-v2',
]
for (const directory of directories) {
  console.log(`Collecting ${directory}`)
  await walk(directory)
}
const files = [
  'D:/AMD/doc/AgentForChip_Progress_and_Innovation_Report_2026-10-18.zh.md',
  'D:/AMD/competition_requirements(1).md',
  'D:/AMD/workspaces/rtl-api-distillation-20261017/KNOWLEDGE_RUNTIME.md',
  'D:/AMD/workspaces/harness-mainline-20261018/evidence/verification-summary.json',
  'D:/AMD/workspaces/rtl-history-ui-20261018/verification.json',
  'D:/AMD/output/fpga_rtl_agent_bank_200_v3/README.md',
  'D:/deepseek-harness/rtl-tools/agent-demo/README.zh.md',
  'D:/deepseek-harness/docs/cookbook/rtl-agent-demo.zh.md',
]
for (const file of files) await copy(file)
await copy('D:/AMD/verilog-eval/LICENSE', 'licenses/VerilogEval-LICENSE.txt')
await copy('D:/deepseek-harness/LICENSE', 'licenses/DeepSeek-Harness-LICENSE.txt')
await copy('D:/deepseek-harness/THIRD_PARTY_NOTICES.md', 'licenses/DeepSeek-Harness-THIRD_PARTY_NOTICES.md')
await copy(join(here, 'templates/README.md'), 'README.md')
await copy(join(here, 'templates/WECHAT.zh.md'), 'WECHAT.zh.md')
await copy(join(here, 'templates/verify-package.mjs'), 'tools/verify-package.mjs')
await copy(fileURLToPath(import.meta.url), 'tools/build-package.mjs')

const reportPath = files[0]
const report = await readFile(reportPath, 'utf8')
const portable = report.replace(/\]\((D:\/[^\r\n]+?\.(?:md|json))\)/g, (all, path) => {
  const target = mapped(path)
  if (!copied.has(target)) throw new Error(`Report evidence omitted: ${path}`)
  return `](${encodeURI(target)})`
})
await put('REPORT.zh.md', portable, reportPath, 'Markdown absolute links to included package-relative paths only')

const review = await get('D:/AMD/output/rtl-rule-transfer-review-20261018/EVIDENCE_REVIEW.json')
const summary = await get('D:/AMD/output/rtl-rule-transfer-probes-20261018/comparison-summary.json')
const fifty = await get('D:/AMD/output/cloud-agent-questions50-20261017/summary.json')
const link = (label, path) => `[${label}](${encodeURI(mapped(path))})`
const descriptions = {
  Probe201_six_phase: 'Host 在模型之前阻断；ON/OFF 都是零次模型调用，不得归因为模型不会算枚举容量。',
  Probe203_typed_toggle: 'ON 方向合理但连续多行片段被格式拒绝；OFF 恢复为单行显式转换后通过。',
  Probe204_feedback_serial: '成功修复固定标量索引；没有扩宽公共输入。四阶段通过不等于完整网表验收。',
  Probe205_packet_parity: 'ON 找到过程赋值声明问题，但 cause 首次 297、恢复 223 字符，均超出 160 上限；未交编码器。',
  Probe206_owned_pulse: '两组都定位多驱动；多行替换片段被当前规划协议拒绝，未实际执行修复。',
  Probe208_valid_capacity: 'ON 成功结果伴随错误容量解释和 A-to-A 项；实际只改 marker。不能从 PASS 反推所有诊断正确。',
}
let cases = '# 典型案例与原始日志导航\n\n本文件是打包时生成的导航，不是新的模型实验。先读独立复核，再看原始输出。\n\n'
for (const [task, description] of Object.entries(descriptions)) {
  const pair = review.pairs.find(item => item.task === task)
  if (!pair) throw new Error(`Missing reviewed case ${task}`)
  cases += `## ${task}\n\n${description}\n\n`
  for (const arm of ['on', 'off']) {
    const run = pair[arm]
    cases += `- ${arm.toUpperCase()}：${run.terminal}；${run.model_calls} 次模型调用；${link('任务结果', run.result)}；${link('最终 EDA', run.final_eda)}。\n`
    const plans = review.plans.filter(item => item.task === task && item.arm === arm)
    for (const plan of plans) cases += `- ${arm.toUpperCase()} ${plan.recovery ? '恢复规划' : '首次规划'}：${link('规划原文', plan.output)}；${link('真实规划输入', plan.request)}；${link('Host 规划检查', plan.validation)}。\n`
  }
  cases += '\n'
}
cases += '## 进一步追踪\n\n'
cases += '- 规划和实际修改脱节、重复拒绝后仍重复：`AMD/output/rtl-plan-effectiveness-audit-20261018/REPORT.zh.md`，对应原始运行在 `rtl-grounded-minimal-fixed-20261018/`。\n'
cases += '- FIFO 冻结测试通过仍有容量反证：`AMD/output/rtl-api-distillation-20261017/agent-knowledge-04/RUN_REPORT.md` 与其中独立诊断目录。开发者补验不算模型自主闭环。\n'
cases += '- 知识送达后仍未进入修改：`AMD/output/rtl-api-distillation-20261017/agent-knowledge-07-smallstep/RUN_REPORT.md`。Q123 两次请求；Q114 未启动，不能算失败。\n'
cases += '- 全批逐调用入口：`AMD/output/cloud-agent-questions50-20261017/call-index.json` 和 `AMD/output/rtl-rule-transfer-probes-20261018/call-index.json`。JSON 中的绝对路径按 README 的映射规则定位。\n'
await put('CASES.zh.md', cases)

const callChecks = []
for (const [name, expected] of [['cloud-agent-questions50-20261017', 216], ['rtl-rule-transfer-probes-20261018', 42]]) {
  const rows = await get(`D:/AMD/output/${name}/call-index.json`)
  if (!Array.isArray(rows) || rows.length !== expected) throw new Error(`Unexpected call count: ${name}`)
  let bound = 0
  for (const row of rows) {
    for (const field of ['request_file', 'sse_file', 'transport_file']) {
      if (typeof row[field] !== 'string' || !copied.has(mapped(row[field]))) throw new Error(`Missing ${name} ${field}`)
      bound++
    }
  }
  callChecks.push({ batch: name, calls: rows.length, http_artifacts_checked: bound })
}
if (summary.tasks !== 8 || summary.on_rtl_pass !== 4 || summary.off_rtl_pass !== 6 || review.totals.plans !== 20 || fifty.selected_tasks !== 50 || fifty.all_four_rtl_stages_pass !== 24) throw new Error('Summary mismatch')
if (secretHits.length) {
  await writeFile(join(here, 'secret-review-required.json'), JSON.stringify(secretHits, null, 2))
  throw new Error(`Credential-pattern review required for ${secretHits.length} files; nothing may be published`)
}
console.log(`Checking ${sources.length} original source files remain unchanged`)
for (const source of sources) {
  const data = await readFile(source.source)
  if (hash(data) !== source.sha256) throw new Error(`Original changed during packaging: ${source.source}`)
}
await put('SOURCE_SNAPSHOT.json', JSON.stringify({ date: '2026-10-18', files: sources }, null, 2))
await put('EXCLUSIONS.json', JSON.stringify({ scope: 'Selected reports, evidence and source snapshots only', entries: exclusions }, null, 2))
await put('SECURITY_SCAN.json', JSON.stringify({ status: 'PASS', scope: 'Selected exported text; signature scan and explicit path exclusions, not a guarantee of absence of all sensitive content', scanned_files_before_metadata: records.length, patterns: credentialPatterns.map(([code]) => code), credential_pattern_hits: secretHits, raw_evidence_redactions: 0, source_files_unchanged: sources.length, excluded_directory_names: [...excludedDirectories], external_model_calls: 0, eda_runs: 0 }, null, 2))
await put('PACKAGE_VERIFICATION.json', JSON.stringify({ status: 'PASS', date: '2026-10-18', call_artifact_checks: callChecks, eight_tasks: 8, eight_on_rtl_pass: 4, eight_off_rtl_pass: 6, eight_plans: 20, fifty_tasks: 50, fifty_rtl_pass: 24, source_hashes_rechecked: sources.length, raw_evidence_modified: false, portable_report_links: 'all referenced local evidence included', full_netlist_acceptance_claimed: false, new_model_calls: 0, new_eda_runs: 0 }, null, 2))
records.sort((a, b) => a.path.localeCompare(b.path))
const manifest = { schema: 'agentforchip-advisor-package-v1', date: '2026-10-18', root: basename(root), file_count: records.length, total_bytes: records.reduce((sum, item) => sum + item.bytes, 0), note: 'MANIFEST.json deliberately does not list itself. Raw evidence is byte-identical; only REPORT.zh.md rewrites evidence links.', files: records }
await writeFile(join(root, 'MANIFEST.json'), JSON.stringify(manifest, null, 2), { flag: 'wx' })
await writeFile(join(here, 'build-result.json'), JSON.stringify({ root, files: manifest.file_count + 1, bytes_excluding_manifest: manifest.total_bytes, source_files: sources.length, excluded_entries: exclusions.length }, null, 2), { flag: 'wx' })
console.log(JSON.stringify({ status: 'PASS', root, files: manifest.file_count + 1, megabytes: manifest.total_bytes / 1024 / 1024, excluded: exclusions.length }))

import { readFile, stat } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { dirname, resolve, relative, isAbsolute } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const inside = value => {
  const path = resolve(root, value)
  const rel = relative(root, path)
  if (rel.startsWith('..') || isAbsolute(rel)) throw new Error('Path escapes package')
  return path
}
if (process.argv[2] === '--resolve') {
  const value = (process.argv[3] ?? '').replaceAll('\\', '/')
  const mapped = value.replace(/^D:\/(AMD|deepseek-harness)\//i, '$1/')
  if (mapped === value) throw new Error('Expected a historical D:/AMD or D:/deepseek-harness path')
  const path = inside(mapped)
  await stat(path)
  console.log(path)
} else {
  const manifest = JSON.parse(await readFile(inside('MANIFEST.json'), 'utf8'))
  let bytes = 0
  for (const file of manifest.files) {
    const data = await readFile(inside(file.path))
    const hash = createHash('sha256').update(data).digest('hex')
    if (data.length !== file.bytes || hash !== file.sha256) throw new Error(`Mismatch: ${file.path}`)
    bytes += data.length
  }
  console.log(JSON.stringify({ status: 'PASS', files: manifest.files.length, bytes, scope: 'Exported file integrity only; no model or EDA execution' }, null, 2))
}

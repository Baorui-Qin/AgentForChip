
module TopModule (
    input  logic clk,
    input  logic x,
    output logic z
);

    logic [2:0] q = 3'b000;  // q[0]: XOR FF, q[1]: AND FF, q[2]: OR FF

    always_ff @(posedge clk) begin
        q[0] <= x ^ q[0];
        q[1] <= x & ~q[1];
        q[2] <= x | ~q[2];
    end

    assign z = ~(q[0] | q[1] | q[2]);

endmodule

# 验收模板，不是验收结果

`p09_acceptance_template.json` 的 T01—T32 全部为 `NOT_RUN`。由 Codex 执行用户项目后另行生成实际 `p09-acceptance.json`，填写 evidence_kind 和真实证据路径，不覆盖此模板冒充新结果。

合法状态：PASS、FAIL、BLOCKED、NOT_RUN、NOT_APPLICABLE。Mock、历史回放、新 API、新 EDA、人工审批和无人干预需分别记录。不适用/跳过不计通过。

`../metadata/package_validation.json` 只检查本资料包是否自洽、下载脚本是否通过离线单元测试，绝不能代替这些 P09 项目验收。

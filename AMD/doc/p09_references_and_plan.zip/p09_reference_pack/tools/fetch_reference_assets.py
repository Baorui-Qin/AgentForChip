#!/usr/bin/env python3
"""Fetch versioned P09 references. Standard library only; never execute sources.

Run from any directory:
    python tools/fetch_reference_assets.py --papers --dry-run
    python tools/fetch_reference_assets.py --papers
    python tools/fetch_reference_assets.py --sources

The supplied ZIP has no PDFs. This helper has offline unit tests, not a verified
live-download run in the authoring environment. Results append to a separate
receipt; the original reference manifest is never rewritten.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import socket
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

ALLOWED_HOSTS = frozenset({"arxiv.org", "www.arxiv.org", "export.arxiv.org",
                           "api.github.com", "raw.githubusercontent.com", "github.com"})
DEFAULT_ROOT = Path(__file__).resolve().parents[1]
MAX_PDF_BYTES = 64 * 1024 * 1024
MAX_SOURCE_BYTES = 4 * 1024 * 1024
USER_AGENT = "P09ReferenceCollector/1.0 (personal research; no code execution)"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def checked_url(url: str) -> str:
    p = urllib.parse.urlsplit(url)
    if (p.scheme != "https" or p.hostname not in ALLOWED_HOSTS
            or p.username or p.password or p.port not in (None, 443)):
        raise ValueError("URL is not an allowlisted credential-free HTTPS URL")
    return url


def safe_path(root: Path, relative: str) -> Path:
    p = PurePosixPath(relative)
    if (not relative or p.is_absolute() or any(x in ("..", ".", "") for x in relative.split("/"))
            or "\\" in relative or ":" in relative):
        raise ValueError("Unsafe relative destination")
    r = root.resolve()
    out = (r / p).resolve()
    if not out.is_relative_to(r) or out == r:
        raise ValueError("Destination escapes collection root")
    return out


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        checked_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch_bytes(url: str, *, timeout: float, max_bytes: int, retries: int = 1) -> bytes:
    """Bound response size; use TLS validation and normal OS proxy settings."""
    checked_url(url)
    opener = urllib.request.build_opener(SafeRedirect())
    for attempt in range(retries + 1):
        started = time.monotonic()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT,
                                                        "Accept": "*/*"})
            with opener.open(req, timeout=timeout) as response:
                checked_url(response.geturl())
                declared = response.headers.get("Content-Length")
                if declared and int(declared) > max_bytes:
                    raise ValueError("Response exceeds byte limit")
                chunks: list[bytes] = []
                count = 0
                while True:
                    if time.monotonic() - started > timeout:
                        raise TimeoutError("Download deadline exceeded")
                    block = response.read(min(65536, max_bytes + 1 - count))
                    if not block:
                        break
                    chunks.append(block)
                    count += len(block)
                    if count > max_bytes:
                        raise ValueError("Response exceeds byte limit")
                return b"".join(chunks)
        except urllib.error.HTTPError as exc:
            if exc.code not in {408, 429, 500, 502, 503, 504} or attempt >= retries:
                raise
        except (urllib.error.URLError, TimeoutError, socket.timeout, ConnectionError):
            if attempt >= retries:
                raise
        time.sleep(min(2 ** attempt, 4))
    raise RuntimeError("Unreachable retry state")


def validate_pdf(data: bytes) -> None:
    # Check signature/size, not complete PDF syntax or licensing.
    if len(data) < 1024 or not data.startswith(b"%PDF-"):
        raise ValueError("Response is not a plausible PDF; nothing was written")


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".download-", delete=False) as f:
        temporary = Path(f.name)
        try:
            f.write(data)
            f.flush()
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
    try:
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def safe_error(exc: Exception) -> dict[str, Any]:
    # Do not record arbitrary exception repr, proxy credentials or request headers.
    if isinstance(exc, urllib.error.HTTPError):
        return {"type": "http_error", "http_status": exc.code}
    if isinstance(exc, (TimeoutError, socket.timeout)):
        return {"type": "timeout"}
    if isinstance(exc, urllib.error.URLError):
        return {"type": "network_error", "cause_type": type(exc.reason).__name__}
    return {"type": type(exc).__name__, "details": "See limits, paths, format, or network configuration."}


def store_asset(root: Path, *, asset_id: str, url: str, relative: str,
                kind: str, timeout: float, retries: int, overwrite: bool,
                optional: bool = False) -> dict[str, Any]:
    result: dict[str, Any] = {"id": asset_id, "kind": kind, "url": url,
                              "relative_path": relative, "checked_at": utc_now()}
    try:
        dest = safe_path(root, relative)
        if dest.exists() and not overwrite:
            data = dest.read_bytes()
            if kind == "paper_pdf":
                validate_pdf(data)
            result.update(status="existing_not_download_verified", bytes=len(data),
                          sha256=hashlib.sha256(data).hexdigest())
            return result
        data = fetch_bytes(url, timeout=timeout,
                           max_bytes=MAX_PDF_BYTES if kind == "paper_pdf" else MAX_SOURCE_BYTES,
                           retries=retries)
        if kind == "paper_pdf":
            validate_pdf(data)
        elif not data or b"\x00" in data[:4096]:
            raise ValueError("Expected nonempty text source")
        atomic_write(dest, data)
        result.update(status="downloaded", bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    except urllib.error.HTTPError as exc:
        if optional and exc.code == 404:
            result.update(status="optional_not_found", error=safe_error(exc))
        else:
            result.update(status="failed", error=safe_error(exc))
    except Exception as exc:
        result.update(status="failed", error=safe_error(exc))
    return result


def resolve_commit(repo: str, branch: str, timeout: float, retries: int) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo):
        raise ValueError("Invalid GitHub repository identifier")
    url = f"https://api.github.com/repos/{repo}/commits/{urllib.parse.quote(branch, safe='')}"
    obj = json.loads(fetch_bytes(url, timeout=timeout, max_bytes=2 * 1024 * 1024, retries=retries))
    commit = obj.get("sha")
    if not isinstance(commit, str) or not re.fullmatch(r"[0-9a-f]{40}", commit):
        raise ValueError("GitHub response did not include a full commit SHA")
    return commit


def append_receipt(root: Path, record: dict[str, Any]) -> None:
    path = safe_path(root, "metadata/download_results.json")
    if path.exists():
        obj = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(obj, dict) or not isinstance(obj.get("runs"), list):
            raise ValueError("Existing receipt is invalid; refusing to overwrite history")
    else:
        obj = {"schema_version": 1, "kind": "user_executed_reference_download_receipts", "runs": []}
    obj["runs"].append(record)
    atomic_write(path, (json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--papers", action="store_true", help="Fetch six versioned arXiv PDFs")
    parser.add_argument("--sources", action="store_true", help="Fetch selected source files, not full repositories")
    parser.add_argument("--dry-run", action="store_true", help="Show planned targets without network or writes")
    parser.add_argument("--overwrite", action="store_true", help="Explicitly replace existing target assets")
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--timeout", type=float, default=60.0)
    parser.add_argument("--retries", type=int, default=1, help="Extra temporary-network attempts per asset (0..3)")
    args = parser.parse_args(argv)
    if not args.papers and not args.sources:
        parser.error("Select --papers and/or --sources")
    if args.timeout <= 0 or not 0 <= args.retries <= 3:
        parser.error("Timeout must be positive and retries must be between 0 and 3")
    root = args.root.resolve()
    try:
        manifest = json.loads((root / "metadata/references.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        print(f"Cannot read reference manifest: {type(exc).__name__}", file=sys.stderr)
        return 2
    if args.dry_run:
        if args.papers:
            for p in manifest["papers"]:
                print(f"{p['id']}: {p['pdf_url']} -> {p['planned_pdf_path']}")
        if args.sources:
            for repo in manifest["repositories"]:
                print(f"{repo['id']}: resolve {repo['repo']}@{repo['branch']}; selected files + available licenses")
        return 0
    record: dict[str, Any] = {"started_at": utc_now(), "original_manifest_unchanged": True,
                              "assets": [], "repository_resolutions": []}
    common = dict(timeout=args.timeout, retries=args.retries, overwrite=args.overwrite)
    if args.papers:
        for p in manifest["papers"]:
            result = store_asset(root, asset_id=p["id"], url=p["pdf_url"],
                                 relative=p["planned_pdf_path"], kind="paper_pdf", **common)
            record["assets"].append(result)
            print(f"{p['id']}: {result['status']}", flush=True)
    if args.sources:
        for repo in manifest["repositories"]:
            resolved = {"id": repo["id"], "repo": repo["repo"], "branch": repo["branch"], "resolved_at": utc_now()}
            try:
                commit = resolve_commit(repo["repo"], repo["branch"], args.timeout, args.retries)
                resolved.update(status="resolved_at_download_time", commit=commit)
                base = f"source_snapshots/{repo['id'].lower()}/{commit}"
                required = set(repo["files"])
                paths = list(dict.fromkeys([*repo["files"], "LICENSE", "LICENSE.md", "LICENSE.txt", "NOTICE"]))
                for filename in paths:
                    url = f"https://raw.githubusercontent.com/{repo['repo']}/{commit}/{urllib.parse.quote(filename, safe='/')}"
                    result = store_asset(root, asset_id=f"{repo['id']}:{filename}", url=url,
                                         relative=f"{base}/{filename}", kind="selected_source",
                                         optional=filename not in required, **common)
                    result.update(repo=repo["repo"], commit=commit)
                    record["assets"].append(result)
                    print(f"{result['id']}: {result['status']}", flush=True)
            except Exception as exc:
                resolved.update(status="failed", error=safe_error(exc))
                print(f"{repo['id']}: commit resolution failed", file=sys.stderr, flush=True)
            record["repository_resolutions"].append(resolved)
    record["finished_at"] = utc_now()
    record["downloaded_count"] = sum(a["status"] == "downloaded" for a in record["assets"])
    record["needs_attention"] = (any(a["status"] in {"failed", "existing_not_download_verified"} for a in record["assets"])
                                  or any(r["status"] == "failed" for r in record["repository_resolutions"]))
    try:
        append_receipt(root, record)
    except Exception as exc:
        print(f"Could not append receipt: {type(exc).__name__}. Downloaded files remain on disk.", file=sys.stderr)
        return 2
    print(f"Downloaded {record['downloaded_count']} assets. Receipt: metadata/download_results.json")
    return 1 if record["needs_attention"] else 0


if __name__ == "__main__":
    raise SystemExit(main())

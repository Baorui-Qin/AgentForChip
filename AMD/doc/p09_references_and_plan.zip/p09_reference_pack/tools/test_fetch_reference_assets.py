"""Offline tests only. These do not prove live access or P09 implementation."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import urllib.error

_spec = importlib.util.spec_from_file_location('fetch', Path(__file__).with_name('fetch_reference_assets.py'))
f = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(f)
PDF = b'%PDF-1.7\n' + b'0' * 1500 + b'\n%%EOF'


class OfflineTests(unittest.TestCase):
    def test_allow_https(self):
        self.assertEqual(f.checked_url('https://arxiv.org/pdf/2311.04887v2'), 'https://arxiv.org/pdf/2311.04887v2')

    def test_reject_bad_hosts_or_credentials(self):
        for url in ('http://arxiv.org/pdf/1', 'https://evil.test/a', 'file:///tmp/a', 'https://x:y@arxiv.org/a'):
            with self.assertRaises(ValueError): f.checked_url(url)

    def test_relative_paths(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            self.assertEqual(f.safe_path(root, 'papers/a.pdf'), root / 'papers/a.pdf')
            for s in ('../x', '/tmp/x', 'a/../x', 'D:/x', 'a\\b', ''):
                with self.assertRaises(ValueError): f.safe_path(root, s)

    def test_pdf_header(self):
        f.validate_pdf(PDF)
        for s in (b'<html>error</html>', b'%PDF-1.7\n'):
            with self.assertRaises(ValueError): f.validate_pdf(s)

    def test_success_writes_and_hashes(self):
        with tempfile.TemporaryDirectory() as td, patch.object(f, 'fetch_bytes', return_value=PDF):
            r = f.store_asset(Path(td), asset_id='P1', url='https://arxiv.org/pdf/a', relative='papers/a.pdf', kind='paper_pdf', timeout=1, retries=0, overwrite=False)
            self.assertEqual(r['status'], 'downloaded')
            self.assertEqual((Path(td)/'papers/a.pdf').read_bytes(), PDF)
            self.assertEqual(len(r['sha256']), 64)

    def test_html_not_written_as_pdf(self):
        with tempfile.TemporaryDirectory() as td, patch.object(f, 'fetch_bytes', return_value=b'<html>no</html>'):
            r = f.store_asset(Path(td), asset_id='P1', url='https://arxiv.org/pdf/a', relative='papers/a.pdf', kind='paper_pdf', timeout=1, retries=0, overwrite=False)
            self.assertEqual(r['status'], 'failed')
            self.assertFalse((Path(td)/'papers/a.pdf').exists())

    def test_existing_preserved(self):
        with tempfile.TemporaryDirectory() as td:
            dest = Path(td)/'a.pdf'; dest.write_bytes(PDF)
            with patch.object(f, 'fetch_bytes') as mock:
                r = f.store_asset(Path(td), asset_id='P1', url='https://arxiv.org/pdf/a', relative='a.pdf', kind='paper_pdf', timeout=1, retries=0, overwrite=False)
            mock.assert_not_called()
            self.assertEqual(r['status'], 'existing_not_download_verified')

    def test_receipt_history(self):
        with tempfile.TemporaryDirectory() as td:
            f.append_receipt(Path(td), {'x':1})
            f.append_receipt(Path(td), {'x':2})
            obj=json.loads((Path(td)/'metadata/download_results.json').read_text())
            self.assertEqual([v['x'] for v in obj['runs']], [1,2])

    def test_commit_resolution(self):
        with patch.object(f, 'fetch_bytes', return_value=json.dumps({'sha':'a'*40}).encode()):
            self.assertEqual(f.resolve_commit('a/b','main',1,0), 'a'*40)

    def test_invalid_commit(self):
        with patch.object(f, 'fetch_bytes', return_value=b'{"sha":"main"}'):
            with self.assertRaises(ValueError): f.resolve_commit('a/b','main',1,0)

    def test_error_redaction(self):
        err = urllib.error.URLError('https://user:secret@proxy.test failed')
        self.assertNotIn('secret',json.dumps(f.safe_error(err)))

    def test_optional_license_missing(self):
        e = urllib.error.HTTPError('https://raw.githubusercontent.com/a/b/c/LICENSE',404,'not found',{},None)
        with tempfile.TemporaryDirectory() as td, patch.object(f,'fetch_bytes',side_effect=e):
            r=f.store_asset(Path(td),asset_id='R:LICENSE',url=e.url,relative='LICENSE',kind='selected_source',timeout=1,retries=0,overwrite=False,optional=True)
            self.assertEqual(r['status'],'optional_not_found')

if __name__=='__main__': unittest.main(verbosity=2)

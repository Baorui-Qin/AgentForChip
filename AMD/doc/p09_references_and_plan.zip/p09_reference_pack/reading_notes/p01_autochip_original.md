# P01｜AutoChip: Automating HDL Generation Using LLM Feedback

**作者：** Shailja Thakur; Jason Blocklove; Hammond Pearce; Benjamin Tan; Siddharth Garg; Ramesh Karri  
**本包采用版本：** arXiv:2311.04887v2（2024；核对日 2026-09-17）  
**原文：** [摘要/版本页](https://arxiv.org/abs/2311.04887v2) · [PDF](https://arxiv.org/pdf/2311.04887v2) · [HTML](https://arxiv.org/html/2311.04887v2)  
**配套项目：** [shailja-thakur/AutoChip](https://github.com/shailja-thakur/AutoChip)

> 此文件为中文导读，不是论文原文、全文译文或复现实验报告。原始 PDF 未成功下载进本包。

## 原文支持的思路

区分 full context 与 succinct feedback。精简模式将固定系统提示、题面、最新候选以及该候选的工具反馈送入下一轮；迭代达到成功或上限后结束。

## 建议阅读位置

§3 AutoChip Design Framework；PDF 第 3 页 Table 3；Choice of Context Window。上述章节/关键词供定位；网页排版和 PDF 页码可能不同。

## 对本项目的采用建议（工程设计，不是论文结论）

把 P09 的默认上下文组织成当前状态视图，而非无界聊天历史；旧候选只在磁盘存档，不默认再次进入模型输入。

## 边界与不能照搬的部分

早期实验基于 HDLBits 衍生任务与 Icarus；论文中的工具、模型和测试集不等于本项目的 Vivado 2025.2 环境。

## 阅读后应回答

1. 作者的失败事实来自哪里，谁控制下一轮？
2. 哪些旧信息被保留、遮蔽或总结，哪些始终不可丢失？
3. 作者的循环单位和我们 P07 的 repair round 是否一致？
4. 借鉴到 Vivado 后，需要补哪一项正反验收，而不是只换一个类名？

## 获取与许可记录

arXiv 页面标示 CC BY-NC-SA 4.0；PDF 首页另有作者版本限制提示，使用时核对原始声明。。论文与代码是不同许可对象，保留各自作者与原始通知；本包不把公开可访问等同于任意使用授权。

可在联网电脑执行 `python tools/fetch_reference_assets.py --papers` 下载固定版本。下载器只保存文件和哈希，不执行论文代码；首次下载哈希为本地完整性记录，不代表预先核验的原文校验和。

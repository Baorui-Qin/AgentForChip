# P04｜The Complexity Trap: Simple Observation Masking Is as Efficient as LLM Summarization for Agent Context Management

**作者：** Tobias Lindenbauer; Igor Slinko; Ludwig Felder; Egor Bogomolov; Yaroslav Zharov  
**本包采用版本：** arXiv:2508.21433v3（2025；核对日 2026-09-17）  
**原文：** [摘要/版本页](https://arxiv.org/abs/2508.21433v3) · [PDF](https://arxiv.org/pdf/2508.21433v3) · [HTML](https://arxiv.org/html/2508.21433v3)  
**配套项目：** [JetBrains-Research/the-complexity-trap](https://github.com/JetBrains-Research/the-complexity-trap)

> 此文件为中文导读，不是论文原文、全文译文或复现实验报告。原始 PDF 未成功下载进本包。

## 原文支持的思路

在软件工程 Agent 实验中比较保留原历史、遮蔽旧观察与模型总结。v3 还包含混合策略和 OpenHands 泛化探测；观察遮蔽是有竞争力的成本基线。

## 建议阅读位置

方法中 observation masking 与 summarization 的比较；源码 LastNObservations / SummarizeEveryNTurns。上述章节/关键词供定位；网页排版和 PDF 页码可能不同。

## 对本项目的采用建议（工程设计，不是论文结论）

首版不新增总结模型。只减少送进 Prompt 的旧工具正文，保留磁盘原证据；默认最新反馈加两条确定性历史。

## 边界与不能照搬的部分

不是 RTL 实验；上一轮提到的 v1 与本包索引的 v3 不应混作同一实验版本。对 RTL 的收益仍需自测。

## 阅读后应回答

1. 作者的失败事实来自哪里，谁控制下一轮？
2. 哪些旧信息被保留、遮蔽或总结，哪些始终不可丢失？
3. 作者的循环单位和我们 P07 的 repair round 是否一致？
4. 借鉴到 Vivado 后，需要补哪一项正反验收，而不是只换一个类名？

## 获取与许可记录

arXiv 页面：CC BY 4.0。论文与代码是不同许可对象，保留各自作者与原始通知；本包不把公开可访问等同于任意使用授权。

可在联网电脑执行 `python tools/fetch_reference_assets.py --papers` 下载固定版本。下载器只保存文件和哈希，不执行论文代码；首次下载哈希为本地完整性记录，不代表预先核验的原文校验和。

# P06｜Reflexion: Language Agents with Verbal Reinforcement Learning

**作者：** Noah Shinn; Federico Cassano; Edward Berman; Ashwin Gopinath; Karthik Narasimhan; Shunyu Yao  
**本包采用版本：** arXiv:2303.11366v4（2023；核对日 2026-09-17）  
**原文：** [摘要/版本页](https://arxiv.org/abs/2303.11366v4) · [PDF](https://arxiv.org/pdf/2303.11366v4) · [HTML](https://arxiv.org/html/2303.11366v4)  
**配套项目：** [noahshinn/reflexion](https://github.com/noahshinn/reflexion)

> 此文件为中文导读，不是论文原文、全文译文或复现实验报告。原始 PDF 未成功下载进本包。

## 原文支持的思路

通过文本反馈与情节记忆帮助后续尝试，不是在线更新模型权重。框架区分执行、评估与反思职责。

## 建议阅读位置

§3 Reflexion；programming_runs/；episodic memory。上述章节/关键词供定位；网页排版和 PDF 页码可能不同。

## 对本项目的采用建议（工程设计，不是论文结论）

先实现事实型修复账本：候选版本、修改摘要、真实结果、尚未解决的问题。推测单独标注；默认不保存长篇思考过程。

## 边界与不能照搬的部分

不是证明任意长反思都有益。模型自己的解释不能自动升级为工具已证实的根因；不同独立实验不能共享试题答案记忆。

## 阅读后应回答

1. 作者的失败事实来自哪里，谁控制下一轮？
2. 哪些旧信息被保留、遮蔽或总结，哪些始终不可丢失？
3. 作者的循环单位和我们 P07 的 repair round 是否一致？
4. 借鉴到 Vivado 后，需要补哪一项正反验收，而不是只换一个类名？

## 获取与许可记录

arXiv 页面：CC BY 4.0。论文与代码是不同许可对象，保留各自作者与原始通知；本包不把公开可访问等同于任意使用授权。

可在联网电脑执行 `python tools/fetch_reference_assets.py --papers` 下载固定版本。下载器只保存文件和哈希，不执行论文代码；首次下载哈希为本地完整性记录，不代表预先核验的原文校验和。

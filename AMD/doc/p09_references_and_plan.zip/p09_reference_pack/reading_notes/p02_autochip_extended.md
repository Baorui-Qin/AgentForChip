# P02｜Automatically Improving LLM-based Verilog Generation using EDA Tool Feedback

**作者：** Jason Blocklove; Shailja Thakur; Benjamin Tan; Hammond Pearce; Siddharth Garg; Ramesh Karri  
**本包采用版本：** arXiv:2411.11856v3（2025；核对日 2026-09-17）  
**原文：** [摘要/版本页](https://arxiv.org/abs/2411.11856v3) · [PDF](https://arxiv.org/pdf/2411.11856v3) · [HTML](https://arxiv.org/html/2411.11856v3)  
**配套项目：** [shailja-thakur/AutoChip](https://github.com/shailja-thakur/AutoChip)

> 此文件为中文导读，不是论文原文、全文译文或复现实验报告。原始 PDF 未成功下载进本包。

## 原文支持的思路

扩展版引入多候选的贪心搜索，并再次讨论 succinct/full-context 输入。论文说明实验使用 VerilogEval v1；反馈并非在所有受测模型上都稳定优于零反馈。

## 建议阅读位置

§3；Table 2（每轮输入）；§4.1（VerilogEval v1）；§4.2（候选数/深度）。上述章节/关键词供定位；网页排版和 PDF 页码可能不同。

## 对本项目的采用建议（工程设计，不是论文结论）

默认单候选，每轮依据实际 revision 与反馈构建 Prompt。把无历史、短历史与技能增量做固定预算对照，不预先宣称增益。

## 边界与不能照搬的部分

不要把候选数 k、搜索深度 d、独立样本数混为一个参数；P09 不复制其多模型和多候选搜索。

## 阅读后应回答

1. 作者的失败事实来自哪里，谁控制下一轮？
2. 哪些旧信息被保留、遮蔽或总结，哪些始终不可丢失？
3. 作者的循环单位和我们 P07 的 repair round 是否一致？
4. 借鉴到 Vivado 后，需要补哪一项正反验收，而不是只换一个类名？

## 获取与许可记录

arXiv 页面：CC BY-NC-SA 4.0。论文与代码是不同许可对象，保留各自作者与原始通知；本包不把公开可访问等同于任意使用授权。

可在联网电脑执行 `python tools/fetch_reference_assets.py --papers` 下载固定版本。下载器只保存文件和哈希，不执行论文代码；首次下载哈希为本地完整性记录，不代表预先核验的原文校验和。

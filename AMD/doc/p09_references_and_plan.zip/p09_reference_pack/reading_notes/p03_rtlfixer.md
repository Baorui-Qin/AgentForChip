# P03｜RTLFixer: Automatically Fixing RTL Syntax Errors with Large Language Models

**作者：** Yun-Da Tsai; Mingjie Liu; Haoxing Ren  
**本包采用版本：** arXiv:2311.16543v3（2024；核对日 2026-09-17）  
**原文：** [摘要/版本页](https://arxiv.org/abs/2311.16543v3) · [PDF](https://arxiv.org/pdf/2311.16543v3) · [HTML](https://arxiv.org/html/2311.16543v3)  
**配套项目：** [NVlabs/RTLFixer](https://github.com/NVlabs/RTLFixer)

> 此文件为中文导读，不是论文原文、全文译文或复现实验报告。原始 PDF 未成功下载进本包。

## 原文支持的思路

将编译反馈与检索的调试经验结合；ReAct 让模型交替分析和使用工具。论文实验给出温度 0.4 与最多 10 次 Thought–Action–Observation 迭代。

## 建议阅读位置

§3.1–3.3；Figure 2；§4 Setup。上述章节/关键词供定位；网页排版和 PDF 页码可能不同。

## 对本项目的采用建议（工程设计，不是论文结论）

小技能包按实际错误标签检索，技能只提供检查方向。禁止把某个夹具的正确补丁写成所有题目通用的自动修复规则。

## 边界与不能照搬的部分

主要研究语法/编译修复；动作迭代不等于完整语义修复轮次。论文也使用简单规则预处理，本项目不自动继承这种源码修正。

## 阅读后应回答

1. 作者的失败事实来自哪里，谁控制下一轮？
2. 哪些旧信息被保留、遮蔽或总结，哪些始终不可丢失？
3. 作者的循环单位和我们 P07 的 repair round 是否一致？
4. 借鉴到 Vivado 后，需要补哪一项正反验收，而不是只换一个类名？

## 获取与许可记录

arXiv 页面：CC BY-NC-SA 4.0。论文与代码是不同许可对象，保留各自作者与原始通知；本包不把公开可访问等同于任意使用授权。

可在联网电脑执行 `python tools/fetch_reference_assets.py --papers` 下载固定版本。下载器只保存文件和哈希，不执行论文代码；首次下载哈希为本地完整性记录，不代表预先核验的原文校验和。

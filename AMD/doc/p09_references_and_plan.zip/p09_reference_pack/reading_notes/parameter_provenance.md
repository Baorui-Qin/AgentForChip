# 参数出处与采用边界

本页区分 **来源观察** 和 **P09 项目建议**。源码配置会随上游变化；本包只保存导航和观察记录，未解析 commit，也没有打包源码快照。Codex 采用时必须固定实际版本。

## 1. 来源中可核对的数值

| 来源 | 数值/设计 | 位置 | 不能作出的推论 |
|---|---|---|---|
| P01/P02 AutoChip | full vs succinct；精简模式以最新候选和对应反馈为核心 | P01 §3/Table 3；P02 §3/Table 2 | 不能保证所有模型都提升，也不是固定 16K 配置依据 |
| P03 RTLFixer | 温度 0.4；最多 10 次 Thought–Action–Observation 迭代 | arXiv 2311.16543v3 §4 实验设置 | 动作迭代不等于完整修复轮或 pass@k 独立样本 |
| R03 Complexity Trap | LastNObservations；配置文件名含 M=10 | history_processors.py、default_no_demo_N=1_M=10.yaml | 软件 Agent 的消息窗口不是本项目最佳 RTL 历史条数 |
| R04 VerilogCoder | 部分角色 HistoryLimit=3；写代码温度 0.1、调试 0.2；timeout=600；群聊 max_round=40 | verilog_agent_configs.py | 群聊轮数、单次请求 timeout 与 DUT 语义修复上限不可混为一谈 |
| R07 DeepSeek Harness | thresholdRatio=0.8、retainRatio=0.16、maxTokens=8192、compactionRetries=1、maxOverflowRetries=1 | compaction-basic/README.md | maxTokens 是压缩调用预算，不是 DUT 输出上限；独立 callText 不一定经过此钩子 |
| D03 vLLM | max-model-len 对应输入+输出；批次 Token 参数属于调度 | Engine Arguments | 不能用批次 Token 数证明单请求窗口或实际显存足够 |

## 2. P09 建议初值：没有“论文最优值”背书

| 参数 | 建议 | 理由与限制 |
|---|---:|---|
| 项目上下文上限 | 16,384 Token | 小型 RTL 起点；模型/服务/显存需实际支持 |
| 输出预留 | 4,096 Token | 示例，不保证推理模式下可见代码也有 4K |
| 安全余量 | 1,024 Token | 不是估算绝不低估的证明 |
| 输入可用预算 | 11,264 Token | 由三者相减，不另手写成独立冲突参数 |
| 当前代码软阈值 | 3,072 Token | 只告警，不裁剪源码 |
| 最新反馈软预算 | 2,048 Token | 最低必要诊断不能因配额而被截断为错误含义 |
| 近期历史 | 2 条/512 Token | 保留已尝试动作与工具结果，不保存长推理 |
| 选择技能 | <=2 条/768 Token | 从已验证的小库选；无匹配就为空 |
| 自动模型总结 | 关闭 | 先测确定性短账本和旧日志遮蔽 |
| 语义修复 | 3 轮 | 继承当前 P07；不强制增加模型调用次数 |
| 单轮候选 | 1 个 | 暂不引入多候选搜索 |
| 传输重试 | 最多额外 2 次 | 所有真实尝试与成本仍计数；不保证服务端只生成一次 |
| 格式恢复、上下文恢复 | 各最多 1 次，整题独立预算 | Prompt 变化不叫相同请求传输重试 |
| 全局模型调用硬上限 | 15 次示例 | 可以提前耗尽；不是保证任何错误组合都可执行所有恢复 |
| 温度/top_p | 继承现状 | 0.2/1.0 仅作后续非推理模式实验起点，不能覆盖当前 high 模式 |

优先级：**实际已审核部署参数 → 本规划采用决策 → 参考项目默认值。** 不得为采用论文配置静默改变模型、推理模式或上下文限制。

## 3. 计量原则

完整消息需通过匹配的 chat template/Tokenizer 计量；不能把各块 Token 简单求和当精确最终值。计入角色、特殊 Token、生成前缀和工具描述。当前 text-only 请求的 tools 应为空。云端无法精确计数时，明确标记估算；未知服务端窗口不是无限窗口。

计数维度分别保存：独立 sample、修复提案轮、模型逻辑请求、实际派发尝试、格式恢复、上下文恢复、EDA 次数、Token、墙钟及人工等待。只有有效新候选进入 EDA，部分模型输出不执行。

## 4. 直接来源

- P01：https://arxiv.org/abs/2311.04887v2
- P02：https://arxiv.org/html/2411.11856v3
- P03：https://arxiv.org/abs/2311.16543v3
- R03：https://github.com/JetBrains-Research/the-complexity-trap/blob/main/sweagent/agent/history_processors.py
- R04：https://github.com/NVlabs/VerilogCoder/blob/main/hardware_agent/examples/VerilogCoder/verilog_agent_configs.py
- R07：https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/compaction/compaction-basic/README.md
- D02：https://huggingface.co/docs/transformers/en/chat_templating
- D03：https://docs.vllm.ai/en/latest/configuration/engine_args/

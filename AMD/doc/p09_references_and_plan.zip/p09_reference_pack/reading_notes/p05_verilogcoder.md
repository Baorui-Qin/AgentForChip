# P05｜VerilogCoder: Autonomous Verilog Coding Agents with Graph-based Planning and Abstract Syntax Tree (AST)-based Waveform Tracing Tool

**作者：** Chia-Tung Ho; Haoxing Ren; Brucek Khailany  
**本包采用版本：** arXiv:2408.08927v2（2025；核对日 2026-09-17）  
**原文：** [摘要/版本页](https://arxiv.org/abs/2408.08927v2) · [PDF](https://arxiv.org/pdf/2408.08927v2) · [HTML](https://arxiv.org/html/2408.08927v2)  
**配套项目：** [NVlabs/VerilogCoder](https://github.com/NVlabs/VerilogCoder)

> 此文件为中文导读，不是论文原文、全文译文或复现实验报告。原始 PDF 未成功下载进本包。

## 原文支持的思路

通过任务/电路关系规划以及 AST 辅助波形追踪支持 RTL 生成和调试。其配置区分生成、验证与调试角色。

## 建议阅读位置

Figure 2；Functional Debug with Waveform；配置文件 verilog_agent_configs.py。上述章节/关键词供定位；网页排版和 PDF 页码可能不同。

## 对本项目的采用建议（工程设计，不是论文结论）

借鉴相关证据筛选与模板分离。P09 不实现 AST 波形追踪；实际没有输出的 expected/observed、周期或行号不得补写。

## 边界与不能照搬的部分

任务/电路关系图不是宿主状态机。源码中的 HistoryLimit、群聊轮数、超时不能直接视为本项目的最优预算。

## 阅读后应回答

1. 作者的失败事实来自哪里，谁控制下一轮？
2. 哪些旧信息被保留、遮蔽或总结，哪些始终不可丢失？
3. 作者的循环单位和我们 P07 的 repair round 是否一致？
4. 借鉴到 Vivado 后，需要补哪一项正反验收，而不是只换一个类名？

## 获取与许可记录

arXiv 页面：CC BY 4.0。论文与代码是不同许可对象，保留各自作者与原始通知；本包不把公开可访问等同于任意使用授权。

可在联网电脑执行 `python tools/fetch_reference_assets.py --papers` 下载固定版本。下载器只保存文件和哈希，不执行论文代码；首次下载哈希为本地完整性记录，不代表预先核验的原文校验和。

# 开源实现导航（不是已下载源码包）

只读取这里的代码以确定可借鉴位置；不要把参考仓库的 main/master 自动安装进当前 Harness。采用前固定 commit，核对 LICENSE/NOTICE，记录移植范围。

## R01｜shailja-thakur/AutoChip

[仓库](https://github.com/shailja-thakur/AutoChip) · 查阅分支 `main` · commit：本次未解析。

**用途：**最新候选与反馈的循环；会话管理

**搜索符号：**`Conversation`, `get_last_n_messages`, `verilog_loop`

- [`README.md`](https://github.com/shailja-thakur/AutoChip/blob/main/README.md)

- [`autochip_scripts/conversation.py`](https://github.com/shailja-thakur/AutoChip/blob/main/autochip_scripts/conversation.py)

- [`autochip_scripts/generate_verilog.py`](https://github.com/shailja-thakur/AutoChip/blob/main/autochip_scripts/generate_verilog.py)

- [`autochip_scripts/verilog_handling.py`](https://github.com/shailja-thakur/AutoChip/blob/main/autochip_scripts/verilog_handling.py)

**边界：**不复制其 Icarus 验证器替代本项目 EDA；不要让启发式代码提取偷偷修正模型输出。

## R02｜NVlabs/RTLFixer

[仓库](https://github.com/NVlabs/RTLFixer) · 查阅分支 `main` · commit：本次未解析。

**用途：**编译反馈、标签检索与独立预算

**搜索符号：**`react_fix_compile`, `react_fix_simulate`, `max_iters`, `max_budgets`, `num_samples`

- [`LICENSE`](https://github.com/NVlabs/RTLFixer/blob/main/LICENSE)

- [`readme.md`](https://github.com/NVlabs/RTLFixer/blob/main/readme.md)

- [`src/main.py`](https://github.com/NVlabs/RTLFixer/blob/main/src/main.py)

- [`src/scripts/run_oneshot_fix_compile.sh`](https://github.com/NVlabs/RTLFixer/blob/main/src/scripts/run_oneshot_fix_compile.sh)

**边界：**编译工具、错误标签和实验统计口径需重新适配；禁止把基准答案导入 skill。

## R03｜JetBrains-Research/the-complexity-trap

[仓库](https://github.com/JetBrains-Research/the-complexity-trap) · 查阅分支 `main` · commit：本次未解析。

**用途：**旧观察遮蔽与可选总结

**搜索符号：**`LastNObservations`, `SummarizeEveryNTurns`

- [`README.md`](https://github.com/JetBrains-Research/the-complexity-trap/blob/main/README.md)

- [`sweagent/agent/history_processors.py`](https://github.com/JetBrains-Research/the-complexity-trap/blob/main/sweagent/agent/history_processors.py)

- [`config/default_no_demo_N=1_M=10.yaml`](https://github.com/JetBrains-Research/the-complexity-trap/blob/main/config/default_no_demo_N=1_M=10.yaml)

**边界：**借鉴消息处理，不引入整个 SWE-agent；工具历史需维护调用与结果配对。

## R04｜NVlabs/VerilogCoder

[仓库](https://github.com/NVlabs/VerilogCoder) · 查阅分支 `main` · commit：本次未解析。

**用途：**生成/调试 Prompt 与局部证据

**搜索符号：**`HistoryLimit`, `get_verilog_completion_prompt`, `get_verilog_debug_prompt`, `tool_usage_prompt`

- [`README.md`](https://github.com/NVlabs/VerilogCoder/blob/main/README.md)

- [`hardware_agent/examples/VerilogCoder/verilog_agent_configs.py`](https://github.com/NVlabs/VerilogCoder/blob/main/hardware_agent/examples/VerilogCoder/verilog_agent_configs.py)

- [`hardware_agent/examples/VerilogCoder/verilogcoder.py`](https://github.com/NVlabs/VerilogCoder/blob/main/hardware_agent/examples/VerilogCoder/verilogcoder.py)

**边界：**不复制通用执行器权限，不在 P09 上多 Agent 或 AST 波形图。

## R05｜noahshinn/reflexion

[仓库](https://github.com/noahshinn/reflexion) · 查阅分支 `main` · commit：本次未解析。

**用途：**修复记忆与实验轨迹

**搜索符号：**`programming_runs/`

- [`README.md`](https://github.com/noahshinn/reflexion/blob/main/README.md)

**边界：**反思是推断，不是判分事实；首版仅使用确定性账本。

## R06｜SWE-agent/mini-swe-agent

[仓库](https://github.com/SWE-agent/mini-swe-agent) · 查阅分支 `main` · commit：本次未解析。

**用途：**小循环、模板和调用预算

**搜索符号：**`system_template`, `instance_template`, `observation_template`, `format_error_template`

- [`README.md`](https://github.com/SWE-agent/mini-swe-agent/blob/main/README.md)

- [`src/minisweagent/agents/default.py`](https://github.com/SWE-agent/mini-swe-agent/blob/main/src/minisweagent/agents/default.py)

- [`src/minisweagent/config/default.yaml`](https://github.com/SWE-agent/mini-swe-agent/blob/main/src/minisweagent/config/default.yaml)

**边界：**借鉴结构，不继承 Bash 工具权限；字符上限不等于 Token 上限。

## R07｜deepseek-ai/deepseek-harness

[仓库](https://github.com/deepseek-ai/deepseek-harness) · 查阅分支 `master` · commit：本次未解析。

**用途：**原生循环、Token 计量与压缩钩子

**搜索符号：**`agent/pre-step`, `thresholdRatio`, `retainRatio`, `maxTokens`

- [`README.md`](https://github.com/deepseek-ai/deepseek-harness/blob/master/README.md)

- [`packages/core/agent-loop/README.md`](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/core/agent-loop/README.md)

- [`packages/llm/token-meter/README.md`](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/llm/token-meter/README.md)

- [`packages/compaction/compaction-basic/README.md`](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/compaction/compaction-basic/README.md)

- [`packages/compaction/compaction-tool-result-pruner/README.md`](https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/compaction/compaction-tool-result-pruner/README.md)

**边界：**上游 master 不等于用户本地 commit；独立 callText 可能绕过压缩钩子，必须检查实际路径。

## 下载行为

`python tools/fetch_reference_assets.py --sources` 会通过 GitHub API 解析分支 commit，再下载所列文件至 `source_snapshots/`；不会安装依赖或执行源码。不同仓库缺失的 README/许可文件会单独记录，不用空文件冒充成功。第一次运行得到的 commit 是下载时版本，不是本包生成时的锁定版本。

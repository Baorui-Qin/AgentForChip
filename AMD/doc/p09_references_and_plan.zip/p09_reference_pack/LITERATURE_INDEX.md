# P09 文献与实现总索引

核对日期：2026-09-17。原文 PDF 与完整仓库未打入包；下列是核实过的原文入口与导读。

## 六篇论文

| ID | 文献与版本 | 重点 | 导读 |
|---|---|---|---|
| P01 | [AutoChip: Automating HDL Generation Using LLM Feedback](https://arxiv.org/abs/2311.04887v2) · `2311.04887v2` | §3 AutoChip Design Framework；PDF 第 3 页 Table 3；Choice of Context Window | [中文导读](reading_notes/p01_autochip_original.md) |
| P02 | [Automatically Improving LLM-based Verilog Generation using EDA Tool Feedback](https://arxiv.org/abs/2411.11856v3) · `2411.11856v3` | §3；Table 2（每轮输入）；§4.1（VerilogEval v1）；§4.2（候选数/深度） | [中文导读](reading_notes/p02_autochip_extended.md) |
| P03 | [RTLFixer: Automatically Fixing RTL Syntax Errors with Large Language Models](https://arxiv.org/abs/2311.16543v3) · `2311.16543v3` | §3.1–3.3；Figure 2；§4 Setup | [中文导读](reading_notes/p03_rtlfixer.md) |
| P04 | [The Complexity Trap: Simple Observation Masking Is as Efficient as LLM Summarization for Agent Context Management](https://arxiv.org/abs/2508.21433v3) · `2508.21433v3` | 方法中 observation masking 与 summarization 的比较；源码 LastNObservations / SummarizeEveryNTurns | [中文导读](reading_notes/p04_complexity_trap.md) |
| P05 | [VerilogCoder: Autonomous Verilog Coding Agents with Graph-based Planning and Abstract Syntax Tree (AST)-based Waveform Tracing Tool](https://arxiv.org/abs/2408.08927v2) · `2408.08927v2` | Figure 2；Functional Debug with Waveform；配置文件 verilog_agent_configs.py | [中文导读](reading_notes/p05_verilogcoder.md) |
| P06 | [Reflexion: Language Agents with Verbal Reinforcement Learning](https://arxiv.org/abs/2303.11366v4) · `2303.11366v4` | §3 Reflexion；programming_runs/；episodic memory | [中文导读](reading_notes/p06_reflexion.md) |

## 七个实现项目

| ID | 仓库 | 优先看 |
|---|---|---|
| R01 | [shailja-thakur/AutoChip](https://github.com/shailja-thakur/AutoChip) | 最新候选与反馈的循环；会话管理 |
| R02 | [NVlabs/RTLFixer](https://github.com/NVlabs/RTLFixer) | 编译反馈、标签检索与独立预算 |
| R03 | [JetBrains-Research/the-complexity-trap](https://github.com/JetBrains-Research/the-complexity-trap) | 旧观察遮蔽与可选总结 |
| R04 | [NVlabs/VerilogCoder](https://github.com/NVlabs/VerilogCoder) | 生成/调试 Prompt 与局部证据 |
| R05 | [noahshinn/reflexion](https://github.com/noahshinn/reflexion) | 修复记忆与实验轨迹 |
| R06 | [SWE-agent/mini-swe-agent](https://github.com/SWE-agent/mini-swe-agent) | 小循环、模板和调用预算 |
| R07 | [deepseek-ai/deepseek-harness](https://github.com/deepseek-ai/deepseek-harness) | 原生循环、Token 计量与压缩钩子 |

具体文件见 [源码导航](source_index/README.md)。

## 官方文档

**[D01] [LangGraph — Thinking in LangGraph](https://docs.langchain.com/oss/python/langgraph/thinking-in-langgraph)**：保持 raw state、按需渲染 Prompt；区分临时错误、模型可恢复错误与开发问题。

**[D02] [Hugging Face Transformers — Chat templates](https://huggingface.co/docs/transformers/en/chat_templating)**：按实际 chat template 计入角色、生成提示和特殊 token；避免重复添加特殊 token。

**[D03] [vLLM — Engine Arguments](https://docs.vllm.ai/en/latest/configuration/engine_args/)**：max-model-len 为输入与输出的上下文约束；不要把调度批次预算当成窗口。

## 本地项目依据

U01：用户已有 `phase1_agent_implementation_guide.md`，P07–P09 工作包。

U02：用户已有 `2026-09-13-rtl-simulation-tool.zh.md`，独立调用与执行边界说明；它是较早版本，不能代替现场源码。

U03：用户上传 `p07-20260916.zip` 的半自动验收证据。后续补跑是否完成，必须由 Codex 查本地最新报告，不能在 P09 中预填 PASS。

## 版本与使用说明

论文固定到 arXiv 版本。GitHub 路径为本次查阅的分支导航，未获得固定 commit，不称为锁定源码快照。下载器在用户实际下载时解析 commit 并保存结果；之后应以该 commit 复现。

来源论文/项目的实验参数与本包建议配置分别记录在 [参数来源表](reading_notes/parameter_provenance.md)。

本包不包含任何论文实验的模型权重、数据集或用户 API 密钥，也不是可直接运行的完整 Agent。

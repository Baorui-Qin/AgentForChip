# P09 文献参考与 Codex 执行资料包

**交付类型：参考资料索引、中文导读和实施规划。** 本包没有成功下载原始论文 PDF，也没有打包完整开源仓库；不要把导读、网页快捷方式或脚本视为论文全文。原因是当前文件下载通道/DNS 请求失败。原文浏览和下载是两个不同通道。

## 从哪里开始

- **交给 Codex：**先读 [P09_EXECUTION_PLAN.md](P09_EXECUTION_PLAN.md)，按 Q0—Q7 执行。它是实施规范，不是已经运行或验收的代码。
- **自己阅读：**双击 [index.html](index.html) 打开离线导航；阅读 [LITERATURE_INDEX.md](LITERATURE_INDEX.md) 与六篇中文导读。
- **核对参数：**[reading_notes/parameter_provenance.md](reading_notes/parameter_provenance.md) 区分论文/源码原值与项目建议初值。
- **查实现位置：**[source_index/README.md](source_index/README.md) 列出七个开源项目的文件和符号。未下载仓库，不声称已锁定 commit。
- **核对包：**[SHA256SUMS.txt](SHA256SUMS.txt) 是本次打包时的文件摘要；下载后新增的原文不包含在这份原始清单内。

## 内容

```text
P09_EXECUTION_PLAN.md             可单独发送给 Codex 的完整规划
CODEX_START_HERE.md               简短执行入口
LITERATURE_INDEX.md               6 篇论文 + 7 个项目 + 3 份官方文档
references.bib                   6 条版本化 BibTeX
index.html                       离线导航，无 CDN
papers/*.url                     原文 PDF 快捷入口，不是 PDF 文件
reading_notes/                   原创中文导读与参数来源说明
source_index/README.md           源码位置及迁移边界
config/p09_defaults.yaml         待映射的建议配置，不是 Harness 原生 Schema
templates/                       原创 Prompt / skill 草案模板
acceptance/                      全部标为 NOT_RUN 的验收模板
tools/                           下载脚本和其离线单元测试
metadata/references.json         版本、出处、原文缺项与下载状态
metadata/package_validation.json  资料包自身检查；不是 P09 的真实验收
SHA256SUMS.txt                    本包完整性校验
```

## 在联网电脑补齐原文

需要 Python 3.10 或更新版本，只使用标准库。在解压目录中执行：

```powershell
python tools/fetch_reference_assets.py --papers --dry-run
python tools/fetch_reference_assets.py --papers
```

脚本下载清单中指定版本的六篇 arXiv PDF，检查文件头、限制大小、计算 SHA-256，并将结果追加到 `metadata/download_results.json`。它不会安装依赖、调用模型或运行下载的代码。本包环境未完成这个脚本的联网端到端验证；离线测试只覆盖本地处理逻辑。

可选：下载七个仓库中导航列出的少量文件及可获得的许可证文件：

```powershell
python tools/fetch_reference_assets.py --sources
```

这不是完整仓库克隆。脚本先通过 GitHub API 解析下载当时的 commit，再按该 commit 取文件，写入 `source_snapshots/`。API 限流、文件改名或网络问题会明确记录；不要把缺失文件当成成功。首次解析的 commit 是下载时版本，不是本包生成时版本。

已有目标文件默认不会覆盖：脚本会记录其实际摘要和“来源未在本次验证”，最终返回非零提醒核对。确实需要重新下载时再显式加 `--overwrite`。代理环境变量由 Python 标准网络栈处理；不要关闭 TLS 验证，不要把代理密码写进脚本或提交物。

## 文献版本与使用限制

已明确版本：P01 2311.04887v2；P02 2411.11856v3；P03 2311.16543v3；P04 2508.21433v3；P05 2408.08927v2；P06 2303.11366v4。P04 固定到所核查的 v3，不把此前 v1 描述无差别套入新版本。

每篇保留官方入口与许可说明。论文许可、作者版本声明及代码 LICENSE/NOTICE 分别适用。尤其 P01 的 arXiv 许可标签与 PDF 首页作者版本提示应由使用者再次核对；本包没有转载论文全文。复制代码前要核对具体文件头和仓库许可证，本资料包不替代授权审查。

## 项目边界

P09 接现有 P07 修复循环：固定题面 + 当前 DUT + 最新反馈 + 两条短历史 + 最多两条已验证技能。不得为裁剪上下文改动测试台、XDC、参考实现或判分规则。不得把 16K/4K 示例配置静默覆盖到当前 high 推理模式。

本包没有执行用户仓库测试、真实模型调用、Vivado、ROCm 或安全隔离验收；也没有解除 Prob038 的原始测试台兼容性阻塞。

# Codex 执行入口

请先完整读取同目录 `P09_EXECUTION_PLAN.md`，再读取当前仓库的 `AGENTS.md`、赛题要求、最新 P07/P08 报告与实际源码。

按 Q0—Q7 实施，不要只给第二份规划。复用现有 P07 Loop、模型 Adapter、候选版本、执行审批与 EDA 验证器；在实际模型请求构造处接入 P09，而不是增加一个未被调用的演示类。

`config/p09_defaults.yaml` 是建议草案：继承现有模型、推理模式、预算和安全边界，参数变化必须单独记录依据。模板和 skill 都是草案，不得直接宣称已验证。文献在 `LITERATURE_INDEX.md`；没有原始 PDF 不阻止实现纯函数和离线测试。

实施后按 T01—T32 报告证据类型和实际结果；真实模型、真实 EDA、历史回放与 Mock 分开。输出 `p09-implementation.md`、`p09-acceptance.md/json` 及规划规定的其他交付物。不得修改原始历史 FAIL，不得将人工审批移除后假称无人干预安全已验证。

# 原文存放目录

本次原文下载失败，目录内只有六个 `.url` 快捷入口，**当前不包含任何论文 PDF**。

联网后从包根目录运行：

```powershell
python tools/fetch_reference_assets.py --papers
```

预期 PDF 文件名、版本和来源见 `../metadata/references.json`。实际完成情况见脚本生成的 `../metadata/download_results.json`；失败时不会留下冒充 PDF 的 HTML 错误页。

中文笔记在 `../reading_notes/`，不是原文翻译或全文复刻。下载后请遵守论文及作者版本的许可声明。
